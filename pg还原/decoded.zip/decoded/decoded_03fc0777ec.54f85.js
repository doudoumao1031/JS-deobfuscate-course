!function () {
  'use strict';

  !function () {
    var C = function () {
      var d = !false;
      return function (s, j) {
        var P = d ? function () {
          if (j) {
            {
              var T = j["apply"](s, arguments);
              j = null;
              return T;
            }
          }
        } : function () {};
        d = false;
        return P;
      };
    }();
    var E;
    !function (d) {
      var s = C(this, function () {
        {
          return s["toString"]()["search"]("(((.+)+)+)+$")["toString"]()["constructor"](s)["search"]("(((.+)+)+)+$");
        }
      });
      s();
      d['l'] = "window", d['h'] = "self";
    }(E || (E = {}));
    var g = (0x0, eval)("this"),
      A = (g[E['h']], g[E['l']]);
    System["register"](["6d5cafebdb", "react", "react-dom", "99212c6ec4", "react-spring/renderprops", "react-spring"], function (j) {
      'use strict';

      var P, T, U, W, p, L, F, Q, M, I, k, G, y, b;
      return {
        'setters': [null, function (Z) {
          P = Z["default"], T = Z["useEffect"], U = Z["useRef"], W = Z["useState"];
        }, function (Z) {
          p = Z["default"];
        }, function (Z) {
          L = Z["ResRC"], F = Z["Utils"], Q = Z["Serialiser"], M = Z["Deserialiser"], I = Z["XHR"];
        }, function (Z) {
          {
            k = Z["Transition"], G = Z["animated"];
          }
        }, function (Z) {
          y = Z["useSpring"], b = Z["animated"];
        }],
        'execute': function () {
          j({
            'u': function (sl) {
              {
                HX["launchType"] = sl;
              }
            },
            'isCard': function () {
              return HX["launchType"] === xS["CARD"];
            }
          });
          var xF = A["__extends"],
            xa = A["__assign"],
            xQ = A["__decorate"],
            xM = A["__awaiter"],
            xI = A["__generator"],
            xk = A["__read"];
          function xf(sl, sl) {
            {
              var sl = {};
              for (var sl in sl) sl["hasOwnProperty"](sl) ? sl[sl[sl]] = sl[sl] : sl[sl] = sl[sl];
              return sl;
            }
          }
          var xG = {};
          xG["unloadBundleAsset"] = "releaseBundleAsset";
          xG["unload"] = "release";
          xG["unloadBundle"] = "releaseBundle";
          xG["deleteBundle"] = "removeBundle";
          xG["loadByBundleAsset"] = "loadBundleAsset";
          xG["loadRemoteBySingle"] = "loadRemoteSingle";
          xf(xG, L);
          var xy = {};
          xy["convertNodeSpace"] = "convertToNodeSpace";
          xy["convertNodeSpaceAR"] = "convertToNodeSpaceAR";
          xy["getAbsolutePos"] = "getAbsolutePosition";
          xy["getAbsoluteXPos"] = "getAbsoluteX";
          xy["getAbsoluteYPos"] = "getAbsoluteY";
          xy["setAbsolutePos"] = "setAbsolutePosition";
          xy["setAbsoluteXPos"] = "setAbsoluteX";
          xy["setAbsoluteYPos"] = "setAbsoluteY";
          xy["transferToNewParent"] = "transferToParent";
          xy["getSharedSimpleScheduler"] = "getSharedScheduler";
          xy["delay"] = "delayCallback";
          xy["timeout"] = "timeoutCallback";
          xy["selector"] = "selectorCallback";
          xy["sequence"] = "sequenceCallback";
          xy["spawn"] = "spawnCallback";
          xy["waterfall"] = "waterfCallback";
          xy["condition"] = "condCallback";
          xy["defer"] = "deferCallback";
          xy["tick"] = "tickCallback";
          xy["observe"] = "observeCallback";
          xy["formatLeadingZero"] = "formatTwoDigit";
          xy["formatDateTime"] = "formatDate";
          xy["isRightToLeft"] = "isRTL";
          xy["getLocationProtocol"] = "getProtocol";
          xy["getLocationOrigin"] = "getOrigin";
          var xb = xf(xy, F);
          function xZ(sl) {
            return "[object Object]" === Object["prototype"]["toString"]["call"](sl);
          }
          function xc(sl, sl, sl, sl) {
            var sl = sl["request"]("POST", sl, sl, function (sl) {
              return function (sl, sl) {
                sl = sl || function (sl) {
                  var sl = undefined;
                  if (xZ(sl) && sl["hasOwnProperty"]("err") && sl["hasOwnProperty"]('dt')) {
                    var sl = sl["err"];
                    sl && (sl = function (sl) {
                      return xZ(sl) || (sl = Object["create"](null)), sl["hasOwnProperty"]('cd') && +sl['cd'] || (sl['cd'] = 0x1965), new (0x0, shell["Error"])(shell["ServerError"]["Domain"], sl['cd'], sl["tid"]);
                    }(sl));
                  } else sl = new (0x0, shell["Error"])(shell["ServerError"]["Domain"], 0x1965);
                  return sl;
                }(sl), sl(sl, sl);
              };
            }(sl));
            return function () {
              return sl["abort"]();
            };
          }
          var xS,
            xX,
            xJ,
            xV,
            xN = function (sl) {
              function sl() {
                var sl = null !== sl && sl["apply"](this, arguments) || this;
                return sl["encodingParameters"] = function (sl) {
                  var sl = sl['v'];
                  sl["length"] = 0x0;
                  var sl = function (sl) {
                    {
                      if (Object["prototype"]["hasOwnProperty"]["call"](sl, sl)) {
                        var sl = sl[sl];
                        undefined !== sl && (sl instanceof Array ? sl["forEach"](function (sl) {
                          {
                            sl["push"](''["concat"](encodeURIComponent(sl), '=')["concat"](encodeURIComponent(JSON["stringify"](sl))));
                          }
                        }) : "object" == typeof sl ? sl["push"](''["concat"](encodeURIComponent(sl), '=')["concat"](encodeURIComponent(JSON["stringify"](sl)))) : sl["push"](''["concat"](encodeURIComponent(sl), '=')["concat"](encodeURIComponent(sl))));
                      }
                    }
                  };
                  for (var sl in sl) sl(sl);
                  var sl = sl["join"]('&');
                  return sl["length"] = 0x0, sl;
                }, sl;
              }
              return xF(sl, sl), sl['v'] = [], sl;
            }(Q),
            xR = function (sl) {
              function sl() {
                var sl = null !== sl && sl["apply"](this, arguments) || this;
                return sl["transformResponse"] = function (sl) {
                  return sl;
                }, sl;
              }
              return xF(sl, sl), sl;
            }(M),
            xB = function () {
              function sl() {
                {
                  this['m'] = new xN(), this['p'] = new xR("json"), this['_'] = new I(this['m'], this['p']);
                }
              }
              return sl["prototype"]["request"] = function (sl, sl, sl) {
                {
                  return xc(this['_'], sl, sl, sl);
                }
              }, sl;
            }();
          j("GameHistoryView", xS), function (sl) {
            sl[sl["GAME"] = 0x1] = "GAME", sl[sl["CARD"] = 0x2] = "CARD", sl[sl["SLOT"] = 0x3] = "SLOT", sl[sl["APIREPLAY"] = 0x5] = "APIREPLAY";
          }(xS || j("GameHistoryView", xS = {})), function (sl) {
            sl[sl["None"] = -0x1] = "None", sl[sl["HistoryList"] = 0x0] = "HistoryList", sl[sl["HistoryDetails"] = 0x1] = "HistoryDetails", sl[sl["HistoryFreeSpinDetails"] = 0x2] = "HistoryFreeSpinDetails", sl[sl["HistoryCalendar"] = 0x3] = "HistoryCalendar", sl[sl["HistoryDismiss"] = 0x4] = "HistoryDismiss";
          }(xX || (xX = {})), function (sl) {
            sl[sl["SELECTION"] = 0x0] = "SELECTION", sl[sl["CUSTOM"] = 0x1] = "CUSTOM";
          }(xJ || (xJ = {})), function (sl) {
            {
              sl[sl["LANDSCAPE"] = 0x5a] = "LANDSCAPE", sl[sl["PORTRAIT"] = 0x0] = "PORTRAIT";
            }
          }(xV || (xV = {}));
          var xY = {};
          xY["tension"] = 0xa3;
          xY["friction"] = 0x15;
          xY["velocity"] = 0xa;
          xY["clamp"] = true;
          var xl = {};
          xl['r'] = 0xff;
          xl['g'] = 0xff;
          xl['b'] = 0xff;
          xl['a'] = 0x1;
          var xw,
            xY = xY,
            xl = xl;
          !function (sl) {
            {
              sl[sl["NormalBet"] = 0x1] = "NormalBet", sl[sl["FreeBet"] = 0x2] = "FreeBet", sl[sl["BonusBet"] = 0x3] = "BonusBet", sl[sl["ReBet"] = 0x4] = "ReBet", sl[sl["JackpotBet"] = 0x8] = "JackpotBet", sl[sl["ContinueBet"] = 0x9] = "ContinueBet", sl[sl["CashWallet"] = 0xb] = "CashWallet", sl[sl["BonusWallet"] = 0xc] = "BonusWallet", sl[sl["FreeGameWallet"] = 0xd] = "FreeGameWallet", sl[sl["PointTournament"] = 0x15] = "PointTournament", sl[sl["CashTournament"] = 0x16] = "CashTournament", sl[sl["AutoBet"] = 0x1f] = "AutoBet", sl[sl["TurboBet"] = 0x20] = "TurboBet", sl[sl["BaccaratSupersix"] = 0x29] = "BaccaratSupersix", sl[sl["BaccaratCommission"] = 0x2a] = "BaccaratCommission", sl[sl["AmericanBlackjack"] = 0x2b] = "AmericanBlackjack", sl[sl["EuropeanBlackjack"] = 0x2c] = "EuropeanBlackjack", sl[sl["FreeHand"] = 0x33] = "FreeHand";
            }
          }(xw || (xw = {}));
          var xz = 0xa0,
            xv = (undefined !== g || undefined !== A || "undefined" != typeof global && global, {}),
            xO = {},
            xK = {};
          !function (sl) {
            var sl, sl;
            var sl = {};
            sl["value"] = true;
            var sl = {};
            sl["height"] = "272px";
            sl["width"] = "360px";
            sl["position"] = "absolute";
            sl["display"] = "flex";
            sl["flexDirection"] = "column";
            var sl = {};
            sl["height"] = "30px";
            sl["fontSize"] = "12px";
            sl["width"] = "120px";
            sl["textAlign"] = "center";
            sl["alignItems"] = "center";
            sl["justifyContent"] = "center";
            sl["display"] = "flex";
            sl["opacity"] = 0x1;
            var sl = {};
            sl["height"] = "35px";
            sl["fontSize"] = "20px";
            sl["textAlign"] = "center";
            sl["alignItems"] = "center";
            sl["display"] = "flex";
            sl["opacity"] = 0x1;
            sl["left"] = "17px";
            sl["position"] = "relative";
            var sl = {};
            sl["paddingTop"] = "27px";
            sl["display"] = "block";
            sl["height"] = "185px";
            sl["width"] = "360px";
            var sl = {};
            sl["display"] = "flex";
            sl["width"] = "360px";
            var sl = {};
            sl["height"] = "162px";
            sl["width"] = "32px";
            sl["display"] = "flex";
            sl["fontSize"] = "11px";
            sl["alignItems"] = "center";
            sl["textAlign"] = "center";
            sl["flexDirection"] = "column";
            sl["paddingRight"] = "40px";
            sl["paddingTop"] = "35px";
            var sl = {};
            sl["height"] = "162px";
            sl["width"] = "360px";
            sl["flexDirection"] = "column";
            sl["display"] = "flex";
            var sl = {};
            sl["top"] = "0px";
            sl["margin"] = "auto";
            sl["height"] = "32px";
            sl["width"] = "280px";
            sl["fontSize"] = "12px";
            sl["display"] = "flex";
            sl["alignItems"] = "center";
            sl["textAlign"] = "center";
            sl["paddingRight"] = "40px";
            sl["paddingLeft"] = "40px";
            sl["paddingTop"] = "5px";
            sl["paddingBottom"] = "10px";
            var xM = {};
            xM["top"] = "0px";
            xM["margin"] = "auto";
            xM["height"] = "32px";
            xM["width"] = "340px";
            xM["fontSize"] = "20px";
            xM["display"] = "flex";
            xM["alignItems"] = "center";
            xM["textAlign"] = "center";
            xM["paddingRight"] = "0px";
            xM["paddingLeft"] = "15px";
            xM["paddingTop"] = "5px";
            xM["paddingBottom"] = "10px";
            var sl = {};
            sl["width"] = "300px";
            sl["height"] = "35px";
            sl["textAlign"] = "center";
            sl["fontSize"] = "30px";
            sl["color"] = "#FFFFFF";
            sl["textShadow"] = "1px 1px 1px rgba(0,0,0,0.3)";
            sl["borderRadius"] = "30px";
            sl["backgroundImage"] = "linear-gradient(to bottom,rgba(251, 233, 111, 1) 30%,rgb(255, 225, 150) 50%,rgba(223, 155, 25, 1) 90%)";
            sl["position"] = "relative";
            sl["margin"] = "auto";
            var sl = {};
            sl["height"] = "35px";
            sl["width"] = "inherit";
            sl["fontSize"] = "12px";
            sl["display"] = "flex";
            sl["alignItems"] = "center";
            sl["justifyContent"] = "center";
            sl["color"] = "#FFFFFF";
            sl["borderColor"] = "#FFFFFF";
            sl["borderStyle"] = "none";
            sl["borderWidth"] = "1px";
            sl["backgroundColor"] = "none";
            var sl = {};
            sl["height"] = "35px";
            sl["width"] = "inherit";
            sl["fontSize"] = "20px";
            sl["display"] = "flex";
            sl["alignItems"] = "center";
            sl["justifyContent"] = "center";
            sl["color"] = "#FFFFFF";
            sl["borderColor"] = "#FFFFFF";
            sl["borderStyle"] = "none";
            sl["borderWidth"] = "1px";
            sl["borderRadius"] = "5px";
            sl["backgroundColor"] = "none";
            var sl = {};
            sl["height"] = "30px";
            var sl = {};
            sl["height"] = "85px";
            sl["width"] = "8px";
            sl["position"] = "relative";
            sl["left"] = "55px";
            sl["display"] = "flex";
            sl["flexWrap"] = "wrap";
            var sl = {};
            sl["height"] = "32px";
            sl["width"] = "44px";
            sl["fontSize"] = "12px";
            sl["alignItems"] = "center";
            sl["textAlign"] = "center";
            sl["display"] = "none";
            var jx = {};
            jx["height"] = "32px";
            jx["fontSize"] = "16px";
            jx["alignItems"] = "center";
            jx["textAlign"] = "center";
            jx["display"] = "flex";
            var sl = {};
            sl["paddingTop"] = "14px";
            sl["paddingBottom"] = "14px";
            sl["width"] = "4px";
            sl["height"] = "44px";
            var jh = {};
            jh["width"] = "200px";
            jh["height"] = "30px";
            jh["fontSize"] = "12px";
            jh["alignItems"] = "center";
            jh["textAlign"] = "center";
            jh["flexDirection"] = "row";
            jh["justifyContent"] = "space-between";
            jh["display"] = "inline-flex";
            var jE = {};
            jE["width"] = "340px";
            jE["height"] = "50px";
            jE["fontSize"] = "12px";
            jE["alignItems"] = "center";
            jE["textAlign"] = "center";
            jE["flexDirection"] = "row";
            jE["justifyContent"] = "space-between";
            jE["display"] = "inline-flex";
            jE["position"] = "relative";
            jE["left"] = "17px";
            var jg = {};
            jg["width"] = "62px";
            jg["background"] = '#';
            jg["fontSize"] = "12px";
            var jA = {};
            jA["width"] = "100px";
            jA["height"] = "35px";
            jA["borderRadius"] = "5px";
            jA["background"] = '#';
            jA["fontSize"] = "20px";
            var jh = {};
            jh["height"] = "5px";
            jh["width"] = "5px";
            jh["opacity"] = 0x1;
            jh["borderRadius"] = "50%";
            var jh = {};
            jh["position"] = "relative";
            jh["fontFamily"] = "Arial";
            var jj = {};
            jj["customPageContainer"] = sl;
            jj["calendarCustomDescriptionLabel"] = sl;
            jj["calendarCustomDescriptionLabelHorizontal"] = sl;
            jj["datePageContainer"] = sl;
            jj["dateRowContainer"] = sl;
            jj["descriptionContainer"] = sl;
            jj["datePickerContainer"] = sl;
            jj["comfirmButtonContainer"] = sl;
            jj["comfirmButtonContainerHorizontal"] = xM;
            jj["confirmButtonCardContainer"] = sl;
            jj["confirmButtonLabel"] = sl;
            jj["confirmButtonLabelHorizontal"] = sl;
            jj["calendarDateListItem"] = sl;
            jj["dotContainer"] = sl;
            jj["dateItem"] = sl;
            jj["dateItemHorizontal"] = jx;
            jj["connectImageContainer"] = sl;
            jj["dateContainer"] = jh;
            jj["dateContainerHorizontal"] = jE;
            jj["selectScrollContainer"] = jg;
            jj["selectScrollContainerHorizontal"] = jA;
            jj["dotIcon"] = jh;
            jj["selectContainer"] = jh;
            Object["defineProperty"](sl, "__esModule", sl), sl["styles"] = sl["LocalePrefix"] = sl["CaseType"] = sl["CalendarState"] = undefined, sl["styles"] = jj, function (jP) {
              jP[jP["SELECTION"] = 0x0] = "SELECTION", jP[jP["CUSTOM"] = 0x1] = "CUSTOM";
            }(sl["CalendarState"] || (sl["CalendarState"] = {})), (sl = sl["CaseType"] || (sl["CaseType"] = {}))[sl["SLOT_GAME"] = 0x0] = "SLOT_GAME", sl[sl["CARD_GAME"] = 0x1] = "CARD_GAME", (sl = sl["LocalePrefix"] || (sl["LocalePrefix"] = {}))["DEFAULT"] = "CustomCalendar", sl["TOURNAMENT"] = "TournamentCustomCalender";
          }(xK);
          var H0 = {};
          function H1(sl, sl) {
            var sl = new Date(sl);
            return sl ? (sl["setHours"](0x17), sl["setMinutes"](0x3b), sl["setSeconds"](0x3b), sl["setMilliseconds"](0x3e7)) : (sl["setHours"](0x0), sl["setMinutes"](0x0), sl["setSeconds"](0x0), sl["setMilliseconds"](0x0)), sl;
          }
          var H2 = {};
          H2["value"] = true;
          Object["defineProperty"](H0, "__esModule", H2), H0["convertTimeToBeginningOrEndOfTheDay"] = H0["getCustomDateObject"] = undefined, H0["getCustomDateObject"] = function (sl) {
            {
              var sl = new Date(sl["startDate"]),
                sl = new Date(sl["endDate"]);
              return {
                'startDate': H1(sl),
                'endDate': H1(sl, true)
              };
            }
          }, H0["convertTimeToBeginningOrEndOfTheDay"] = H1;
          var H3 = {},
            H4 = {};
          function H5(sl) {
            var sl,
              sl,
              sl,
              sl,
              sl,
              sl = [];
            for (sl = document["getElementsByClassName"]("select-items"), sl = document["getElementsByClassName"]("select-selected"), sl = sl["length"], sl = sl["length"], sl = 0x0; sl < sl; sl++) sl === sl[sl] ? sl["push"](sl) : sl[sl]["classList"]["remove"]("select-arrow-active");
            for (sl = 0x0; sl < sl; sl++) sl["indexOf"](sl) && sl[sl]["classList"]["add"]("select-hide");
          }
          var H6 = {};
          H6["value"] = true;
          Object["defineProperty"](H4, "__esModule", H6), H4["customSelectUtil"] = undefined;
          var H7 = function () {
            function sl() {}
            return sl["prototype"]["convertOptionToDiv"] = function (sl, sl, sl) {
              var sl, sl, sl, sl, sl, sl, sl, sl, xM;
              for (undefined === sl && (sl = true), sl = (sl = document["getElementsByClassName"](sl))["length"], sl = 0x0; sl < sl; sl++) {
                if ((sl = sl[sl]["getElementsByTagName"]("select")[0x0])["setAttribute"]("style", "display:none"), sl = sl["length"], sl) sl = document["createElement"]("DIV");else {
                  for (var sl = document["getElementsByClassName"]("select-selected"), sl = 0x0; sl < sl["length"]; sl++) sl[sl]["parentNode"]["className"] === sl && (sl = sl[sl]);
                  H5(this);
                }
                for (sl["setAttribute"]("class", "select-selected"), sl[sl]["appendChild"](sl), sl["innerHTML"] = sl["options"][sl["selectedIndex"]]["innerHTML"], (sl = document["createElement"]("DIV"))["setAttribute"]("class", "select-items select-hide"), sl["setAttribute"]('id', "style-scroller"), sl <= 0x4 ? sl["setAttribute"]("style", "height :" + 0x24 * sl + "px;") : (sl["setAttribute"]("style", "left:1px"), sl["setAttribute"]("style", "height :155px; overflow: auto; width: 65px;")), sl = 0x0; sl < sl; sl++) (xM = document["createElement"]("DIV"))["innerHTML"] = sl["options"][sl]["innerHTML"], xM["setAttribute"]("style", "width: 55px;height: 34px;opacity:0.9;"), xM["addEventListener"]("click", function () {
                  var sl, sl, sl, sl, jx, sl, jh;
                  for (sl = (sl = this["parentNode"]["parentNode"]["getElementsByTagName"]("select")[0x0])["length"], jx = this["parentNode"]["previousSibling"], sl = 0x0; sl < sl; sl++) if (sl["options"][sl]["innerHTML"] == this["innerHTML"]) {
                    {
                      for (sl["selectedIndex"] = sl, jx["innerHTML"] = this["innerHTML"], jh = (sl = this["parentNode"]["getElementsByClassName"]("same-as-selected"))["length"], sl = 0x0; sl < jh; sl++) sl[sl]["removeAttribute"]("class");
                      this["setAttribute"]("class", "same-as-selected"), sl(sl["options"][sl["selectedIndex"]]["innerHTML"]);
                      break;
                    }
                  }
                  jx["click"]();
                }), sl["appendChild"](xM);
                sl[sl]["appendChild"](sl), sl && sl["addEventListener"]("click", function (sl) {
                  sl["stopPropagation"](), H5(this), this["nextSibling"]["classList"]["toggle"]("select-hide"), this["classList"]["toggle"]("select-arrow-active");
                });
              }
              document["addEventListener"]("click", H5);
            }, sl["prototype"]["dynamicChangeAllOption"] = function (sl) {
              for (var sl = document["getElementsByClassName"]("select-selected"), sl = 0x0; sl < sl["length"]; sl++) switch (sl[sl]["parentNode"]["className"]) {
                case "select-container-year-start":
                  sl[sl]["innerHTML"] = sl["startYear"];
                  break;
                case "select-container-month-start":
                  sl[sl]["innerHTML"] = sl["startMonth"];
                  break;
                case "select-container-day-start":
                  sl[sl]["innerHTML"] = sl["startDay"];
                  break;
                case "select-container-year-end":
                  sl[sl]["innerHTML"] = sl["endYear"];
                  break;
                case "select-container-month-end":
                  sl[sl]["innerHTML"] = sl["endMonth"];
                  break;
                case "select-container-day-end":
                  sl[sl]["innerHTML"] = sl["endDay"];
              }
            }, sl["prototype"]["resetTargetOption"] = function (sl) {
              for (var sl = document["getElementsByClassName"](sl), sl = 0x0; sl < sl[0x0]["children"]["length"]; sl++) "select-items select-hide" === sl[0x0]["children"][sl]["className"] && sl[0x0]["children"][sl]["remove"]();
            }, sl["prototype"]["addOptionGlobalStyle"] = function (sl) {
              var sl = document["createElement"]("style");
              sl["innerHTML"] = "\n        .select-selected {\n            background-color:" + sl["backgroundColor"] + ";\n        }\n\n        .select-selected:after {\n        position: absolute;\n        top: 14px;\n        right: 10px;\n        width: 0;\n        height: 0;\n        border: 6px solid transparent;\n        height: 150px;\n        }\n\n        .select-selected.select-arrow-active:after {\n            border-color: " + sl["borderColor"] + " ;\n            top: 7px;\n        }\n\n        .select-items div,\n        .select-selected {\n            color: " + sl["textColor"] + ";\n            border: " + sl["selectedBorderSize"] + "px solid transparent;\n            border-color:  " + sl["textColor"] + ";\n            cursor: pointer;\n            user-select: none;\n            position: relative;\n            width: 55px;\n            height: 34px;\n            align-items: center;\n            display: grid;\n            font-size: " + sl["fontSize"] + "px;\n            left: 1px;\n        }\n\n        .select-items {\n            position: absolute;\n            background-color : " + sl["backgroundColor"] + ";\n            top: 100%;\n            left: 0;\n            right: 0;\n            z-index: 99;\n        }\n\n        .select-hide {\n            display: none;\n        }\n        \n        .select-items div:hover,                        \n        .same-as-selected {\n            background-color: rgba(0, 0, 0, 0.3);\n        }\n\n        #style-scroller::-webkit-scrollbar-track\n        {\n            -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);\n            border-radius: 5px;\n            background-color: " + sl["backgroundColor"] + ";\n        }\n\n        #style-scroller::-webkit-scrollbar\n        {\n         width: 5px;\n         background-color: " + sl["backgroundColor"] + ";\n        }\n\n        #style-scroller::-webkit-scrollbar-thumb\n        {\n         border-radius: 5px;\n         -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);\n         background-color: rgba(255, 255, 255, 0.6);\n        }\n        ", document["head"]["appendChild"](sl);
            }, sl;
          }();
          var H8 = {};
          H8["value"] = true;
          H4["customSelectUtil"] = new H7(), Object["defineProperty"](H3, "__esModule", H8), H3["CalendarPickDateView"] = undefined;
          var H9 = __importDefault(P),
            xK = xK,
            H4 = H4,
            HH = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                return sl['C'] = sl['C']["bind"](sl), sl['k'] = sl['k']["bind"](sl), H4["customSelectUtil"]["addOptionGlobalStyle"]({
                  'backgroundColor': sl["props"]["backgroundColor"],
                  'borderColor': sl["props"]["themeColor"],
                  'textColor': sl["props"]["themeColor"],
                  'selectedBorderSize': 0x1,
                  'fontSize': 0xc
                }), sl['S'] = sl['S']["bind"](sl), sl['D'] = sl['D']["bind"](sl), sl['H'] = sl['H']["bind"](sl), sl['j'] = sl['j']["bind"](sl), sl;
              }
              return __extends(sl, sl), sl["prototype"]["render"] = function () {
                {
                  var sl = this["props"]["onSelectedDate"];
                  return H9["default"]["createElement"]("div", {
                    'id': "date-container",
                    'style': this['k']()
                  }, H9["default"]["createElement"]("div", {
                    'className': "select-container-year-" + this["props"]["extraName"],
                    'style': xK["styles"]["selectContainer"]
                  }, H9["default"]["createElement"]("select", {
                    'value': sl["getFullYear"]()["toString"](),
                    'style': this['C'](),
                    'onChange': function () {}
                  }, this['D']())), H9["default"]["createElement"]("div", {
                    'className': "select-container-month-" + this["props"]["extraName"],
                    'style': xK["styles"]["selectContainer"]
                  }, H9["default"]["createElement"]("select", {
                    'value': '' + (sl["getMonth"]() + 0x1),
                    'style': this['C'](),
                    'onChange': function () {}
                  }, this['H']())), H9["default"]["createElement"]("div", {
                    'className': "select-container-day-" + this["props"]["extraName"],
                    'style': xK["styles"]["selectContainer"]
                  }, H9["default"]["createElement"]("select", {
                    'value': sl["getDate"]()["toString"](),
                    'style': this['C'](),
                    'onChange': function () {}
                  }, this['j']())));
                }
              }, sl["prototype"]["componentDidMount"] = function () {
                this['O'](true);
              }, sl["prototype"]["componentDidUpdate"] = function (sl) {
                this["props"]["onSelectedDate"] !== sl["onSelectedDate"] && (this['N'](), this['O'](false));
              }, sl["prototype"]['N'] = function () {
                H4["customSelectUtil"]["resetTargetOption"]("select-container-year-" + this["props"]["extraName"]), H4["customSelectUtil"]["resetTargetOption"]("select-container-month-" + this["props"]["extraName"]), H4["customSelectUtil"]["resetTargetOption"]("select-container-day-" + this["props"]["extraName"]);
              }, sl["prototype"]['O'] = function (sl) {
                H4["customSelectUtil"]["convertOptionToDiv"]("select-container-year-" + this["props"]["extraName"], this['S']["bind"](this, 0x0), sl), H4["customSelectUtil"]["convertOptionToDiv"]("select-container-month-" + this["props"]["extraName"], this['S']["bind"](this, 0x1), sl), H4["customSelectUtil"]["convertOptionToDiv"]("select-container-day-" + this["props"]["extraName"], this['S']["bind"](this, 0x2), sl);
              }, sl["prototype"]['C'] = function () {
                var sl = {};
                sl["color"] = "#FFFFFF";
                sl["borderColor"] = "#FFFFFF";
                sl["backgroundColor"] = "#30303b";
                var sl = __assign(__assign({}, xK["styles"]["selectScrollContainer"]), sl);
                return undefined !== this["props"]["themeColor"] && (sl["color"] = this["props"]["themeColor"], sl["borderColor"] = this["props"]["themeColor"]), undefined !== this["props"]["backgroundColor"] && (sl["backgroundColor"] = this["props"]["backgroundColor"]), shell["environment"]["isIOS"]() && (sl["color"] = "#30303b", sl["backgroundColor"] = "#FFFFFF"), sl;
              }, sl["prototype"]['k'] = function () {
                var sl = {};
                sl["color"] = "#FFFFFF";
                var sl = __assign(__assign({}, xK["styles"]["dateContainer"]), sl);
                return undefined !== this["props"]["backgroundColor"] && (sl["color"] = this["props"]["backgroundColor"]), this["props"]["isRTL"] && (sl["direction"] = "rtl"), sl;
              }, sl["prototype"]['D'] = function () {
                {
                  for (var sl = [], sl = this["props"]["onLastDate"]["getFullYear"](), sl = this["props"]["onBeginDate"]["getFullYear"](); sl <= sl; sl++) sl["push"](H9["default"]["createElement"]("option", {
                    'className': "date-item-year",
                    'key': "date-item-year" + sl,
                    'value': sl,
                    'style': xK["styles"]["dateItem"]
                  }, sl));
                  return sl;
                }
              }, sl["prototype"]['H'] = function () {
                var sl,
                  sl = [],
                  sl = this["props"]["onBeginDate"]["getFullYear"](),
                  sl = this["props"]["onLastDate"],
                  sl = sl["getMonth"]() + 0x1,
                  sl = sl["getFullYear"](),
                  sl = this["props"]["onSelectedDate"]["getFullYear"](),
                  sl = this["props"]["onBeginDate"];
                if (sl = sl === sl || sl === sl ? sl["getMonth"]() + 0x1 : sl === sl ? 0x1 : sl["getMonth"]() + 0x1, sl === sl) for (; sl <= sl; sl++) sl > 0x0 && sl["push"](H9["default"]["createElement"]("option", {
                  'className': "date-item-month",
                  'key': "date-item-month" + sl,
                  'value': sl,
                  'style': xK["styles"]["dateItem"]
                }, sl));else for (sl = sl; sl <= 0xc; sl++) sl["push"](H9["default"]["createElement"]("option", {
                  'className': "date-item-month",
                  'key': "date-item-month" + sl,
                  'value': sl,
                  'style': xK["styles"]["dateItem"]
                }, sl));
                return sl;
              }, sl["prototype"]['j'] = function () {
                var sl,
                  sl = [],
                  sl = this["props"]["onLastDate"],
                  sl = sl["getMonth"]() + 0x1,
                  sl = this["props"]["onSelectedDate"],
                  sl = sl["getMonth"]() + 0x1,
                  sl = new Date(sl["getFullYear"](), sl, 0x0),
                  sl = sl["getMonth"]() + 0x1 === sl,
                  sl = this["props"]["onBeginDate"],
                  sl = sl["getMonth"]() + 0x1,
                  xM = sl["getDate"]();
                sl = sl ? sl["getDate"]() : sl["getDate"]();
                var sl = 0x1;
                sl === sl && (sl = xM);
                for (; sl <= sl; sl++) sl["push"](H9["default"]["createElement"]("option", {
                  'className': "date-item",
                  'key': "date-item-day" + sl,
                  'value': sl,
                  'style': xK["styles"]["dateItem"]
                }, sl));
                return sl;
              }, sl["prototype"]['S'] = function (sl, sl) {
                var sl = Object["create"](null),
                  sl = this["props"]["onSelectedDate"];
                sl["year"] = sl["getFullYear"](), sl["month"] = sl["getMonth"]() + 0x1, sl["day"] = sl["getDate"]();
                var sl,
                  sl = this["props"]["onLastDate"];
                switch (sl) {
                  case 0x0:
                    sl["year"] = sl;
                    break;
                  case 0x1:
                    sl["month"] = sl;
                    var sl = new Date(sl["year"], sl["month"], 0x0);
                    sl["day"] > sl["getDate"]() && (sl["day"] = sl["getDate"]());
                    break;
                  case 0x2:
                    sl["day"] = sl;
                }
                sl = new Date(sl["year"], sl["month"] - 0x1, sl["day"]) > sl ? sl : new Date(sl["year"], sl["month"] - 0x1, sl["day"]), this["props"]["onHandleChange"](sl), this['N'](), this['O'](false);
              }, sl;
            }(H9["default"]["Component"]);
          var Hh = {};
          Hh["value"] = true;
          H3["CalendarPickDateView"] = HH, Object["defineProperty"](xO, "__esModule", Hh), xO["CalendarCustomView"] = undefined;
          var HE = __importDefault(P),
            xK = xK,
            H0 = H0,
            H3 = H3,
            H4 = H4,
            Hj = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this,
                  sl = new Date(),
                  sl = sl['T'](sl),
                  sl = sl['M'](sl),
                  sl = sl['P'](),
                  sl = sl['L'](),
                  sl = sl["getFullYear"](),
                  sl = sl["getMonth"]() + 0x1,
                  sl = sl["getDate"]();
                return sl["state"] = {
                  'themeColor': sl,
                  'onBeginDate': sl,
                  'onLastDate': sl,
                  'calendarRangeDate': sl,
                  'startYear': sl,
                  'startMonth': sl,
                  'startDay': sl,
                  'endYear': sl,
                  'endMonth': sl,
                  'endDay': sl,
                  'startDate': H0["convertTimeToBeginningOrEndOfTheDay"](sl),
                  'endDate': H0["convertTimeToBeginningOrEndOfTheDay"](sl, true),
                  'currentCalendarCustomType': 0x2
                }, sl['F'] = sl['F']["bind"](sl), sl['I'] = sl['I']["bind"](sl), sl['B'] = sl['B']["bind"](sl), sl['R'] = sl['R']["bind"](sl), sl['A'] = sl['A']["bind"](sl), sl['W'] = sl['W']["bind"](sl), sl['T'] = sl['T']["bind"](sl), sl['M'] = sl['M']["bind"](sl), sl['Y'] = sl['Y']["bind"](sl), sl['G'] = sl['G']["bind"](sl), sl['U'] = sl['U']["bind"](sl), sl['V'] = sl['V']["bind"](sl), sl['q'] = sl['q']["bind"](sl), sl['X'] = sl['X']["bind"](sl), sl['K'] = sl['K']["bind"](sl), sl;
              }
              return __extends(sl, sl), sl["prototype"]["render"] = function () {
                {
                  var sl = this["props"]["localePrefix"] || xK["LocalePrefix"]["DEFAULT"],
                    sl = __assign({}, xK["styles"]["dotContainer"]);
                  if (this["props"]["isRTL"]) {
                    var sl = sl["left"];
                    sl["right"] = sl, delete sl["left"];
                  }
                  var sl = {};
                  sl['id'] = "date-page-container";
                  sl["style"] = xK["styles"]["datePageContainer"];
                  var sl = {};
                  sl['id'] = "date-picker-container";
                  sl["style"] = xK["styles"]["datePickerContainer"];
                  var sl = {};
                  sl["style"] = xK["styles"]["dateRowContainer"];
                  var sl = {};
                  sl['id'] = "dot-container";
                  sl["style"] = sl;
                  var sl = {};
                  sl["style"] = xK["styles"]["dateRowContainer"];
                  return HE["default"]["createElement"]("div", {
                    'id': "custom-page-container",
                    'style': this['B']()
                  }, HE["default"]["createElement"]("div", sl, HE["default"]["createElement"]("div", sl, HE["default"]["createElement"]("div", sl, HE["default"]["createElement"]("div", {
                    'style': this['A']()
                  }, HE["default"]["createElement"]("div", null, shell["I18n"]['t'](sl + ".Start"))), HE["default"]["createElement"](H3["CalendarPickDateView"], {
                    'isRTL': this["props"]["isRTL"],
                    'themeColor': this['F'](),
                    'backgroundColor': this['I'](),
                    'onBeginDate': this["state"]["onBeginDate"],
                    'onLastDate': this["state"]["onLastDate"],
                    'onSelectedDate': new Date(this["state"]["startYear"], this["state"]["startMonth"] - 0x1, this["state"]["startDay"]),
                    'onHandleChange': this['U'],
                    'extraName': "start"
                  })), HE["default"]["createElement"]("div", sl, HE["default"]["createElement"]("div", {
                    'id': "dot-icon",
                    'style': this['W']()
                  }), HE["default"]["createElement"]("div", {
                    'id': "dot-icon",
                    'style': this['W']()
                  }), HE["default"]["createElement"]("div", {
                    'id': "dot-icon",
                    'style': this['W']()
                  }), HE["default"]["createElement"]("div", {
                    'id': "dot-icon",
                    'style': this['W']()
                  }), HE["default"]["createElement"]("div", {
                    'id': "dot-icon",
                    'style': this['W']()
                  })), HE["default"]["createElement"]("div", sl, HE["default"]["createElement"]("div", {
                    'style': this['A']()
                  }, HE["default"]["createElement"]("div", null, shell["I18n"]['t'](sl + ".End"))), HE["default"]["createElement"](H3["CalendarPickDateView"], {
                    'isRTL': this["props"]["isRTL"],
                    'themeColor': this['F'](),
                    'backgroundColor': this['I'](),
                    'onBeginDate': this["state"]["onBeginDate"],
                    'onLastDate': this["state"]["onLastDate"],
                    'onSelectedDate': new Date(this["state"]["endYear"], this["state"]["endMonth"] - 0x1, this["state"]["endDay"]),
                    'onHandleChange': this['V'],
                    'extraName': "end"
                  })))), HE["default"]["createElement"]("div", {
                    'id': "comfirm-button-container",
                    'style': this['J']()
                  }, HE["default"]["createElement"]("div", {
                    'id': "confirm-button-label",
                    'onClick': this['G'],
                    'style': this['R']()
                  }, HE["default"]["createElement"]("div", null, shell["I18n"]['t'](sl + ".Confirm")))));
                }
              }, sl["prototype"]['F'] = function () {
                return this['Z'](), xK["CaseType"]["CARD_GAME"], this["state"]["themeColor"];
              }, sl["prototype"]['J'] = function () {
                return this['Z']() === xK["CaseType"]["CARD_GAME"] ? xK["styles"]["confirmButtonCardContainer"] : xK["styles"]["comfirmButtonContainer"];
              }, sl["prototype"]['B'] = function () {
                var sl = __assign(__assign({}, xK["styles"]["customPageContainer"]), {
                  'backgroundColor': this['I']()
                });
                return this["props"]["isRTL"] && (sl["direction"] = "rtl"), sl;
              }, sl["prototype"]['I'] = function () {
                var sl;
                return sl = this['Z']() === xK["CaseType"]["CARD_GAME"] ? "#262121" : "#30303b", undefined !== this["props"]["backgroundColor"] && (sl = this["props"]["backgroundColor"]), sl;
              }, sl["prototype"]['R'] = function () {
                var sl = {};
                sl["color"] = this["props"]["themeColor"];
                sl["borderColor"] = this["props"]["themeColor"];
                sl["borderStyle"] = "solid";
                sl["backgroundColor"] = this["props"]["backgroundColor"];
                var sl = __assign(__assign({}, xK["styles"]["confirmButtonLabel"]), sl);
                return this['Z']() === xK["CaseType"]["CARD_GAME"] ? sl["color"] = "rgba(0,0,0)" : (undefined !== this["props"]["themeColor"] && (sl["color"] = this["props"]["themeColor"], sl["borderColor"] = this["props"]["themeColor"]), sl["borderStyle"] = "solid"), undefined !== this["props"]["confirmBackgroundColor"] && (sl["backgroundColor"] = this["props"]["confirmBackgroundColor"]), sl;
              }, sl["prototype"]['A'] = function () {
                {
                  var sl = {};
                  sl["opacity"] = 0x1;
                  sl["color"] = "#FFFFFF";
                  var sl = __assign(__assign({}, xK["styles"]["calendarCustomDescriptionLabel"]), sl);
                  return this['Z']() === xK["CaseType"]["CARD_GAME"] ? (undefined !== this["props"]["themeColor"] && (sl["color"] = this["props"]["themeColor"]), sl["opacity"] = 0.6) : undefined !== this["props"]["themeColor"] && (sl["color"] = this["props"]["themeColor"]), sl;
                }
              }, sl["prototype"]['W'] = function () {
                {
                  var sl = {};
                  sl["opacity"] = 0x1;
                  sl["backgroundColor"] = "#292934";
                  var sl = __assign(__assign({}, xK["styles"]["dotIcon"]), sl);
                  if (this['Z']() === xK["CaseType"]["CARD_GAME"]) {
                    if (undefined !== this["props"]["themeColor"]) {
                      var sl = this["props"]["themeColor"];
                      sl["backgroundColor"] = sl;
                    }
                    sl["opacity"] = 0.6;
                  } else undefined !== this["props"]["themeColor"] && (sl = this["props"]["themeColor"], sl["backgroundColor"] = sl);
                  return sl;
                }
              }, sl["prototype"]['U'] = function (sl) {
                {
                  var sl = this['X'](0x0, sl),
                    sl = new Date(sl["startYear"], sl["startMonth"] - 0x1, sl["startDay"]),
                    sl = new Date(sl["endYear"], sl["endMonth"] - 0x1, sl["endDay"]);
                  this['K'](0x0, sl, sl);
                }
              }, sl["prototype"]['V'] = function (sl) {
                var sl = this['X'](0x1, sl),
                  sl = new Date(sl["startYear"], sl["startMonth"] - 0x1, sl["startDay"]),
                  sl = new Date(sl["endYear"], sl["endMonth"] - 0x1, sl["endDay"]);
                this['K'](0x1, sl, sl);
              }, sl["prototype"]['X'] = function (sl, sl) {
                var sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  sl = Object["create"](null),
                  sl = this["state"]["onLastDate"],
                  xM = sl["getFullYear"](),
                  sl = sl["getMonth"]() + 0x1;
                switch (sl) {
                  case 0x0:
                    if (sl["startYear"] = sl["getFullYear"](), sl["startMonth"] = sl["getMonth"]() + 0x1, sl["startDay"] = sl["getDate"](), sl["endYear"] = this["state"]["endYear"], sl["endMonth"] = this["state"]["endMonth"], sl["endDay"] = this["state"]["endDay"], sl["startYear"] !== this["state"]["startYear"] && sl["startYear"] !== xM) {
                      sl["startYear"] = sl["getFullYear"]();
                      var sl = this["state"]["onBeginDate"]["getMonth"]() + 0x1;
                      sl = (sl = new Date(sl["startYear"], sl, 0x0))["getDate"](), sl = sl, sl["startDay"] = sl, sl["startMonth"] = sl;
                    } else sl["startMonth"] !== this["state"]["startMonth"] ? (sl["startMonth"] = sl["getMonth"]() + 0x1, sl = new Date(sl["startYear"], sl["startMonth"], 0x0), sl = sl["startMonth"] == sl ? sl["getDate"]() : sl["getDate"](), sl["startDay"] = sl) : sl["startDay"] = sl["getDate"]();
                    break;
                  case 0x1:
                    sl["startYear"] = this["state"]["startYear"], sl["startMonth"] = this["state"]["startMonth"], sl["startDay"] = this["state"]["startDay"], sl["endYear"] = sl["getFullYear"](), sl["endMonth"] = sl["getMonth"]() + 0x1, sl["endDay"] = sl["getDate"](), sl["endYear"] !== this["state"]["endYear"] && sl["endYear"] !== xM ? (sl["endYear"] = sl["getFullYear"](), sl = this["state"]["onBeginDate"]["getMonth"]() + 0x1, sl = (sl = new Date(sl["endYear"], sl, 0x0))["getDate"](), sl = sl, sl["endDay"] = sl, sl["endMonth"] = sl) : sl["endMonth"] !== this["state"]["endMonth"] ? (sl["endMonth"] = sl["getMonth"]() + 0x1, sl = new Date(sl["endYear"], sl["endMonth"], 0x0), sl = sl["endMonth"] === sl ? sl["getDate"]() : sl["getDate"](), sl["endDay"] = sl) : sl["endDay"] = sl["getDate"]();
                }
                return sl;
              }, sl["prototype"]['K'] = function (sl, sl, sl) {
                var sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  xM,
                  sl = sl,
                  sl = sl["getTime"]() - sl["getTime"]() + 0x1,
                  sl = Math["abs"](sl / 0x5265c00),
                  sl = this["state"]["onLastDate"],
                  sl = sl["getFullYear"](),
                  sl = sl["getMonth"]() + 0x1,
                  jx = this["state"]["onBeginDate"],
                  sl = jx["getDate"](),
                  jh = jx["getMonth"]() + 0x1,
                  jE = this["state"]["calendarRangeDate"];
                if (sl >= jE || sl["getTime"]() > sl["getTime"]()) {
                  {
                    var jg = sl["getTime"]();
                    switch (sl) {
                      case 0x0:
                        if (sl["getFullYear"]() !== this["state"]["startYear"] && sl["getFullYear"]() === sl) return void this['$'](sl, sl);
                        if (sl = new Date(jg), (sl = sl["getDate"]() + jE - 0x1) <= (sl = new Date(sl["getFullYear"](), sl["getMonth"]() + 0x1, 0x0)["getDate"]())) sl["setDate"](sl);else {
                          var jA = sl - sl,
                            jh = sl["getMonth"]() + 0x1 + 0x1;
                          sl["setDate"](jA), jh > 0xc ? sl["setMonth"](0x0) : sl["setMonth"](jh - 0x1);
                        }
                        if (sl["getDate"]() <= sl["getDate"]()) {
                          var jh = sl["getMonth"]() + 0x1 + 0x1,
                            jj = sl["getFullYear"]();
                          if (jh >= sl) {
                            if (jj <= sl) {
                              if (jh > 0xc) {
                                if (sl["getTime"]() < sl["getTime"]()) sl["setMonth"](0x0), sl["setFullYear"](jj + 0x1);else {
                                  var jP = sl["getFullYear"](),
                                    jT = sl["getMonth"]() + 0x1,
                                    jU = sl["getDate"]();
                                  sl["setFullYear"](jP), sl["setMonth"](jT - 0x1), sl["getDate"]() > jU && sl["setDate"](jU);
                                }
                              } else sl["setFullYear"](jj), sl["getTime"]() > sl["getTime"]() && (sl["setDate"](sl["getDate"]()), sl["setMonth"](sl - 0x1)), jh <= sl && sl["setMonth"](jh - 0x1);
                            } else {
                              {
                                var jW = sl["getMonth"]() + 0x1;
                                sl["setMonth"](jW - 0x1), sl["getDate"]() > sl["getDate"]() && sl["setDate"](sl["getDate"]());
                              }
                            }
                          } else sl["setFullYear"](jj), sl["setMonth"](jh - 0x1);
                        } else jW = sl["getMonth"]() + 0x1, sl["setFullYear"](sl["getFullYear"]()), sl["setMonth"](jW - 0x1);
                        sl["getMonth"]() !== sl["getMonth"]() && (jA = sl - sl) >= jE && sl["setDate"](jA), sl["getTime"]() > sl["getTime"]() && sl["setDate"](sl["getDate"]()), this['$'](sl, sl);
                        break;
                      case 0x1:
                        if (sl["getFullYear"]() !== this["state"]["endYear"] && sl["getFullYear"]() === sl) return void this['$'](sl, sl);
                        if (sl = new Date(jg), sl = sl["getFullYear"](), sl = sl["getMonth"]() + 0x1, sl = sl["getDate"]() - jE + 0x1, sl = new Date(sl["getFullYear"](), sl["getMonth"](), 0x0)["getDate"](), sl >= 0x0) sl["setDate"](sl);else {
                          var ju = sl + sl;
                          sl["setMonth"](sl - 0x1), sl["setDate"](ju), sl["setFullYear"](sl["getFullYear"]());
                        }
                        if (xM = this['Y'](jx, sl), sl["getDate"]() >= sl["getDate"]()) {
                          if ((jh = sl["getMonth"]() + 0x1 - 0x1) <= xM) {
                            if (jh >= sl) sl["setMonth"](jh - 0x1), jh < 0x0 ? (sl["setMonth"](0xb), sl["setFullYear"](sl - 0x1)) : (sl["setMonth"](jh - 0x1), sl["setFullYear"](sl), jh < xM && (sl["setMonth"](xM - 0x1), sl["getMonth"]() + 0x1 === sl["getMonth"]() + 0x1 && sl["setDate"](sl)));else {
                              if (jh > 0x0) sl["setMonth"](jh - 0x1);else {
                                {
                                  var jp = 0xc + jh;
                                  sl["setMonth"](jp - 0x1), sl["setFullYear"](sl - 0x1);
                                }
                              }
                              if (sl["getMonth"]() + 0x1 < xM) {
                                var jL = sl["getMonth"]() + 0x1;
                                sl["setDate"](sl), sl["setMonth"](jL - 0x1), sl["setFullYear"](sl);
                              }
                              sl = this['tt'](sl);
                            }
                          } else sl["getTime"]() >= jx["getTime"]() ? sl["setMonth"](jh - 0x1) : (sl["setMonth"](jh - 0x1), sl["setDate"](sl)), sl["setFullYear"](sl);
                        } else sl = sl["getMonth"]() + 0x1, sl["setMonth"](sl - 0x1), sl["setFullYear"](sl), sl = this['tt'](sl);
                        this['$'](sl, sl);
                    }
                  }
                } else {
                  var jm = this['tt'](sl);
                  this['$'](jm, sl);
                }
              }, sl["prototype"]['Z'] = function () {
                var sl = xK["CaseType"]["SLOT_GAME"];
                return undefined !== this["props"]["caseType"] && (sl = this["props"]["caseType"]), sl;
              }, sl["prototype"]['tt'] = function (sl) {
                var sl = sl,
                  sl = this["state"]["onBeginDate"];
                return sl["getTime"]() < sl["getTime"]() && (sl = sl), sl;
              }, sl["prototype"]['T'] = function (sl) {
                {
                  var sl,
                    sl = sl["getFullYear"](),
                    sl = sl["getDate"]();
                  if (undefined !== this["props"]["onBeginDate"]) sl = this["props"]["onBeginDate"];else {
                    var sl = sl["getMonth"]() + 0x1 - 0x3;
                    sl = sl > 0x0 ? new Date(sl, sl - 0x1, sl) : new Date(sl - 0x1, 0xc + sl - 0x1, sl);
                  }
                  return sl;
                }
              }, sl["prototype"]['M'] = function (sl) {
                return undefined !== this["props"]["onLastDate"] ? this["props"]["onLastDate"] : sl;
              }, sl["prototype"]['L'] = function () {
                return undefined !== this["props"]["themeColor"] ? this["props"]["themeColor"] : "#FFFFFF";
              }, sl["prototype"]['P'] = function () {
                return undefined !== this["props"]["calendarRangeDate"] ? this["props"]["calendarRangeDate"] : 0x7;
              }, sl["prototype"]['Y'] = function (sl, sl) {
                var sl = sl["getFullYear"](),
                  sl = sl["getFullYear"](),
                  sl = sl["getMonth"]();
                return sl === sl ? sl : 0x1;
              }, sl["prototype"]['$'] = function (sl, sl) {
                {
                  this["setState"]({
                    'startYear': sl["getFullYear"](),
                    'startMonth': sl["getMonth"]() + 0x1,
                    'startDay': sl["getDate"](),
                    'startDate': sl,
                    'endYear': sl["getFullYear"](),
                    'endMonth': sl["getMonth"]() + 0x1,
                    'endDay': sl["getDate"](),
                    'endDate': sl
                  }), H4["customSelectUtil"]["dynamicChangeAllOption"]({
                    'startYear': sl["getFullYear"](),
                    'startMonth': sl["getMonth"]() + 0x1,
                    'startDay': sl["getDate"](),
                    'endYear': sl["getFullYear"](),
                    'endMonth': sl["getMonth"]() + 0x1,
                    'endDay': sl["getDate"]()
                  });
                }
              }, sl["prototype"]['q'] = function (sl, sl) {
                var sl = {};
                sl["currentCalendarCustomType"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['G'] = function () {
                var sl = this["state"]["startDate"],
                  sl = H0["convertTimeToBeginningOrEndOfTheDay"](this["state"]["endDate"], true);
                this["props"]["onConfirmClicked"](sl, sl);
              }, sl;
            }(HE["default"]["Component"]);
          xO["CalendarCustomView"] = Hj;
          var HP = {},
            HT = {};
          var HU = {};
          HU["value"] = true;
          Object["defineProperty"](HT, "__esModule", HU), HT["CalendarPickDateViewH"] = undefined;
          var HW = __importDefault(P),
            xK = xK,
            H4 = H4,
            HL = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                return sl['C'] = sl['C']["bind"](sl), sl['k'] = sl['k']["bind"](sl), H4["customSelectUtil"]["addOptionGlobalStyle"]({
                  'backgroundColor': sl["props"]["backgroundColor"],
                  'borderColor': sl["props"]["themeColor"],
                  'textColor': sl["props"]["themeColor"],
                  'selectedBorderSize': 0x2,
                  'fontSize': 0x12
                }), sl['S'] = sl['S']["bind"](sl), sl['D'] = sl['D']["bind"](sl), sl['H'] = sl['H']["bind"](sl), sl['j'] = sl['j']["bind"](sl), sl;
              }
              return __extends(sl, sl), sl["prototype"]["render"] = function () {
                var sl = this["props"]["onSelectedDate"];
                return HW["default"]["createElement"]("div", {
                  'id': "date-container",
                  'style': this['k']()
                }, HW["default"]["createElement"]("div", {
                  'className': "select-container-year-" + this["props"]["extraName"],
                  'style': xK["styles"]["selectContainer"]
                }, HW["default"]["createElement"]("select", {
                  'value': sl["getFullYear"]()["toString"](),
                  'style': this['C'](),
                  'onChange': function () {}
                }, this['D']())), HW["default"]["createElement"]("div", {
                  'className': "select-container-month-" + this["props"]["extraName"],
                  'style': xK["styles"]["selectContainer"]
                }, HW["default"]["createElement"]("select", {
                  'value': '' + (sl["getMonth"]() + 0x1),
                  'style': this['C'](),
                  'onChange': function () {}
                }, this['H']())), HW["default"]["createElement"]("div", {
                  'className': "select-container-day-" + this["props"]["extraName"],
                  'style': xK["styles"]["selectContainer"]
                }, HW["default"]["createElement"]("select", {
                  'value': sl["getDate"]()["toString"](),
                  'style': this['C'](),
                  'onChange': function () {}
                }, this['j']())));
              }, sl["prototype"]["componentDidMount"] = function () {
                this['O'](true);
              }, sl["prototype"]["componentDidUpdate"] = function (sl) {
                this["props"]["onSelectedDate"] !== sl["onSelectedDate"] && (this['N'](), this['O'](false));
              }, sl["prototype"]['N'] = function () {
                H4["customSelectUtil"]["resetTargetOption"]("select-container-year-" + this["props"]["extraName"]), H4["customSelectUtil"]["resetTargetOption"]("select-container-month-" + this["props"]["extraName"]), H4["customSelectUtil"]["resetTargetOption"]("select-container-day-" + this["props"]["extraName"]);
              }, sl["prototype"]['O'] = function (sl) {
                H4["customSelectUtil"]["convertOptionToDiv"]("select-container-year-" + this["props"]["extraName"], this['S']["bind"](this, 0x0), sl), H4["customSelectUtil"]["convertOptionToDiv"]("select-container-month-" + this["props"]["extraName"], this['S']["bind"](this, 0x1), sl), H4["customSelectUtil"]["convertOptionToDiv"]("select-container-day-" + this["props"]["extraName"], this['S']["bind"](this, 0x2), sl);
              }, sl["prototype"]['C'] = function () {
                var sl = {};
                sl["color"] = "#FFFFFF";
                sl["borderColor"] = "#FFFFFF";
                sl["backgroundColor"] = "#30303b";
                var sl = __assign(__assign({}, xK["styles"]["selectScrollContainerHorizontal"]), sl);
                return undefined !== this["props"]["themeColor"] && (sl["color"] = this["props"]["themeColor"], sl["borderColor"] = this["props"]["themeColor"]), undefined !== this["props"]["backgroundColor"] && (sl["backgroundColor"] = this["props"]["backgroundColor"]), sl;
              }, sl["prototype"]['k'] = function () {
                var sl = {};
                sl["color"] = "#FFFFFF";
                var sl = __assign(__assign({}, xK["styles"]["dateContainerHorizontal"]), sl);
                if (undefined !== this["props"]["backgroundColor"] && (sl["color"] = this["props"]["backgroundColor"]), this["props"]["isRTL"]) {
                  {
                    sl["direction"] = "rtl";
                    var sl = sl["left"];
                    sl["right"] = sl, delete sl["left"];
                  }
                }
                return sl;
              }, sl["prototype"]['D'] = function () {
                for (var sl = [], sl = this["props"]["onLastDate"]["getFullYear"](), sl = this["props"]["onBeginDate"]["getFullYear"](); sl <= sl; sl++) sl["push"](HW["default"]["createElement"]("option", {
                  'className': "date-item-year",
                  'key': "date-item-year" + sl,
                  'style': xK["styles"]["dateItemHorizontal"],
                  'value': sl
                }, sl));
                return sl;
              }, sl["prototype"]['H'] = function () {
                var sl,
                  sl = [],
                  sl = this["props"]["onBeginDate"]["getFullYear"](),
                  sl = this["props"]["onLastDate"],
                  sl = sl["getMonth"]() + 0x1,
                  sl = sl["getFullYear"](),
                  sl = this["props"]["onSelectedDate"]["getFullYear"](),
                  sl = this["props"]["onBeginDate"];
                if (sl = sl === sl || sl === sl ? sl["getMonth"]() + 0x1 : sl === sl ? 0x1 : sl["getMonth"]() + 0x1, sl === sl) for (; sl <= sl; sl++) sl > 0x0 && sl["push"](HW["default"]["createElement"]("option", {
                  'className': "date-item-month",
                  'key': "date-item-month" + sl,
                  'style': xK["styles"]["dateItemHorizontal"],
                  'value': sl
                }, sl));else for (sl = sl; sl <= 0xc; sl++) sl["push"](HW["default"]["createElement"]("option", {
                  'className': "date-item-month",
                  'key': "date-item-month" + sl,
                  'style': xK["styles"]["dateItemHorizontal"],
                  'value': sl
                }, sl));
                return sl;
              }, sl["prototype"]['j'] = function () {
                var sl,
                  sl = [],
                  sl = this["props"]["onLastDate"],
                  sl = sl["getMonth"]() + 0x1,
                  sl = this["props"]["onSelectedDate"],
                  sl = sl["getMonth"]() + 0x1,
                  sl = new Date(sl["getFullYear"](), sl, 0x0),
                  sl = sl["getMonth"]() + 0x1 === sl,
                  sl = this["props"]["onBeginDate"],
                  sl = sl["getMonth"]() + 0x1,
                  xM = sl["getDate"]();
                sl = sl ? sl["getDate"]() : sl["getDate"]();
                var sl = 0x1;
                sl === sl && (sl = xM);
                for (; sl <= sl; sl++) sl["push"](HW["default"]["createElement"]("option", {
                  'className': "date-item",
                  'key': "date-item-day" + sl,
                  'style': xK["styles"]["dateItemHorizontal"],
                  'value': sl
                }, sl));
                return sl;
              }, sl["prototype"]['S'] = function (sl, sl) {
                var sl = Object["create"](null),
                  sl = this["props"]["onSelectedDate"];
                sl["year"] = sl["getFullYear"](), sl["month"] = sl["getMonth"]() + 0x1, sl["day"] = sl["getDate"]();
                var sl,
                  sl = this["props"]["onLastDate"];
                switch (sl) {
                  case 0x0:
                    sl["year"] = sl;
                    break;
                  case 0x1:
                    sl["month"] = sl;
                    var sl = new Date(sl["year"], sl["month"], 0x0);
                    sl["day"] > sl["getDate"]() && (sl["day"] = sl["getDate"]());
                    break;
                  case 0x2:
                    sl["day"] = sl;
                }
                sl = new Date(sl["year"], sl["month"] - 0x1, sl["day"]) > sl ? sl : new Date(sl["year"], sl["month"] - 0x1, sl["day"]), this["props"]["onHandleChange"](sl), this['N'](), this['O'](false);
              }, sl;
            }(HW["default"]["Component"]);
          var Hm = {};
          Hm["value"] = true;
          HT["CalendarPickDateViewH"] = HL, Object["defineProperty"](HP, "__esModule", Hm), HP["CalendarCustomViewH"] = undefined;
          var HF = __importDefault(P),
            xK = xK,
            H0 = H0,
            HT = HT,
            H4 = H4,
            Hk = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this,
                  sl = new Date(),
                  sl = sl['T'](sl),
                  sl = sl['M'](sl),
                  sl = sl['P'](),
                  sl = sl['L'](),
                  sl = sl["getFullYear"](),
                  sl = sl["getMonth"]() + 0x1,
                  sl = sl["getDate"]();
                return sl["state"] = {
                  'themeColor': sl,
                  'onBeginDate': sl,
                  'onLastDate': sl,
                  'calendarRangeDate': sl,
                  'startYear': sl,
                  'startMonth': sl,
                  'startDay': sl,
                  'endYear': sl,
                  'endMonth': sl,
                  'endDay': sl,
                  'startDate': H0["convertTimeToBeginningOrEndOfTheDay"](sl),
                  'endDate': H0["convertTimeToBeginningOrEndOfTheDay"](sl, true),
                  'currentCalendarCustomType': 0x2
                }, sl['F'] = sl['F']["bind"](sl), sl['I'] = sl['I']["bind"](sl), sl['B'] = sl['B']["bind"](sl), sl['R'] = sl['R']["bind"](sl), sl['A'] = sl['A']["bind"](sl), sl['W'] = sl['W']["bind"](sl), sl['T'] = sl['T']["bind"](sl), sl['M'] = sl['M']["bind"](sl), sl['Y'] = sl['Y']["bind"](sl), sl['G'] = sl['G']["bind"](sl), sl['U'] = sl['U']["bind"](sl), sl['V'] = sl['V']["bind"](sl), sl['q'] = sl['q']["bind"](sl), sl['X'] = sl['X']["bind"](sl), sl['K'] = sl['K']["bind"](sl), sl;
              }
              return __extends(sl, sl), sl["prototype"]["render"] = function () {
                var sl = this["props"]["localePrefix"] || xK["LocalePrefix"]["DEFAULT"];
                var sl = {};
                sl['id'] = "date-page-container";
                sl["style"] = xK["styles"]["datePageContainer"];
                var sl = {};
                sl['id'] = "date-picker-container";
                sl["style"] = xK["styles"]["datePickerContainer"];
                var sl = {};
                sl["style"] = xK["styles"]["dateRowContainer"];
                var sl = {};
                sl["style"] = xK["styles"]["dateRowContainer"];
                var sl = {};
                sl["style"] = xK["styles"]["dateRowContainer"];
                var sl = {};
                sl["style"] = xK["styles"]["dateRowContainer"];
                return HF["default"]["createElement"]("div", {
                  'id': "custom-page-container",
                  'style': this['B']()
                }, HF["default"]["createElement"]("div", sl, HF["default"]["createElement"]("div", sl, HF["default"]["createElement"]("div", sl, HF["default"]["createElement"]("div", {
                  'style': this['A']()
                }, HF["default"]["createElement"]("div", null, shell["I18n"]['t'](sl + ".Start")))), HF["default"]["createElement"]("div", sl, HF["default"]["createElement"](HT["CalendarPickDateViewH"], {
                  'isRTL': this["props"]["isRTL"],
                  'themeColor': this['F'](),
                  'backgroundColor': this['I'](),
                  'onBeginDate': this["state"]["onBeginDate"],
                  'onLastDate': this["state"]["onLastDate"],
                  'onSelectedDate': new Date(this["state"]["startYear"], this["state"]["startMonth"] - 0x1, this["state"]["startDay"]),
                  'onHandleChange': this['U'],
                  'extraName': "start"
                })), HF["default"]["createElement"]("div", sl, HF["default"]["createElement"]("div", {
                  'style': this['A']()
                }, HF["default"]["createElement"]("div", null, shell["I18n"]['t'](sl + ".End")))), HF["default"]["createElement"]("div", sl, HF["default"]["createElement"](HT["CalendarPickDateViewH"], {
                  'isRTL': this["props"]["isRTL"],
                  'themeColor': this['F'](),
                  'backgroundColor': this['I'](),
                  'onBeginDate': this["state"]["onBeginDate"],
                  'onLastDate': this["state"]["onLastDate"],
                  'onSelectedDate': new Date(this["state"]["endYear"], this["state"]["endMonth"] - 0x1, this["state"]["endDay"]),
                  'onHandleChange': this['V'],
                  'extraName': "end"
                })))), HF["default"]["createElement"]("div", {
                  'id': "comfirm-button-container",
                  'style': this['J']()
                }, HF["default"]["createElement"]("div", {
                  'id': "confirm-button-label",
                  'onClick': this['G'],
                  'style': this['R']()
                }, HF["default"]["createElement"]("div", null, shell["I18n"]['t'](sl + ".Confirm")))));
              }, sl["prototype"]['F'] = function () {
                return this['Z'](), xK["CaseType"]["CARD_GAME"], this["state"]["themeColor"];
              }, sl["prototype"]['J'] = function () {
                var sl;
                if (sl = this['Z']() === xK["CaseType"]["CARD_GAME"] ? __assign({}, xK["styles"]["confirmButtonCardContainer"]) : __assign({}, xK["styles"]["comfirmButtonContainerHorizontal"]), this["props"]["isRTL"]) {
                  var sl = sl["paddingLeft"];
                  sl["paddingRight"] = sl;
                  var sl = sl["paddingRight"];
                  sl["paddingLeft"] = sl;
                }
                return sl;
              }, sl["prototype"]['B'] = function () {
                var sl = __assign({}, xK["styles"]["customPageContainer"]);
                return this["props"]["isRTL"] && (sl["direction"] = "rtl"), sl;
              }, sl["prototype"]['I'] = function () {
                {
                  var sl;
                  return sl = this['Z']() === xK["CaseType"]["CARD_GAME"] ? "#262121" : "#30303b", undefined !== this["props"]["backgroundColor"] && (sl = this["props"]["backgroundColor"]), sl;
                }
              }, sl["prototype"]['R'] = function () {
                var sl = {};
                sl["color"] = this["props"]["themeColor"];
                sl["borderColor"] = this["props"]["themeColor"];
                sl["borderStyle"] = "solid";
                sl["backgroundColor"] = this["props"]["backgroundColor"];
                var sl = __assign(__assign({}, xK["styles"]["confirmButtonLabelHorizontal"]), sl);
                return this['Z']() === xK["CaseType"]["CARD_GAME"] ? sl["color"] = "rgba(0,0,0)" : (undefined !== this["props"]["themeColor"] && (sl["color"] = this["props"]["themeColor"], sl["borderColor"] = this["props"]["themeColor"]), sl["borderStyle"] = "solid"), undefined !== this["props"]["confirmBackgroundColor"] && (sl["backgroundColor"] = this["props"]["confirmBackgroundColor"]), sl;
              }, sl["prototype"]['A'] = function () {
                {
                  var sl = {};
                  sl["opacity"] = 0x1;
                  sl["color"] = "#FFFFFF";
                  var sl = __assign(__assign({}, xK["styles"]["calendarCustomDescriptionLabelHorizontal"]), sl);
                  return this['Z']() === xK["CaseType"]["CARD_GAME"] ? (undefined !== this["props"]["themeColor"] && (sl["color"] = this["props"]["themeColor"]), sl["opacity"] = 0.6) : undefined !== this["props"]["themeColor"] && (sl["color"] = this["props"]["themeColor"]), this["props"]["isRTL"] && (sl["right"] = sl["left"], delete sl["left"]), sl;
                }
              }, sl["prototype"]['W'] = function () {
                var sl = {};
                sl["opacity"] = 0x1;
                sl["backgroundColor"] = "#292934";
                var sl = __assign(__assign({}, xK["styles"]["dotIcon"]), sl);
                if (this['Z']() === xK["CaseType"]["CARD_GAME"]) {
                  if (undefined !== this["props"]["themeColor"]) {
                    var sl = this["props"]["themeColor"];
                    sl["backgroundColor"] = sl;
                  }
                  sl["opacity"] = 0.6;
                } else undefined !== this["props"]["themeColor"] && (sl = this["props"]["themeColor"], sl["backgroundColor"] = sl);
                return sl;
              }, sl["prototype"]['U'] = function (sl) {
                var sl = this['X'](0x0, sl),
                  sl = new Date(sl["startYear"], sl["startMonth"] - 0x1, sl["startDay"]),
                  sl = new Date(sl["endYear"], sl["endMonth"] - 0x1, sl["endDay"]);
                this['K'](0x0, sl, sl);
              }, sl["prototype"]['V'] = function (sl) {
                var sl = this['X'](0x1, sl),
                  sl = new Date(sl["startYear"], sl["startMonth"] - 0x1, sl["startDay"]),
                  sl = new Date(sl["endYear"], sl["endMonth"] - 0x1, sl["endDay"]);
                this['K'](0x1, sl, sl);
              }, sl["prototype"]['X'] = function (sl, sl) {
                var sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  sl = Object["create"](null),
                  sl = this["state"]["onLastDate"],
                  xM = sl["getFullYear"](),
                  sl = sl["getMonth"]() + 0x1;
                switch (sl) {
                  case 0x0:
                    if (sl["startYear"] = sl["getFullYear"](), sl["startMonth"] = sl["getMonth"]() + 0x1, sl["startDay"] = sl["getDate"](), sl["endYear"] = this["state"]["endYear"], sl["endMonth"] = this["state"]["endMonth"], sl["endDay"] = this["state"]["endDay"], sl["startYear"] !== this["state"]["startYear"] && sl["startYear"] !== xM) {
                      sl["startYear"] = sl["getFullYear"]();
                      var sl = this["state"]["onBeginDate"]["getMonth"]() + 0x1;
                      sl = (sl = new Date(sl["startYear"], sl, 0x0))["getDate"](), sl = sl, sl["startDay"] = sl, sl["startMonth"] = sl;
                    } else sl["startMonth"] !== this["state"]["startMonth"] ? (sl["startMonth"] = sl["getMonth"]() + 0x1, sl = new Date(sl["startYear"], sl["startMonth"], 0x0), sl = sl["startMonth"] == sl ? sl["getDate"]() : sl["getDate"](), sl["startDay"] = sl) : sl["startDay"] = sl["getDate"]();
                    break;
                  case 0x1:
                    sl["startYear"] = this["state"]["startYear"], sl["startMonth"] = this["state"]["startMonth"], sl["startDay"] = this["state"]["startDay"], sl["endYear"] = sl["getFullYear"](), sl["endMonth"] = sl["getMonth"]() + 0x1, sl["endDay"] = sl["getDate"](), sl["endYear"] !== this["state"]["endYear"] && sl["endYear"] !== xM ? (sl["endYear"] = sl["getFullYear"](), sl = this["state"]["onBeginDate"]["getMonth"]() + 0x1, sl = (sl = new Date(sl["endYear"], sl, 0x0))["getDate"](), sl = sl, sl["endDay"] = sl, sl["endMonth"] = sl) : sl["endMonth"] !== this["state"]["endMonth"] ? (sl["endMonth"] = sl["getMonth"]() + 0x1, sl = new Date(sl["endYear"], sl["endMonth"], 0x0), sl = sl["endMonth"] === sl ? sl["getDate"]() : sl["getDate"](), sl["endDay"] = sl) : sl["endDay"] = sl["getDate"]();
                }
                return sl;
              }, sl["prototype"]['K'] = function (sl, sl, sl) {
                var sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  sl,
                  xM,
                  sl = sl,
                  sl = sl["getTime"]() - sl["getTime"]() + 0x1,
                  sl = Math["abs"](sl / 0x5265c00),
                  sl = this["state"]["onLastDate"],
                  sl = sl["getFullYear"](),
                  sl = sl["getMonth"]() + 0x1,
                  jx = this["state"]["onBeginDate"],
                  sl = jx["getDate"](),
                  jh = jx["getMonth"]() + 0x1,
                  jE = this["state"]["calendarRangeDate"];
                if (sl >= jE || sl["getTime"]() > sl["getTime"]()) {
                  var jg = sl["getTime"]();
                  switch (sl) {
                    case 0x0:
                      if (sl["getFullYear"]() !== this["state"]["startYear"] && sl["getFullYear"]() === sl) return void this['$'](sl, sl);
                      if (sl = new Date(jg), (sl = sl["getDate"]() + jE - 0x1) <= (sl = new Date(sl["getFullYear"](), sl["getMonth"]() + 0x1, 0x0)["getDate"]())) sl["setDate"](sl);else {
                        var jA = sl - sl,
                          jh = sl["getMonth"]() + 0x1 + 0x1;
                        sl["setDate"](jA), jh > 0xc ? sl["setMonth"](0x0) : sl["setMonth"](jh - 0x1);
                      }
                      if (sl["getDate"]() <= sl["getDate"]()) {
                        var jh = sl["getMonth"]() + 0x1 + 0x1,
                          jj = sl["getFullYear"]();
                        if (jh >= sl) {
                          if (jj <= sl) {
                            if (jh > 0xc) {
                              if (sl["getTime"]() < sl["getTime"]()) sl["setMonth"](0x0), sl["setFullYear"](jj + 0x1);else {
                                var jP = sl["getFullYear"](),
                                  jT = sl["getMonth"]() + 0x1,
                                  jU = sl["getDate"]();
                                sl["setFullYear"](jP), sl["setMonth"](jT - 0x1), sl["getDate"]() > jU && sl["setDate"](jU);
                              }
                            } else sl["setFullYear"](jj), sl["getTime"]() > sl["getTime"]() && (sl["setDate"](sl["getDate"]()), sl["setMonth"](sl - 0x1)), jh <= sl && sl["setMonth"](jh - 0x1);
                          } else {
                            var jW = sl["getMonth"]() + 0x1;
                            sl["setMonth"](jW - 0x1), sl["getDate"]() > sl["getDate"]() && sl["setDate"](sl["getDate"]());
                          }
                        } else sl["setFullYear"](jj), sl["setMonth"](jh - 0x1);
                      } else jW = sl["getMonth"]() + 0x1, sl["setFullYear"](sl["getFullYear"]()), sl["setMonth"](jW - 0x1);
                      sl["getMonth"]() !== sl["getMonth"]() && (jA = sl - sl) >= jE && sl["setDate"](jA), sl["getTime"]() > sl["getTime"]() && sl["setDate"](sl["getDate"]()), this['$'](sl, sl);
                      break;
                    case 0x1:
                      if (sl["getFullYear"]() !== this["state"]["endYear"] && sl["getFullYear"]() === sl) return void this['$'](sl, sl);
                      if (sl = new Date(jg), sl = sl["getFullYear"](), sl = sl["getMonth"]() + 0x1, sl = sl["getDate"]() - jE + 0x1, sl = new Date(sl["getFullYear"](), sl["getMonth"](), 0x0)["getDate"](), sl >= 0x0) sl["setDate"](sl);else {
                        var ju = sl + sl;
                        sl["setMonth"](sl - 0x1), sl["setDate"](ju), sl["setFullYear"](sl["getFullYear"]());
                      }
                      if (xM = this['Y'](jx, sl), sl["getDate"]() >= sl["getDate"]()) {
                        if ((jh = sl["getMonth"]() + 0x1 - 0x1) <= xM) {
                          if (jh >= sl) sl["setMonth"](jh - 0x1), jh < 0x0 ? (sl["setMonth"](0xb), sl["setFullYear"](sl - 0x1)) : (sl["setMonth"](jh - 0x1), sl["setFullYear"](sl), jh < xM && (sl["setMonth"](xM - 0x1), sl["getMonth"]() + 0x1 === sl["getMonth"]() + 0x1 && sl["setDate"](sl)));else {
                            if (jh > 0x0) sl["setMonth"](jh - 0x1);else {
                              var jp = 0xc + jh;
                              sl["setMonth"](jp - 0x1), sl["setFullYear"](sl - 0x1);
                            }
                            if (sl["getMonth"]() + 0x1 < xM) {
                              var jL = sl["getMonth"]() + 0x1;
                              sl["setDate"](sl), sl["setMonth"](jL - 0x1), sl["setFullYear"](sl);
                            }
                            sl = this['tt'](sl);
                          }
                        } else sl["getTime"]() >= jx["getTime"]() ? sl["setMonth"](jh - 0x1) : (sl["setMonth"](jh - 0x1), sl["setDate"](sl)), sl["setFullYear"](sl);
                      } else sl = sl["getMonth"]() + 0x1, sl["setMonth"](sl - 0x1), sl["setFullYear"](sl), sl = this['tt'](sl);
                      this['$'](sl, sl);
                  }
                } else {
                  var jm = this['tt'](sl);
                  this['$'](jm, sl);
                }
              }, sl["prototype"]['Z'] = function () {
                var sl = xK["CaseType"]["SLOT_GAME"];
                return undefined !== this["props"]["caseType"] && (sl = this["props"]["caseType"]), sl;
              }, sl["prototype"]['tt'] = function (sl) {
                {
                  var sl = sl,
                    sl = this["state"]["onBeginDate"];
                  return sl["getTime"]() < sl["getTime"]() && (sl = sl), sl;
                }
              }, sl["prototype"]['T'] = function (sl) {
                var sl,
                  sl = sl["getFullYear"](),
                  sl = sl["getDate"]();
                if (undefined !== this["props"]["onBeginDate"]) sl = this["props"]["onBeginDate"];else {
                  var sl = sl["getMonth"]() + 0x1 - 0x3;
                  sl = sl > 0x0 ? new Date(sl, sl - 0x1, sl) : new Date(sl - 0x1, 0xc + sl - 0x1, sl);
                }
                return sl;
              }, sl["prototype"]['M'] = function (sl) {
                return undefined !== this["props"]["onLastDate"] ? this["props"]["onLastDate"] : sl;
              }, sl["prototype"]['L'] = function () {
                return undefined !== this["props"]["themeColor"] ? this["props"]["themeColor"] : "#FFFFFF";
              }, sl["prototype"]['P'] = function () {
                return undefined !== this["props"]["calendarRangeDate"] ? this["props"]["calendarRangeDate"] : 0x7;
              }, sl["prototype"]['Y'] = function (sl, sl) {
                {
                  var sl = sl["getFullYear"](),
                    sl = sl["getFullYear"](),
                    sl = sl["getMonth"]();
                  return sl === sl ? sl : 0x1;
                }
              }, sl["prototype"]['$'] = function (sl, sl) {
                this["setState"]({
                  'startYear': sl["getFullYear"](),
                  'startMonth': sl["getMonth"]() + 0x1,
                  'startDay': sl["getDate"](),
                  'startDate': sl,
                  'endYear': sl["getFullYear"](),
                  'endMonth': sl["getMonth"]() + 0x1,
                  'endDay': sl["getDate"](),
                  'endDate': sl
                }), H4["customSelectUtil"]["dynamicChangeAllOption"]({
                  'startYear': sl["getFullYear"](),
                  'startMonth': sl["getMonth"]() + 0x1,
                  'startDay': sl["getDate"](),
                  'endYear': sl["getFullYear"](),
                  'endMonth': sl["getMonth"]() + 0x1,
                  'endDay': sl["getDate"]()
                });
              }, sl["prototype"]['q'] = function (sl, sl) {
                var sl = {};
                sl["currentCalendarCustomType"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['G'] = function () {
                var sl = this["state"]["startDate"],
                  sl = H0["convertTimeToBeginningOrEndOfTheDay"](this["state"]["endDate"], true);
                this["props"]["onConfirmClicked"](sl, sl);
              }, sl;
            }(HF["default"]["Component"]);
          HP["CalendarCustomViewH"] = Hk, function (sl) {
            {
              var sl = {};
              sl["value"] = true;
              Object["defineProperty"](sl, "__esModule", sl);
              var sl = xO;
              var sl = {};
              sl["enumerable"] = true;
              sl["get"] = function () {
                return sl["CalendarCustomView"];
              };
              Object["defineProperty"](sl, "CalendarCustomView", sl);
              var sl = HP;
              var sl = {};
              sl["enumerable"] = true;
              sl["get"] = function () {
                return sl["CalendarCustomViewH"];
              };
              Object["defineProperty"](sl, "CalendarCustomViewH", sl);
              var sl = H3;
              var sl = {};
              sl["enumerable"] = true;
              sl["get"] = function () {
                return sl["CalendarPickDateView"];
              };
              Object["defineProperty"](sl, "CalendarPickDateView", sl);
              var sl = HT;
              var sl = {};
              sl["enumerable"] = true;
              sl["get"] = function () {
                return sl["CalendarPickDateViewH"];
              };
              Object["defineProperty"](sl, "CalendarPickDateViewH", sl);
              var sl = H0;
              var sl = {};
              sl["enumerable"] = true;
              sl["get"] = function () {
                return sl["getCustomDateObject"];
              };
              var xM = {};
              xM["enumerable"] = true;
              xM["get"] = function () {
                return sl["convertTimeToBeginningOrEndOfTheDay"];
              };
              Object["defineProperty"](sl, "getCustomDateObject", sl), Object["defineProperty"](sl, "convertTimeToBeginningOrEndOfTheDay", xM);
              var sl = xK;
              var sl = {};
              sl["enumerable"] = true;
              sl["get"] = function () {
                return sl["CaseType"];
              };
              Object["defineProperty"](sl, "CaseType", sl), Object["defineProperty"](sl, "LocalePrefix", {
                'enumerable': true,
                'get': function () {
                  {
                    return sl["LocalePrefix"];
                  }
                }
              });
            }
          }(xv);
          var Hf = {};
          Hf["theme_color"] = "rgba(245, 172, 88, 1)";
          Hf["loading_color"] = "rgba(245, 172, 88, 1)";
          Hf["loading_close_button_icon_color"] = "rgba(255, 255, 255, 0.6)";
          Hf["navigator_bar_bg"] = "#24242e";
          Hf["navigator_separator_bg"] = "#30303c";
          Hf["navigator_title_font_color"] = "#f5ac58";
          Hf["navigator_back_button_icon_color"] = "#f5ac58";
          Hf["navigator_close_button_icon_color"] = "rgba(255, 255, 255, 0.6)";
          Hf["list_bg"] = "#30303b";
          Hf["list_header_font_color"] = "rgba(255, 255, 255, 0.4)";
          Hf["list_header_bg"] = "#24242e";
          Hf["list_item_bg_odd"] = "#34343f";
          Hf["list_item_bg_even"] = "#30303c";
          Hf["list_item_bg_selected"] = "#44444e";
          Hf["list_item_bg_pressed"] = "#3c3c46";
          Hf["list_item_bg_hover"] = "#282834";
          Hf["list_item_font_color"] = "rgba(255, 255, 255, 0.6)";
          Hf["list_item_win_font_color"] = "#ffffff";
          Hf["list_item_loss_font_color"] = "rgba(255, 255, 255, 0.6)";
          Hf["list_item_selected_font_color"] = "#ffffff";
          Hf["list_item_arrow_color"] = "rgba(255, 255, 255, 0.4)";
          Hf["summary_bg"] = "#292934";
          Hf["summary_date_font_color"] = "#f5ac58";
          Hf["detail_bg"] = "#30303b";
          Hf["detail_header_bg"] = "#24242e";
          Hf["detail_header_key_font_color"] = "#f5ac58";
          Hf["detail_header_value_font_color"] = "rgba(255, 255, 255, 0.6)";
          Hf["main_title_font_color"] = "#f5ac58";
          Hf["highlight_font_color"] = "#ffffff";
          Hf["primary_font_color"] = "rgba(255, 255, 255, 0.6)";
          Hf["secondary_font_color"] = "rgba(255, 255, 255, 0.4)";
          Hf["error_message_font_color"] = "#64646c";
          Hf["error_retry_font_color"] = "#f5ac58";
          Hf["error_close_font_color"] = "rgba(255, 255, 255, 0.6)";
          Hf["error_retry_button"] = "#31313a";
          Hf["error_retry_button_outline"] = "#24242e";
          Hf["calendar_bg"] = "#30303b";
          Hf["calendar_color"] = "#f5ac58";
          Hf["calendar_title_color"] = "#f5ac58";
          Hf["free_spin_list_item_font_color"] = "#ffffff";
          Hf["free_spin_list_selected_font_color"] = "#f5ac58";
          Hf["free_spin_list_close_button_color"] = "rgba(255, 255, 255, 0.6)";
          Hf["free_spin_list_arrow_color"] = "#f5ac58";
          Hf["pages_button_arrow_color"] = "#f5ac58";
          Hf["pages_button_background_color"] = "rgba(0, 0, 0, 0.4)";
          Hf["alert_background_color"] = "rgba(47, 47, 59, 0.95)";
          Hf["alert_border_color"] = "rgba(0, 0, 0, 0.4)";
          Hf["summary_border"] = "#30303c";
          Hf["calendar_separator_bg"] = "#282834";
          Hf["list_header_font_color_horizontal"] = "rgba(251, 177, 66, 0.6)";
          Hf["list_header_bg_horizontal"] = "#24242e";
          Hf["navigator_bar_bg_horizontal"] = "#292934";
          Hf["navigator_separator_bg_horizontal"] = "rgba(216, 216, 216, 0.1)";
          Hf["navigator_panel_bg_horizontal"] = "#30303c";
          Hf["scroll_to_top_button_horizontal"] = "#30303c";
          Hf["scroll_to_top_button_border_horizontal"] = "#282831";
          var HG = {};
          HG["theme_color"] = "rgba(227, 194, 115, 1)";
          HG["loading_color"] = "rgba(227, 194, 115, 1)";
          HG["loading_close_button_icon_color"] = "#e3c273";
          HG["navigator_bar_bg"] = '';
          HG["navigator_separator_bg"] = "#251814";
          HG["navigator_title_font_color"] = "#e3c273";
          HG["navigator_back_button_icon_color"] = "#e3c273";
          HG["navigator_close_button_icon_color"] = "#e3c273";
          HG["list_bg"] = "#0e0c0c";
          HG["list_header_bg"] = "#0e0c0c";
          HG["list_header_font_color"] = "#97855F";
          HG["list_item_bg_odd"] = "#0e0c0c linear-gradient(0deg, #0f0d0d 80%, #191616)";
          HG["list_item_bg_even"] = "#0e0c0c linear-gradient(0deg, #0f0d0d 80%, #191616)";
          HG["list_item_bg_selected"] = "#0f0d0d";
          HG["list_item_bg_pressed"] = "#272525";
          HG["list_item_bg_hover"] = "#575656";
          HG["list_item_font_color"] = "#A7A6A6";
          HG["list_item_win_font_color"] = "#ffffff";
          HG["list_item_loss_font_color"] = "#A7A6A6";
          HG["list_item_selected_font_color"] = "#ffffff";
          HG["list_item_arrow_color"] = "rgba(255, 255, 255, 0.4)";
          HG["summary_bg"] = "#262121";
          HG["summary_border"] = "#30303c";
          HG["summary_date_font_color"] = "#e3c273";
          HG["detail_bg"] = "#0e0c0c";
          HG["detail_header_bg"] = "#262121";
          HG["detail_header_key_font_color"] = "rgba(167, 166, 166, 0.5)";
          HG["detail_header_value_font_color"] = "#A7A6A6";
          HG["main_title_font_color"] = "#e3c273";
          HG["highlight_font_color"] = "#ffffff";
          HG["primary_font_color"] = "#A7A6A6";
          HG["secondary_font_color"] = "#97855F";
          HG["error_message_font_color"] = "#978557";
          HG["error_retry_font_color"] = "rgb(67, 52, 40)";
          HG["error_close_font_color"] = "rgb(67, 52, 40)";
          HG["error_retry_button"] = '';
          HG["error_retry_button_outline"] = '';
          HG["calendar_bg"] = "#262121";
          HG["calendar_color"] = "#e3c273";
          HG["calendar_separator_bg"] = "#282834";
          HG["calendar_title_color"] = "#e3c273";
          HG["free_spin_list_item_font_color"] = "#ffffff";
          HG["free_spin_list_selected_font_color"] = "#e3c273";
          HG["free_spin_list_close_button_color"] = "#ffffff";
          HG["free_spin_list_arrow_color"] = "#e3c273";
          HG["pages_button_arrow_color"] = "#e3c273";
          HG["pages_button_background_color"] = "rgba(0, 0, 0, 0.4)";
          HG["alert_background_color"] = "rgba(38, 33, 33, 0.95)";
          HG["alert_border_color"] = "rgba(0, 0, 0, 0.4)";
          var Hf = Hf,
            HG = HG;
          function HZ(sl) {
            return "land" === shell["environment"]["getOrientationMode"]() ? sl + "_horizontal" : sl;
          }
          function Hc(sl, sl) {
            var sl;
            if (undefined === sl && (sl = false), "land" !== shell["environment"]["getOrientationMode"]() || sl["includes"]("theme_color")) sl = shell["uiAppearance"]['v'](sl);else {
              {
                var sl = HZ(sl);
                sl = shell["uiAppearance"]['v'](sl) || sl;
              }
            }
            return sl && (sl = sl ? sl : sl["toCSS"]("rgba")), sl;
          }
          var HS = function () {
              function sl() {
                this['et'] = Hc("history.theme_color") || Hc("game.theme_color"), this['it'] = Hc("history.loading_color", true) || Hc("history.theme_color", true), this['nt'] = Hc("history.loading_close_button_icon_color"), this['rt'] = Hc("history.navigator_bar_bg"), this['ot'] = Hc("history.navigator_separator_bg"), this['lt'] = Hc("history.navigator_title_font_color"), this['ct'] = Hc("history.navigator_back_button_icon_color"), this['ht'] = Hc("history.navigator_close_button_icon_color"), this['ut'] = Hc("history.list_bg"), this['ft'] = Hc("history.list_header_bg"), this['gt'] = Hc("history.list_header_font_color"), this['vt'] = Hc("history.list_item_bg_odd"), this['yt'] = Hc("history.list_item_bg_even"), this['xt'] = Hc("history.list_item_bg_hover"), this['_t'] = Hc("history.list_item_bg_pressed"), this['wt'] = Hc("history.list_item_bg_selected"), this['wt'] = Hc("history.list_item_bg_selected"), this['Ct'] = Hc("history.list_item_font_color"), this['kt'] = Hc("history.list_item_win_font_color"), this['St'] = Hc("history.list_item_loss_font_color"), this['zt'] = Hc("history.list_item_selected_font_color"), this['Dt'] = Hc("history.list_item_arrow_color"), this['Ht'] = Hc("history.summary_bg"), this['jt'] = Hc("history.summary_date_font_color"), this['Ot'] = Hc("history.detail_bg"), this['Nt'] = Hc("history.detail_header_bg"), this['Tt'] = Hc("history.detail_header_key_font_color"), this['Mt'] = Hc("history.detail_header_value_font_color"), this['Pt'] = Hc("history.main_title_font_color"), this['Lt'] = Hc("history.highlight_font_color"), this['Ft'] = Hc("history.primary_font_color"), this['It'] = Hc("history.secondary_font_color"), this['Bt'] = Hc("history.error_message_font_color"), this['Rt'] = Hc("history.error_retry_font_color"), this['At'] = Hc("history.error_close_font_color"), this['Et'] = Hc("history.error_retry_button"), this['Wt'] = Hc("history.error_retry_button_outline"), this['Yt'] = Hc("history.calendar_bg"), this['Gt'] = Hc("history.calendar_title_color"), this['Ut'] = Hc("history.free_spin_list_item_font_color"), this['Vt'] = Hc("history.free_spin_list_selected_font_color"), this['qt'] = Hc("history.free_spin_list_close_button_color"), this['Xt'] = Hc("history.free_spin_list_arrow_color"), this['Kt'] = Hc("history.pages_button_arrow_color"), this['Jt'] = Hc("history.pages_button_background_color"), this['Zt'] = Hc("history.alert_background_color", true), this['$t'] = Hc("history.alert_border_color"), "land" === shell["environment"]["getOrientationMode"]() && (this['Qt'] = Hc("history.navigator_panel_bg"), this['te'] = Hc("history.scroll_to_top_button"), this['ee'] = Hc("history.scroll_to_top_button_border"), this['ie'] = Hc("history.calendar_color")), "port" === shell["environment"]["getOrientationMode"]() && (this['ne'] = Hc("history.summary_border"), this['re'] = Hc("history.calendar_separator_bg"));
              }
              return sl["prototype"]["setDefaultStyle"] = function (sl) {
                this['oe'] = sl === xS["CARD"] ? HG : Hf;
              }, sl["prototype"]['ae'] = function (sl) {
                var sl = HZ(sl);
                return Object["prototype"]["hasOwnProperty"]["call"](this['oe'], sl) ? this['oe'][sl] : this['oe'][sl];
              }, Object["defineProperty"](sl["prototype"], "themeColor", {
                'get': function () {
                  return this['et'] || this['ae']("theme_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "loadingColor", {
                'get': function () {
                  return this['it'] || this["themeColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "loadingCloseButtonIconColor", {
                'get': function () {
                  return this['nt'] || this["navCloseButtonIconColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "navBarColor", {
                'get': function () {
                  return this['oe'] === Hf && this['rt'] || this['ae']("navigator_bar_bg");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "navBarSeparatorColor", {
                'get': function () {
                  return this['ot'] || this['ae']("navigator_separator_bg");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "navBarPanelColor", {
                'get': function () {
                  return this['Qt'] || this['ae']("navigator_panel_bg");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "navBarFontTitleColor", {
                'get': function () {
                  return this['lt'] || this["titleFontColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "navBackButtonIconColor", {
                'get': function () {
                  return this['ct'] || this["themeColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "navCloseButtonIconColor", {
                'get': function () {
                  return this['ht'] || this['ae']("navigator_close_button_icon_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listBackgroundColor", {
                'get': function () {
                  return this['ut'] || this['ae']("list_bg");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listHeaderColor", {
                'get': function () {
                  return this['ft'] || this['ae']("list_header_bg");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listHeaderFontColor", {
                'get': function () {
                  return this['gt'] || this['ae']("list_header_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemOddColor", {
                'get': function () {
                  return this['oe'] === HG ? this['ae']("list_item_bg_odd") : this['vt'] || this['ae']("list_item_bg_odd");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemEvenColor", {
                'get': function () {
                  return this['oe'] === HG ? this['ae']("list_item_bg_even") : this['yt'] || this['ae']("list_item_bg_even");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemHoverColor", {
                'get': function () {
                  return this['xt'] || this['ae']("list_item_bg_hover");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemSelectedColor", {
                'get': function () {
                  return this['wt'] || this['ae']("list_item_bg_selected");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemPressedColor", {
                'get': function () {
                  return this['_t'] || this['ae']("list_item_bg_pressed");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemFontColor", {
                'get': function () {
                  return this['Ct'] || this["primaryFontColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemWinFontColor", {
                'get': function () {
                  {
                    return this['kt'] || this["highlightFontColor"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemLossFontColor", {
                'get': function () {
                  return this['St'] || this["listItemFontColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemSelectedFontColor", {
                'get': function () {
                  return this['zt'] || this["highlightFontColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "listItemArrowColor", {
                'get': function () {
                  {
                    return this['Dt'] || this['ae']("list_item_arrow_color");
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "footerBarColor", {
                'get': function () {
                  return this['Ht'] || this['ae']("summary_bg");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "footerSeparatorColor", {
                'get': function () {
                  return this['ne'] || this['ae']("summary_border");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "footerDateFontColor", {
                'get': function () {
                  {
                    return this['jt'] || this["themeColor"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "detailBackgroundColor", {
                'get': function () {
                  return this['Ot'] || this['ae']("detail_bg");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "transactionDetailsHeaderColor", {
                'get': function () {
                  {
                    return this['Nt'] || this['ae']("detail_header_bg");
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "transactionDetailsHeaderKeyFontColor", {
                'get': function () {
                  return this['Tt'] || this['ae']("detail_header_key_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "transactionDetailsHeaderValueFontColor", {
                'get': function () {
                  {
                    return this['Mt'] || this['ae']("detail_header_value_font_color");
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "scrollToTopButtonColor", {
                'get': function () {
                  return this['te'] || this['ae']("scroll_to_top_button");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "scrollToTopButtonBorderColor", {
                'get': function () {
                  return this['ee'] || this['ae']("scroll_to_top_button_border");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "titleFontColor", {
                'get': function () {
                  return this['Pt'] || this['ae']("main_title_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "highlightFontColor", {
                'get': function () {
                  return this['Lt'] || this['ae']("highlight_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "primaryFontColor", {
                'get': function () {
                  return this['Ft'] || this['ae']("primary_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "secondaryFontColor", {
                'get': function () {
                  return this['It'] || this['ae']("secondary_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "errorMessageFontColor", {
                'get': function () {
                  return this['Bt'] || this['ae']("error_message_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "errorRetryFontColor", {
                'get': function () {
                  return this['Rt'] || this['ae']("error_retry_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "errorCloseFontColor", {
                'get': function () {
                  return this['At'] || this['ae']("error_close_font_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "errorRetryButtonColor", {
                'get': function () {
                  return this['oe'] === HG ? this['ae']("error_retry_button") : this['Et'] || this['ae']("error_retry_button");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "errorRetryButtonOutlineColor", {
                'get': function () {
                  {
                    return this['oe'] === HG ? this['ae']("error_retry_button_outline") : this['Wt'] || this['ae']("error_retry_button_outline");
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "calendarBackgroundColor", {
                'get': function () {
                  {
                    return this['Yt'] || this['ae']("calendar_bg");
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "calendarColor", {
                'get': function () {
                  {
                    return this['ie'] || this["themeColor"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "calendarSeparatorBackgroundColor", {
                'get': function () {
                  return this['re'] || this['ae']("calendar_separator_bg");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "calendarTitleColor", {
                'get': function () {
                  return this['Gt'] || this["titleFontColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "freeSpinListFontColor", {
                'get': function () {
                  {
                    return this['Ut'] || this["highlightFontColor"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "freeSpinListSelectedFontColor", {
                'get': function () {
                  return this['Vt'] || this["themeColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "freeSpinListCloseButtonColor", {
                'get': function () {
                  return this['qt'] || this["primaryFontColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "freeSpinListArrowColor", {
                'get': function () {
                  {
                    return this['Xt'] || this["themeColor"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "pagesButtonArrowColor", {
                'get': function () {
                  return this['Kt'] || this["themeColor"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "pagesButtonBackgroundColor", {
                'get': function () {
                  return this['Jt'] || this['ae']("pages_button_background_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "alertBackgroundColor", {
                'get': function () {
                  return this['Zt'] || this['ae']("alert_background_color");
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "alertBorderColor", {
                'get': function () {
                  return this['$t'] || this['ae']("alert_border_color");
                },
                'enumerable': false,
                'configurable': true
              }), sl;
            }(),
            HX = new (function () {
              {
                function sl() {
                  this['se'] = {}, this['le'] = {}, this["gameName"] = '', this["replayVersion"] = 0x0, this["resourcesLoaded"] = false, this["isPortrait"] = true, this["isMobile"] = true, this["isApiReplay"] = false, this["isPrototype"] = false, this["hasHeader"] = false, this["gsScale"] = 0x1;
                }
                return sl["prototype"]["initHelpers"] = function () {
                  {
                    this['ce'] = new HS();
                  }
                }, Object["defineProperty"](sl["prototype"], "appearanceHelper", {
                  'get': function () {
                    return this['ce'];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](sl["prototype"], "displayConfig", {
                  'get': function () {
                    {
                      return this['se'];
                    }
                  },
                  'set': function (sl) {
                    sl && (this['se'] = sl);
                  },
                  'enumerable': false,
                  'configurable': true
                }), sl["prototype"]["setGameUrl"] = function (sl, sl) {
                  this['le'][sl] = sl;
                }, sl["prototype"]["getGameUrl"] = function (sl) {
                  return this['le'][sl];
                }, sl;
              }
            }())();
          function HJ(sl, sl) {
            var sl,
              sl,
              sl = new Date();
            if (0x2 === sl) {
              var sl = new Date();
              sl["setDate"](sl["getDate"]() - 0x6), sl = xv["convertTimeToBeginningOrEndOfTheDay"](sl)["getTime"](), sl = xv["convertTimeToBeginningOrEndOfTheDay"](sl, true)["getTime"]();
            } else 0x3 === sl && sl ? (sl = sl["startDate"]["getTime"](), sl = sl["endDate"]["getTime"]()) : (sl = xv["convertTimeToBeginningOrEndOfTheDay"](sl)["getTime"](), sl = xv["convertTimeToBeginningOrEndOfTheDay"](sl, true)["getTime"]());
            var sl = {};
            sl["startDate"] = sl;
            sl["endDate"] = sl;
            return sl;
          }
          function HV(sl) {
            {
              return sl < 0xa && sl >= 0x0 ? '0' + sl["toString"]() : sl["toString"]();
            }
          }
          function HN(sl, sl) {
            var sl = new Date(sl),
              sl = sl["getFullYear"](),
              sl = HV(sl["getMonth"]() + 0x1) + '/' + HV(sl["getDate"]());
            return sl ? sl + '/' + sl : sl;
          }
          function HR(sl, sl) {
            undefined === sl && (sl = true);
            var sl = new Date(sl),
              sl = HV(sl["getHours"]()) + ':' + HV(sl["getMinutes"]());
            return sl && (sl = sl + ':' + HV(sl["getSeconds"]())), sl;
          }
          function HB(sl) {
            var sl = -0x1 * new Date(sl)["getTimezoneOffset"](),
              sl = Math["floor"](Math["abs"](sl) / 0x3c)["toString"](),
              sl = HV(Math["abs"](sl) % 0x3c);
            return "(GMT"["concat"](sl >= 0x0 ? '+' : '-')["concat"](sl, ':')["concat"](sl, ')');
          }
          function HY(sl, sl, sl, sl, sl) {
            var sl = {};
            sl["category"] = shell['ga']["CATEGORY_GAME"];
            sl["domain"] = sl;
            sl["code"] = sl;
            sl["error"] = sl;
            sl["retry"] = sl;
            sl["messages"] = sl;
            HX["context"]["emit"]("Error.Report", sl);
          }
          function Hl(sl) {
            {
              var sl = function () {
                var sl = HX["context"],
                  sl = {
                    'background': {
                      'backgroundColor': HX["appearanceHelper"]["alertBackgroundColor"],
                      'border': HX["appearanceHelper"]["alertBorderColor"] + " 1px solid"
                    },
                    'message': {
                      'fontColor': HX["appearanceHelper"]["primaryFontColor"]
                    }
                  };
                var sl = {};
                sl["toastStyle"] = "Notification";
                sl["message"] = sl["message"];
                sl["duration"] = sl["duration"];
                sl["toastPosition"] = "Bottom";
                sl["imageSrc"] = '';
                sl["layoutStyle"] = sl;
                sl["event"]["emit"]("Toast.Show", sl, function () {
                  sl["eventCallback"] && sl["eventCallback"]();
                });
              };
              sl["delay"] ? setTimeout(sl, 0x3e8 * sl["delay"]) : sl();
            }
          }
          function Hw() {
            var sl = false,
              sl = shell["environment"]["getOSVersion"](),
              sl = shell["environment"]["getBrowserType"]()["toLowerCase"]();
            return (shell["environment"]["isIOS"]() && sl["startsWith"]('12') || sl["startsWith"]('11')) && (sl = true), "firefox" !== sl && "edge" !== sl && "ucbrowser" !== sl && "lite baidu" !== sl && "baidubrowser" !== sl && "360browser" !== sl && "opera" !== sl || (sl = true), sl;
          }
          function Hq() {
            var sl = shell["environment"]["getSafeAreaPadding"] ? shell["environment"]["getSafeAreaPadding"]()["top"] : 0x0;
            return HX["hasHeader"] || (sl /= 0x2), sl;
          }
          function HD() {
            {
              return shell["environment"]["getSafeAreaPadding"] ? shell["environment"]["getSafeAreaPadding"]()["bottom"] : 0x0;
            }
          }
          function Ho() {
            return 0x3e + Hq();
          }
          function Hv() {
            {
              return 0x30 + HD();
            }
          }
          function HO() {
            return 0x54 + HD();
          }
          var HK = undefined,
            h0 = undefined,
            h1 = undefined,
            h2 = [],
            h3 = undefined,
            h4 = xb["getPlatform"](),
            h5 = undefined,
            h6 = "v2/BetSummary/Get",
            h7 = "v2/BetHistory/Get";
          function h8(sl) {
            sl["atk"] = h0, sl['pf'] = h4, sl['wk'] = h3, sl["btt"] = h1;
          }
          var h9,
            hC,
            hx,
            hH,
            hh,
            hE = shell["I18n"],
            hg = function (sl) {
              {
                function sl(sl) {
                  var sl = sl["call"](this, sl) || this;
                  return sl["isPortrait"] = sl["props"]["orientation"] ? "port" === sl["props"]["orientation"] : HX["isPortrait"], sl['he'] = sl['he']["bind"](sl), sl['ue'] = sl['ue']["bind"](sl), sl['de'] = P["createRef"](), sl['fe'] = P["createRef"](), sl;
                }
                return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                  if (this['fe']["current"] && this['de']["current"]) {
                    var sl = this["isPortrait"] ? 0x64 : 0xc8;
                    this['de']["current"]["offsetWidth"] > sl ? (this['fe']["current"]["style"]["width"] = ''["concat"](this['de']["current"]["offsetWidth"], 'px'), this['fe']["current"]["style"]["paddingLeft"] = '3%', this['fe']["current"]["style"]["paddingRight"] = '3%') : this['de']["current"]["style"]["width"] = ''["concat"](this['fe']["current"]["offsetWidth"], 'px'), this['de']["current"]["style"]["lineHeight"] = ''["concat"](this['fe']["current"]["offsetHeight"], 'px');
                  }
                }, sl["prototype"]["render"] = function () {
                  var sl,
                    sl,
                    sl = [];
                  var sl = {};
                  sl["color"] = HX["appearanceHelper"]["errorMessageFontColor"];
                  var sl = {};
                  sl['id'] = "error-label";
                  sl["key"] = "error-label";
                  sl["style"] = sl;
                  sl["push"](P["createElement"]("div", sl, this["props"]["error"]["message"])), this["props"]["error"]["shouldRetry"] && this["props"]["retryButtonCallback"] && sl["push"](this['ve'](HX["launchType"], this["isPortrait"], this['he'])), this["props"]["closeButtonCallback"] && sl["push"]((sl = this['ue'], sl = this["isPortrait"] ? '5%' : '2%', HX["launchType"] === xS["CARD"] ? P["createElement"]("div", {
                    'id': "error-retry-button-container-card-close",
                    'className': "error-retry-button-container-vertical",
                    'key': "error-retry-button-container-card-close",
                    'style': {
                      'marginTop': sl
                    },
                    'onClick': sl
                  }, P["createElement"]("div", {
                    'id': "error-close-button-label-card",
                    'key': "error-close-button-label",
                    'style': {
                      'color': HX["appearanceHelper"]["errorCloseFontColor"]
                    }
                  }, hE['t']("History.HistoryBarClose"))) : P["createElement"]("div", {
                    'id': "error-close-button-label",
                    'key': "error-close-button-label",
                    'onClick': sl,
                    'style': {
                      'color': HX["appearanceHelper"]["errorCloseFontColor"],
                      'marginTop': sl
                    }
                  }, hE['t']("History.HistoryBarClose"))));
                  var sl = {};
                  sl["backgroundColor"] = HX["appearanceHelper"]["listBackgroundColor"];
                  var sl = sl,
                    sl = this["isPortrait"] ? "error-container-vertical" : "error-container-horizontal";
                  var sl = {};
                  sl['id'] = "error-container";
                  sl["className"] = sl;
                  sl["style"] = sl;
                  return P["createElement"]("div", sl, sl);
                }, sl["prototype"]['ve'] = function (sl, sl, sl) {
                  {
                    var sl = {};
                    sl["backgroundColor"] = HX["appearanceHelper"]["errorRetryButtonColor"];
                    sl["outlineColor"] = HX["appearanceHelper"]["errorRetryButtonOutlineColor"];
                    var sl = sl,
                      sl = sl === xS["CARD"] ? "error-retry-button-container-card" : '',
                      sl = sl ? "error-retry-button-container-vertical" : "error-retry-button-container-horizontal";
                    var sl = {};
                    sl["color"] = HX["appearanceHelper"]["errorRetryFontColor"];
                    return P["createElement"]("div", {
                      'id': "error-retry-button-container",
                      'key': "error-retry-button-container",
                      'className': ''["concat"](sl, '\x20')["concat"](sl),
                      'ref': this['fe'],
                      'onClick': sl,
                      'style': sl
                    }, P["createElement"]("div", {
                      'id': "error-retry-button-label",
                      'ref': this['de'],
                      'style': sl
                    }, hE['t']("History.HistoryRetry")));
                  }
                }, sl["prototype"]['he'] = function () {
                  this["props"]["retryButtonCallback"] && this["props"]["retryButtonCallback"]();
                }, sl["prototype"]['ue'] = function () {
                  this["props"]["closeButtonCallback"] && this["props"]["closeButtonCallback"]();
                }, sl;
              }
            }(P["Component"]),
            hA = {},
            hd = {},
            hs = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                var sl = {};
                sl["active"] = false;
                sl["hover"] = false;
                return sl["state"] = sl, sl['me'] = sl['me']["bind"](sl), sl['pe'] = sl['pe']["bind"](sl), sl['be'] = sl['be']["bind"](sl), sl['ye'] = sl['ye']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]["render"] = function () {
                var sl = {};
                sl["backgroundColor"] = this["state"]["active"] ? HX["appearanceHelper"]["listItemPressedColor"] : HX["appearanceHelper"]["listBackgroundColor"];
                var sl = sl,
                  sl = HX["appearanceHelper"]["freeSpinListFontColor"],
                  sl = this["props"]["selected"] ? HX["appearanceHelper"]["freeSpinListSelectedFontColor"] : sl,
                  sl = {
                    'color': sl
                  },
                  sl = {
                    'color': sl
                  };
                var sl = {};
                sl["paddingRight"] = "15px";
                sl["paddingLeft"] = "0px";
                var sl = {};
                sl["marginRight"] = "auto";
                sl["marginLeft"] = 0x0;
                sl["paddingRight"] = "0px";
                sl["paddingLeft"] = "15px";
                return shell["isRTLLanguage"]() && (sl["direction"] = "rtl", sl = xa(xa({}, sl), sl), sl = xa(xa({}, sl), sl)), P["createElement"]("div", {
                  'className': "game-free-spin-list-item",
                  'onClick': this['me'],
                  'onMouseLeave': this['pe'],
                  'onMouseDown': this['be'],
                  'onMouseUp': this['ye'],
                  'style': sl
                }, P["createElement"]("div", {
                  'className': "game-free-spin-type",
                  'style': sl
                }, this["props"]["title"]), P["createElement"]("div", {
                  'className': "game-free-spin-amount",
                  'style': sl
                }, this["props"]["winLostAmount"]));
              }, sl["prototype"]['me'] = function () {
                this["props"]["onClickCallback"] && this["props"]["onClickCallback"]();
              }, sl["prototype"]['pe'] = function () {
                {
                  var sl = {};
                  sl["active"] = false;
                  this["setState"](sl);
                }
              }, sl["prototype"]['be'] = function () {
                {
                  var sl = {};
                  sl["active"] = true;
                  this["setState"](sl);
                }
              }, sl["prototype"]['ye'] = function () {
                var sl = {};
                sl["active"] = false;
                this["setState"](sl);
              }, sl;
            }(P["Component"]),
            hj = {},
            hP = {},
            hT = {
              get 'exports'() {
                return hP;
              },
              set 'exports'(sl) {
                hP = sl;
              }
            };
          ({
            get 'exports'() {
              {
                return hj;
              }
            },
            set 'exports'(sl) {
              hj = sl;
            }
          })["exports"] = function (sl, sl, sl) {
            return (() => {
              var sl = {
                  0xe5: sl => {
                    if (undefined === sl) {
                      var sl = Error("Cannot find module 'prop-types'");
                      throw sl["code"] = "MODULE_NOT_FOUND", sl;
                    }
                    sl["exports"] = sl;
                  },
                  0x129: sl => {
                    {
                      sl["exports"] = sl;
                    }
                  },
                  0x10c: sl => {
                    sl["exports"] = sl;
                  }
                },
                sl = {};
              function sl(sl) {
                var sl = sl[sl];
                if (undefined !== sl) return sl["exports"];
                var sl = {};
                sl["exports"] = {};
                var sl = sl[sl] = sl;
                return sl[sl](sl, sl["exports"], sl), sl["exports"];
              }
              sl['n'] = sl => {
                var sl = sl && sl["__esModule"] ? () => sl["default"] : () => sl;
                return sl['d'](sl, {
                  'a': sl
                }), sl;
              }, sl['d'] = (sl, sl) => {
                for (var sl in sl) sl['o'](sl, sl) && !sl['o'](sl, sl) && Object["defineProperty"](sl, sl, {
                  'enumerable': true,
                  'get': sl[sl]
                });
              }, sl['o'] = (sl, sl) => Object["prototype"]["hasOwnProperty"]["call"](sl, sl), sl['r'] = sl => {
                var sl = {};
                sl["value"] = "Module";
                var sl = {};
                sl["value"] = true;
                "undefined" != typeof Symbol && Symbol["toStringTag"] && Object["defineProperty"](sl, Symbol["toStringTag"], sl), Object["defineProperty"](sl, "__esModule", sl);
              };
              var sl = {};
              return (() => {
                var sl = {};
                sl["default"] = () => jh;
                sl['r'](sl), sl['d'](sl, sl);
                var sl = sl(0x129),
                  sl = sl['n'](sl),
                  sl = sl(0x10c),
                  sl = sl['n'](sl);
                var xM = {};
                xM["custom-scroll"] = "rcs-custom-scroll";
                xM["customScroll"] = "rcs-custom-scroll";
                xM["outer-container"] = "rcs-outer-container";
                xM["outerContainer"] = "rcs-outer-container";
                xM["positioning"] = "rcs-positioning";
                xM["custom-scrollbar"] = "rcs-custom-scrollbar";
                xM["customScrollbar"] = "rcs-custom-scrollbar";
                xM["inner-container"] = "rcs-inner-container";
                xM["innerContainer"] = "rcs-inner-container";
                xM["content-scrolled"] = "rcs-content-scrolled";
                xM["contentScrolled"] = "rcs-content-scrolled";
                xM["scroll-handle-dragged"] = "rcs-scroll-handle-dragged";
                xM["scrollHandleDragged"] = "rcs-scroll-handle-dragged";
                xM["custom-scrollbar-rtl"] = "rcs-custom-scrollbar-rtl";
                xM["customScrollbarRtl"] = "rcs-custom-scrollbar-rtl";
                xM["custom-scroll-handle"] = "rcs-custom-scroll-handle";
                xM["customScrollHandle"] = "rcs-custom-scroll-handle";
                xM["inner-handle"] = "rcs-inner-handle";
                xM["innerHandle"] = "rcs-inner-handle";
                const sl = xM;
                function sl(jj) {
                  return (sl = "function" == typeof Symbol && "symbol" == typeof Symbol["iterator"] ? function (jP) {
                    {
                      return typeof jP;
                    }
                  } : function (jP) {
                    return jP && "function" == typeof Symbol && jP["constructor"] === Symbol && jP !== Symbol["prototype"] ? "symbol" : typeof jP;
                  })(jj);
                }
                function sl(jj, jP) {
                  return (sl = Object["setPrototypeOf"] || function (jT, jU) {
                    return jT["__proto__"] = jU, jT;
                  })(jj, jP);
                }
                function sl(jj, jP) {
                  return !jP || "object" !== sl(jP) && "function" != typeof jP ? sl(jj) : jP;
                }
                function sl(jj) {
                  {
                    if (undefined === jj) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return jj;
                  }
                }
                function sl(jj) {
                  {
                    return (sl = Object["setPrototypeOf"] ? Object["getPrototypeOf"] : function (jP) {
                      return jP["__proto__"] || Object["getPrototypeOf"](jP);
                    })(jj);
                  }
                }
                function jx(jj, jP, jT) {
                  var jU = {};
                  jU["value"] = jT;
                  jU["enumerable"] = true;
                  jU["configurable"] = true;
                  jU["writable"] = true;
                  return jP in jj ? Object["defineProperty"](jj, jP, jU) : jj[jP] = jT, jj;
                }
                var sl = function (jj, jP, jT) {
                  return (jP = jP || 0x0 === jP ? jP : jj) > (jT = jT || 0x0 === jT ? jT : jj) ? jj : jj < jP ? jP : jj > jT ? jT : jj;
                };
                function jh(jj, jP) {
                  return jj["clientX"] > jP["left"] && jj["clientX"] < jP["right"] && jj["clientY"] > jP["top"] && jj["clientY"] < jP["top"] + jP["height"];
                }
                var jE = function (jj) {
                  !function (jp, jL) {
                    {
                      if ("function" != typeof jL && null !== jL) throw new TypeError("Super expression must either be null or a function");
                      jp["prototype"] = Object["create"](jL && jL["prototype"], {
                        'constructor': {
                          'value': jp,
                          'writable': true,
                          'configurable': true
                        }
                      }), jL && sl(jp, jL);
                    }
                  }(ju, jj);
                  var jP,
                    jT,
                    jU,
                    jW = (jT = ju, jU = function () {
                      if ("undefined" == typeof Reflect || !Reflect["construct"]) return false;
                      if (Reflect["construct"]["sham"]) return false;
                      if ("function" == typeof Proxy) return true;
                      try {
                        return Boolean["prototype"]["valueOf"]["call"](Reflect["construct"](Boolean, [], function () {})), true;
                      } catch (jp) {
                        return false;
                      }
                    }(), function () {
                      var jp,
                        jL = sl(jT);
                      if (jU) {
                        var jm = sl(this)["constructor"];
                        jp = Reflect["construct"](jL, arguments, jm);
                      } else jp = jL["apply"](this, arguments);
                      return sl(this, jp);
                    });
                  function ju(jp) {
                    {
                      var jL;
                      var jm = {};
                      jm["scrollPos"] = 0x0;
                      jm["onDrag"] = false;
                      return function (jF, ja) {
                        if (!(jF instanceof ja)) throw new TypeError("Cannot call a class as a function");
                      }(this, ju), jx(sl(jL = jW["call"](this, jp)), "innerContainerRef", (0x0, sl["createRef"])()), jx(sl(jL), "customScrollbarRef", (0x0, sl["createRef"])()), jx(sl(jL), "scrollHandleRef", (0x0, sl["createRef"])()), jx(sl(jL), "contentWrapperRef", (0x0, sl["createRef"])()), jx(sl(jL), "adjustFreezePosition", function (jF) {
                        if (jL["contentWrapperRef"]["current"]) {
                          var ja = jL["getScrolledElement"](),
                            jQ = jL["contentWrapperRef"]["current"];
                          jL["props"]["freezePosition"] && (jQ["scrollTop"] = jL["state"]["scrollPos"]), jF["freezePosition"] && (ja["scrollTop"] = jL["state"]["scrollPos"]);
                        }
                      }), jx(sl(jL), "toggleScrollIfNeeded", function () {
                        var jF = jL["contentHeight"] - jL["visibleHeight"] > 0x1;
                        jL["hasScroll"] !== jF && (jL["hasScroll"] = jF, jL["forceUpdate"]());
                      }), jx(sl(jL), "updateScrollPosition", function (jF) {
                        var ja = jL["getScrolledElement"](),
                          jQ = sl(jF, 0x0, jL["contentHeight"] - jL["visibleHeight"]);
                        ja["scrollTop"] = jQ, jL["setState"]({
                          'scrollPos': jQ
                        });
                      }), jx(sl(jL), "onClick", function (jF) {
                        if (jL["hasScroll"] && jL["isMouseEventOnCustomScrollbar"](jF) && !jL["isMouseEventOnScrollHandle"](jF)) {
                          var ja = jL["calculateNewScrollHandleTop"](jF),
                            jQ = jL["getScrollValueFromHandlePosition"](ja);
                          jL["updateScrollPosition"](jQ);
                        }
                      }), jx(sl(jL), "isMouseEventOnCustomScrollbar", function (jF) {
                        if (!jL["customScrollbarRef"]["current"]) return false;
                        var ja = sl()["findDOMNode"](sl(jL))["getBoundingClientRect"](),
                          jQ = jL["customScrollbarRef"]["current"]["getBoundingClientRect"](),
                          jM = jL["props"]["rtl"] ? {
                            'left': ja["left"],
                            'right': jQ["right"]
                          } : {
                            'left': jQ["left"],
                            'width': ja["right"]
                          };
                        var ja = {};
                        ja["left"] = ja["left"];
                        ja["right"] = ja["right"];
                        ja["top"] = ja["top"];
                        ja["height"] = ja["height"];
                        return jh(jF, Object["assign"]({}, ja, jM));
                      }), jx(sl(jL), "isMouseEventOnScrollHandle", function (jF) {
                        return !!jL["scrollHandleRef"]["current"] && function (ja, jQ) {
                          return jh(ja, jQ["getBoundingClientRect"]());
                        }(jF, sl()["findDOMNode"](jL["scrollHandleRef"]["current"]));
                      }), jx(sl(jL), "calculateNewScrollHandleTop", function (jF) {
                        var ja = sl()["findDOMNode"](sl(jL))["getBoundingClientRect"]()["top"] + A["pageYOffset"],
                          jQ = jF["pageY"] - ja,
                          jM = jL["getScrollHandleStyle"]()["top"];
                        return jQ > jM + jL["scrollHandleHeight"] ? jM + Math["min"](jL["scrollHandleHeight"], jL["visibleHeight"] - jL["scrollHandleHeight"]) : jM - Math["max"](jL["scrollHandleHeight"], 0x0);
                      }), jx(sl(jL), "getScrollValueFromHandlePosition", function (jF) {
                        return jF / jL["scrollRatio"];
                      }), jx(sl(jL), "getScrollHandleStyle", function () {
                        var jF = jL["state"]["scrollPos"] * jL["scrollRatio"];
                        return jL["scrollHandleHeight"] = jL["visibleHeight"] * jL["scrollRatio"], {
                          'height': jL["scrollHandleHeight"],
                          'top': jF
                        };
                      }), jx(sl(jL), "adjustCustomScrollPosToContentPos", function (jF) {
                        var ja = {};
                        ja["scrollPos"] = jF;
                        jL["setState"](ja);
                      }), jx(sl(jL), "onScroll", function (jF) {
                        jL["props"]["freezePosition"] || (jL["hideScrollThumb"](), jL["adjustCustomScrollPosToContentPos"](jF["currentTarget"]["scrollTop"]), jL["props"]["onScroll"] && jL["props"]["onScroll"](jF));
                      }), jx(sl(jL), "getScrolledElement", function () {
                        return jL["innerContainerRef"]["current"];
                      }), jx(sl(jL), "onMouseDown", function (jF) {
                        var ja = {};
                        ja["onDrag"] = true;
                        var jQ = {};
                        jQ["passive"] = false;
                        var jM = {};
                        jM["passive"] = false;
                        jL["hasScroll"] && jL["isMouseEventOnScrollHandle"](jF) && (jL["startDragHandlePos"] = jL["getScrollHandleStyle"]()["top"], jL["startDragMousePos"] = jF["pageY"], jL["setState"](ja), document["addEventListener"]("mousemove", jL["onHandleDrag"], jQ), document["addEventListener"]("mouseup", jL["onHandleDragEnd"], jM));
                      }), jx(sl(jL), "onTouchStart", function () {
                        var jF = {};
                        jF["onDrag"] = true;
                        jL["setState"](jF);
                      }), jx(sl(jL), "onHandleDrag", function (jF) {
                        jF["preventDefault"]();
                        var ja = jF["pageY"] - jL["startDragMousePos"],
                          jQ = sl(jL["startDragHandlePos"] + ja, 0x0, jL["visibleHeight"] - jL["scrollHandleHeight"]),
                          jM = jL["getScrollValueFromHandlePosition"](jQ);
                        jL["updateScrollPosition"](jM);
                      }), jx(sl(jL), "onHandleDragEnd", function (jF) {
                        var ja = {};
                        ja["onDrag"] = false;
                        jL["setState"](ja), jF["preventDefault"](), document["removeEventListener"]("mousemove", jL["onHandleDrag"]), document["removeEventListener"]("mouseup", jL["onHandleDragEnd"]);
                      }), jx(sl(jL), "blockOuterScroll", function (jF) {
                        if (!jL["props"]["allowOuterScroll"]) {
                          var ja = jF["currentTarget"],
                            jQ = jF["currentTarget"]["scrollHeight"] - jF["currentTarget"]["offsetHeight"],
                            jM = jF["deltaY"] % 0x3 ? jF["deltaY"] : 0xa * jF["deltaY"];
                          ja["scrollTop"] + jM <= 0x0 ? (ja["scrollTop"] = 0x0, jF["preventDefault"]()) : ja["scrollTop"] + jM >= jQ && (ja["scrollTop"] = jQ, jF["preventDefault"]()), jF["stopPropagation"]();
                        }
                      }), jx(sl(jL), "getInnerContainerClasses", function () {
                        return jL["state"]["scrollPos"] && jL["props"]["addScrolledClass"] ? ''["concat"](sl["innerContainer"], '\x20')["concat"](sl["contentScrolled"]) : sl["innerContainer"];
                      }), jx(sl(jL), "getScrollStyles", function () {
                        var jF = jL["scrollbarYWidth"] || 0x14,
                          ja = jL["props"]["rtl"] ? "marginLeft" : "marginRight",
                          jQ = {
                            'height': jL["props"]["heightRelativeToParent"] || jL["props"]["flex"] ? "100%" : ''
                          };
                        jQ[ja] = -0x1 * jF;
                        var jM = {};
                        jM["height"] = jL["props"]["heightRelativeToParent"] || jL["props"]["flex"] ? "100%" : '';
                        jM["overflowY"] = jL["props"]["freezePosition"] ? "hidden" : "visible";
                        var ja = jM;
                        return ja[ja] = jL["scrollbarYWidth"] ? 0x0 : jF, {
                          'innerContainer': jQ,
                          'contentWrapper': ja
                        };
                      }), jx(sl(jL), "getOuterContainerStyle", function () {
                        var jF = {};
                        jF["height"] = jL["props"]["heightRelativeToParent"] || jL["props"]["flex"] ? "100%" : '';
                        return jF;
                      }), jx(sl(jL), "getRootStyles", function () {
                        var jF = {};
                        return jL["props"]["heightRelativeToParent"] ? jF["height"] = jL["props"]["heightRelativeToParent"] : jL["props"]["flex"] && (jF["flex"] = jL["props"]["flex"]), jF;
                      }), jx(sl(jL), "enforceMinHandleHeight", function (jF) {
                        var ja = jL["props"]["minScrollHandleHeight"];
                        if (jF["height"] >= ja) return jF;
                        var jQ = (ja - jF["height"]) * (jL["state"]["scrollPos"] / (jL["contentHeight"] - jL["visibleHeight"]));
                        var jM = {};
                        jM["height"] = ja;
                        jM["top"] = jF["top"] - jQ;
                        return jM;
                      }), jL["scrollbarYWidth"] = 0x0, jL["state"] = jm, jL["hideScrollThumb"] = function () {
                        var jF;
                        function ja() {
                          {
                            clearTimeout(jF);
                          }
                        }
                        function jQ() {
                          {
                            ja(), jF = setTimeout(function () {
                              var jM = {};
                              jM["onDrag"] = false;
                              jL["setState"](jM);
                            }, 0x1f4);
                          }
                        }
                        return jQ["cancel"] = ja, jQ;
                      }(), jL;
                    }
                  }
                  return (jP = [{
                    'key': "componentDidMount",
                    'value': function () {
                      var jp = {};
                      jp["passive"] = false;
                      undefined !== this["props"]["scrollTo"] ? this["updateScrollPosition"](this["props"]["scrollTo"]) : this["forceUpdate"](), this["innerContainerRef"]["current"] && this["innerContainerRef"]["current"]["addEventListener"]("wheel", this["blockOuterScroll"], jp);
                    }
                  }, {
                    'key': "componentDidUpdate",
                    'value': function (jp, jL) {
                      var jm = this["contentHeight"],
                        jF = this["visibleHeight"],
                        ja = this["getScrolledElement"](),
                        jQ = jL["scrollPos"] >= jm - jF;
                      this["contentHeight"] = ja["scrollHeight"], this["scrollbarYWidth"] = ja["offsetWidth"] - ja["clientWidth"], this["visibleHeight"] = ja["clientHeight"], this["scrollRatio"] = this["contentHeight"] ? this["visibleHeight"] / this["contentHeight"] : 0x1, this["toggleScrollIfNeeded"]();
                      var jM = this["state"] === jL;
                      (this["props"]["freezePosition"] || jp["freezePosition"]) && this["adjustFreezePosition"](jp), undefined !== this["props"]["scrollTo"] && this["props"]["scrollTo"] !== jp["scrollTo"] ? this["updateScrollPosition"](this["props"]["scrollTo"]) : this["props"]["keepAtBottom"] && jM && jQ && this["updateScrollPosition"](this["contentHeight"] - this["visibleHeight"]);
                    }
                  }, {
                    'key': "componentWillUnmount",
                    'value': function () {
                      this["hideScrollThumb"]["cancel"](), document["removeEventListener"]("mousemove", this["onHandleDrag"]), document["removeEventListener"]("mouseup", this["onHandleDragEnd"]), this["innerContainerRef"]["current"] && this["innerContainerRef"]["current"]["removeEventListener"]("wheel", this["blockOuterScroll"]);
                    }
                  }, {
                    'key': "render",
                    'value': function () {
                      var jp = this["getScrollStyles"](),
                        jL = this["getRootStyles"](),
                        jm = this["enforceMinHandleHeight"](this["getScrollHandleStyle"]()),
                        jF = [this["props"]["className"] || '', sl["customScroll"], this["state"]["onDrag"] ? sl["scrollHandleDragged"] : '']["join"]('\x20');
                      var ja = {};
                      ja["className"] = jF;
                      ja["style"] = jL;
                      return sl()["createElement"]("div", ja, sl()["createElement"]("div", {
                        'className': sl["outerContainer"],
                        'style': this["getOuterContainerStyle"](),
                        'onMouseDown': this["onMouseDown"],
                        'onTouchStart': this["onTouchStart"],
                        'onClick': this["onClick"]
                      }, this["hasScroll"] ? sl()["createElement"]("div", {
                        'className': sl["positioning"]
                      }, sl()["createElement"]("div", {
                        'ref': this["customScrollbarRef"],
                        'className': ''["concat"](sl["customScrollbar"], '\x20')["concat"](this["props"]["rtl"] ? sl["customScrollbarRtl"] : ''),
                        'key': "scrollbar"
                      }, sl()["createElement"]("div", {
                        'ref': this["scrollHandleRef"],
                        'className': sl["customScrollHandle"],
                        'style': jm
                      }, sl()["createElement"]("div", {
                        'className': this["props"]["handleClass"]
                      })))) : null, sl()["createElement"]("div", {
                        'ref': this["innerContainerRef"],
                        'className': this["getInnerContainerClasses"](),
                        'style': jp["innerContainer"],
                        'onScroll': this["onScroll"]
                      }, sl()["createElement"]("div", {
                        'className': sl["contentWrapper"],
                        'ref': this["contentWrapperRef"],
                        'style': jp["contentWrapper"]
                      }, this["props"]["children"]))));
                    }
                  }]) && function (jp, jL) {
                    for (var jm = 0x0; jm < jL["length"]; jm++) {
                      var jF = jL[jm];
                      jF["enumerable"] = jF["enumerable"] || false, jF["configurable"] = true, "value" in jF && (jF["writable"] = true), Object["defineProperty"](jp, jF["key"], jF);
                    }
                  }(ju["prototype"], jP), ju;
                }(sl["Component"]);
                try {
                  {
                    var jg = sl(0xe5);
                    var jA = {};
                    jA["children"] = jg["any"];
                    jA["allowOuterScroll"] = jg["bool"];
                    jA["heightRelativeToParent"] = jg["string"];
                    jA["onScroll"] = jg["func"];
                    jA["addScrolledClass"] = jg["bool"];
                    jA["freezePosition"] = jg["bool"];
                    jA["handleClass"] = jg["string"];
                    jA["minScrollHandleHeight"] = jg["number"];
                    jA["flex"] = jg["string"];
                    jA["rtl"] = jg["bool"];
                    jA["scrollTo"] = jg["number"];
                    jA["keepAtBottom"] = jg["bool"];
                    jA["className"] = jg["string"];
                    jE["propTypes"] = jA;
                  }
                } catch (jj) {}
                var jh = {};
                jh["handleClass"] = sl["innerHandle"];
                jh["minScrollHandleHeight"] = 0x26;
                jE["defaultProps"] = jh;
                const jh = jE;
              })(), sl;
            })();
          }(function () {
            try {
              return hh || (hh = 0x1, hT["exports"] = function () {
                if (hH) return hx;
                hH = 0x1;
                var sl = hC ? h9 : (hC = 0x1, h9 = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
                function sl() {}
                function sl() {}
                return sl["resetWarningCache"] = sl, hx = function () {
                  function sl(sl, sl, sl, sl, sl, xM) {
                    if (xM !== sl) {
                      var sl = Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                      throw sl["name"] = "Invariant Violation", sl;
                    }
                  }
                  function sl() {
                    return sl;
                  }
                  sl["isRequired"] = sl;
                  var sl = {};
                  sl["array"] = sl;
                  sl["bigint"] = sl;
                  sl["bool"] = sl;
                  sl["func"] = sl;
                  sl["number"] = sl;
                  sl["object"] = sl;
                  sl["string"] = sl;
                  sl["symbol"] = sl;
                  sl["any"] = sl;
                  sl["arrayOf"] = sl;
                  sl["element"] = sl;
                  sl["elementType"] = sl;
                  sl["instanceOf"] = sl;
                  sl["node"] = sl;
                  sl["objectOf"] = sl;
                  sl["oneOf"] = sl;
                  sl["oneOfType"] = sl;
                  sl["shape"] = sl;
                  sl["exact"] = sl;
                  sl["checkPropTypes"] = sl;
                  sl["resetWarningCache"] = sl;
                  return sl["PropTypes"] = sl, sl;
                };
              }()()), hP;
            } catch (sl) {}
          }(), P, p);
          var hj = hj,
            hW = shell["I18n"],
            hu = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                var sl = {};
                sl["showing"] = false;
                sl["scrollToPosition"] = 0x0;
                return sl["state"] = sl, sl['xe'] = sl['xe']["bind"](sl), sl['_e'] = sl['_e']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                var sl = 0x32 * this["props"]["currentSelectedIndex"];
                var sl = {};
                sl["scrollToPosition"] = sl;
                this["setState"](sl), HX["isMobile"] && Hw() && 0x5a === shell["environment"]["getOrientation"]() && document["querySelectorAll"](".rcs-custom-scroll .rcs-inner-container")["forEach"](function (sl) {
                  sl["style"]["webkitOverflowScrolling"] = "auto";
                });
              }, sl["prototype"]["render"] = function () {
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["listBackgroundColor"];
                sl["color"] = HX["appearanceHelper"]["freeSpinListCloseButtonColor"];
                var sl = {};
                sl['id'] = "game-free-spin-view-container";
                sl["className"] = "history regular";
                sl["style"] = sl;
                return P["createElement"]("div", sl, P["createElement"](hj["default"], {
                  'heightRelativeToParent': "calc("["concat"](this["props"]["parentHeight"], "px - ")["concat"](0x32, "px)"),
                  'scrollTo': this["state"]["scrollToPosition"]
                }, P["createElement"]("div", null, this['we']())), P["createElement"]("div", {
                  'id': "close-list-button",
                  'onClick': this['xe']["bind"](this, -0x1)
                }, hW['t']("History.HistoryBarClose")));
              }, sl["prototype"]['we'] = function () {
                for (var sl = [], sl = this["props"]["totalCount"], sl = 0x0; sl < sl; sl++) {
                  var sl = this['Ce'](sl, sl);
                  sl["push"](P["createElement"](hs, {
                    'key': "game-free-spin-list-item-"["concat"](sl),
                    'selected': this["props"]["currentSelectedIndex"] === sl,
                    'title': sl,
                    'winLostAmount': this["props"]["winLostAmountArrary"][sl]["toString"](),
                    'onClickCallback': this['xe']["bind"](this, sl)
                  }));
                }
                return sl;
              }, sl["prototype"]['Ce'] = function (sl, sl) {
                var sl = this["props"]["getTitleText"](sl);
                return "object" == typeof sl ? sl["noCount"] ? sl["title"] : ''["concat"](sl["title"], ':\x20') + (sl + 0x1) + '/' + sl : 0x0 === sl ? hW['t']("History.HistoryNormalSpin") : ''["concat"](sl, ':\x20') + sl + '/' + (sl - 0x1);
              }, sl["prototype"]['xe'] = function (sl) {
                this["props"]["onPageClickCallback"](sl);
              }, sl["prototype"]['_e'] = function () {
                {
                  this["props"]["onClickCallback"](0x0);
                }
              }, sl;
            }(P["PureComponent"]);
          function hp(sl) {
            var sl = HX["isMobile"] ? "-mobile" : '',
              sl = sl["isPortrait"] ? "vertical" : "horizontal"["concat"](sl),
              sl = sl["isPortrait"] ? "exit-icon-stroke-vertical" : "horizontal exit-icon-stroke-horizontal"["concat"](sl),
              sl = {
                'backgroundColor': sl["customColor"] ? sl["customColor"] : HX["appearanceHelper"]["navCloseButtonIconColor"]
              };
            return P["createElement"]("div", {
              'className': "exit-icon "["concat"](sl),
              'onClick': sl["onClickCallback"]
            }, P["createElement"]("div", {
              'className': "exit-icon-stroke exit-icon-stroke-one "["concat"](sl),
              'style': sl
            }), P["createElement"]("div", {
              'className': "exit-icon-stroke exit-icon-stroke-two "["concat"](sl),
              'style': sl
            }));
          }
          function hL(sl) {
            return sl ? "game-list-nav-image-container-disabled" : HX["launchType"] === xS["CARD"] ? "game-list-nav-image-container-card" : "game-list-nav-image-container-slot";
          }
          function hm(sl) {
            var sl = HN(sl, true),
              sl = HR(sl, false),
              sl = HB(sl);
            return ''["concat"](sl, '\x20')["concat"](sl, '\x20')["concat"](sl);
          }
          function hF(sl) {
            {
              return HX["appearanceHelper"]["secondaryFontColor"], shell["isRTLLanguage"](), P["createElement"]("div", {
                'key': sl,
                'className': "game-list-nav-subtitle-label",
                'style': {
                  'color': HX["appearanceHelper"]["secondaryFontColor"]
                }
              }, sl);
            }
          }
          var ha = shell["I18n"],
            hQ = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                return sl['ke'] = HX["launchType"] === xS["CARD"], sl['Se'] = P["createRef"](), sl['ze'] = P["createRef"](), sl['De'] = sl['De']["bind"](sl), sl['He'] = sl['He']["bind"](sl), sl['je'] = sl['je']["bind"](sl), sl['Oe'] = sl['Oe']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                {
                  this['Ne']();
                }
              }, sl["prototype"]["componentDidUpdate"] = function () {
                this['Ne']();
              }, sl["prototype"]["render"] = function () {
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["navBarColor"];
                return shell["isRTLLanguage"]() && (sl["direction"] = "rtl"), P["createElement"]("div", {
                  'id': "game-list-nav",
                  'style': sl
                }, this['De']());
              }, sl["prototype"]['De'] = function () {
                var sl = [],
                  sl = this['ke'] ? 0x4 : 0x2;
                if (sl["push"](P["createElement"]("div", {
                  'id': "game-list-nav-bar",
                  'key': "game-list-nav-bar",
                  'className': "game-list-nav-bar-vertical",
                  'style': {
                    'height': "calc(100% - "["concat"](sl, "px)")
                  }
                }, this['Te']())), this["props"]["currentState"] === xX["HistoryDetails"] || this["props"]["currentState"] === xX["HistoryList"]) {
                  {
                    var sl = this['ke'] ? "game-list-nav-separator-vertical-card" : "game-list-nav-separator-vertical-slot",
                      sl = HX["appearanceHelper"]["navBarSeparatorColor"];
                    var sl = {};
                    sl["backgroundColor"] = sl;
                    var sl = {};
                    sl["key"] = "game-list-nav-separator";
                    sl["className"] = sl;
                    sl["style"] = sl;
                    sl["push"](P["createElement"]("div", sl));
                  }
                }
                return sl;
              }, sl["prototype"]['Te'] = function () {
                var sl = [],
                  sl = HX["appearanceHelper"]["titleFontColor"],
                  sl = HX["appearanceHelper"]["navBarFontTitleColor"],
                  sl = HX["isPortrait"] ? '' : "game-detail-nav-label-container-horizontal";
                switch (sl["push"](P["createElement"]("div", {
                  'className': "game-list-nav-image-container "["concat"](hL(this["props"]["showLeftDisabled"])),
                  'key': "game-list-nav-image-container-left",
                  'onClick': this['je']
                }, this['Me']())), this["props"]["currentState"]) {
                  case xX["HistoryDetails"]:
                  case xX["HistoryFreeSpinDetails"]:
                    var sl = {};
                    sl["className"] = "game-list-nav-row-container ";
                    sl["onClick"] = this["props"]["titleClickCallback"];
                    sl["push"](P["createElement"]("div", {
                      'id': "game-list-nav-label-container",
                      'className': "game-list-nav-label-container-vertical "["concat"](sl),
                      'key': "game-list-nav-label-container-details"
                    }, P["createElement"]("div", sl, this['Pe'](this["props"]["showTitle"](), sl), this['Le']()), this['Fe']()));
                    break;
                  case xX["HistoryList"]:
                    var sl = {};
                    sl['id'] = "game-list-nav-label-container";
                    sl["className"] = "game-list-nav-label-container-vertical";
                    sl["key"] = "game-list-nav-label-container-list";
                    var sl = {};
                    sl["color"] = sl;
                    var sl = {};
                    sl["className"] = "game-list-nav-period-label";
                    sl["style"] = sl;
                    sl["push"](P["createElement"]("div", sl, P["createElement"]("div", sl, ha['t']("History.HistoryMainTitle")), hF(this['He']())));
                    break;
                  case xX["HistoryCalendar"]:
                    var sl = {};
                    sl["justifyContent"] = "center";
                    sl["color"] = HX["appearanceHelper"]["secondaryFontColor"];
                    var sl = {};
                    sl['id'] = "game-list-nav-label-container";
                    sl["className"] = "game-list-nav-label-container-vertical";
                    sl["key"] = "game-list-nav-label-container-calendar";
                    sl["style"] = sl;
                    var xM = {};
                    xM["color"] = HX["appearanceHelper"]["calendarTitleColor"];
                    xM["justifyContent"] = "center";
                    var sl = {};
                    sl["className"] = "game-list-nav-period-label";
                    sl["style"] = xM;
                    sl["push"](P["createElement"]("div", sl, P["createElement"]("div", sl, this['He']())));
                }
                return sl["push"](P["createElement"]("div", {
                  'className': "game-list-nav-image-container "["concat"](hL(this["props"]["showRightDisabled"])),
                  'key': "game-list-nav-image-container-right",
                  'onClick': this['Oe']
                }, this["props"]["customRightItem"] || this['Ie']())), sl;
              }, sl["prototype"]['Fe'] = function () {
                {
                  var sl = this["props"],
                    sl = sl["betTime"],
                    sl = sl["transactionStartTime"],
                    sl = [];
                  if (sl) {
                    {
                      var sl = shell["I18n"]['t']("History.HistoryCalenderStart") + ':\x20' + hm(sl);
                      sl["push"](hF(sl));
                    }
                  }
                  if (sl) {
                    var sl = sl ? shell["I18n"]['t']("History.HistoryCalenderEnd") + ':\x20' : '';
                    sl += hm(sl), sl["push"](hF(sl));
                  }
                  return sl;
                }
              }, sl["prototype"]['je'] = function () {
                var sl = this["props"]["leftButtonClickedCallback"];
                sl && sl();
              }, sl["prototype"]['Oe'] = function () {
                {
                  var sl = this["props"]["currentState"],
                    sl = this["props"]["rightButtonClickedCallback"];
                  switch (sl) {
                    case xX["HistoryDetails"]:
                      HX["isPortrait"] || sl && sl();
                      break;
                    case xX["HistoryCalendar"]:
                    case xX["HistoryFreeSpinDetails"]:
                      break;
                    default:
                      sl && sl();
                  }
                }
              }, sl["prototype"]['Le'] = function () {
                if (this["props"]["showDropDownArrow"]()) {
                  var sl = {};
                  sl["transition"] = "transform 0.15s ease-out";
                  sl["borderColor"] = HX["appearanceHelper"]["freeSpinListArrowColor"];
                  var sl = this["props"]["currentState"] === xX["HistoryFreeSpinDetails"] ? "angle-up" : "angle-down",
                    sl = "angle-up" === sl ? "translateY(4px)" : "translateY(-4px)",
                    sl = sl,
                    sl = HX["isMobile"] ? "gh-angle-horizontal-mobile" : "gh-angle-horizontal";
                  var sl = {};
                  sl['id'] = "nav-drop-down-arrow";
                  var sl = {};
                  sl["transform"] = sl;
                  var sl = {};
                  sl["className"] = "gh-angle-wrapper";
                  sl["style"] = sl;
                  return P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", {
                    'id': "calendar-arrow",
                    'className': ''["concat"](sl, '\x20')["concat"](sl),
                    'style': sl
                  })));
                }
                return null;
              }, sl["prototype"]['He'] = function () {
                var sl = '';
                if (this["props"]["currentState"] === xX["HistoryCalendar"]) switch (this["props"]["currentCalendarState"]) {
                  case xJ["SELECTION"]:
                    sl = ha['t']("History.HistoryCalendarDateRange");
                    break;
                  case xJ["CUSTOM"]:
                    sl = ha['t']("History.HistoryCalenderCustom");
                } else switch (this["props"]["currentCalendarType"]) {
                  case 0x1:
                  default:
                    sl = ha['t']("History.HistoryCalenderToday");
                    break;
                  case 0x2:
                    sl = ha['t']("History.HistoryCalenderWeek");
                    break;
                  case 0x3:
                    sl = HN(this["props"]["calendarCustomDateConfig"]["startDate"], true) + " - " + HN(this["props"]["calendarCustomDateConfig"]["endDate"], true);
                }
                return sl;
              }, sl["prototype"]['Me'] = function () {
                {
                  var sl = '',
                    sl = '',
                    sl = shell["isRTLLanguage"]() ? -0.7 : 0.7,
                    sl = 0x0,
                    sl = 0x0,
                    sl = '',
                    sl = {},
                    sl = {};
                  switch (this["props"]["currentState"]) {
                    case xX["HistoryList"]:
                      HX["launchType"] === xS["CARD"] ? (sl = "gh_card_btn_calendar_normal", sl = "gh_card_history_sprite", sl = shell["isRTLLanguage"]() ? 0x32 : -0x32, sl = -0x5, sl = 0.3) : HX["isApiReplay"] || (sl = "gh_ic_nav_calendar", sl = "gh_basic_sprite", sl = 0.325);
                      break;
                    case xX["HistoryFreeSpinDetails"]:
                    case xX["HistoryDetails"]:
                    default:
                      HX["launchType"] === xS["CARD"] ? (sl = "gh_card_ic_nav_back_default", sl = "gh_card_history_sprite", sl = "game-list-nav-image-details-card", sl = shell["isRTLLanguage"]() ? -0.3 : 0.3, sl["transformOrigin"] = shell["isRTLLanguage"]() ? "right" : "left", sl = shell["isRTLLanguage"]() ? 0x6a : 0x0) : (sl = "gh-arrow", sl = {
                        'backgroundColor': HX["appearanceHelper"]["navBackButtonIconColor"]
                      });
                  }
                  return P["createElement"]("div", {
                    'id': "game-list-nav-image-left",
                    'className': "game-list-nav-image "["concat"](sl),
                    'key': "game-list-nav-image-left",
                    'style': xa({
                      'transform': "scaleX("["concat"](sl, ") scaleY(")["concat"](Math["abs"](sl), ')')
                    }, sl)
                  }, P["createElement"]("div", {
                    'className': ''["concat"](sl, '\x20')["concat"](sl),
                    'style': xa({
                      'transform': "translate("["concat"](sl, "px, ")["concat"](sl, "px)")
                    }, sl)
                  }));
                }
              }, sl["prototype"]['Ie'] = function () {
                var sl = '',
                  sl = '',
                  sl = '',
                  sl = undefined,
                  sl = this["props"]["currentState"],
                  sl = sl === xX["HistoryDetails"] || HX["isPortrait"];
                switch (HX["launchType"]) {
                  case xS["GAME"]:
                  case xS["SLOT"]:
                  case xS["APIREPLAY"]:
                    var sl = {};
                    sl["isPortrait"] = sl;
                    sl = sl === xX["HistoryDetails"] ? '' : "translateX("["concat"](shell["isRTLLanguage"]() ? -0x9 : 0x9, "px)"), sl = P["createElement"](hp, sl);
                    break;
                  case xS["CARD"]:
                    sl = "gh_card_history_sprite", sl = "gh_card_btn_close_normal", sl = "scale(0.3) translateY("["concat"](shell["isRTLLanguage"]() ? 0x5 : -0x5, "px)"), sl = P["createElement"]("div", {
                      'className': ''["concat"](sl, '\x20')["concat"](sl)
                    });
                }
                return P["createElement"]("div", {
                  'id': "game-list-nav-image-right",
                  'className': "game-list-nav-image",
                  'key': "game-list-nav-image-right",
                  'style': {
                    'display': this['Be'](),
                    'transform': sl
                  }
                }, sl);
              }, sl["prototype"]['Be'] = function () {
                {
                  var sl = '';
                  switch (this["props"]["currentState"]) {
                    case xX["HistoryDetails"]:
                      sl = HX["isPortrait"] ? "none" : "flex";
                      break;
                    case xX["HistoryCalendar"]:
                    case xX["HistoryFreeSpinDetails"]:
                      sl = "none";
                      break;
                    default:
                      sl = "flex";
                  }
                  return sl;
                }
              }, sl["prototype"]['Pe'] = function (sl, sl) {
                var sl = {};
                sl['id'] = "game-free-spin-nav-label-wrapper";
                sl["ref"] = this['Se'];
                var sl = {};
                sl["color"] = sl;
                var sl = {};
                sl['id'] = "game-free-spin-nav-label";
                sl["style"] = sl;
                sl["ref"] = this['ze'];
                return P["createElement"]("div", sl, P["createElement"]("div", sl, sl));
              }, sl["prototype"]['Ne'] = function () {
                if (this['ze']["current"] && this['Se']["current"]) {
                  {
                    var sl = this['ze']["current"]["offsetWidth"];
                    if (sl > 0xd2) {
                      {
                        this['Se']["current"]["style"]["width"] = ''["concat"](0xd2, 'px');
                        var sl = 0xd2 / sl;
                        this['ze']["current"]["style"]["transform"] = "scale("["concat"](sl, ')');
                      }
                    } else this['Se']["current"]["style"]["width"] = ''["concat"](sl, 'px');
                  }
                }
              }, sl;
            }(P["Component"]);
          function hM(sl) {
            var sl,
              sl = sl["isHorizontal"],
              sl = sl["isFade"],
              sl = sl["fromSide"],
              sl = sl["loadMore"],
              sl = sl["isMobile"],
              sl = document["getElementById"]("game-history-container"),
              sl = document["getElementById"]("game-list-detail-wrapper"),
              sl = sl["clientHeight"],
              sl = sl["clientWidth"],
              sl = sl ? sl["clientWidth"] : 0x0;
            if (sl) {
              var xM = undefined,
                sl = undefined,
                sl = undefined,
                sl = undefined;
              sl && false === sl ? (sl = sl / 0x3 * 0.8, sl = xz, xM = 0.6 * (sl / 0x3 - sl / 0x2), sl = (sl - xz + 0x5a) / 0x3) : sl && true === sl ? (sl = sl - 0x32, sl = 0xb4, xM = sl / 0x2 + 0x19, sl = sl - 0x28) : (sl = sl, sl = 0xb4, xM = sl / 0x2, sl = sl - 0x28 - Hv() + 0xa), sl = {
                'label': shell["I18n"]['t']("History.HistoryLoading"),
                'isFullBackground': true,
                'width': sl,
                'height': sl,
                'x': xM,
                'y': sl,
                'opacity': 0x1,
                'scale': sl && !sl ? 0.6 : 0x1,
                'inAnimate': "Fade",
                'inDuration': 0.5,
                'inValue': 0x0,
                'color': HX["appearanceHelper"]["loadingColor"]
              };
            } else {
              xM = undefined, sl = undefined, sl = undefined, sl = undefined;
              var sl = undefined;
              sl && false === sl ? (sl = 0x168, sl = 0x280, xM = sl / 0x3 * (sl ? 0.83 : 0.6), xM = shell["isRTLLanguage"]() ? sl / 0x3 - xM : xM, sl = sl / 0x3 * 0.5, sl = 0.6) : sl && true === sl ? (sl = sl - 0x32, sl = sl, xM = sl / 0x2 + 0x19, sl = sl / 0x2, sl = 0x1) : (sl = 0x168, sl = 0x280, xM = sl / 0x2, sl = sl / 0x2, sl = 0x1);
              var sl = {};
              sl['x'] = sl;
              var sl = {};
              sl['y'] = sl;
              var jx = sl ? "Fade" : "Slide",
                sl = sl ? 0.2 : 0.5,
                jh = sl ? 0x0 : sl ? sl : sl;
              shell["isRTLLanguage"]() && "object" == typeof jh && (jh['x'] = -0x1 * jh['x']), sl = {
                'label': shell["I18n"]['t']("History.HistoryLoading"),
                'width': sl,
                'height': sl,
                'x': xM,
                'y': sl,
                'opacity': 0x1,
                'scale': sl,
                'inAnimate': jx,
                'inEasing': "easeOutCubic",
                'inDuration': sl,
                'inValue': jh,
                'color': HX["appearanceHelper"]["loadingColor"]
              };
            }
            var jE = {};
            jE['id'] = "loading";
            return T(function () {
              var jg = HX["context"]["event"];
              return jg["emit"]("Loading.Show", sl), function () {
                {
                  jg["emit"]("Loading.Hide");
                }
              };
            }, []), P["createElement"]("div", jE, function (jg, jA, jh) {
              var jh = jg ? "horizontal"["concat"](jA ? "-mobile" : '') : "vertical";
              if (jh) {
                var jj = {
                  'top': (jg ? jA ? 0xe : 0x1f : 0xd) + (jg ? 0x0 : Hq())
                };
                return shell["isRTLLanguage"]() && (jj["left"] = jg ? "28px" : "15px", jj["right"] = 0x0), P["createElement"]("div", {
                  'id': "loading-exit",
                  'className': jh,
                  'style': jj
                }, P["createElement"](hp, {
                  'isPortrait': !jg,
                  'onClickCallback': function () {
                    jh();
                  },
                  'customColor': HX["appearanceHelper"]["loadingCloseButtonIconColor"]
                }));
              }
            }(sl["isHorizontal"], sl["isMobile"], sl["onButtonClickCallback"]));
          }
          function hI(sl, sl) {
            {
              return sl["map"](function (sl, sl) {
                return sl + sl[sl];
              });
            }
          }
          function hk(sl, sl) {
            return sl["map"](function (sl, sl) {
              return sl - sl[sl];
            });
          }
          function hf(sl, sl, sl) {
            {
              return sl = sl || Math["hypot"]["apply"](Math, sl), sl ? sl / sl : 0x0;
            }
          }
          function hG(sl, sl) {
            {
              return sl ? sl["map"](function (sl) {
                return sl / sl;
              }) : Array(sl["length"])["fill"](0x0);
            }
          }
          function hy(sl) {
            return Math["hypot"]["apply"](Math, sl);
          }
          function hb(sl, sl) {
            return sl = sl || Math["hypot"]["apply"](Math, sl) || 0x1, sl["map"](function (sl) {
              return sl / sl;
            });
          }
          function hZ(sl, sl, sl) {
            var sl = Math["hypot"]["apply"](Math, sl);
            return {
              'velocities': hG(sl, sl),
              'velocity': hf(sl, sl, sl),
              'distance': hy(sl),
              'direction': hb(sl, sl)
            };
          }
          function hc(sl) {
            return Math["sign"] ? Math["sign"](sl) : +(sl > 0x0) - +(sl < 0x0) || +sl;
          }
          function hS(sl, sl) {
            return Math["abs"](sl) >= sl && hc(sl) * sl;
          }
          function hX(sl, sl, sl) {
            return 0x0 === sl || Math["abs"](sl) === 0x1 / 0x0 ? function (sl, sl) {
              return Math["pow"](sl, 0x5 * sl);
            }(sl, sl) : sl * sl * sl / (sl + sl * sl);
          }
          function hJ(sl, sl, sl, sl) {
            {
              return undefined === sl && (sl = 0.15), 0x0 === sl ? function (sl, sl, sl) {
                return Math["max"](sl, Math["min"](sl, sl));
              }(sl, sl, sl) : sl < sl ? -hX(sl - sl, sl - sl, sl) + sl : sl > sl ? hX(sl - sl, sl - sl, sl) + sl : sl;
            }
          }
          function hV(sl, sl) {
            for (var sl = 0x0; sl < sl["length"]; sl++) {
              var sl = sl[sl];
              sl["enumerable"] = sl["enumerable"] || false, sl["configurable"] = true, "value" in sl && (sl["writable"] = true), Object["defineProperty"](sl, sl["key"], sl);
            }
          }
          function hN() {
            return hN = Object["assign"] || function (sl) {
              for (var sl = 0x1; sl < arguments["length"]; sl++) {
                var sl = arguments[sl];
                for (var sl in sl) Object["prototype"]["hasOwnProperty"]["call"](sl, sl) && (sl[sl] = sl[sl]);
              }
              return sl;
            }, hN["apply"](this, arguments);
          }
          function hR(sl, sl) {
            sl["prototype"] = Object["create"](sl["prototype"]), sl["prototype"]["constructor"] = sl, sl["__proto__"] = sl;
          }
          function hB(sl, sl) {
            if (null == sl) return {};
            var sl,
              sl,
              sl = {},
              sl = Object["keys"](sl);
            for (sl = 0x0; sl < sl["length"]; sl++) sl = sl[sl], sl["indexOf"](sl) >= 0x0 || (sl[sl] = sl[sl]);
            return sl;
          }
          function hY(sl, sl) {
            (null == sl || sl > sl["length"]) && (sl = sl["length"]);
            for (var sl = 0x0, sl = Array(sl); sl < sl; sl++) sl[sl] = sl[sl];
            return sl;
          }
          function hl(sl) {
            {
              var sl = 0x0;
              if ("undefined" == typeof Symbol || null == sl[Symbol["iterator"]]) {
                {
                  if (Array["isArray"](sl) || (sl = function (sl, sl) {
                    if (sl) {
                      if ("string" == typeof sl) return hY(sl, sl);
                      var sl = Object["prototype"]["toString"]["call"](sl)["slice"](0x8, -0x1);
                      return "Object" === sl && sl["constructor"] && (sl = sl["constructor"]["name"]), "Map" === sl || "Set" === sl ? Array["from"](sl) : "Arguments" === sl || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/["test"](sl) ? hY(sl, sl) : undefined;
                    }
                  }(sl))) return function () {
                    var sl = {};
                    sl["done"] = true;
                    return sl >= sl["length"] ? sl : {
                      'done': false,
                      'value': sl[sl++]
                    };
                  };
                  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
              }
              return (sl = sl[Symbol["iterator"]]())["next"]["bind"](sl);
            }
          }
          function hw() {}
          var hq = function () {
              for (var sl = arguments["length"], sl = Array(sl), sl = 0x0; sl < sl; sl++) sl[sl] = arguments[sl];
              return function () {
                for (var sl = arguments["length"], sl = Array(sl), sl = 0x0; sl < sl; sl++) sl[sl] = arguments[sl];
                return sl["forEach"](function (sl) {
                  {
                    return sl["apply"](undefined, sl);
                  }
                });
              };
            },
            hD = function (sl) {
              {
                return Array["isArray"](sl) ? sl : [sl, sl];
              }
            },
            hz = function (sl, sl) {
              return undefined !== sl ? sl : sl;
            };
          function hv(sl, sl) {
            var sl = {};
            return Object["entries"](sl)["forEach"](function (sl) {
              var sl = sl[0x0],
                sl = sl[0x1];
              return (undefined !== sl || sl in sl) && (sl[sl] = sl);
            }), sl;
          }
          function hO(sl) {
            {
              return "function" == typeof sl ? sl() : sl;
            }
          }
          function hK() {
            {
              var sl = {};
              sl['Re'] = false;
              sl['Ae'] = false;
              sl['Ee'] = [false, false];
              sl['We'] = [0x0, 0x0];
              sl['Ye'] = [0x0, 0x0];
              sl['Ge'] = undefined;
              sl["event"] = undefined;
              sl["values"] = [0x0, 0x0];
              sl["velocities"] = [0x0, 0x0];
              sl["delta"] = [0x0, 0x0];
              sl["movement"] = [0x0, 0x0];
              sl["offset"] = [0x0, 0x0];
              sl["lastOffset"] = [0x0, 0x0];
              sl["direction"] = [0x0, 0x0];
              sl["initial"] = [0x0, 0x0];
              sl["previous"] = [0x0, 0x0];
              sl["first"] = false;
              sl["last"] = false;
              sl["active"] = false;
              sl["timeStamp"] = 0x0;
              sl["startTime"] = 0x0;
              sl["elapsedTime"] = 0x0;
              sl["cancel"] = hw;
              sl["canceled"] = false;
              sl["memo"] = undefined;
              sl["args"] = undefined;
              var sl = {};
              sl["axis"] = undefined;
              sl['xy'] = [0x0, 0x0];
              sl["vxvy"] = [0x0, 0x0];
              sl["velocity"] = 0x0;
              sl["distance"] = 0x0;
              var sl = sl,
                sl = sl;
              var sl = {};
              sl["hovering"] = false;
              sl["scrolling"] = false;
              sl["wheeling"] = false;
              sl["dragging"] = false;
              sl["moving"] = false;
              sl["pinching"] = false;
              sl["touches"] = 0x0;
              sl["buttons"] = 0x0;
              sl["down"] = false;
              sl["shiftKey"] = false;
              sl["altKey"] = false;
              sl["metaKey"] = false;
              sl["ctrlKey"] = false;
              var sl = {};
              sl['Ue'] = true;
              sl['Ve'] = false;
              sl["tap"] = false;
              sl["swipe"] = [0x0, 0x0];
              var sl = {};
              sl['da'] = [0x0, 0x0];
              sl["vdva"] = [0x0, 0x0];
              sl["origin"] = undefined;
              sl["turns"] = 0x0;
              return {
                'shared': sl,
                'drag': hN(hN(hN({}, sl), sl), {}, sl),
                'pinch': hN(hN({}, sl), sl),
                'wheel': hN(hN({}, sl), sl),
                'move': hN(hN({}, sl), sl),
                'scroll': hN(hN({}, sl), sl)
              };
            }
          }
          var E0 = function (sl) {
              {
                return function (sl, sl, sl) {
                  var sl = sl ? "addEventListener" : "removeEventListener";
                  sl["forEach"](function (sl) {
                    var sl = sl[0x0],
                      sl = sl[0x1];
                    return sl[sl](sl, sl, sl);
                  });
                };
              }
            },
            E1 = E0(true),
            E2 = E0(false);
          function E3(sl) {
            if ("touches" in sl) {
              {
                var sl = sl["touches"],
                  sl = sl["changedTouches"];
                return sl["length"] > 0x0 ? sl : sl;
              }
            }
            return null;
          }
          function E4(sl) {
            {
              var sl = "buttons" in sl ? sl["buttons"] : 0x0,
                sl = E3(sl),
                sl = sl && sl["length"] || 0x0;
              var sl = {};
              sl["touches"] = sl;
              sl["down"] = sl > 0x0 || sl > 0x0;
              sl["buttons"] = sl;
              return hN(sl, function (sl) {
                var sl = {};
                sl["shiftKey"] = sl["shiftKey"];
                sl["altKey"] = sl["altKey"];
                sl["metaKey"] = sl["metaKey"];
                sl["ctrlKey"] = sl["ctrlKey"];
                return sl;
              }(sl));
            }
          }
          function E5(sl) {
            var sl = sl["currentTarget"],
              sl = sl["scrollX"],
              sl = sl["scrollY"],
              sl = sl["scrollLeft"],
              sl = sl["scrollTop"];
            var sl = {};
            sl["values"] = [sl || sl || 0x0, sl || sl || 0x0];
            return sl;
          }
          function E6(sl) {
            var sl = {};
            sl["values"] = [sl["deltaX"], sl["deltaY"]];
            return sl;
          }
          function E7(sl) {
            var sl = E3(sl),
              sl = sl ? sl[0x0] : sl;
            var sl = {};
            sl["values"] = [sl["clientX"], sl["clientY"]];
            return sl;
          }
          function E8(sl) {
            var sl = {};
            sl["values"] = [0x104 * sl["scale"], sl["rotation"]];
            return sl;
          }
          function E9(sl) {
            {
              var sl = sl["touches"],
                sl = sl[0x1]["clientX"] - sl[0x0]["clientX"],
                sl = sl[0x1]["clientY"] - sl[0x0]["clientY"];
              return {
                'values': [Math["hypot"](sl, sl), -0xb4 * Math["atan2"](sl, sl) / Math['PI']],
                'origin': [(sl[0x1]["clientX"] + sl[0x0]["clientX"]) / 0x2, (sl[0x1]["clientY"] + sl[0x0]["clientY"]) / 0x2]
              };
            }
          }
          var EC = {};
          EC["lockDirection"] = false;
          EC["axis"] = undefined;
          EC["bounds"] = undefined;
          var Ex = function () {
              var sl = this;
              this["state"] = hK(), this["timeouts"] = {}, this["domListeners"] = [], this["windowListeners"] = {}, this["bindings"] = {}, this["clean"] = function () {
                sl["resetBindings"](), Object["values"](sl["timeouts"])["forEach"](clearTimeout), Object["keys"](sl["windowListeners"])["forEach"](function (sl) {
                  return sl["removeWindowListeners"](sl);
                });
              }, this["resetBindings"] = function () {
                {
                  sl["bindings"] = {};
                  var sl = sl["getDomTarget"]();
                  sl && (E2(sl, sl["domListeners"], sl["config"]["eventOptions"]), sl["domListeners"] = []);
                }
              }, this["getDomTarget"] = function () {
                var sl = sl["config"]["domTarget"];
                return sl && "current" in sl ? sl["current"] : sl;
              }, this["addWindowListeners"] = function (sl, sl) {
                sl["config"]["window"] && (sl["windowListeners"][sl] = sl, E1(sl["config"]["window"], sl, sl["config"]["eventOptions"]));
              }, this["removeWindowListeners"] = function (sl) {
                if (sl["config"]["window"]) {
                  var sl = sl["windowListeners"][sl];
                  sl && (E2(sl["config"]["window"], sl, sl["config"]["eventOptions"]), delete sl["windowListeners"][sl]);
                }
              }, this["addDomTargetListeners"] = function (sl) {
                Object["entries"](sl["bindings"])["forEach"](function (sl) {
                  var sl = sl[0x0],
                    sl = sl[0x1];
                  sl["domListeners"]["push"]([sl["substr"](0x2)["toLowerCase"](), hq["apply"](undefined, sl)]);
                }), E1(sl, sl["domListeners"], sl["config"]["eventOptions"]);
              }, this["addBindings"] = function (sl, sl) {
                (Array["isArray"](sl) ? sl : [sl])["forEach"](function (sl) {
                  sl["bindings"][sl] ? sl["bindings"][sl]["push"](sl) : sl["bindings"][sl] = [sl];
                });
              }, this["getBindings"] = function () {
                var sl = {},
                  sl = sl["config"]["captureString"];
                return Object["entries"](sl["bindings"])["forEach"](function (sl) {
                  var sl = sl[0x0],
                    sl = sl[0x1],
                    sl = Array["isArray"](sl) ? sl : [sl];
                  sl[sl + sl] = hq["apply"](undefined, sl);
                }), sl;
              }, this["getBind"] = function () {
                if (sl["config"]["domTarget"]) {
                  {
                    var sl = sl["getDomTarget"]();
                    return sl && sl["addDomTargetListeners"](sl), sl["clean"];
                  }
                }
                return sl["getBindings"]();
              };
            },
            EH = function () {
              function sl(sl, sl, sl) {
                {
                  var sl = this;
                  undefined === sl && (sl = []), this["stateKey"] = sl, this["controller"] = sl, this["args"] = sl, this["debounced"] = true, this["setTimeout"] = function (sl, sl) {
                    {
                      var sl;
                      undefined === sl && (sl = 0x8c);
                      for (var sl = arguments["length"], xM = Array(sl > 0x2 ? sl - 0x2 : 0x0), sl = 0x2; sl < sl; sl++) xM[sl - 0x2] = arguments[sl];
                      sl["controller"]["timeouts"][sl["stateKey"]] = (sl = A)["setTimeout"]["apply"](sl, [sl, sl]["concat"](xM));
                    }
                  }, this["clearTimeout"] = function () {
                    clearTimeout(sl["controller"]["timeouts"][sl["stateKey"]]);
                  }, this["addWindowListeners"] = function (sl) {
                    sl["controller"]["addWindowListeners"](sl["stateKey"], sl);
                  }, this["removeWindowListeners"] = function () {
                    sl["controller"]["removeWindowListeners"](sl["stateKey"]);
                  }, this["getStartGestureState"] = function (sl, sl) {
                    return hN(hN({}, hK()[sl["stateKey"]]), {}, {
                      'Re': true,
                      'values': sl,
                      'initial': sl,
                      'offset': sl["state"]["offset"],
                      'lastOffset': sl["state"]["offset"],
                      'startTime': sl["timeStamp"]
                    });
                  }, this["rubberband"] = function (sl, sl) {
                    {
                      var sl = sl["config"]["bounds"];
                      return sl["map"](function (sl, xM) {
                        return hJ(sl, sl[xM][0x0], sl[xM][0x1], sl[xM]);
                      });
                    }
                  }, this["fireGestureHandler"] = function (sl) {
                    {
                      if (sl["state"]['Ae']) return sl["debounced"] || (sl["state"]['Re'] = false, sl["clean"]()), null;
                      var sl = sl["state"]['Ee'],
                        sl = sl[0x0],
                        sl = sl[0x1];
                      if (!sl && false === sl && false === sl) return null;
                      var xM = sl["state"],
                        sl = xM['Re'],
                        sl = xM["active"];
                      sl["state"]["active"] = sl, sl["state"]["first"] = sl && !sl, sl["state"]["last"] = sl && !sl, sl["controller"]["state"]["shared"][sl["ingKey"]] = sl;
                      var sl = hN(hN(hN({}, sl["controller"]["state"]["shared"]), sl["state"]), sl["mapStateValues"](sl["state"])),
                        sl = sl["handler"](sl);
                      return sl["state"]["memo"] = undefined !== sl ? sl : sl["state"]["memo"], sl || sl["clean"](), sl;
                    }
                  };
                }
              }
              var sl,
                sl,
                sl = sl["prototype"];
              return sl["updateSharedState"] = function (sl) {
                Object["assign"](this["controller"]["state"]["shared"], sl);
              }, sl["updateGestureState"] = function (sl) {
                Object["assign"](this["state"], sl);
              }, sl["getGenericPayload"] = function (sl, sl) {
                {
                  var sl = sl["timeStamp"],
                    sl = sl["type"],
                    sl = this["state"],
                    sl = sl["values"],
                    sl = sl["startTime"];
                  var sl = {};
                  sl['Ge'] = sl;
                  sl["event"] = sl;
                  sl["timeStamp"] = sl;
                  sl["elapsedTime"] = sl ? 0x0 : sl - sl;
                  sl["args"] = this["args"];
                  sl["previous"] = sl;
                  return sl;
                }
              }, sl["checkIntentionality"] = function (sl) {
                {
                  var sl = {};
                  sl['Ee'] = sl;
                  sl['Ae'] = false;
                  return sl;
                }
              }, sl["getMovement"] = function (sl, sl) {
                undefined === sl && (sl = this["state"]);
                var sl = this["config"],
                  sl = sl["initial"],
                  sl = sl["threshold"],
                  sl = sl["rubberband"],
                  sl = sl[0x0],
                  sl = sl[0x1],
                  xM = sl,
                  sl = xM['Ye'],
                  sl = xM['Re'],
                  sl = xM['Ee'],
                  sl = xM["lastOffset"],
                  sl = xM["movement"],
                  sl = sl[0x0],
                  jx = sl[0x1],
                  sl = this["getInternalMovement"](sl, sl),
                  jh = sl[0x0],
                  jE = sl[0x1];
                false === sl && (sl = hS(jh, sl)), false === jx && (jx = hS(jE, sl));
                var jg = this["checkIntentionality"]([sl, jx], [jh, jE], sl),
                  jA = jg['Ee'],
                  jh = jg['Ae'],
                  jh = jA[0x0],
                  jj = jA[0x1],
                  jP = [jh, jE];
                var jT = {};
                jT['We'] = jP;
                jT["delta"] = [0x0, 0x0];
                if (false !== jh && false === sl[0x0] && (sl[0x0] = hO(sl)[0x0]), false !== jj && false === sl[0x1] && (sl[0x1] = hO(sl)[0x1]), jh) return hN(hN({}, jg), {}, jT);
                var jU = [false !== jh ? jh - jh : hO(sl)[0x0], false !== jj ? jE - jj : hO(sl)[0x1]],
                  jW = hI(jU, sl),
                  ju = sl ? sl : [0x0, 0x0];
                return jU = this["rubberband"](hI(jU, sl), ju), hN(hN({}, jg), {}, {
                  'Ye': sl,
                  'We': jP,
                  'movement': jU,
                  'offset': this["rubberband"](jW, ju),
                  'delta': hk(jU, sl)
                });
              }, sl["clean"] = function () {
                this["clearTimeout"](), this["removeWindowListeners"]();
              }, sl = sl, (sl = [{
                'key': "config",
                'get': function () {
                  return this["controller"]["config"][this["stateKey"]];
                }
              }, {
                'key': "enabled",
                'get': function () {
                  return this["controller"]["config"]["enabled"] && this["config"]["enabled"];
                }
              }, {
                'key': "state",
                'get': function () {
                  {
                    return this["controller"]["state"][this["stateKey"]];
                  }
                }
              }, {
                'key': "handler",
                'get': function () {
                  return this["controller"]["handlers"][this["stateKey"]];
                }
              }]) && hV(sl["prototype"], sl), sl;
            }(),
            Eh = function (sl) {
              {
                function sl() {
                  return sl["apply"](this, arguments) || this;
                }
                hR(sl, sl);
                var sl = sl["prototype"];
                return sl["getInternalMovement"] = function (sl, sl) {
                  {
                    return hk(sl, sl["initial"]);
                  }
                }, sl["checkIntentionality"] = function (sl, sl, sl) {
                  var sl = sl,
                    sl = sl[0x0],
                    sl = sl[0x1],
                    sl = false !== sl || false !== sl,
                    sl = sl["axis"],
                    sl = false;
                  if (sl) {
                    var xM = sl["map"](Math["abs"]),
                      sl = xM[0x0],
                      sl = xM[0x1],
                      sl = this["config"],
                      sl = sl["axis"],
                      sl = sl["lockDirection"];
                    sl = sl || (sl > sl ? 'x' : sl < sl ? 'y' : undefined), (sl || sl) && (sl ? sl && sl !== sl ? sl = true : sl['x' === sl ? 0x1 : 0x0] = false : sl = [false, false]);
                  }
                  var sl = {};
                  sl['Ee'] = sl;
                  sl['Ae'] = sl;
                  sl["axis"] = sl;
                  return sl;
                }, sl["getKinematics"] = function (sl, sl) {
                  var sl = this["state"]["timeStamp"],
                    sl = this["getMovement"](sl, this["state"]),
                    sl = sl['Ae'],
                    sl = sl["delta"],
                    sl = sl["movement"];
                  if (sl) return sl;
                  var sl = hZ(sl, sl, sl["timeStamp"] - sl);
                  var sl = {};
                  sl["values"] = sl;
                  sl["delta"] = sl;
                  return hN(hN(sl, sl), sl);
                }, sl["mapStateValues"] = function (sl) {
                  {
                    var sl = {};
                    sl['xy'] = sl["values"];
                    sl["vxvy"] = sl["velocities"];
                    return sl;
                  }
                }, sl;
              }
            }(EH),
            EE = function (sl) {
              function sl(sl, sl) {
                var sl;
                return (sl = sl["call"](this, "drag", sl, sl) || this)["ingKey"] = "dragging", sl["wasTouch"] = false, sl["isEventTypeTouch"] = function (sl) {
                  {
                    return !!sl && 0x0 === sl["indexOf"]("touch");
                  }
                }, sl["dragShouldStart"] = function (sl) {
                  var sl = E4(sl)["touches"],
                    sl = sl["state"]['Ge'];
                  return !(!sl["controller"]["config"]["pointer"] && sl["isEventTypeTouch"](sl) && !sl["isEventTypeTouch"](sl["type"]) && Math["abs"](sl["timeStamp"] - sl["state"]["startTime"]) < 0xc8) && sl["enabled"] && sl < 0x2;
                }, sl["setPointers"] = function (sl) {
                  var sl = sl["currentTarget"],
                    sl = sl["pointerId"];
                  sl && sl["setPointerCapture"](sl), sl["updateGestureState"]({
                    'currentTarget': sl,
                    'pointerId': sl
                  });
                }, sl["removePointers"] = function () {
                  var sl = sl["state"],
                    sl = sl["currentTarget"],
                    sl = sl["pointerId"];
                  sl && sl && sl["releasePointerCapture"](sl);
                }, sl["setListeners"] = function (sl) {
                  sl["removeWindowListeners"]();
                  var sl = sl ? [["touchmove", sl["onDragChange"]], ["touchend", sl["onDragEnd"]], ["touchcancel", sl["onDragEnd"]]] : [["mousemove", sl["onDragChange"]], ["mouseup", sl["onDragEnd"]]];
                  sl["addWindowListeners"](sl);
                }, sl["onDragStart"] = function (sl) {
                  sl["dragShouldStart"](sl) && (sl["controller"]["config"]["pointer"] ? sl["setPointers"](sl) : sl["setListeners"](sl["isEventTypeTouch"](sl["type"])), sl["config"]["delay"] > 0x0 ? (sl["state"]['Ve'] = true, "function" == typeof sl["persist"] && sl["persist"](), sl["setTimeout"](function () {
                    {
                      return sl["startDrag"](sl);
                    }
                  }, sl["config"]["delay"])) : sl["startDrag"](sl));
                }, sl["onDragChange"] = function (sl) {
                  if (!sl["state"]["canceled"]) if (sl["state"]['Re']) {
                    var sl = E4(sl);
                    if (sl["down"]) {
                      {
                        sl["updateSharedState"](sl);
                        var sl = E7(sl)["values"],
                          sl = sl["getKinematics"](sl, sl),
                          sl = sl["state"]['Ue'];
                        sl && hy(sl['We']) >= 0x3 && (sl = false), sl["updateGestureState"](hN(hN(hN({}, sl["getGenericPayload"](sl)), sl), {}, {
                          'Ue': sl,
                          'cancel': function () {
                            return sl["onCancel"]();
                          }
                        })), sl["fireGestureHandler"]();
                      }
                    } else sl["onDragEnd"](sl);
                  } else sl["state"]['Ve'] && (sl["clearTimeout"](), sl["startDrag"](sl));
                }, sl["onDragEnd"] = function (sl) {
                  {
                    var sl = {};
                    sl["down"] = false;
                    sl["buttons"] = 0x0;
                    sl["touches"] = 0x0;
                    sl["state"]['Re'] = false, sl["updateSharedState"](sl);
                    var sl = sl["state"],
                      sl = sl['Ue'],
                      sl = sl["values"],
                      sl = sl["velocities"],
                      xM = sl[0x0],
                      sl = sl[0x1],
                      sl = sl["movement"],
                      sl = sl[0x0],
                      sl = sl[0x1],
                      sl = sl['Ee'],
                      sl = sl[0x0],
                      jx = sl[0x1],
                      sl = hN(hN({}, sl["getGenericPayload"](sl)), sl["getMovement"](sl)),
                      jh = sl["elapsedTime"],
                      jE = sl["config"],
                      jg = jE["swipeVelocity"],
                      jA = jg[0x0],
                      jh = jg[0x1],
                      jh = jE["swipeDistance"],
                      jj = jh[0x0],
                      jP = jh[0x1],
                      jT = [0x0, 0x0];
                    var jU = {};
                    jU["event"] = sl;
                    jh < 0xdc && (false !== sl && Math["abs"](xM) > jA && Math["abs"](sl) > jj && (jT[0x0] = hc(xM)), false !== jx && Math["abs"](sl) > jh && Math["abs"](sl) > jP && (jT[0x1] = hc(sl))), sl["updateGestureState"](hN(hN(jU, sl), {}, {
                      'tap': sl,
                      'swipe': jT
                    })), sl["fireGestureHandler"](sl["config"]["filterTaps"] && sl["state"]['Ue']);
                  }
                }, sl["clean"] = function () {
                  sl["prototype"]["clean"]["call"](function (sl) {
                    if (undefined === sl) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return sl;
                  }(sl)), sl["state"]['Ve'] = false, sl["controller"]["config"]["pointer"] && sl["removePointers"]();
                }, sl["onCancel"] = function () {
                  var sl = {};
                  sl["canceled"] = true;
                  sl["cancel"] = hw;
                  var sl = {};
                  sl["down"] = false;
                  sl["buttons"] = 0x0;
                  sl["touches"] = 0x0;
                  sl["updateGestureState"](sl), sl["state"]['Re'] = false, sl["updateSharedState"](sl), requestAnimationFrame(function () {
                    return sl["fireGestureHandler"]();
                  });
                }, sl;
              }
              hR(sl, sl);
              var sl = sl["prototype"];
              return sl["startDrag"] = function (sl) {
                var sl = this,
                  sl = E7(sl)["values"];
                this["updateSharedState"](E4(sl));
                var sl = hN(hN({}, this["getStartGestureState"](sl, sl)), this["getGenericPayload"](sl, true));
                this["updateGestureState"](hN(hN(hN({}, sl), this["getMovement"](sl, sl)), {}, {
                  'cancel': function () {
                    return sl["onCancel"]();
                  }
                })), this["fireGestureHandler"]();
              }, sl["addBindings"] = function () {
                this["controller"]["config"]["pointer"] ? (this["controller"]["addBindings"]("onPointerDown", this["onDragStart"]), this["controller"]["addBindings"]("onPointerMove", this["onDragChange"]), this["controller"]["addBindings"](["onPointerUp", "onPointerCancel"], this["onDragEnd"])) : this["controller"]["addBindings"](["onTouchStart", "onMouseDown"], this["onDragStart"]);
              }, sl;
            }(Eh),
            Eg = undefined !== A ? A : undefined,
            EC = EC;
          function Ed(sl) {
            {
              var sl = sl["threshold"],
                sl = undefined === sl ? undefined : sl,
                sl = sl["rubberband"],
                sl = undefined === sl ? 0x0 : sl,
                sl = sl["enabled"],
                sl = undefined === sl || sl,
                sl = sl["initial"];
              return "boolean" == typeof sl && (sl = sl ? 0.15 : 0x0), undefined === sl && (sl = 0x0), {
                'enabled': sl,
                'initial': undefined === sl ? [0x0, 0x0] : sl,
                'threshold': hD(sl),
                'rubberband': hD(sl)
              };
            }
          }
          function Es(sl) {
            undefined === sl && (sl = {});
            var sl = sl,
              sl = sl["axis"],
              sl = sl["lockDirection"],
              sl = sl["bounds"],
              sl = undefined === sl ? {} : sl,
              sl = hB(sl, ["axis", "lockDirection", "bounds"]),
              sl = [[hz(sl["left"], -0x1 / 0x0), hz(sl["right"], 0x1 / 0x0)], [hz(sl["top"], -0x1 / 0x0), hz(sl["bottom"], 0x1 / 0x0)]];
            var sl = {};
            sl["axis"] = sl;
            sl["lockDirection"] = sl;
            var sl = {};
            sl["bounds"] = sl;
            return hN(hN(hN(hN({}, Ed(sl)), EC), hv(sl, sl)), {}, sl);
          }
          var Ej = function (sl) {
              {
                function sl() {
                  {
                    return sl["apply"](this, arguments) || this;
                  }
                }
                hR(sl, sl);
                var sl = sl["prototype"];
                return sl["getInternalMovement"] = function (sl, sl) {
                  var sl = sl[0x0],
                    sl = sl[0x1],
                    sl = sl["values"],
                    sl = sl["turns"],
                    sl = sl["initial"],
                    sl = (sl = undefined !== sl ? sl : sl[0x1]) - sl[0x1],
                    sl = Math["abs"](sl) > 0x10e ? sl + hc(sl) : sl;
                  return [sl - sl[0x0], sl - 0x168 * sl - sl[0x1]];
                }, sl["getKinematics"] = function (sl, sl) {
                  var sl = this["state"],
                    sl = sl["timeStamp"],
                    sl = sl["initial"],
                    sl = this["getMovement"](sl, this["state"]),
                    sl = sl["delta"],
                    sl = sl["movement"],
                    sl = (sl[0x1] - sl[0x1] - sl[0x1]) / 0x168,
                    xM = hZ(sl, sl, sl["timeStamp"] - sl);
                  var sl = {};
                  sl["values"] = sl;
                  sl["delta"] = sl;
                  sl["turns"] = sl;
                  return hN(hN(sl, sl), xM);
                }, sl["mapStateValues"] = function (sl) {
                  var sl = {};
                  sl['da'] = sl["values"];
                  sl["vdva"] = sl["velocities"];
                  return sl;
                }, sl;
              }
            }(EH),
            EP = function (sl) {
              function sl(sl, sl) {
                {
                  var sl;
                  return (sl = sl["call"](this, "pinch", sl, sl) || this)["ingKey"] = "pinching", sl["pinchShouldStart"] = function (sl) {
                    {
                      var sl = E4(sl)["touches"];
                      return sl["enabled"] && 0x2 === sl;
                    }
                  }, sl["onPinchStart"] = function (sl) {
                    if (sl["pinchShouldStart"](sl)) {
                      var sl = E9(sl),
                        sl = sl["values"],
                        sl = sl["origin"];
                      sl["updateSharedState"](E4(sl));
                      var sl = hN(hN({}, sl["getStartGestureState"](sl, sl)), sl["getGenericPayload"](sl, true));
                      sl["updateGestureState"](hN(hN(hN({}, sl), sl["getMovement"](sl, sl)), {}, {
                        'origin': sl,
                        'cancel': function () {
                          return sl["onCancel"]();
                        }
                      })), sl["fireGestureHandler"]();
                    }
                  }, sl["onPinchChange"] = function (sl) {
                    var sl = sl["state"],
                      sl = sl["canceled"],
                      sl = sl["timeStamp"],
                      sl = sl['Re'];
                    if (!sl && sl) {
                      var sl = E4(sl);
                      if (0x2 === sl["touches"] && sl["timeStamp"] !== sl) {
                        sl["updateSharedState"](sl);
                        var sl = E9(sl),
                          xM = sl["values"],
                          sl = sl["origin"],
                          sl = sl["getKinematics"](xM, sl);
                        sl["updateGestureState"](hN(hN(hN({}, sl["getGenericPayload"](sl)), sl), {}, {
                          'origin': sl,
                          'cancel': function () {
                            return sl["onCancel"]();
                          }
                        })), sl["fireGestureHandler"]();
                      }
                    }
                  }, sl["onPinchEnd"] = function (sl) {
                    var sl = {};
                    sl["down"] = false;
                    sl["touches"] = 0x0;
                    var sl = {};
                    sl["event"] = sl;
                    sl["state"]["active"] && (sl["state"]['Re'] = false, sl["updateSharedState"](sl), sl["updateGestureState"](hN(hN(sl, sl["getGenericPayload"](sl)), sl["getMovement"](sl["state"]["values"]))), sl["fireGestureHandler"]());
                  }, sl["onCancel"] = function () {
                    {
                      var sl = {};
                      sl["canceled"] = true;
                      sl["cancel"] = hw;
                      var sl = {};
                      sl["down"] = false;
                      sl["touches"] = 0x0;
                      sl["state"]['Re'] = false, sl["updateGestureState"](sl), sl["updateSharedState"](sl), requestAnimationFrame(function () {
                        {
                          return sl["fireGestureHandler"]();
                        }
                      });
                    }
                  }, sl["onGestureStart"] = function (sl) {
                    if (sl["enabled"]) {
                      {
                        sl["preventDefault"]();
                        var sl = E8(sl)["values"];
                        sl["updateSharedState"](E4(sl));
                        var sl = hN(hN({}, sl["getStartGestureState"](sl, sl)), sl["getGenericPayload"](sl, true));
                        sl["updateGestureState"](hN(hN(hN({}, sl), sl["getMovement"](sl, sl)), {}, {
                          'cancel': function () {
                            return sl["onCancel"]();
                          }
                        })), sl["fireGestureHandler"]();
                      }
                    }
                  }, sl["onGestureChange"] = function (sl) {
                    {
                      var sl = sl["state"],
                        sl = sl["canceled"],
                        sl = sl['Re'];
                      if (!sl && sl) {
                        sl["preventDefault"]();
                        var sl = E4(sl);
                        sl["updateSharedState"](sl);
                        var sl = E8(sl)["values"],
                          sl = sl["getKinematics"](sl, sl);
                        sl["updateGestureState"](hN(hN(hN({}, sl["getGenericPayload"](sl)), sl), {}, {
                          'cancel': function () {
                            return sl["onCancel"]();
                          }
                        })), sl["fireGestureHandler"]();
                      }
                    }
                  }, sl["onGestureEnd"] = function (sl) {
                    var sl = {};
                    sl["down"] = false;
                    sl["touches"] = 0x0;
                    sl["preventDefault"](), sl["state"]["active"] && (sl["state"]['Re'] = false, sl["updateSharedState"](sl), sl["updateGestureState"](hN(hN({
                      'event': sl
                    }, sl["getGenericPayload"](sl)), sl["getMovement"](sl["state"]["values"]))), sl["fireGestureHandler"]());
                  }, sl["updateTouchData"] = function (sl) {
                    if (sl["enabled"] && 0x2 === sl["touches"]["length"] && sl["state"]['Re']) {
                      {
                        var sl = E9(sl)["origin"];
                        sl["state"]["origin"] = sl;
                      }
                    }
                  }, sl["wheelShouldRun"] = function (sl) {
                    return sl["enabled"] && sl["ctrlKey"];
                  }, sl["getWheelValuesFromEvent"] = function (sl) {
                    var sl = E6(sl)["values"][0x1],
                      sl = sl["state"]["values"],
                      sl = sl[0x0],
                      sl = sl[0x1];
                    var sl = {};
                    sl["values"] = [sl - sl, undefined !== sl ? sl : 0x0];
                    sl["origin"] = [sl["clientX"], sl["clientY"]];
                    sl["delta"] = [0x0, sl];
                    return sl;
                  }, sl["onWheel"] = function (sl) {
                    {
                      sl["wheelShouldRun"](sl) && (sl["clearTimeout"](), sl["setTimeout"](sl["onWheelEnd"]), sl["state"]['Re'] ? sl["onWheelChange"](sl) : sl["onWheelStart"](sl));
                    }
                  }, sl["onWheelStart"] = function (sl) {
                    var sl = sl["getWheelValuesFromEvent"](sl),
                      sl = sl["values"],
                      sl = sl["delta"],
                      sl = sl["origin"];
                    sl["controller"]["config"]["eventOptions"]["passive"] || sl["preventDefault"](), sl["updateSharedState"](E4(sl));
                    var sl = hN(hN(hN({}, sl["getStartGestureState"](sl, sl)), sl["getGenericPayload"](sl, true)), {}, {
                      'initial': sl["state"]["values"]
                    });
                    sl["updateGestureState"](hN(hN(hN({}, sl), sl["getMovement"](sl, sl)), {}, {
                      'offset': sl,
                      'delta': sl,
                      'origin': sl
                    })), sl["fireGestureHandler"]();
                  }, sl["onWheelChange"] = function (sl) {
                    var sl = E4(sl);
                    sl["updateSharedState"](sl);
                    var sl = sl["getWheelValuesFromEvent"](sl),
                      sl = sl["values"],
                      sl = sl["origin"],
                      sl = sl["delta"],
                      sl = sl["getKinematics"](sl, sl);
                    var xM = {};
                    xM["origin"] = sl;
                    xM["delta"] = sl;
                    sl["updateGestureState"](hN(hN(hN({}, sl["getGenericPayload"](sl)), sl), {}, xM)), sl["fireGestureHandler"]();
                  }, sl["onWheelEnd"] = function () {
                    sl["state"]['Re'] = false, sl["updateGestureState"](sl["getMovement"](sl["state"]["values"])), sl["fireGestureHandler"]();
                  }, sl;
                }
              }
              return hR(sl, sl), sl["prototype"]["addBindings"] = function () {
                this["controller"]["config"]["domTarget"] && function () {
                  try {
                    return "constructor" in GestureEvent;
                  } catch (sl) {
                    return false;
                  }
                }() ? (this["controller"]["addBindings"]("onGestureStart", this["onGestureStart"]), this["controller"]["addBindings"]("onGestureChange", this["onGestureChange"]), this["controller"]["addBindings"](["onGestureEnd", "onTouchCancel"], this["onGestureEnd"]), this["controller"]["addBindings"](["onTouchStart", "onTouchMove"], this["updateTouchData"])) : (this["controller"]["addBindings"]("onTouchStart", this["onPinchStart"]), this["controller"]["addBindings"]("onTouchMove", this["onPinchChange"]), this["controller"]["addBindings"](["onTouchEnd", "onTouchCancel"], this["onPinchEnd"]), this["controller"]["addBindings"]("onWheel", this["onWheel"]));
              }, sl;
            }(Ej),
            ET = function (sl) {
              function sl(sl, sl) {
                var sl;
                return (sl = sl["call"](this, "wheel", sl, sl) || this)["ingKey"] = "wheeling", sl["debounced"] = true, sl["wheelShouldRun"] = function (sl) {
                  return (!sl["ctrlKey"] || !("pinch" in sl["controller"]["handlers"])) && sl["enabled"];
                }, sl["getValuesFromEvent"] = function (sl) {
                  var sl = sl["state"]["values"];
                  return {
                    'values': hI(E6(sl)["values"], sl)
                  };
                }, sl["onWheel"] = function (sl) {
                  sl["wheelShouldRun"](sl) && (sl["clearTimeout"](), sl["setTimeout"](sl["onWheelEnd"]), sl["state"]['Re'] ? sl["onWheelChange"](sl) : sl["onWheelStart"](sl));
                }, sl["onWheelStart"] = function (sl) {
                  var sl = sl["getValuesFromEvent"](sl)["values"];
                  sl["updateSharedState"](E4(sl));
                  var sl = hN(hN(hN({}, sl["getStartGestureState"](sl, sl)), sl["getGenericPayload"](sl, true)), {}, {
                      'initial': sl["state"]["values"]
                    }),
                    sl = sl["getMovement"](sl, sl),
                    sl = sl["delta"];
                  sl["updateGestureState"](hN(hN(hN({}, sl), sl), {}, {
                    'distance': hy(sl),
                    'direction': hb(sl)
                  })), sl["fireGestureHandler"]();
                }, sl["onWheelChange"] = function (sl) {
                  var sl = E4(sl);
                  sl["updateSharedState"](sl);
                  var sl = sl["getValuesFromEvent"](sl)["values"],
                    sl = sl["getKinematics"](sl, sl);
                  sl["updateGestureState"](hN(hN({}, sl["getGenericPayload"](sl)), sl)), sl["fireGestureHandler"]();
                }, sl["onWheelEnd"] = function () {
                  var sl = {};
                  sl["velocities"] = [0x0, 0x0];
                  sl["velocity"] = 0x0;
                  sl["state"]['Re'] = false, sl["updateGestureState"](hN(hN({}, sl["getMovement"](sl["state"]["values"])), {}, sl)), sl["fireGestureHandler"]();
                }, sl;
              }
              return hR(sl, sl), sl["prototype"]["addBindings"] = function () {
                this["controller"]["addBindings"]("onWheel", this["onWheel"]);
              }, sl;
            }(Eh),
            EU = function (sl) {
              function sl(sl, sl) {
                {
                  var sl;
                  return (sl = sl["call"](this, "move", sl, sl) || this)["ingKey"] = "moving", sl["debounced"] = true, sl["moveShouldRun"] = function () {
                    return sl["enabled"];
                  }, sl["onMove"] = function (sl) {
                    sl["moveShouldRun"]() && (sl["clearTimeout"](), sl["setTimeout"](sl["onMoveEnd"]), sl["state"]['Re'] ? sl["onMoveChange"](sl) : sl["onMoveStart"](sl));
                  }, sl["onMoveStart"] = function (sl) {
                    var sl = E7(sl)["values"];
                    sl["updateSharedState"](E4(sl));
                    var sl = hN(hN({}, sl["getStartGestureState"](sl, sl)), sl["getGenericPayload"](sl, true));
                    sl["updateGestureState"](hN(hN({}, sl), sl["getMovement"](sl, sl))), sl["fireGestureHandler"]();
                  }, sl["onMoveChange"] = function (sl) {
                    var sl = E4(sl);
                    sl["updateSharedState"](sl);
                    var sl = E7(sl)["values"],
                      sl = sl["getKinematics"](sl, sl);
                    sl["updateGestureState"](hN(hN({}, sl["getGenericPayload"](sl)), sl)), sl["fireGestureHandler"]();
                  }, sl["onMoveEnd"] = function () {
                    var sl = {};
                    sl["velocities"] = [0x0, 0x0];
                    sl["velocity"] = 0x0;
                    sl["state"]['Re'] = false, sl["updateGestureState"](hN(hN({}, sl["getMovement"](sl["state"]["values"])), {}, sl)), sl["fireGestureHandler"]();
                  }, sl["onPointerEnter"] = function (sl) {
                    if (sl["controller"]["state"]["shared"]["hovering"] = true, sl["controller"]["config"]["enabled"]) {
                      if (sl["controller"]["config"]["hover"]["enabled"]) {
                        var sl = E7(sl)["values"],
                          sl = hN(hN(hN(hN({}, sl["controller"]["state"]["shared"]), sl["state"]), sl["getGenericPayload"](sl, true)), {}, {
                            'values': sl,
                            'active': true,
                            'hovering': true
                          });
                        sl["controller"]["handlers"]["hover"](hN(hN({}, sl), sl["mapStateValues"](sl)));
                      }
                      "move" in sl["controller"]["handlers"] && sl["onMoveStart"](sl);
                    }
                  }, sl["onPointerLeave"] = function (sl) {
                    if (sl["controller"]["state"]["shared"]["hovering"] = false, "move" in sl["controller"]["handlers"] && sl["onMoveEnd"](), sl["controller"]["config"]["hover"]["enabled"]) {
                      {
                        var sl = E7(sl)["values"],
                          sl = hN(hN(hN(hN({}, sl["controller"]["state"]["shared"]), sl["state"]), sl["getGenericPayload"](sl)), {}, {
                            'values': sl,
                            'active': false
                          });
                        sl["controller"]["handlers"]["hover"](hN(hN({}, sl), sl["mapStateValues"](sl)));
                      }
                    }
                  }, sl;
                }
              }
              return hR(sl, sl), sl["prototype"]["addBindings"] = function () {
                this["controller"]["config"]["pointer"] ? ("move" in this["controller"]["handlers"] && this["controller"]["addBindings"]("onPointerMove", this["onMove"]), "hover" in this["controller"]["handlers"] && (this["controller"]["addBindings"]("onPointerEnter", this["onPointerEnter"]), this["controller"]["addBindings"]("onPointerLeave", this["onPointerLeave"]))) : ("move" in this["controller"]["handlers"] && this["controller"]["addBindings"]("onMouseMove", this["onMove"]), "hover" in this["controller"]["handlers"] && (this["controller"]["addBindings"]("onMouseEnter", this["onPointerEnter"]), this["controller"]["addBindings"]("onMouseLeave", this["onPointerLeave"])));
              }, sl;
            }(Eh),
            EW = function (sl) {
              function sl(sl, sl) {
                {
                  var sl;
                  return (sl = sl["call"](this, "scroll", sl, sl) || this)["ingKey"] = "scrolling", sl["debounced"] = true, sl["scrollShouldRun"] = function () {
                    return sl["enabled"];
                  }, sl["onScroll"] = function (sl) {
                    sl["scrollShouldRun"]() && (sl["clearTimeout"](), sl["setTimeout"](sl["onScrollEnd"]), sl["state"]['Re'] ? sl["onScrollChange"](sl) : sl["onScrollStart"](sl));
                  }, sl["onScrollStart"] = function (sl) {
                    var sl = E5(sl)["values"];
                    sl["updateSharedState"](E4(sl));
                    var sl = hN(hN(hN({}, sl["getStartGestureState"](sl, sl)), sl["getGenericPayload"](sl, true)), {}, {
                        'initial': sl["state"]["values"]
                      }),
                      sl = sl["getMovement"](sl, sl),
                      sl = sl["delta"];
                    sl["updateGestureState"](hN(hN(hN({}, sl), sl), {}, {
                      'distance': hy(sl),
                      'direction': hb(sl)
                    })), sl["fireGestureHandler"]();
                  }, sl["onScrollChange"] = function (sl) {
                    var sl = E4(sl);
                    sl["updateSharedState"](sl);
                    var sl = E5(sl)["values"],
                      sl = sl["getKinematics"](sl, sl);
                    sl["updateGestureState"](hN(hN({}, sl["getGenericPayload"](sl)), sl)), sl["fireGestureHandler"]();
                  }, sl["onScrollEnd"] = function () {
                    var sl = {};
                    sl["velocities"] = [0x0, 0x0];
                    sl["velocity"] = 0x0;
                    sl["state"]['Re'] = false, sl["updateGestureState"](hN(hN({}, sl["getMovement"](sl["state"]["values"])), {}, sl)), sl["fireGestureHandler"]();
                  }, sl;
                }
              }
              return hR(sl, sl), sl["prototype"]["addBindings"] = function () {
                this["controller"]["addBindings"]("onScroll", this["onScroll"]);
              }, sl;
            }(Eh);
          function Eu(sl, sl) {
            undefined === sl && (sl = {});
            var sl = P["useState"](function () {
                return new Set(Object["keys"](sl)["map"](function (sl) {
                  return sl["replace"](/End|Start/, '');
                }));
              })[0x0],
              sl = sl,
              sl = sl["drag"],
              sl = sl["wheel"],
              sl = sl["move"],
              sl = sl["scroll"],
              sl = sl["pinch"],
              sl = sl["hover"],
              sl = function (sl) {
                undefined === sl && (sl = {});
                var sl = sl,
                  sl = sl["eventOptions"],
                  sl = (sl = undefined === sl ? {} : sl)["passive"],
                  jx = undefined === sl || sl,
                  sl = sl["capture"],
                  jh = undefined !== sl && sl,
                  jE = sl["pointer"],
                  jg = undefined !== jE && jE,
                  jA = sl["window"],
                  jh = undefined === jA ? Eg : jA,
                  jh = sl["domTarget"],
                  jj = undefined === jh ? undefined : jh,
                  jP = sl["enabled"],
                  jT = undefined === jP || jP;
                var jU = {};
                jU["enabled"] = jT;
                jU["domTarget"] = jj;
                jU["window"] = jh;
                jU["eventOptions"] = {};
                jU["captureString"] = jh ? "Capture" : '';
                jU["pointer"] = !!jg;
                jU["eventOptions"]["passive"] = !jj || !!jx;
                jU["eventOptions"]["capture"] = !!jh;
                return hN(hN({}, hB(sl, ["eventOptions", "window", "domTarget", "enabled"])), {}, jU);
              }(hB(sl, ["drag", "wheel", "move", "scroll", "pinch", "hover"])),
              sl = [],
              xM = {},
              sl = hN({}, sl);
            var sl = {};
            sl["enabled"] = true;
            return sl["has"]("onDrag") && (sl["push"](EE), xM["drag"] = Ep(sl, "onDrag", sl), sl["drag"] = function (sl) {
              undefined === sl && (sl = {});
              var sl = sl,
                sl = sl["enabled"],
                sl = sl["threshold"],
                jx = sl["bounds"],
                sl = sl["rubberband"],
                jh = sl["initial"],
                jE = hB(sl, ["enabled", "threshold", "bounds", "rubberband", "initial"]),
                jg = jE["swipeVelocity"],
                jA = undefined === jg ? 0.5 : jg,
                jh = jE["swipeDistance"],
                jh = undefined === jh ? 0x3c : jh,
                jj = jE["delay"],
                jP = undefined !== jj && jj,
                jT = jE["filterTaps"],
                jU = undefined !== jT && jT,
                jW = jE["axis"],
                ju = jE["lockDirection"];
              undefined === sl ? sl = Math["max"](0x0, jU ? 0x3 : 0x0, ju || jW ? 0x1 : 0x0) : jU = true;
              var jp = {};
              jp["enabled"] = sl;
              jp["threshold"] = sl;
              jp["bounds"] = jx;
              jp["rubberband"] = sl;
              jp["axis"] = jW;
              jp["lockDirection"] = ju;
              jp["initial"] = jh;
              var jL = Es(hv(jp, sl));
              return hN(hN({}, jL), {}, {
                'filterTaps': jU || jL["threshold"][0x0] + jL["threshold"][0x1] > 0x0,
                'swipeVelocity': hD(jA),
                'swipeDistance': hD(jh),
                'delay': "number" == typeof jP ? jP : jP ? 0xb4 : 0x0
              });
            }(sl)), sl["has"]("onWheel") && (sl["push"](ET), xM["wheel"] = Ep(sl, "onWheel", sl), sl["wheel"] = Es(sl)), sl["has"]("onScroll") && (sl["push"](EW), xM["scroll"] = Ep(sl, "onScroll", sl), sl["scroll"] = Es(sl)), sl["has"]("onMove") && (sl["push"](EU), xM["move"] = Ep(sl, "onMove", sl), sl["move"] = Es(sl)), sl["has"]("onPinch") && (sl["push"](EP), xM["pinch"] = Ep(sl, "onPinch", sl), sl["pinch"] = function (sl) {
              undefined === sl && (sl = {});
              var sl = sl,
                sl = sl["distanceBounds"],
                sl = undefined === sl ? {} : sl,
                jx = sl["angleBounds"],
                sl = undefined === jx ? {} : jx,
                jh = hB(sl, ["distanceBounds", "angleBounds"]),
                jE = [[hz(sl["min"], -0x1 / 0x0), hz(sl["max"], 0x1 / 0x0)], [hz(sl["min"], -0x1 / 0x0), hz(sl["max"], 0x1 / 0x0)]];
              var jg = {};
              jg["bounds"] = jE;
              return hN(hN({}, Ed(jh)), {}, jg);
            }(sl)), sl["has"]("onHover") && (sl["has"]("onMove") || sl["push"](EU), xM["hover"] = sl["onHover"], sl["hover"] = hN(sl, sl), delete sl["onHover"]), function (sl, sl, sl, sl) {
              var jx = P["useMemo"](function () {
                var sl = new Ex();
                return {
                  'nativeRefs': sl,
                  'current': sl,
                  'bind': function () {
                    sl["resetBindings"]();
                    for (var jh = arguments["length"], jE = Array(jh), jg = 0x0; jg < jh; jg++) jE[jg] = arguments[jg];
                    for (var jA, jh = hl(sl); !(jA = jh())["done"];) new (0x0, jA["value"])(sl, jE)["addBindings"]();
                    if (jx["nativeRefs"]) for (var jh in jx["nativeRefs"]) sl["addBindings"](jh, jx["nativeRefs"][jh]);
                    return sl["getBind"]();
                  }
                };
              }, []);
              return jx["current"]["config"] = sl, jx["current"]["handlers"] = sl, jx["nativeRefs"] = sl, P["useEffect"](function () {
                return jx["current"]["clean"];
              }, []), jx["bind"];
            }(xM, sl, sl, sl);
          }
          function Ep(sl, sl, sl) {
            var sl = sl + "Start",
              sl = sl + "End";
            return delete sl[sl], delete sl[sl], delete sl[sl], function (sl) {
              {
                var sl = undefined;
                return sl["first"] && sl in sl && sl[sl](sl), sl in sl && (sl = sl[sl](sl)), sl["last"] && sl in sl && sl[sl](sl), sl;
              }
            };
          }
          var EL = {},
            Em = {};
          var EF = {};
          EF["value"] = true;
          Object["defineProperty"](Em, "__esModule", EF);
          var Ea = {};
          Ea["display"] = "flex";
          Ea["width"] = "inherit";
          Ea["height"] = "50px";
          Ea["margin"] = "0 auto 5px auto";
          Ea["justifyContent"] = "center";
          Ea["alignItems"] = "center";
          Ea["paddingLeft"] = "10px";
          Ea["paddingRight"] = "10px";
          var EQ = {};
          EQ["fontSize"] = "11px";
          EQ["textAlign"] = "center";
          EQ["wordBreak"] = "break-word";
          var EM = {};
          EM["width"] = "2px";
          EM["height"] = "12px";
          EM["marginLeft"] = "10px";
          EM["marginRight"] = "10px";
          var EI = {};
          EI["color"] = "rgba(255, 255, 255, 0.4)";
          var Ek = {};
          Ek["backgroundColor"] = "#282833";
          var Ef = {};
          Ef["labels"] = EI;
          Ef["separator"] = Ek;
          var EG = __importDefault(P),
            Ey = shell["I18n"],
            Ea = Ea,
            EQ = EQ,
            EM = EM,
            Ef = Ef;
          Em["default"] = function (sl) {
            var sl = sl["betSizeTitle"] ? sl["betSizeTitle"] : Ey['t']("History.HistoryBetSize"),
              sl = sl["betLevelTitle"] ? sl["betLevelTitle"] : Ey['t']("History.HistoryBetLevel"),
              sl = Ef,
              sl = Object["assign"]({}, EQ, sl["labels"]),
              sl = Object["assign"]({}, EM, sl["separator"]);
            sl["color"] = sl["labelColor"] ? sl["labelColor"] : sl["color"], sl["backgroundColor"] = sl["seperatorColor"] ? sl["seperatorColor"] : sl["backgroundColor"];
            var sl = __assign({}, Ea);
            var sl = {};
            sl['id'] = "bet-size-label";
            sl["style"] = sl;
            var sl = {};
            sl['id'] = "separator";
            sl["style"] = sl;
            var sl = {};
            sl['id'] = "bet-level-label";
            sl["style"] = sl;
            return sl["isRTL"] && (sl["direction"] = "rtl"), EG["default"]["createElement"]("div", {
              'id': "bet-information-container",
              'style': sl
            }, function (sl) {
              if (sl["totalRoundCount"] && sl["currentRoundCount"]) {
                var sl = sl["roundsTitlei18nKey"] ? sl["roundsTitlei18nKey"] : "History.HistoryDetailItemRoundLabel",
                  xM = Ey['t'](sl, {
                    'currCount': sl["currentRoundCount"]["toString"](),
                    'maxCount': sl["totalRoundCount"]["toString"]()
                  }),
                  sl = sl["themeColor"] ? sl["themeColor"] : "#9C9B9B";
                var sl = {};
                sl["color"] = sl;
                return EG["default"]["createElement"]("div", {
                  'id': "rounds-label",
                  'style': Object["assign"]({}, EQ, sl)
                }, xM);
              }
            }(sl), function (sl) {
              if (sl["totalRoundCount"] && sl["currentRoundCount"]) {
                var sl = Object["assign"]({}, EM, Ef["separator"]);
                var xM = {};
                xM['id'] = "separator";
                xM["style"] = sl;
                return EG["default"]["createElement"]("div", xM);
              }
            }(sl), EG["default"]["createElement"]("div", sl, sl + '\x20' + sl["betSize"]), EG["default"]["createElement"]("div", sl), EG["default"]["createElement"]("div", sl, sl + '\x20' + sl["betLevel"]));
          };
          var EX = {};
          var EJ = {};
          EJ["value"] = true;
          Object["defineProperty"](EX, "__esModule", EJ);
          var EV = {};
          EV["display"] = "flex";
          EV["width"] = "inherit";
          EV["height"] = "48px";
          EV["justifyContent"] = "center";
          EV["alignItems"] = "center";
          EV["margin"] = "0 auto";
          var EN = {};
          EN["fontSize"] = "14px";
          var ER = {};
          ER["noComboContainer"] = EV;
          ER["text"] = EN;
          var EB = {};
          EB["color"] = "#CCCCCC";
          var EY = __importDefault(P),
            El = shell["I18n"],
            ER = ER,
            EB = EB;
          EX["default"] = function (sl) {
            var sl = Object["assign"]({}, ER["text"], EB);
            var sl = {};
            sl['id'] = "no-winning-combination-container";
            sl["style"] = ER["noComboContainer"];
            return sl["color"] = sl["labelColor"] ? sl["labelColor"] : sl["color"], EY["default"]["createElement"]("div", sl, EY["default"]["createElement"]("div", {
              'id': "no-winning-combination-text",
              'style': sl
            }, El['t']("History.HistoryNoWinning")));
          };
          var ED = {},
            Eo = {},
            Ez = {},
            Ev = {};
          var EO = {};
          EO["value"] = true;
          Object["defineProperty"](Ev, "__esModule", EO);
          var EK = {};
          EK["writable"] = false;
          EK["value"] = undefined;
          EK["enumerable"] = false;
          EK["configurable"] = false;
          function g1(sl, sl, sl) {
            for (var sl = sl["length"], sl = 0x0; sl < sl; sl++) {
              var sl = sl[sl];
              sl && sl(sl, sl);
            }
          }
          var g2 = {};
          g2["value"] = true;
          Ev["unwatch"] = function (sl, sl, sl) {
            if ("object" != typeof sl || null === sl) throw Error("Invalid parameter at index 0");
            if ("string" != typeof sl || '' === sl) throw Error("Invalid parameter at index 1");
            var sl = sl["watch_eventPool"];
            if (sl) {
              {
                var sl = sl[sl];
                if (sl) if (undefined === sl) sl["length"] = 0x0;else {
                  var sl = sl["indexOf"](sl);
                  -0x1 !== sl && sl["splice"](sl, 0x1);
                }
              }
            }
          }, Ev["watch"] = function (sl, sl, sl) {
            {
              if ("object" != typeof sl || null === sl) throw Error("Invalid parameter at index 0");
              if ("string" != typeof sl || '' === sl) throw Error("Invalid parameter at index 1");
              if ("function" != typeof sl) throw Error("Invalid parameter at index 2");
              var sl = sl["watch_eventPool"];
              if (!sl) {
                if (!Object["isExtensible"](sl)) throw Error("Object is not extensible");
                sl = EK["value"] = Object["create"](null), Object["defineProperty"](sl, "watch_eventPool", EK);
              }
              var sl = sl[sl];
              if (!sl) {
                {
                  var sl = Object["getOwnPropertyDescriptor"](sl, sl);
                  if (!sl) throw Error("Object property not exists");
                  if (false === sl["writable"] || undefined !== sl["get"] && undefined === sl["set"]) throw Error("Object property is readonly");
                  if (!sl["configurable"]) throw Error("Object property is not configurable");
                  sl = sl[sl] = [], function (sl, sl, sl) {
                    if (sl["writable"]) {
                      var sl = sl["value"];
                      sl["get"] = function () {
                        return sl;
                      }, sl["set"] = function (xM) {
                        sl = xM, g1(this["watch_eventPool"][sl], xM, sl);
                      }, delete sl["value"], delete sl["writable"];
                    } else if (sl["get"]) {
                      var sl = sl["set"];
                      sl["set"] = function (xM) {
                        sl["call"](this, xM), g1(this["watch_eventPool"][sl], this[sl]);
                      };
                    } else {
                      var sl = sl["set"];
                      sl["set"] = function (xM) {
                        sl["call"](this, xM), g1(this["watch_eventPool"][sl], xM);
                      };
                    }
                    Object["defineProperty"](sl, sl, sl);
                  }(sl, sl, sl);
                }
              }
              if (-0x1 !== sl["indexOf"](sl)) throw Error("Watch callback exists");
              sl["push"](sl);
            }
          }, Object["defineProperty"](Ez, "__esModule", g2);
          var Ev = Ev,
            g4 = new (function () {
              function sl() {
                var sl = {};
                sl["isActive"] = false;
                sl["title"] = '';
                sl["desc"] = '';
                sl["posY"] = 0x0;
                this["tooltipProps"] = sl;
              }
              return sl["prototype"]["observe"] = function (sl, sl, sl) {
                var sl,
                  sl,
                  sl = this;
                return sl && undefined !== this[sl] && sl(this[sl], this), (sl = this, sl = sl, function (sl) {
                  var sl = sl["bind"](undefined, undefined);
                  Ev["watch"](sl, sl, sl);
                })(function (sl, sl, sl) {
                  sl || undefined === sl || JSON["stringify"](sl) === JSON["stringify"](sl) || sl(sl, sl);
                });
              }, sl["prototype"]["dispose"] = function (sl) {
                {
                  Ev["unwatch"](this, sl);
                }
              }, sl["prototype"]["update"] = function (sl) {
                this["tooltipProps"] = sl;
              }, sl;
            }())();
          var g5 = {};
          g5["value"] = true;
          Ez["tooltipViewModel"] = g4, Object["defineProperty"](Eo, "__esModule", g5);
          var g6 = {};
          g6["width"] = "300px";
          g6["height"] = "48px";
          g6["display"] = "flex";
          var g7 = {};
          g7["width"] = "285px";
          var g8 = {};
          g8["width"] = "15px";
          var g9 = {};
          g9["transform"] = "scale(0.3333)";
          g9["transformOrigin"] = "center left";
          g9["opacity"] = "40%";
          var gC = {};
          gC["wrappedContent"] = g6;
          gC["childrenContent"] = g7;
          gC["infoIconContent"] = g8;
          gC["infoIcon"] = g9;
          var gx = __importDefault(P),
            Ez = Ez,
            gC = gC,
            gE = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                return sl['qe'] = undefined, sl['Xe'] = false, sl;
              }
              return __extends(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                this['Ke']();
              }, sl["prototype"]["componentDidUpdate"] = function () {
                this['Ke']();
              }, sl["prototype"]['Ke'] = function () {
                {
                  var sl = this;
                  this['Xe'] = false, clearTimeout(this['qe']), this['qe'] = setTimeout(function () {
                    sl['Xe'] = true;
                  }, 0x0);
                }
              }, sl["prototype"]["componentWillUnmount"] = function () {
                clearTimeout(this['qe']);
              }, sl["prototype"]['Je'] = function (sl, sl) {
                undefined === sl && (sl = false);
                var sl = sl ? sl["map"](function (sl) {
                  {
                    return shell["I18n"]['t'](sl);
                  }
                }) : sl;
                return this["props"]["isRTL"] && (sl = sl["reverse"]()), sl["join"](" x ");
              }, sl["prototype"]['Ze'] = function (sl) {
                var sl = this;
                if (this['Xe']) {
                  var sl = sl["currentTarget"],
                    sl = sl["parentNode"],
                    sl = Array["prototype"]["indexOf"]["call"](sl["children"], sl),
                    sl = 0x30 * (sl["children"]["length"] - 0x1 - sl),
                    sl = Object["keys"](this["props"]["winCalculation"]),
                    sl = sl["map"](function (sl) {
                      return sl["props"]["winCalculation"][sl];
                    }),
                    sl = {
                      'isActive': true,
                      'posY': sl,
                      'title': this['Je'](sl, true),
                      'desc': this['Je'](sl)
                    };
                  Ez["tooltipViewModel"]["currentTarget"] = sl, Ez["tooltipViewModel"]["update"](sl);
                }
              }, sl["prototype"]['$e'] = function (sl) {
                sl["currentTarget"]["style"]["opacity"] = "0.8";
              }, sl["prototype"]['Qe'] = function (sl) {
                sl["currentTarget"]["style"]["opacity"] = '1';
              }, sl["prototype"]["render"] = function () {
                var sl = [];
                var sl = {};
                sl["key"] = "wrapper-content";
                sl["style"] = gC["childrenContent"];
                var sl = {};
                sl["key"] = "icon-content";
                sl["style"] = gC["infoIconContent"];
                var sl = {};
                sl["className"] = "gh_basic_sprite gh_ic_nav_info_s";
                sl["style"] = gC["infoIcon"];
                return sl["push"](gx["default"]["createElement"]("div", sl, this["props"]["children"])), sl["push"](gx["default"]["createElement"]("div", sl, gx["default"]["createElement"]("div", sl))), gx["default"]["createElement"]("div", {
                  'style': gC["wrappedContent"],
                  'onMouseDown': this['$e']["bind"](this),
                  'onMouseUp': this['Qe']["bind"](this),
                  'onTouchStart': this['$e']["bind"](this),
                  'onTouchEnd': this['Qe']["bind"](this),
                  'onClick': this['Ze']["bind"](this)
                }, this["props"]["isRTL"] ? sl["reverse"]() : sl);
              }, sl;
            }(gx["default"]["Component"]);
          var gg = {};
          gg["value"] = true;
          Eo["default"] = gE, Object["defineProperty"](ED, "__esModule", gg);
          var gA = {};
          gA["display"] = "flex";
          gA["width"] = "inherit";
          gA["justifyContent"] = "space-between";
          gA["alignItems"] = "center";
          gA["height"] = "48px";
          gA["margin"] = "0 auto";
          var gd = {};
          gd["display"] = "flex";
          gd["alignItems"] = "center";
          gd["height"] = "inherit";
          var gs = {};
          gs["display"] = "flex";
          gs["flexDirection"] = "column";
          var gj = {};
          gj["width"] = "38px";
          gj["height"] = "24px";
          var gP = {};
          gP["width"] = "25px";
          gP["fontSize"] = "14px";
          gP["textAlign"] = "left";
          var gT = {};
          gT["width"] = "100px";
          gT["fontSize"] = "14px";
          gT["textAlign"] = "right";
          var gU = {};
          gU["width"] = "100px";
          gU["fontSize"] = "11px";
          gU["textAlign"] = "right";
          var gW = {};
          gW["paylineContainer"] = gA;
          gW["paylineNumberImageWrapper"] = gd;
          gW["paylineLabels"] = gs;
          gW["paylineImage"] = gj;
          gW["winLineLabel"] = gP;
          gW["winValueLabel"] = gT;
          gW["subValueLabel"] = gU;
          var gu = {};
          gu["color"] = "#CCCCCC";
          var gp = {};
          gp["color"] = "#CCCCCC";
          var gL = {};
          gL["color"] = "#9C9B9B";
          var gm = {};
          gm["winLineLabel"] = gu;
          gm["winValueLabel"] = gp;
          gm["subValueLabel"] = gL;
          var gF = __importDefault(P),
            gQ = __importDefault(Eo),
            gW = gW,
            gm = gm;
          ED["default"] = function (sl) {
            var sl = gm,
              sl = Object["assign"]({}, gW["winLineLabel"], sl["winLineLabel"]),
              sl = Object["assign"]({}, gW["winValueLabel"], sl["winValueLabel"]),
              sl = __assign({}, gW["paylineContainer"]);
            sl["color"] = sl["winLineLabelColor"] ? sl["winLineLabelColor"] : sl["color"], sl["color"] = sl["winValueLabelColor"] ? sl["winValueLabelColor"] : sl["color"], sl["isRTL"] && (sl["direction"] = "rtl", sl["textAlign"] = "right", sl["textAlign"] = "left");
            var sl = {};
            sl['id'] = "payline-container";
            sl["style"] = sl;
            var sl = {};
            sl['id'] = "payline-number-sprite-wrapper";
            sl["style"] = gW["paylineNumberImageWrapper"];
            var sl = {};
            sl['id'] = "win-line-number-label";
            sl["style"] = sl;
            var sl = gF["default"]["createElement"]("div", sl, gF["default"]["createElement"]("div", sl, gF["default"]["createElement"]("div", sl, ('0' + parseInt(sl["winLine"], 0xa)["toString"]())["slice"](-0x2)), function (sl) {
              var sl = sl["paylineSpriteClassName"],
                sl = sl["paylineImageMap"],
                xM = sl["paylineImageStyle"],
                sl = sl["winLine"],
                sl = sl["isRTL"];
              if (sl) {
                var sl = {};
                sl["width"] = gW["paylineImage"]["width"];
                sl["height"] = gW["paylineImage"]["height"];
                var sl = sl[sl],
                  sl = sl || '',
                  sl = sl,
                  jx = Object["assign"]({}, sl, xM || {});
                return sl && (jx["transformOrigin"] = "right"), gF["default"]["createElement"]("span", {
                  'className': sl + '\x20' + sl,
                  'style': jx
                });
              }
              return null;
            }(sl)), gF["default"]["createElement"]("div", {
              'id': "payline-labels",
              'style': gW["paylineLabels"]
            }, gF["default"]["createElement"]("div", {
              'id': "payline-win-value-label",
              'style': sl
            }, sl["winValue"]), function (sl) {
              {
                var sl = sl["subValue"],
                  sl = sl["subValueLabelColor"],
                  xM = sl["isRTL"],
                  sl = Object["assign"]({}, gW["subValueLabel"], gm["subValueLabel"]);
                return sl["color"] = sl || sl["color"], xM && (sl["textAlign"] = "left"), sl ? gF["default"]["createElement"]("div", {
                  'id': "payline-subvalue-label",
                  'style': sl
                }, gF["default"]["createElement"]("bdi", null, sl)) : null;
              }
            }(sl)));
            return sl["winCalculation"] ? gF["default"]["createElement"](gQ["default"], {
              'isRTL': sl["isRTL"],
              'winCalculation': sl["winCalculation"]
            }, sl) : sl;
          };
          var gk = {};
          var gf = {};
          gf["value"] = true;
          Object["defineProperty"](gk, "__esModule", gf);
          var gG = {};
          gG["display"] = "flex";
          gG["width"] = "inherit";
          gG["height"] = "32px";
          gG["justifyContent"] = "center";
          gG["alignItems"] = "center";
          gG["margin"] = "0 auto";
          var gy = {};
          gy["width"] = "120px";
          var gb = {};
          gb["textAlign"] = "center";
          gb["width"] = "72px";
          gb["fontSize"] = "11px";
          var gZ = {};
          gZ["payoutTitleContainer"] = gG;
          gZ["line"] = gy;
          gZ["text"] = gb;
          var gc = {};
          gc["backgroundColor"] = "#282833";
          gc["height"] = "2px";
          var gS = {};
          gS["color"] = "#9C9B9B";
          var gX = {};
          gX["line"] = gc;
          gX["text"] = gS;
          var gJ = __importDefault(P),
            gZ = gZ,
            gX = gX;
          gk["default"] = function (sl) {
            var sl = gX,
              sl = Object["assign"]({}, gZ["line"], sl["line"]),
              sl = Object["assign"]({}, gZ["text"], sl["text"]);
            var sl = {};
            sl['id'] = "payout-title-container";
            sl["style"] = gZ["payoutTitleContainer"];
            return sl["backgroundColor"] = sl["lineColor"] ? sl["lineColor"] : sl["backgroundColor"], sl["color"] = sl["labelColor"] ? sl["labelColor"] : sl["color"], gJ["default"]["createElement"]("div", sl, gJ["default"]["createElement"]("div", {
              'className': "line",
              'style': sl
            }), gJ["default"]["createElement"]("div", {
              'id': "payout-text",
              'style': sl
            }, shell["I18n"]['t']("History.HistoryPayout")), gJ["default"]["createElement"]("div", {
              'className': "line",
              'style': sl
            }));
          };
          var gR = {};
          var gB = {};
          gB["value"] = true;
          Object["defineProperty"](gR, "__esModule", gB);
          var gY = {};
          gY["display"] = "flex";
          gY["width"] = "inherit";
          gY["height"] = "50px";
          gY["margin"] = "0 auto";
          gY["justifyContent"] = "center";
          gY["alignItems"] = "center";
          var gl = {};
          gl["display"] = "flex";
          gl["flexDirection"] = "column";
          gl["alignItems"] = "center";
          var gw = {};
          gw["textAlign"] = "center";
          gw["display"] = "inline-table";
          var gq = {};
          gq["textAlign"] = "center";
          gq["fontSize"] = "11px";
          var gD = {};
          gD["backgroundColor"] = "#24242E";
          var gz = {};
          gz["color"] = "#9C9B9B";
          var gv = {};
          gv["color"] = "#9C9B9B";
          var gO = {};
          gO["container"] = gD;
          gO["valueLabel"] = gz;
          gO["titleLabel"] = gv;
          var gK = {};
          gK["backgroundColor"] = "#262121";
          var A0 = {};
          A0["color"] = "#A7A6A6";
          var A1 = {};
          A1["color"] = "rgba(167,166,166, 0.5)";
          var A2 = {};
          A2["container"] = gK;
          A2["valueLabel"] = A0;
          A2["titleLabel"] = A1;
          var A3 = __importDefault(P),
            A4 = shell["I18n"],
            gY = gY,
            gl = gl,
            gw = gw,
            gq = gq,
            gO = gO,
            A2 = A2;
          function Ax(sl) {
            var sl = {};
            sl["width"] = sl["size"];
            sl["marginLeft"] = sl["marginLeft"];
            var sl = {};
            sl["fontSize"] = "11px";
            var sl = {};
            sl["fontSize"] = "12px";
            var sl = Object["assign"]({}, gl, sl),
              sl = sl["useSmallFont"] ? sl : sl;
            sl["lineHeight"] = sl["valueLineHeight"] ? sl["valueLineHeight"] : sl["fontSize"];
            var sl = sl["isCard"] ? A2 : gO,
              sl = Object["assign"]({}, gw, sl["valueLabel"]),
              sl = Object["assign"]({}, gq, sl["titleLabel"]);
            var sl = {};
            sl["className"] = "transaction-detail-item";
            sl["style"] = sl;
            var sl = {};
            sl["height"] = "23px";
            sl["display"] = "flex";
            sl["justifyContent"] = "center";
            sl["alignItems"] = "center";
            var sl = {};
            sl['id'] = "detail-item-holder";
            sl["style"] = sl;
            return sl["color"] = sl["valueLabelColor"] ? sl["valueLabelColor"] : sl["color"], sl["color"] = sl["keyLabelColor"] ? sl["keyLabelColor"] : sl["color"], A3["default"]["createElement"]("div", sl, A3["default"]["createElement"]("div", sl, A3["default"]["createElement"]("div", {
              'id': sl["keyName"] + "-item-value",
              'style': Object["assign"]({}, sl, sl)
            }, sl["value"])), A3["default"]["createElement"]("div", {
              'id': sl["keyName"] + "-item-key",
              'style': sl
            }, sl["keyName"]));
          }
          function AH(sl, sl) {
            return sl ? sl + '(' + sl + ')' : '' + sl;
          }
          function Ah(sl, sl) {
            if (undefined === sl && (sl = 0xe), sl["length"] > sl && sl["indexOf"]('\x20') < 0x0) {
              {
                var sl = Math["floor"](sl["length"] / 0x2);
                return sl["slice"](0x0, sl) + '\x20' + sl["slice"](sl, sl["length"]);
              }
            }
            return sl;
          }
          gR["default"] = function (sl) {
            var sl = sl["isCard"] ? A2 : gO,
              sl = Object["assign"]({}, gY, sl["container"]),
              sl = AH(sl["currencySymbol"], A4['t']("History.HistoryRecordPayout")),
              sl = AH(sl["currencySymbol"], A4['t']("History.HistoryRecordWin")),
              sl = AH(sl["currencySymbol"], A4['t']("History.HistoryRecordBalance")),
              sl = sl["transactionId"]["length"] > 0xe || sl["betValue"]["length"] > 0xa || sl["profitValue"]["length"] > 0xa || sl["balance"]["length"] > 0x10,
              sl = Ah(sl["transactionId"]);
            return sl["backgroundColor"] = sl["backgroundColor"] ? sl["backgroundColor"] : sl["backgroundColor"], sl["isRTL"] && (sl["direction"] = "rtl"), A3["default"]["createElement"]("div", {
              'id': "transaction-details-container",
              'style': sl
            }, A3["default"]["createElement"](Ax, {
              'keyName': A4['t']("History.HistoryRecordTransaction"),
              'value': sl,
              'size': "27%",
              'useSmallFont': sl,
              'valueLineHeight': "12px",
              'isCard': sl["isCard"],
              'keyLabelColor': sl["keyLabelColor"],
              'valueLabelColor': sl["valueLabelColor"]
            }), A3["default"]["createElement"](Ax, {
              'keyName': sl,
              'value': Ah(sl["betValue"], 0xb),
              'size': "18%",
              'marginLeft': "10px",
              'useSmallFont': sl,
              'valueLineHeight': "12px",
              'isCard': sl["isCard"],
              'keyLabelColor': sl["keyLabelColor"],
              'valueLabelColor': sl["valueLabelColor"]
            }), A3["default"]["createElement"](Ax, {
              'keyName': sl,
              'value': Ah(sl["profitValue"], 0xc),
              'size': "20%",
              'marginLeft': "10px",
              'useSmallFont': sl,
              'valueLineHeight': "12px",
              'isCard': sl["isCard"],
              'keyLabelColor': sl["keyLabelColor"],
              'valueLabelColor': sl["valueLabelColor"]
            }), A3["default"]["createElement"](Ax, {
              'keyName': sl,
              'value': Ah(sl["balance"], 0x11),
              'size': "27%",
              'marginLeft': "10px",
              'useSmallFont': sl,
              'valueLineHeight': "12px",
              'isCard': sl["isCard"],
              'keyLabelColor': sl["keyLabelColor"],
              'valueLabelColor': sl["valueLabelColor"]
            }));
          };
          var AE = {};
          var Ag = {};
          Ag["value"] = true;
          Object["defineProperty"](AE, "__esModule", Ag);
          var AA = {};
          AA["fontSize"] = "12px";
          AA["textAlign"] = "left";
          AA["padding"] = "0px 8px";
          var Ad = {};
          Ad["color"] = "#808080";
          Ad["fontSize"] = "12px";
          Ad["textAlign"] = "left";
          Ad["padding"] = "0px 8px";
          var As = {};
          As["position"] = "relative";
          As["width"] = "300px";
          As["height"] = "inherit";
          As["alignSelf"] = "center";
          var Aj = {};
          Aj["content"] = '\x20';
          Aj["left"] = "90%";
          Aj["border"] = "solid transparent";
          Aj["height"] = '0';
          Aj["width"] = '0';
          Aj["position"] = "absolute";
          Aj["pointerEvents"] = "none";
          Aj["borderWidth"] = "6px";
          Aj["marginLeft"] = '-6';
          Aj["borderBottomColor"] = "#464653";
          Aj["bottom"] = "98%";
          var AP = {};
          AP["backgroundColor"] = "#464653";
          AP["color"] = "#fff";
          AP["borderRadius"] = "6px";
          AP["padding"] = "5px";
          var AT = {};
          AT["descText"] = AA;
          AT["titleText"] = Ad;
          AT["tooltip"] = As;
          AT["tooltipArrow"] = Aj;
          AT["tooltipToast"] = AP;
          var AU = __importDefault(P),
            Ez = Ez,
            AT = AT;
          function Ap(sl) {
            var sl = {};
            sl["isActive"] = false;
            Ez["tooltipViewModel"]["currentTarget"] && Ez["tooltipViewModel"]["currentTarget"]["contains"](sl["target"]) && sl["stopPropagation"](), Ez["tooltipViewModel"]["update"](sl), document["body"]["removeEventListener"]("click", Ap);
          }
          var AL = function (sl) {
            {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                var sl = {};
                sl["isActive"] = false;
                sl["title"] = '';
                sl["desc"] = '';
                sl["posY"] = 0x0;
                return sl["state"] = sl, sl;
              }
              return __extends(sl, sl), sl["prototype"]["componentDidUpdate"] = function () {
                {
                  this["state"]["isActive"] && document["body"]["addEventListener"]("click", Ap);
                }
              }, sl["prototype"]["componentWillUnmount"] = function () {
                document["body"]["removeEventListener"]("click", Ap), Ez["tooltipViewModel"]["dispose"]("tooltipProps");
              }, sl["prototype"]["componentDidMount"] = function () {
                var sl = this;
                Ez["tooltipViewModel"]["observe"]("tooltipProps", function (sl) {
                  var sl = {};
                  sl["isActive"] = sl["isActive"];
                  sl["title"] = sl["title"];
                  sl["desc"] = sl["desc"];
                  sl["posY"] = sl["posY"];
                  sl["setState"](sl);
                });
              }, sl["prototype"]["render"] = function () {
                var sl = this["state"]["isActive"] ? "visible" : "hidden",
                  sl = this["state"]["desc"],
                  sl = this["state"]["title"],
                  sl = this["state"]["posY"],
                  sl = __assign(__assign({}, AT["tooltip"]), {
                    'visibility': sl,
                    'top': '-' + sl + 'px'
                  }),
                  sl = __assign({}, AT["titleText"]),
                  sl = __assign({}, AT["descText"]),
                  sl = __assign({}, AT["tooltipArrow"]);
                if (this["props"]["isRTL"]) {
                  sl["textAlign"] = "right", sl["textAlign"] = "right";
                  var sl = sl["left"];
                  sl["right"] = sl, delete sl["left"];
                }
                var sl = {};
                sl['id'] = "tooltip";
                sl["style"] = sl;
                var xM = {};
                xM["style"] = sl;
                var sl = {};
                sl['id'] = "tooltip-toast";
                sl["style"] = AT["tooltipToast"];
                var sl = {};
                sl['id'] = "tooltip-title";
                sl["style"] = sl;
                var sl = {};
                sl['id'] = "tooltip-desc";
                sl["style"] = sl;
                return AU["default"]["createElement"]("div", sl, AU["default"]["createElement"]("div", xM), AU["default"]["createElement"]("div", sl, AU["default"]["createElement"]("div", sl, sl), AU["default"]["createElement"]("div", sl, sl)));
              }, sl;
            }
          }(AU["default"]["Component"]);
          AE["default"] = AL;
          var Am = {};
          var AF = {};
          AF["value"] = true;
          !function (sl) {
            {
              var sl;
              var sl = {};
              sl["value"] = true;
              Object["defineProperty"](sl, "__esModule", sl), (sl = sl["WinCalculation"] || (sl["WinCalculation"] = {}))["BET_SIZE"] = "History.HistoryTipsBetSize", sl["BET_LEVEL"] = "History.HistoryTipsBetLevel", sl["PAYOUT"] = "History.HistoryTipsPayout", sl["WAYS"] = "History.HistoryTipsWay", sl["COUNTS"] = "History.HistoryTipsSymbolCount", sl["MULTIPLIER"] = "History.HistoryTipsMultiplier";
            }
          }(Am), Object["defineProperty"](EL, "__esModule", AF);
          var Aa = __importDefault(Em);
          EL["BetInformation"] = Aa["default"];
          var AQ = __importDefault(EX);
          EL["NoWinningCombination"] = AQ["default"];
          var AM = __importDefault(ED);
          EL["Payline"] = AM["default"];
          var AI = __importDefault(gk);
          EL["PayoutTitle"] = AI["default"];
          var Ak = __importDefault(gR),
            Af = EL["TransactionDetails"] = Ak["default"],
            AG = __importDefault(AE);
          EL["Tooltip"] = AG["default"];
          var Ay = __importDefault(Eo);
          EL["TooltipWrapper"] = Ay["default"];
          EL["WinCalculation"] = Am["WinCalculation"];
          var AZ = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this,
                  sl = document["getElementById"]("game-history-container"),
                  sl = HX["isPortrait"] || HX["isMobile"],
                  sl = sl ? sl["offsetHeight"] : 0x280;
                return sl['ti'] = sl ? Ho() : 0x58, sl['ei'] = sl ? 0x70 + Hq() : 0x8a, sl["state"] = {
                  'parentHeight': sl - sl['ti'],
                  'scrollHeight': sl - sl['ei']
                }, sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                HX["context"]["event"]['on']("Shell.Scaled", this['ii'], this), HX["isMobile"] && Hw() && 0x5a === shell["environment"]["getOrientation"]() && document["querySelectorAll"](".rcs-custom-scroll .rcs-inner-container")["forEach"](function (sl) {
                  sl["style"]["webkitOverflowScrolling"] = "auto";
                });
              }, sl["prototype"]["componentWillUnmount"] = function () {
                HX["context"]["event"]["off"]("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["shouldComponentUpdate"] = function (sl, sl) {
                {
                  return sl["betDetailsModel"] !== this["props"]["betDetailsModel"] || sl["currentIndexViewed"] !== this["props"]["currentIndexViewed"] || sl["pageWidth"] !== this["props"]["pageWidth"] || sl["scrollHeight"] !== this["state"]["scrollHeight"] || sl["parentHeight"] !== this["state"]["parentHeight"];
                }
              }, sl["prototype"]["render"] = function () {
                return P["createElement"]("div", {
                  'id': "game-details-page-container",
                  'style': {
                    'height': ''["concat"](this["state"]["parentHeight"], 'px')
                  }
                }, this['ni'](this["props"], this["state"]));
              }, sl["prototype"]['ni'] = function (sl, sl) {
                var sl = this,
                  sl = sl["currentIndexViewed"],
                  sl = sl["betDetailsModel"],
                  sl = [],
                  sl = [];
                if (sl["length"] < 0x4) sl = sl["map"](function (xM, sl) {
                  return sl['ri'](sl, sl, sl);
                });else {
                  if (0x0 === sl) sl = [0x0, 0x1, 0x2];else if (sl === sl["length"] - 0x1) {
                    var sl = sl["length"] - 0x1;
                    sl = [sl - 0x2, sl - 0x1, sl];
                  } else sl = [sl - 0x1, sl], !(sl + 0x1 > sl["length"]) && sl["push"](sl + 0x1);
                  sl = sl["map"](function (xM) {
                    return sl['ri'](xM, sl, sl);
                  });
                }
                var sl = {};
                sl["position"] = "relative";
                var sl = {};
                sl['id'] = "game-pages-window";
                sl["style"] = sl;
                return P["createElement"]("div", sl, sl);
              }, sl["prototype"]['oi'] = function (sl) {
                var sl = sl["totalBetAmount"],
                  sl = sl["totalWinLossAmount"],
                  sl = sl["balance"],
                  sl = sl["transactionId"];
                return this["props"]["useDefaultTransactionHeader"] ? P["createElement"](Af, {
                  'isRTL': shell["isRTLLanguage"](),
                  'currencySymbol': xb["getDefaultCurrencyFormat"]()["currencySymbol"],
                  'transactionId': sl + '',
                  'betValue': xb["formatCurrency"](sl, ''),
                  'profitValue': xb["formatCurrency"](sl, ''),
                  'balance': xb["formatCurrency"](sl, ''),
                  'backgroundColor': HX["appearanceHelper"]["transactionDetailsHeaderColor"],
                  'keyLabelColor': HX["appearanceHelper"]["transactionDetailsHeaderKeyFontColor"],
                  'valueLabelColor': HX["appearanceHelper"]["transactionDetailsHeaderValueFontColor"],
                  'isCard': HX["launchType"] === xS["CARD"]
                }) : null;
              }, sl["prototype"]['ri'] = function (sl, sl, sl) {
                var sl = sl["gameDetailComponent"],
                  sl = sl["betDetailsModel"],
                  sl = sl["pageWidth"],
                  sl = sl["currentIndexViewed"],
                  sl = sl["parentHeight"],
                  sl = sl["scrollHeight"],
                  sl = sl[sl],
                  xM = {
                    'width': "100%",
                    'height': sl,
                    'position': "absolute",
                    'left': ''["concat"](sl * sl, 'px')
                  };
                var sl = {};
                sl["className"] = "game-list-page";
                sl["key"] = sl;
                sl["style"] = xM;
                var sl = {};
                sl["className"] = "reset";
                return P["createElement"]("div", sl, P["createElement"]("div", sl, this['oi'](sl), P["createElement"]("div", {
                  'className': "history regular",
                  'style': {
                    'width': "inherit",
                    'height': ''["concat"](sl, 'px')
                  }
                }, this['ai'](sl, sl, sl === sl))));
              }, sl["prototype"]['ai'] = function (sl, sl, sl) {
                var sl = sl["gameDetail"],
                  sl = HX["replayVersion"] ? 0x76 : 0x56;
                var sl = {};
                sl["heightRelativeToParent"] = "inherit";
                return P["createElement"](hj["default"], sl, P["createElement"](sl, {
                  'data': sl,
                  'isBO': false,
                  'isCurrentPage': sl,
                  'isRTL': shell["isRTLLanguage"]()
                }), P["createElement"]("div", {
                  'id': "game-detail-padding",
                  'style': {
                    'width': "inherit",
                    'height': ''["concat"](sl, 'px')
                  }
                }));
              }, sl["prototype"]['ii'] = function (sl) {
                var sl = sl["payload"],
                  sl = HX["isPortrait"] || HX["isMobile"] ? sl["height"] : 0x280,
                  sl = sl - this['ti'],
                  sl = sl - this['ei'];
                var sl = {};
                sl["parentHeight"] = sl;
                sl["scrollHeight"] = sl;
                this["setState"](sl);
              }, sl;
            }(P["Component"]),
            Ac = "land" === shell["environment"]["getOrientationMode"]() ? 0x14 : 0x46,
            AS = xb["timeoutCallback"];
          function AX(sl) {
            {
              var sl = U(null),
                sl = xk(W(0x0), 0x2),
                sl = sl[0x0],
                sl = sl[0x1],
                sl = xk(W(sl["pageWidth"]), 0x2),
                sl = sl[0x0],
                sl = sl[0x1],
                sl = xk(W(false), 0x2),
                sl = sl[0x0],
                sl = sl[0x1],
                sl = xk(W(false), 0x2),
                xM = sl[0x0],
                sl = sl[0x1],
                sl = xk(W(false), 0x2),
                sl = sl[0x0],
                sl = sl[0x1],
                sl = sl,
                sl = 0x0 === sl,
                jx = xk(y(function () {
                  var jh = {};
                  jh['x'] = -sl * sl;
                  return jh;
                }), 0x2),
                sl = jx[0x0]['x'],
                jh = jx[0x1];
              T(function () {
                {
                  sl !== sl["pageIndex"] && (sl(sl["pageIndex"]), jh({
                    'x': -sl["pageIndex"] * sl["pageWidth"],
                    'config': xY,
                    'immediate': sl["noAnim"]
                  }), sl(true), AS(0.3)(function () {
                    sl(false), sl(false);
                  })), sl !== sl["pageWidth"] && (sl(sl["pageWidth"]), jh({
                    'x': -sl["pageIndex"] * sl["pageWidth"],
                    'config': xY,
                    'immediate': true
                  }));
                }
              }, [sl["pageIndex"], sl["pageWidth"]]);
              var jE = {};
              jE["capture"] = false;
              jE["passive"] = false;
              var jg = {};
              jg["swipeDistance"] = 0xa;
              jg["swipeVelocity"] = 0.3;
              var jA = Eu({
                'onDrag': function (jh) {
                  return function (jh) {
                    var jj = xk(jh["delta"], 0x2),
                      jP = jj[0x0],
                      jT = jj[0x1],
                      jU = xk(jh["movement"], 0x2),
                      jW = jU[0x0],
                      ju = jU[0x1],
                      jp = xk(jh["swipe"], 0x2),
                      jL = jp[0x0],
                      jm = jp[0x1],
                      jF = jh["velocity"],
                      ja = jh["down"],
                      jQ = jh["cancel"],
                      jM = jh["canceled"];
                    if (-0x1 !== jh["memo"]) {
                      var ja = Math["abs"](jW),
                        jk = Math["abs"](ju),
                        jP = jP,
                        jW = jW,
                        jL = jL;
                      if (!HX["isMobile"] || shell["environment"]["isMac"]() || HX["isPortrait"] || shell["environment"]["getOrientation"]() !== xV["PORTRAIT"] || (ja = Math["abs"](ju), jk = Math["abs"](jW), jP = jT, jW = ju, jL = jm), !xM && !sl && jk > Ac && sl(true), !xM && !sl && ja > 0x14 && sl(true), !ja || jM) {
                        {
                          if (xM) ;else if (sl) {
                            if (!sl && (function (jN, jR) {
                              return jN >= jR / 0x2;
                            }(ja, sl) || 0x0 !== jL)) {
                              if (sl = function (jN, jR, jB) {
                                var jY = jN + jR;
                                return jY > jB - 0x1 ? jB - 0x1 : jY < 0x0 ? 0x0 === jN ? -0x1 : 0x0 : jY;
                              }(sl, jW < 0x0 ? 0x1 : -0x1, sl["betDetailsModel"]["length"]), sl === (sl = shell["isRTLLanguage"]() && sl <= -0x1 ? 0x0 : sl)) {
                                var jZ = {};
                                jZ["tension"] = xY["tension"];
                                jZ["friction"] = xY["friction"];
                                jZ["velocity"] = xY["velocity"] * (jF < 0x1 ? 0x1 : jF);
                                jZ["clamp"] = sl !== sl["betDetailsModel"]["length"] - 0x1;
                                var jS = {};
                                jS['x'] = -sl * sl;
                                jS["config"] = jZ;
                                jh(jS);
                              } else sl["updateIndexCallback"] && sl !== sl["pageIndex"] && sl["updateIndexCallback"](sl);
                              return sl;
                            }
                            var jX = {};
                            jX['x'] = -sl * sl;
                            jX["config"] = xY;
                            jX["immediate"] = false;
                            jh(jX);
                          }
                          sl(false), sl(false);
                        }
                      } else if (xM) ;else if (sl) {
                        {
                          var jJ = {};
                          jJ['x'] = jW + -sl * sl;
                          jJ["from"] = jW - jP + -sl * sl;
                          jJ["immediate"] = false;
                          jh(jJ);
                          var jV = function (jN, jR, jB, jY) {
                            return undefined === jN && (jN = false), !!(jN && jR > jY / 0x2 || jB > jY);
                          }(sl, jW, ja, sl);
                          jV && ja && jQ();
                        }
                      }
                    }
                  }(jh);
                }
              }, {
                'domTarget': sl,
                'eventOptions': jE,
                'drag': jg
              });
              return T(jA, [jA]), 0x0 === sl["pageIndex"] && sl !== sl["pageIndex"] && (sl = 0x0), P["createElement"](b["div"], {
                'id': "game-detail-spring-wrapper",
                'ref': sl,
                'style': Object["assign"]({}, sl["style"], {
                  'transform': sl["interpolate"](function (jh) {
                    return 'ie' === shell["environment"]["getBrowserBaseType"]() ? "translateX("["concat"](jh, "px)") : "translate3d("["concat"](jh, "px, 0, 0)");
                  })
                })
              }, P["createElement"](AZ, {
                'gameDetailComponent': sl["gameDetailComponent"],
                'betDetailsModel': sl["betDetailsModel"],
                'currentIndexViewed': sl,
                'useDefaultTransactionHeader': sl["useDefaultTransactionHeader"],
                'pageWidth': sl
              }), sl["additionalComponents"] && sl["additionalComponents"]());
            }
          }
          function AJ() {
            var sl = {};
            sl["backgroundColor"] = HX["appearanceHelper"]["highlightFontColor"];
            var sl = sl,
              sl = {
                'borderColor': "transparent transparent transparent "["concat"](HX["appearanceHelper"]["themeColor"])
              };
            var sl = {};
            sl["className"] = "replay-icon-container";
            var sl = {};
            sl["className"] = "replay-icon-bg";
            sl["style"] = sl;
            var sl = {};
            sl["className"] = "replay-icon-triangle";
            sl["style"] = sl;
            return P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", sl)));
          }
          function AV(sl) {
            {
              var sl = {};
              sl["backgroundColor"] = HX["appearanceHelper"]["themeColor"];
              var sl = U(null),
                sl = U(null),
                sl = sl,
                sl = {
                  'color': HX["appearanceHelper"]["highlightFontColor"],
                  'transform': "scale("["concat"](sl["scale"], ')')
                };
              return T(function () {
                if (sl && sl["current"] && sl && sl["current"]) {
                  var sl = Math["round"](sl["current"]["offsetWidth"] / 0x2);
                  sl["current"]["style"]["marginLeft"] = '-'["concat"](sl, 'px');
                }
              }), P["createElement"]("div", {
                'className': "replay-button-bg",
                'onClick': sl["onClickCallback"],
                'style': sl
              }, P["createElement"](AJ, null), P["createElement"]("div", {
                'className': "replay-spin-label-wrapper",
                'ref': sl
              }, P["createElement"]("div", {
                'className': "replay-spin-label",
                'style': sl,
                'ref': sl
              }, sl["text"])));
            }
          }
          function AN(sl, sl) {
            return function () {
              var sl = sl["betDetailsRaw"],
                sl = sl["quitFunction"],
                sl = sl["selectedTransactionId"],
                sl = 0x0;
              sl["forEach"](function (sl, sl) {
                sl["tid"] === sl && (sl = sl);
              });
              var sl,
                sl = {
                  'replayType': sl,
                  'selectedIndex': sl,
                  'replayData': (sl = sl, sl["map"](function (sl) {
                    return sl['gd'];
                  }))
                };
              sl && sl(function () {
                var sl = {};
                sl["actionName"] = "StartReplay";
                HX["context"]["emit"]("Analytics.Event", sl), HX["context"]["emit"]("Game.RequestReplay", sl);
              });
            };
          }
          function AR(sl) {
            var sl = function (sl) {
                return sl["betDetailsRaw"]["length"] > 0x1 && HX["replayVersion"] > 0x1;
              }(sl),
              sl = xk(W(0x1), 0x2),
              sl = sl[0x0],
              sl = sl[0x1];
            T(function () {
              var sl = document["querySelectorAll"](".replay-spin-label"),
                sl = document["querySelectorAll"](".replay-spin-label-wrapper")[0x0]["offsetWidth"] - 0x5;
              sl["forEach"](function (sl) {
                if (sl["offsetWidth"] > sl) {
                  var sl = sl / sl["offsetWidth"];
                  sl < sl && sl(sl);
                }
              });
            });
            var sl = sl ? "space-between" : "center";
            var sl = {};
            sl["justifyContent"] = sl;
            var sl = {};
            sl['id'] = "replay-buttons-container";
            sl["style"] = sl;
            return P["createElement"]("div", sl, sl && P["createElement"](AV, {
              'onClickCallback': AN(sl, "Round"),
              'scale': sl,
              'text': shell["I18n"]['t']("History.HistoryReplayRound")
            }), P["createElement"](AV, {
              'onClickCallback': AN(sl, "Spin"),
              'scale': sl,
              'text': shell["I18n"]['t']("History.HistoryReplaySpin")
            }));
          }
          "undefined" != typeof NodeList && NodeList["prototype"] && !NodeList["prototype"]["forEach"] && (NodeList["prototype"]["forEach"] = Array["prototype"]["forEach"]);
          var AB = j("BetDetailModel", function (sl) {
              {
                var sl = sl['bl'],
                  sl = sl['bt'],
                  sl = sl['gd'],
                  sl = sl['ib'],
                  sl = sl["tba"],
                  sl = sl["tid"],
                  sl = sl["twla"];
                this["balance"] = sl, this["betTime"] = sl, this["transactionStartTime"] = sl ? sl["tst"] : undefined, this["isBot"] = sl, this["totalBetAmount"] = sl, this["transactionId"] = sl, this["totalWinLossAmount"] = sl, this["gameDetail"] = JSON["parse"](JSON["stringify"](sl));
              }
            }),
            AY = xb["formatCurrency"],
            Al = xb["timeoutCallback"];
          function Aw(sl, sl) {
            {
              return new Promise(function (sl, sl) {
                var sl = new plugin["Loader"]();
                sl["onLoad"] = function (sl) {
                  {
                    sl(sl["response"]);
                  }
                }, sl["onError"] = function (sl) {
                  sl(sl);
                }, sl["load"]([{
                  'src': sl,
                  'type': sl,
                  'maxAttemptCount': 0x0
                }]);
              });
            }
          }
          function Aq(sl) {
            if (HX["isMobile"]) {
              if (HX["isPortrait"]) return 0x168;
              var sl = document["getElementById"]("game-history-container");
              return (sl || sl["offsetWidth"]) - 0x33;
            }
            return 0x168;
          }
          var AD = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                sl['si'] = [], sl['li'] = [], sl['ci'] = false, sl['hi'] = false, sl['ke'] = HX["launchType"] === xS["CARD"], sl['ti'] = HX["isPortrait"] || HX["isMobile"] ? Ho() : 0x58;
                var sl = document["getElementById"]("game-history-container"),
                  sl = HX["isPortrait"] || HX["isMobile"] ? sl["offsetHeight"] : 0x280,
                  sl = Aq();
                return sl["state"] = {
                  'viewState': xX["HistoryDetails"],
                  'betDetailModel': undefined,
                  'isLoading': true,
                  'gameDetailComponent': null,
                  'pages': 0x0,
                  'pageIndex': 0x0,
                  'parentHeight': sl - sl['ti'],
                  'noAnimation': false,
                  'detailsPageWidth': sl
                }, sl['ui'] = sl['ui']["bind"](sl), sl['di'] = sl['di']["bind"](sl), sl['fi'] = sl['fi']["bind"](sl), sl['gi'] = sl['gi']["bind"](sl), sl['vi'] = sl['vi']["bind"](sl), sl['mi'] = sl['mi']["bind"](sl), sl['pi'] = sl['pi']["bind"](sl), sl['bi'] = sl['bi']["bind"](sl), sl['yi'] = function () {
                  return function () {
                    return shell["I18n"]['t']("History.HistoryNormalSpin");
                  };
                }, sl['xi'] = function () {
                  {
                    return function () {
                      return shell["I18n"]['t']("History.HistoryNormalSpin");
                    };
                  }
                }, sl['_i'] = function () {
                  return function () {
                    return false;
                  };
                }, sl['wi'] = function () {
                  {
                    return true;
                  }
                }, sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidUpdate"] = function (sl) {
                if (sl["betDetailsRaw"] !== this["props"]["betDetailsRaw"] && sl["gameId"] === this["props"]["gameId"] && this["state"]["gameDetailComponent"]) {
                  var sl = hA[this["props"]["gameId"]];
                  var sl = {};
                  sl["pageIndex"] = 0x0;
                  sl["noAnimation"] = true;
                  sl["viewState"] = xX["HistoryDetails"];
                  this['Ci'](sl), this["setState"](sl);
                }
              }, sl["prototype"]["componentDidMount"] = function () {
                HX["context"]["event"]['on']("Shell.Scaled", this['ii'], this), this['ki'](this["props"]["gameId"]);
              }, sl["prototype"]["componentWillUnmount"] = function () {
                var sl = this['Si'],
                  sl = this['zi'];
                sl && sl(), sl && sl(), this['Si'] = undefined, this['zi'] = undefined, HX["context"]["event"]["off"]("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["render"] = function () {
                var sl = this["state"]["viewState"],
                  sl = {
                    'backgroundColor': HX["appearanceHelper"]["detailBackgroundColor"],
                    'color': HX["appearanceHelper"]["primaryFontColor"],
                    'overflow': sl === xX["HistoryFreeSpinDetails"] ? '' : "hidden"
                  },
                  sl = "Safari" === shell["environment"]["getBrowserBaseType"]() ? "subpixel-antialiased" : "antialiased",
                  sl = "Safari" === shell["environment"]["getBrowserBaseType"]() && HX["isMobile"] ? {} : {
                    'WebkitFontSmoothing': sl
                  };
                return P["createElement"]("div", {
                  'id': "game-details-view-container",
                  'style': xa(xa({}, sl), sl)
                }, this['Di'](this["state"]), this['Hi'](this["state"]));
              }, sl["prototype"]['fi'] = function (sl) {
                -0x1 === sl ? this["props"]["navLeftButtonCallback"] && this["props"]["navLeftButtonCallback"]() : this["setState"]({
                  'pageIndex': sl,
                  'noAnimation': false
                });
              }, sl["prototype"]['di'] = function () {
                var sl = this["state"]["pageIndex"];
                sl + 0x1 < this["state"]["pages"] && this['fi'](sl + 0x1);
              }, sl["prototype"]['ui'] = function () {
                {
                  var sl = this["state"]["pageIndex"];
                  sl - 0x1 > -0x1 && this['fi'](sl - 0x1);
                }
              }, sl["prototype"]['pi'] = function () {
                var sl = this["state"],
                  sl = sl["viewState"],
                  sl = sl["pageIndex"],
                  sl = this['si'][sl],
                  sl = this['li'];
                this['_i'](sl, sl)() && sl["length"] > 0x1 && (sl === xX["HistoryDetails"] ? this["setState"]({
                  'viewState': xX["HistoryFreeSpinDetails"]
                }) : sl === xX["HistoryFreeSpinDetails"] && this['bi'](-0x1));
              }, sl["prototype"]['bi'] = function (sl) {
                var sl = this["state"]["pageIndex"],
                  sl = sl > -0x1 ? this['si']["indexOf"](sl) : sl;
                var sl = {};
                sl["viewState"] = xX["HistoryDetails"];
                sl["pageIndex"] = sl;
                sl["noAnimation"] = true;
                this["setState"](sl);
              }, sl["prototype"]['gi'] = function () {
                this["state"]["viewState"] === xX["HistoryFreeSpinDetails"] && this["setState"]({
                  'viewState': xX["HistoryDetails"],
                  'noAnimation': true
                }), this["props"]["navLeftButtonCallback"] && this["props"]["navLeftButtonCallback"]();
              }, sl["prototype"]['vi'] = function () {
                this["props"]["navRightButtonCallback"] && this["props"]["navRightButtonCallback"]();
              }, sl["prototype"]['ki'] = function (sl) {
                var sl = this,
                  sl = this["props"]["betDetailsRaw"]["length"] > 0x5 ? 0.5 : 0x0;
                this['ji'] = undefined, this["state"]["isLoading"] ? this['Oi']() : this['Ni'](), this['Si'] = Al(sl)(function () {
                  {
                    sl['Ti'](sl);
                  }
                });
              }, sl["prototype"]['Ti'] = function (sl) {
                var sl = hA[sl],
                  sl = hd[sl];
                this['Si'] = undefined, sl ? (this['Mi'](sl), this['Ci'](sl), sl ? (this["setState"]({
                  'gameDetailComponent': sl
                }), this['Pi'](0.25)) : this['Li'](sl)) : this['Fi']();
              }, sl["prototype"]['Fi'] = function () {
                var sl = this;
                Aw(shell["getGameContext"]()["resource"]["resolveUrl"](''["concat"]("history", "/index.json")), plugin["LoadType"]["Json"])["then"](function (sl) {
                  shell["isValidAssets"](sl) && (sl = shell["parseAssets"](sl)), sl["version"];
                  var sl,
                    sl = sl["assets"],
                    sl = sl["main"];
                  return sl = sl["assets"], shell["getGameContext"]()["resource"]["addAssets"](sl), Aw(shell["getGameContext"]()["resource"]["resolveUrl"](sl), plugin["LoadType"]["SystemScript"]);
                })["then"](function (sl) {
                  var sl = sl["GHBetDetailModule"];
                  hA[sl["props"]["gameId"]] = sl, sl['Ii'](sl);
                })["catch"](function () {
                  var sl = shell["Error"],
                    sl = shell["ClientError"],
                    sl = new sl(sl["Domain"], sl["GameLoadResourceError"]);
                  var sl = {};
                  sl["gameDetailComponent"] = null;
                  HY("History Game Details Load Module Error", sl["domain"], sl["code"], undefined, "gameId: "["concat"](sl["props"]["gameId"])), sl['ji'] = sl, sl["setState"](sl), sl['Bi']();
                });
              }, sl["prototype"]['Ii'] = function (sl) {
                {
                  hA[this["props"]["gameId"]] = sl, this['Mi'](sl), this['Ci'](sl), this['Li'](sl);
                }
              }, sl["prototype"]['Li'] = function (sl) {
                var sl = this;
                sl["initialize"](shell["getGameContext"](), HX["operatorContext"])["then"](function (sl) {
                  {
                    hd[sl["props"]["gameId"]] = sl, sl["setState"]({
                      'gameDetailComponent': sl
                    }), sl['Bi']();
                  }
                })["catch"](function (sl) {
                  {
                    if (!(sl instanceof shell["Error"])) {
                      var sl = shell["Error"],
                        sl = shell["ClientError"];
                      sl = new sl(sl["Domain"], sl["GameLoadResourceError"]);
                    }
                    var sl = {};
                    sl["gameDetailComponent"] = null;
                    HY("History Game Details Init Module Error", sl["domain"], sl["code"], undefined, "gameId: "["concat"](sl["props"]["gameId"])), sl['ji'] = sl, sl["setState"](sl), sl['Bi']();
                  }
                });
              }, sl["prototype"]['Mi'] = function (sl) {
                this['yi'] = function (sl, sl) {
                  {
                    return function () {
                      {
                        return sl["getNavTitle"](sl, sl);
                      }
                    };
                  }
                }, this['xi'] = function (sl, sl) {
                  return function (sl) {
                    return sl["getAdditionalSpinsTitle"](sl, sl, sl);
                  };
                }, this['_i'] = function (sl, sl) {
                  return function () {
                    return sl["showNavArrowDropDown"](sl, sl);
                  };
                }, this['wi'] = function () {
                  return !sl["useDefaultTransactionDetailsHeader"] || sl["useDefaultTransactionDetailsHeader"]();
                };
              }, sl["prototype"]['Ri'] = function () {
                var sl = [];
                return this["props"]["betDetailsRaw"]["forEach"](function (sl) {
                  var sl = new AB(sl);
                  sl["push"](sl);
                }), sl;
              }, sl["prototype"]['Ci'] = function (sl) {
                var sl = this['Ri'](),
                  sl = this['Ri'](),
                  sl = [];
                sl["forEach"](function (sl, sl) {
                  sl[sl] = sl;
                }), sl["compileAllHistoryDataBecomePages"] && (sl = sl["compileAllHistoryDataBecomePages"](sl)), sl["compileAllHistoryDataForFreeSpinList"] && (sl = sl["compileAllHistoryDataForFreeSpinList"](sl), sl["length"] = 0x0, sl["forEach"](function (sl, sl) {
                  isNaN(sl["customFreeSpinTitleIndex"]) ? sl["forEach"](function (sl, sl) {
                    sl["betTime"] <= sl["betTime"] && (sl[sl] = sl);
                  }) : sl[sl] = sl["customFreeSpinTitleIndex"];
                })), this['si'] = sl, this['li'] = sl, this["setState"]({
                  'betDetailModel': sl,
                  'pages': sl["length"]
                });
              }, sl["prototype"]['Ai'] = function () {
                if (this["state"]["pages"] > 0x0 && 0x0 !== this["state"]["pageIndex"]) {
                  {
                    var sl = {};
                    sl["top"] = !HX["isPortrait"] && HX["isMobile"] ? "50%" : "calc(50% - 85px)";
                    sl["backgroundColor"] = HX["appearanceHelper"]["pagesButtonBackgroundColor"];
                    var sl = {};
                    sl["borderColor"] = HX["appearanceHelper"]["pagesButtonArrowColor"];
                    var sl = sl,
                      sl = sl,
                      sl = HX["isMobile"] ? "gh-angle-horizontal-mobile" : "gh-angle-horizontal";
                    var sl = {};
                    sl['id'] = "game-details-left-arrow";
                    sl["key"] = "game-details-left-arrow";
                    sl["onClick"] = this['ui'];
                    sl["style"] = sl;
                    var sl = {};
                    sl["transform"] = "translateX(4px) scale(0.7)";
                    var sl = {};
                    sl["className"] = "gh-angle-wrapper";
                    sl["style"] = sl;
                    return P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", {
                      'className': ''["concat"](sl, " angle-left"),
                      'style': sl
                    })));
                  }
                }
                return null;
              }, sl["prototype"]['Ei'] = function () {
                if (this["state"]["pages"] > 0x0 && this["state"]["pageIndex"] !== this["state"]["pages"] - 0x1) {
                  var sl = {};
                  sl["top"] = !HX["isPortrait"] && HX["isMobile"] ? "50%" : "calc(50% - 85px)";
                  sl["backgroundColor"] = HX["appearanceHelper"]["pagesButtonBackgroundColor"];
                  var sl = {};
                  sl["borderColor"] = HX["appearanceHelper"]["pagesButtonArrowColor"];
                  var sl = sl,
                    sl = sl,
                    sl = HX["isMobile"] ? "gh-angle-horizontal-mobile" : "gh-angle-horizontal";
                  var sl = {};
                  sl['id'] = "game-details-right-arrow";
                  sl["key"] = "game-details-right-arrow";
                  sl["onClick"] = this['di'];
                  sl["style"] = sl;
                  var sl = {};
                  sl["transform"] = "translateX(-4px) scale(0.7)";
                  var sl = {};
                  sl["className"] = "gh-angle-wrapper";
                  sl["style"] = sl;
                  return P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", {
                    'className': ''["concat"](sl, " angle-right"),
                    'style': sl
                  })));
                }
                return null;
              }, sl["prototype"]['Di'] = function (sl) {
                {
                  var sl = sl["isLoading"],
                    sl = sl["pageIndex"],
                    sl = sl["viewState"];
                  if (sl["gameDetailComponent"] && !sl && !this['ji']) {
                    var sl = this['si'][sl],
                      sl = this['li'],
                      sl = HX["isPortrait"] || HX["isMobile"] ? Hq() : 0x0,
                      sl = HX["isPortrait"] || HX["isMobile"] ? 0x3e : 0x58,
                      sl = this['ke'] ? "game-list-nav-vertical-card" : '',
                      sl = HX["appearanceHelper"]["navBarColor"];
                    var xM = {};
                    xM["position"] = "absolute";
                    xM["zIndex"] = 0x4;
                    xM["height"] = "inherit";
                    xM["width"] = "inherit";
                    var sl = {};
                    sl["style"] = xM;
                    return P["createElement"]("div", {
                      'id': "game-detail-view-navbar-container",
                      'key': "game-detail-view-navbar-container",
                      'className': sl,
                      'style': {
                        'height': ''["concat"](sl, 'px'),
                        'paddingTop': ''["concat"](sl, 'px'),
                        'backgroundColor': sl
                      }
                    }, P["createElement"]("div", sl, P["createElement"](hQ, {
                      'showTitle': this['yi'](sl, sl),
                      'titleClickCallback': this['pi'],
                      'currentState': sl,
                      'currentCalendarType': undefined,
                      'currentCalendarState': undefined,
                      'leftButtonClickedCallback': this['gi'],
                      'rightButtonClickedCallback': this['vi'],
                      'showDropDownArrow': this['_i'](sl, sl),
                      'betTime': sl["length"] > 0x0 ? sl[sl]["betTime"] : 0x0,
                      'transactionStartTime': sl["length"] > 0x0 ? sl[sl]["transactionStartTime"] : 0x0
                    })));
                  }
                }
              }, sl["prototype"]['ni'] = function (sl) {
                var sl = sl["gameDetailComponent"],
                  sl = sl["pageIndex"],
                  sl = sl["betDetailModel"],
                  sl = sl["noAnimation"],
                  sl = sl["detailsPageWidth"],
                  sl = HX["isPortrait"] || HX["isMobile"] ? 0x1 : 1.6875;
                return P["createElement"](AX, {
                  'key': "game-detail-page-wrapper",
                  'gameDetailComponent': sl,
                  'betDetailsModel': sl,
                  'pageIndex': sl,
                  'updateIndexCallback': this['fi'],
                  'style': {
                    'position': "absolute",
                    'height': this["state"]["parentHeight"] / sl
                  },
                  'noAnim': sl,
                  'useDefaultTransactionHeader': this['wi'](),
                  'pageWidth': sl
                });
              }, sl["prototype"]['mi'] = function (sl, sl) {
                return function () {
                  {
                    var sl = sl["betDetailsRaw"],
                      sl = sl["quitCallback"],
                      sl = sl["pageIndex"],
                      sl = sl["betDetailModel"][sl]["transactionId"];
                    var sl = {};
                    sl["key"] = "game-replay-buttons-container";
                    sl["selectedTransactionId"] = sl;
                    sl["betDetailsRaw"] = sl;
                    sl["quitFunction"] = sl;
                    sl["gameId"] = sl["gameId"];
                    if (HX["replayVersion"] && !HX["isApiReplay"]) return P["createElement"](AR, sl);
                  }
                };
              }, sl["prototype"]['Wi'] = function (sl) {
                var sl = this,
                  sl = sl["pageIndex"],
                  sl = sl["viewState"],
                  sl = sl["parentHeight"],
                  sl = [],
                  sl = this['li'];
                sl["forEach"](function (sl) {
                  var sl = AY(sl["totalWinLossAmount"]);
                  sl["push"](sl);
                });
                var sl = this['si'][sl];
                var sl = {};
                sl["bottom"] = "100%";
                var sl = {};
                sl["bottom"] = '0%';
                var xM = {};
                xM["bottom"] = "100%";
                var sl = {};
                sl["key"] = "game-free-spin-list-view-transition";
                sl["config"] = xY;
                sl["items"] = sl;
                sl["from"] = sl;
                sl["enter"] = sl;
                sl["leave"] = xM;
                return P["createElement"](k, sl, function (sl) {
                  return sl === xX["HistoryFreeSpinDetails"] && function (sl) {
                    var sl = {};
                    sl["left"] = '0';
                    sl["position"] = "absolute";
                    sl["width"] = "inherit";
                    sl["height"] = sl;
                    sl["zIndex"] = 0x5;
                    sl["transform"] = "translate3d(0, 0, 0)";
                    return P["createElement"](G["div"], {
                      'style': xa(xa({}, sl), sl)
                    }, P["createElement"](hu, {
                      'key': "game-free-spin-list-view",
                      'totalCount': sl["length"],
                      'currentSelectedIndex': sl,
                      'winLostAmountArrary': sl,
                      'getTitleText': sl['xi'](sl, sl),
                      'onClickCallback': sl['bi'],
                      'onPageClickCallback': sl['bi'],
                      'parentHeight': sl
                    }));
                  };
                });
              }, sl["prototype"]['Hi'] = function (sl) {
                var sl = this,
                  sl = sl["isLoading"],
                  sl = [];
                var sl = {};
                sl["key"] = "loading-page";
                sl["isHorizontal"] = !HX["isPortrait"];
                sl["isMobile"] = HX["isMobile"];
                sl["fromSide"] = true;
                return !sl["gameDetailComponent"] || sl || this['ji'] ? !sl && this['ji'] ? (sl["push"](P["createElement"](hg, {
                  'key': "game-history-view-error",
                  'error': this['ji'],
                  'retryButtonCallback': function () {
                    {
                      sl['ki'](sl["props"]["gameId"]);
                    }
                  },
                  'closeButtonCallback': this["props"]["quitCallback"],
                  'orientation': "port"
                })), sl) : (sl["push"](P["createElement"](hM, sl)), sl) : (sl["push"](this['ni'](sl)), sl["push"](this['Ai']()), sl["push"](this['Ei']()), sl["push"](this['mi'](this["props"], this["state"])()), sl["push"](this['Wi'](sl)), sl);
              }, sl["prototype"]['ii'] = function (sl) {
                var sl = sl["payload"],
                  sl = (HX["isPortrait"] || HX["isMobile"] ? sl["height"] : 0x280) - this['ti'],
                  sl = Aq(sl["width"]);
                var sl = {};
                sl["parentHeight"] = sl;
                sl["detailsPageWidth"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['Ni'] = function () {
                var sl = {};
                sl["isLoading"] = true;
                this['ci'] = false, this['hi'] = false, this["setState"](sl), this['Oi']();
              }, sl["prototype"]['Oi'] = function (sl) {
                var sl = this;
                undefined === sl && (sl = 0x1), this['zi'] = Al(sl)(function () {
                  sl['ci'] = true, sl['Bi']();
                });
              }, sl["prototype"]['Pi'] = function (sl) {
                undefined === sl && (sl = 0x0);
                var sl = this['zi'];
                sl && sl(), this['zi'] = undefined, this['Oi'](sl);
              }, sl["prototype"]['Bi'] = function () {
                var sl = {};
                sl["isLoading"] = false;
                this['hi'] = true, this['ci'] && this['hi'] && this["setState"](sl);
              }, sl;
            }(P["PureComponent"]),
            Ao = shell["I18n"];
          function Az(sl) {
            var sl = HX["displayConfig"],
              sl = sl["listHeaderLabelCol1"],
              sl = sl["listHeaderLabelCol2"],
              sl = sl["listHeaderLabelCol3"],
              sl = sl["listHeaderLabelCol4"],
              sl = [];
            var sl = {};
            sl["className"] = "game-list-nav-table-item";
            sl["key"] = "game-list-nav-table-item-custom";
            var sl = {};
            sl["className"] = "game-list-nav-table-item";
            sl["key"] = "game-list-nav-table-item-time";
            var sl = {};
            sl["className"] = "game-list-nav-table-item";
            sl["key"] = "game-list-nav-table-item-date";
            sl ? sl["push"](P["createElement"]("div", sl, sl)) : (sl["push"](P["createElement"]("div", sl, Ao['t']("History.HistoryMainPageTime"))), sl["push"](P["createElement"]("div", sl, HB(new Date()["getTime"]()))));
            var sl = sl || Ao['t']("History.HistoryMainSpinTypeTime"),
              sl = sl || (sl["currencySymbol"] ? ''["concat"](Ao['t']("History.HistoryMainPagePayout"), '(')["concat"](sl["currencySymbol"], ')') : ''["concat"](Ao['t']("History.HistoryMainPagePayout"))),
              xM = sl || (sl["currencySymbol"] ? ''["concat"](Ao['t']("History.HistoryMainPageWin"), '(')["concat"](sl["currencySymbol"], ')') : ''["concat"](Ao['t']("History.HistoryMainPageWin"))),
              sl = HX["isPortrait"] ? "game-list-nav-table-header-vertical" : HX["isMobile"] ? "game-list-nav-table-header-horizontal-mobile" : "game-list-nav-table-header-horizontal",
              sl = {
                'color': HX["appearanceHelper"]["listHeaderFontColor"],
                'backgroundColor': HX["appearanceHelper"]["listHeaderColor"]
              };
            var sl = {};
            sl["paddingLeft"] = "10px";
            sl["paddingRight"] = "20px";
            sl["direction"] = "rtl";
            var sl = {};
            sl['id'] = "game-list-nav-table-item-container";
            var sl = {};
            sl["className"] = "game-list-nav-table-item";
            var sl = {};
            sl["className"] = "game-list-nav-table-item";
            var jx = {};
            jx["className"] = "game-list-nav-table-item";
            return shell["isRTLLanguage"]() && (sl = xa(xa({}, sl), sl)), P["createElement"]("div", {
              'id': "game-list-nav-table-header",
              'className': sl,
              'style': sl
            }, P["createElement"]("div", sl, sl, '\x20'), P["createElement"]("div", sl, '\x20', sl), P["createElement"]("div", sl, sl), P["createElement"]("div", jx, xM));
          }
          var Av = shell["I18n"],
            AO = function (sl) {
              {
                function sl(sl) {
                  var sl = sl["call"](this, sl) || this;
                  return sl['Yi'] = sl['Yi']["bind"](sl), sl['Gi'] = sl['Gi']["bind"](sl), sl;
                }
                return xF(sl, sl), sl["prototype"]['Yi'] = function () {
                  this["props"]["onItemClicked"] && this["props"]["onItemClicked"](this["props"]["calendarType"]);
                }, sl["prototype"]["render"] = function () {
                  var sl = HX["isPortrait"] ? "calendar-item-container-vertical calendar-item-container" : "calendar-item-container-horizontal calendar-item-container";
                  var sl = {};
                  sl["backgroundColor"] = HX["appearanceHelper"]["calendarBackgroundColor"];
                  var sl = {};
                  sl["className"] = sl;
                  sl["onClick"] = this['Yi'];
                  sl["style"] = sl;
                  return P["createElement"]("div", sl, P["createElement"]("div", {
                    'className': "calendar-item-label",
                    'style': this['Ui']()
                  }, this['Gi']()));
                }, sl["prototype"]['Ui'] = function () {
                  var sl = {};
                  sl["color"] = this["props"]["calendarType"] === this["props"]["currentCalendarType"] ? HX["isPortrait"] ? HX["appearanceHelper"]["themeColor"] : HX["appearanceHelper"]["highlightFontColor"] : HX["appearanceHelper"]["primaryFontColor"];
                  return sl;
                }, sl["prototype"]['Gi'] = function () {
                  var sl;
                  switch (this["props"]["calendarType"]) {
                    case 0x1:
                    default:
                      sl = Av['t']("History.HistoryCalenderToday");
                      break;
                    case 0x2:
                      sl = Av['t']("History.HistoryCalenderWeek");
                      break;
                    case 0x3:
                      sl = Av['t']("History.HistoryCalenderCustom");
                  }
                  return sl;
                }, sl;
              }
            }(P["Component"]),
            AK = function (sl) {
              function sl(sl) {
                {
                  var sl = sl["call"](this, sl) || this,
                    sl = document["getElementById"]("game-history-container");
                  return sl["state"] = {
                    'backgroundHeight': sl["offsetHeight"] - Ho()
                  }, sl['Vi'] = sl['Vi']["bind"](sl), sl['qi'] = sl['qi']["bind"](sl), sl['Xi'] = sl['Xi']["bind"](sl), sl['G'] = sl['G']["bind"](sl), sl;
                }
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                HX["context"]["event"]['on']("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["componentWillUnmount"] = function () {
                HX["context"]["event"]["off"]("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]['Vi'] = function () {
                this["props"]["onChangeCalendarTypeCallback"](0x1);
              }, sl["prototype"]['qi'] = function () {
                this["props"]["onChangeCalendarTypeCallback"](0x2);
              }, sl["prototype"]['Xi'] = function () {
                {
                  this["props"]["onCalendarCustomClicked"]();
                }
              }, sl["prototype"]['G'] = function (sl, sl) {
                {
                  var sl = {};
                  sl["startDate"] = sl;
                  sl["endDate"] = sl;
                  this["props"]["model"]["calendarCustomDateConfig"] = sl, this["props"]["onChangeCalendarTypeCallback"](0x3);
                }
              }, sl["prototype"]["render"] = function () {
                return this["props"]["currentCalendarState"] === xJ["CUSTOM"] ? P["createElement"]("div", {
                  'id': "calendar-view-background",
                  'style': {
                    'height': ''["concat"](this["state"]["backgroundHeight"], 'px')
                  }
                }, this['Ki']()) : P["createElement"]("div", {
                  'id': "calendar-view-background",
                  'style': {
                    'height': ''["concat"](this["state"]["backgroundHeight"], 'px')
                  }
                }, this['Ji']());
              }, sl["prototype"]['Ji'] = function () {
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["calendarBackgroundColor"];
                var sl = {};
                sl['id'] = "calendar-selection-container";
                sl["key"] = "calendar-selection-container";
                sl["style"] = sl;
                var sl = {};
                sl["calendarType"] = 0x1;
                sl["currentCalendarType"] = this["props"]["currentCalendarType"];
                sl["onItemClicked"] = this['Vi'];
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["calendarSeparatorBackgroundColor"];
                var sl = {};
                sl["className"] = "calendar-line-separator";
                sl["style"] = sl;
                var sl = {};
                sl["calendarType"] = 0x2;
                sl["currentCalendarType"] = this["props"]["currentCalendarType"];
                sl["onItemClicked"] = this['qi'];
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["calendarSeparatorBackgroundColor"];
                var sl = {};
                sl["className"] = "calendar-line-separator";
                sl["style"] = sl;
                var sl = {};
                sl["calendarType"] = 0x3;
                sl["currentCalendarType"] = this["props"]["currentCalendarType"];
                sl["onItemClicked"] = this['Xi'];
                return P["createElement"]("div", sl, P["createElement"](AO, sl), P["createElement"]("div", sl), P["createElement"](AO, sl), P["createElement"]("div", sl), P["createElement"](AO, sl));
              }, sl["prototype"]['Ki'] = function () {
                return P["createElement"](xv["CalendarCustomView"], {
                  'key': "calendar-custom-view",
                  'isRTL': shell["isRTLLanguage"](),
                  'caseType': this['Z'](),
                  'themeColor': HX["appearanceHelper"]["calendarColor"],
                  'backgroundColor': HX["appearanceHelper"]["calendarBackgroundColor"],
                  'onConfirmClicked': this['G']
                });
              }, sl["prototype"]['Z'] = function () {
                return HX["launchType"] === xS["CARD"] ? xv["CaseType"]["CARD_GAME"] : xv["CaseType"]["SLOT_GAME"];
              }, sl["prototype"]['ii'] = function (sl) {
                var sl = sl["payload"]["height"] - Ho();
                var sl = {};
                sl["backgroundHeight"] = sl;
                this["setState"](sl);
              }, sl;
            }(P["Component"]);
          function d0(sl) {
            var sl,
              sl = HX["isPortrait"] || HX["isMobile"] ? "14px" : "24px",
              sl = HX["isPortrait"] || HX["isMobile"] ? "0.291" : "0.5";
            if (sl = function () {
              for (var sl = [], sl = 0x0; sl < arguments["length"]; sl++) sl[sl] = arguments[sl];
              var sl = [];
              return sl["forEach"](function (sl) {
                var sl = sl();
                sl && sl["push"](sl);
              }), sl;
            }(function () {
              return function (sl) {
                var sl = sl["gameElements"];
                var sl = {};
                sl["className"] = "game-list-item-image-container";
                sl["key"] = "game-list-item-icon-gift";
                var sl = {};
                sl["className"] = " gh_theme_sprite gh_ic_nav_gift";
                return sl["indexOf"](xw["BonusWallet"]) > -0x1 || sl["indexOf"](xw["FreeGameWallet"]) > -0x1 ? P["createElement"]("div", sl, P["createElement"]("div", sl)) : null;
              }(sl);
            }, function () {
              return function (sl) {
                var sl = {};
                sl["className"] = "game-list-item-image-container";
                sl["key"] = "game-list-item-icon-jackpot";
                var sl = {};
                sl["className"] = " gh_theme_sprite gh_ic_nav_jackpot";
                return sl["gameElements"]["indexOf"](xw["JackpotBet"]) > -0x1 ? P["createElement"]("div", sl, P["createElement"]("div", sl)) : null;
              }(sl);
            }, function () {
              return function (sl) {
                var sl = sl["gameElements"];
                var sl = {};
                sl["className"] = "game-list-item-image-container";
                sl["key"] = "game-list-item-icon-respin";
                var sl = {};
                sl["className"] = "gh_theme_sprite gh_ic_nav_free_spin";
                return sl["indexOf"](xw["ReBet"]) > -0x1 || sl["indexOf"](xw["FreeBet"]) > -0x1 ? P["createElement"]("div", sl, P["createElement"]("div", sl)) : null;
              }(sl);
            }, function () {
              return function (sl) {
                {
                  var sl = {};
                  sl["className"] = "game-list-item-image-container";
                  sl["key"] = "game-list-item-icon-feature";
                  var sl = {};
                  sl["className"] = " gh_theme_sprite gh_ic_nav_bonus_game";
                  return sl["gameElements"]["indexOf"](xw["BonusBet"]) > -0x1 ? P["createElement"]("div", sl, P["createElement"]("div", sl)) : null;
                }
              }(sl);
            }, function () {
              return function (sl) {
                var sl = sl["mainGameCollapseCount"],
                  sl = sl["freeSpinCollapseCount"];
                if (sl > 0x0 || sl > 0x0) {
                  var sl = sl > 0x0 ? '\x20'["concat"](sl, '+')["concat"](sl) : '\x20'["concat"](sl),
                    sl = sl > 0x0 ? "130px" : "100px",
                    sl = HX["isPortrait"] ? "30px" : "34px";
                  var xM = {};
                  xM["className"] = "game-list-item-image-container";
                  var sl = {};
                  sl["className"] = " gh_theme_sprite gh_ic_nav_collapse";
                  var sl = {};
                  sl["fontSize"] = sl;
                  var sl = {};
                  sl["className"] = "game-list-item-collapse-info-label";
                  sl["style"] = sl;
                  return P["createElement"]("div", {
                    'className': "game-list-item-collapse-info",
                    'key': "game-list-item-icon-collapse",
                    'style': {
                      'width': ''["concat"](sl),
                      'backgroundColor': "rgba(0, 0, 0, 0.26)"
                    }
                  }, P["createElement"]("div", xM, P["createElement"]("div", sl)), P["createElement"]("div", sl, sl));
                }
                return null;
              }(sl);
            }, function () {
              return function (sl) {
                {
                  var sl = {};
                  sl["className"] = "game-list-item-image-container";
                  sl["key"] = "game-list-item-icon-super6";
                  var sl = {};
                  sl["className"] = " gh_theme_sprite gh_ic_nav_super6";
                  return sl["gameElements"]["indexOf"](xw["BaccaratSupersix"]) > -0x1 ? P["createElement"]("div", sl, P["createElement"]("div", sl)) : null;
                }
              }(sl);
            }, function () {
              return function (sl) {
                var sl = {};
                sl["className"] = "game-list-item-image-container";
                sl["key"] = "game-list-item-icon-freehand";
                var sl = {};
                sl["className"] = " gh_theme_sprite gh_ic_nav_freehand";
                return sl["gameElements"]["indexOf"](xw["FreeHand"]) > -0x1 ? P["createElement"]("div", sl, P["createElement"]("div", sl)) : null;
              }(sl);
            }), sl["length"] > 0x0) {
              var sl = {
                'height': sl,
                'transform': "scale("["concat"](sl, ')')
              };
              var sl = {};
              sl["transformOrigin"] = "right top";
              return shell["isRTLLanguage"]() && (sl = xa(xa({}, sl), sl)), P["createElement"]("div", {
                'className': "game-list-item-feature-container",
                'key': "game-list-item-feature-container",
                'style': sl
              }, sl);
            }
            return null;
          }
          function d1(sl, sl) {
            if (undefined === sl && (sl = 0xe), sl["length"] > sl) {
              var sl = Math["floor"](sl["length"] / 0x2);
              return sl["slice"](0x0, sl) + '\x20' + sl["slice"](sl, sl["length"]);
            }
            return sl;
          }
          var d2 = function (sl) {
            function sl(sl) {
              var sl = sl["call"](this, sl) || this;
              var sl = {};
              sl["hover"] = false;
              sl["active"] = false;
              return sl["state"] = sl, sl['Yi'] = sl['Yi']["bind"](sl), sl['Zi'] = sl['Zi']["bind"](sl), sl['pe'] = sl['pe']["bind"](sl), sl['be'] = sl['be']["bind"](sl), sl['ye'] = sl['ye']["bind"](sl), sl['$e'] = sl['$e']["bind"](sl), sl['Qe'] = sl['Qe']["bind"](sl), sl['$i'] = sl['$i']["bind"](sl), sl['Qi'] = sl['Qi']["bind"](sl), sl['tn'] = sl['tn']["bind"](sl), sl['en'] = sl['en']["bind"](sl), sl['nn'] = sl['nn']["bind"](sl), sl['rn'] = sl['rn']["bind"](sl), sl['an'] = sl['an']["bind"](sl), sl;
            }
            return xF(sl, sl), sl["prototype"]["render"] = function () {
              var sl = this["props"]["betDetailsRaw"],
                sl = HX["displayConfig"],
                sl = sl["listContentLabelCol1"],
                sl = sl["listContentLabelCol2"],
                sl = sl["listContentLabelCol3"],
                sl = sl["listContentLabelCol4"],
                sl = [];
              var sl = {};
              sl['id'] = "game-list-item";
              sl["key"] = "game-list-item-custom";
              var sl = {};
              sl['id'] = "game-list-item";
              sl["key"] = "game-list-item-time";
              var sl = {};
              sl['id'] = "game-list-item";
              sl["key"] = "game-list-item-date";
              sl ? sl["push"](P["createElement"]("div", sl, sl(sl))) : (sl["push"](P["createElement"]("div", sl, this["props"]["time"])), sl["push"](P["createElement"]("div", sl, this["props"]["date"])));
              var xM = [];
              var sl = {};
              sl['id'] = "game-list-item";
              sl["key"] = "game-list-item-custom";
              if (sl) sl["push"](P["createElement"]("div", sl, sl(sl)));else {
                var sl = function (jF) {
                    var ja = {};
                    ja["color"] = HX["appearanceHelper"]["listItemFontColor"];
                    ja["transition"] = "color 0.5s ease 0s";
                    ja["display"] = "inline-table";
                    var jQ = jF["isSelected"],
                      jM = jF["isHighlight"],
                      ja = ja;
                    return (jM || jQ) && (ja["transition"] = '', ja["color"] = jQ ? HX["appearanceHelper"]["listItemSelectedFontColor"] : HX["appearanceHelper"]["highlightFontColor"]), ja;
                  }(this["props"]),
                  sl = HX["isPortrait"] ? d1(this["props"]["transactionId"]["toString"]()) : this["props"]["transactionId"]["toString"]();
                xM["push"](P["createElement"]("div", {
                  'className': "game-list-item",
                  'key': "game-list-item-transaction-id",
                  'id': "game-list-item-transaction-id-"["concat"](this["props"]["index"]),
                  'style': sl,
                  'onMouseLeave': this['tn'],
                  'onMouseDown': this['Qi'],
                  'onMouseUp': this['en'],
                  'onTouchStart': this['an'],
                  'onTouchEnd': this['nn'],
                  'onTouchMove': this['rn']
                }, sl)), xM["push"](this['sn']());
              }
              var sl,
                sl,
                sl,
                jx,
                sl,
                jh,
                jE,
                jg = sl ? sl(sl) : xb["formatCurrency"](this["props"]["bet"], ''),
                jA = sl ? sl(sl) : xb["formatCurrency"](this["props"]["profit"], ''),
                jh = (sl = this["props"], sl = this["state"], sl = sl["isSelected"], jx = sl["index"], sl = sl["hover"], jh = sl["active"], jE = {
                  'color': HX["appearanceHelper"]["listItemFontColor"],
                  'background': jx % 0x2 == 0x0 ? HX["appearanceHelper"]["listItemEvenColor"] : HX["appearanceHelper"]["listItemOddColor"]
                }, sl ? (jE["color"] = HX["appearanceHelper"]["listItemSelectedFontColor"], jE["background"] = HX["appearanceHelper"]["listItemSelectedColor"]) : jh ? jE["background"] = HX["appearanceHelper"]["listItemPressedColor"] : sl && (jE["background"] = HX["appearanceHelper"]["listItemHoverColor"]), jE),
                jh = function () {
                  {
                    switch (HX["launchType"]) {
                      case xS["CARD"]:
                        return "game-list-item-container-vertical game-list-item-container-card";
                      case xS["GAME"]:
                      case xS["SLOT"]:
                        return HX["isPortrait"] ? "game-list-item-container-vertical" : HX["isMobile"] ? "game-list-item-container-horizontal-mobile" : "game-list-item-container-horizontal";
                      default:
                        return "game-list-item-container-vertical";
                    }
                  }
                }(),
                jj = function (jF) {
                  var ja = {};
                  ja["color"] = jF["isSelected"] ? HX["appearanceHelper"]["listItemSelectedFontColor"] : HX["appearanceHelper"]["listItemFontColor"];
                  return ja;
                }(this["props"]),
                jP = function (jF) {
                  var ja = jF["profit"];
                  var jQ = {};
                  jQ["color"] = jF["isSelected"] ? HX["appearanceHelper"]["listItemSelectedFontColor"] : ja > 0x0 ? HX["appearanceHelper"]["listItemWinFontColor"] : HX["appearanceHelper"]["listItemLossFontColor"];
                  return jQ;
                }(this["props"]),
                jT = xa(xa({}, jh), this["props"]["style"]);
              var jU = {};
              jU["direction"] = "rtl";
              jU["paddingLeft"] = "10px";
              jU["paddingRight"] = "20px";
              var jW = {};
              jW["className"] = "game-list-item-column-container";
              jW["style"] = jj;
              var ju = {};
              ju["className"] = "game-list-item-column-container";
              var jp = {};
              jp["textAlign"] = "right";
              var jL = {};
              jL["className"] = "game-list-item";
              jL["style"] = jp;
              var jm = {};
              jm["textAlign"] = "right";
              return shell["isRTLLanguage"]() && (jT = xa(xa({}, jT), jU)), P["createElement"]("div", {
                'className': "game-list-item-container "["concat"](jh),
                'style': jT,
                'onClick': this['Yi'],
                'onMouseEnter': this['Zi'],
                'onMouseLeave': this['pe'],
                'onMouseDown': this['be'],
                'onMouseUp': this['ye'],
                'onTouchStart': this['$e'],
                'onTouchEnd': this['Qe'],
                'onTouchMove': this['$i']
              }, P["createElement"]("div", jW, sl), P["createElement"]("div", ju, xM), P["createElement"]("div", jL, d1(jg, 0xb)), P["createElement"]("div", {
                'className': "game-list-item",
                'style': xa(xa({}, jP), jm)
              }, d1(jA, 0xc)), this['ln'](this["props"]));
            }, sl["prototype"]['Yi'] = function () {
              if (this["props"]["isClickable"]) {
                this['cn']();
                var sl = this["props"]["onClickedCallback"];
                sl && sl(this["props"]["index"]);
              }
            }, sl["prototype"]['sn'] = function () {
              var sl = {};
              sl["key"] = "game-list-icons";
              return P["createElement"](d0, xa({}, this["props"], sl));
            }, sl["prototype"]['ln'] = function (sl) {
              var sl = HX["isMobile"] ? "gh-angle-horizontal-mobile" : "gh-angle-horizontal",
                sl = HX["isPortrait"] ? "gh-angle-vertical angle-right" : ''["concat"](sl, " angle-right"),
                sl = {
                  'borderColor': sl["isSelected"] ? HX["appearanceHelper"]["listItemSelectedFontColor"] : HX["appearanceHelper"]["listItemArrowColor"]
                };
              var sl = {};
              sl["transform"] = "rotate(-225deg)";
              var sl = {};
              sl['id'] = "game-list-item-arrow-image-container";
              return shell["isRTLLanguage"]() && (sl = xa(xa({}, sl), sl)), P["createElement"]("div", sl, P["createElement"]("div", {
                'className': ''["concat"](sl),
                'style': sl
              }));
            }, sl["prototype"]['Zi'] = function () {
              var sl = {};
              sl["hover"] = true;
              this["setState"](sl);
            }, sl["prototype"]['pe'] = function () {
              var sl = {};
              sl["hover"] = false;
              sl["active"] = false;
              this["setState"](sl);
            }, sl["prototype"]['be'] = function () {
              var sl = {};
              sl["active"] = true;
              this["setState"](sl);
            }, sl["prototype"]['ye'] = function () {
              var sl = {};
              sl["active"] = false;
              this["setState"](sl);
            }, sl["prototype"]['$e'] = function () {
              var sl = this;
              this['hn'] = xb["timeoutCallback"](0.3)(function () {
                var sl = {};
                sl["active"] = true;
                sl["setState"](sl);
              });
            }, sl["prototype"]['Qe'] = function () {
              var sl = {};
              sl["active"] = false;
              this["setState"](sl);
            }, sl["prototype"]['$i'] = function () {
              {
                var sl = {};
                sl["active"] = false;
                this['hn'] && this['hn'](), this['hn'] = undefined, this["state"]["active"] && this["setState"](sl);
              }
            }, sl["prototype"]['an'] = function () {
              {
                this['un'] = xb["timeoutCallback"](0.3)(this['dn']["bind"](this));
              }
            }, sl["prototype"]['nn'] = function () {
              this['cn']();
            }, sl["prototype"]['rn'] = function () {
              this['cn']();
            }, sl["prototype"]['Qi'] = function () {
              this['un'] = xb["timeoutCallback"](0.3)(this['dn']["bind"](this));
            }, sl["prototype"]['en'] = function () {
              this['cn']();
            }, sl["prototype"]['tn'] = function () {
              this['cn']();
            }, sl["prototype"]['cn'] = function () {
              {
                var sl = this['un'];
                sl && sl(), this['un'] = undefined;
              }
            }, sl["prototype"]['dn'] = function () {
              var sl = this['fn'](),
                sl = this["props"]["index"],
                sl = this["props"]["showCopyButton"];
              sl && sl(sl["posX"], sl["posY"], sl);
            }, sl["prototype"]['fn'] = function () {
              var sl = document["getElementById"]("game-list-item-transaction-id-"["concat"](this["props"]["index"])),
                sl = document["getElementById"]("game-list-view-contents-container"),
                sl = sl["getBoundingClientRect"]();
              var sl = {};
              sl["posX"] = sl["offsetLeft"] + sl["offsetLeft"] - 0x4;
              sl["posY"] = sl["top"];
              return sl;
            }, sl;
          }(P["Component"]);
          !function (sl) {
            function sl(sl) {
              var sl = sl["call"](this, sl) || this;
              var sl = {};
              sl["hover"] = false;
              sl["active"] = false;
              sl["isFade"] = false;
              return sl["state"] = sl, sl['gn'] = sl['gn']["bind"](sl), sl['Zi'] = sl['Zi']["bind"](sl), sl['pe'] = sl['pe']["bind"](sl), sl['be'] = sl['be']["bind"](sl), sl['ye'] = sl['ye']["bind"](sl), sl['$e'] = sl['$e']["bind"](sl), sl['Qe'] = sl['Qe']["bind"](sl), sl;
            }
            xF(sl, sl), sl["prototype"]["close"] = function () {
              this['vn']();
            }, sl["prototype"]["componentDidMount"] = function () {
              this['mn'] = xb["timeoutCallback"](0x6)(this['pn']["bind"](this));
            }, sl["prototype"]["componentDidUpdate"] = function () {
              var sl = this;
              this["state"]["isFade"] && (this['yn'] = xb["timeoutCallback"](0.3)(function () {
                {
                  sl['vn']();
                }
              }));
            }, sl["prototype"]["render"] = function () {
              {
                var sl = this["state"],
                  sl = sl["isFade"],
                  sl = sl["active"],
                  sl = sl["hover"],
                  sl = this["props"],
                  sl = sl["posX"],
                  sl = sl["posY"],
                  sl = sl["index"],
                  sl = !HX["isPortrait"],
                  sl = function (sl, jx) {
                    var sl = jx ? -0x12 : -0x5,
                      jh = jx ? 0xf : 0x5;
                    return {
                      'width': "0px",
                      'height': "0px",
                      'borderStyle': "solid",
                      'borderWidth': jh + "px " + jh + "px 0 " + jh + 'px',
                      'borderColor': "grey transparent transparent transparent",
                      'position': "absolute",
                      'left': document["getElementById"]("game-list-item-transaction-id-"["concat"](sl))["clientWidth"] / 0x2 + sl + 'px'
                    };
                  }(sl, sl),
                  xM = function (sl, jx, sl, jh) {
                    var jE = document["getElementById"]("game-list-item-transaction-id-"["concat"](sl)),
                      jg = HX["gsScale"];
                    jg = HX["isPortrait"] ? jg : jg / 0x3;
                    var jA = HX["isPortrait"] ? 2.2 : 3.3,
                      jh = {
                        'position': "absolute",
                        'width': jE["clientWidth"] + 'px',
                        'height': jE["clientHeight"] + 'px',
                        'left': sl + 'px',
                        'top': ''["concat"](jx / jg - jE["clientWidth"] / jA, 'px'),
                        'textAlign': "center",
                        'opacity': '1',
                        'zIndex': 0x63
                      };
                    return jh && (jh["transition"] = "opacity 1s ease 0s", jh["opacity"] = '0'), jh;
                  }(sl, sl, sl, sl),
                  sl = function (sl, jx, sl) {
                    var jh = 0x23,
                      jE = 0xf,
                      jg = 0xc,
                      jA = 0x1;
                    sl && (jh = 0x5a, jE = 0x23, jg = 0x18, jA = 0x3);
                    var jh = "rgb(80,80,80)";
                    return sl ? jh = "rgb(50,50,50)" : jx && (jh = "rgb(90,90,90)"), {
                      'width': jh + 'px',
                      'height': jE + 'px',
                      'fontSize': jg + 'px',
                      'color': HX["appearanceHelper"]["highlightFontColor"],
                      'border': jA + "px solid grey",
                      'padding': "4px",
                      'backgroundColor': jh,
                      'textAlign': "center",
                      'display': "inline-block",
                      'borderRadius': "10%"
                    };
                  }(sl, sl, sl),
                  sl = shell["I18n"]['t']("History.HistoryCopy");
                var sl = {};
                sl["className"] = "transaction-id-copy-button-container";
                sl["style"] = xM;
                sl["onClickCapture"] = this['gn'];
                sl["onMouseEnter"] = this['Zi'];
                sl["onMouseLeave"] = this['pe'];
                sl["onMouseDown"] = this['be'];
                sl["onMouseUp"] = this['ye'];
                sl["onTouchStartCapture"] = this['$e'];
                sl["onTouchEnd"] = this['Qe'];
                var sl = {};
                sl["className"] = "transaction-id-copy-button";
                sl["style"] = sl;
                var sl = {};
                sl["className"] = "copy-button-arrow";
                sl["style"] = sl;
                return P["createElement"]("div", sl, P["createElement"]("div", sl, sl), P["createElement"]("div", sl));
              }
            }, sl["prototype"]['Zi'] = function () {
              var sl = {};
              sl["hover"] = true;
              this["setState"](sl);
            }, sl["prototype"]['pe'] = function () {
              var sl = {};
              sl["hover"] = false;
              sl["active"] = false;
              this["setState"](sl);
            }, sl["prototype"]['be'] = function () {
              var sl = {};
              sl["active"] = true;
              this["setState"](sl);
            }, sl["prototype"]['ye'] = function () {
              var sl = {};
              sl["active"] = false;
              this["setState"](sl);
            }, sl["prototype"]['$e'] = function () {
              var sl = {};
              sl["active"] = true;
              this["setState"](sl);
            }, sl["prototype"]['Qe'] = function () {
              var sl = {};
              sl["active"] = false;
              this["setState"](sl);
            }, sl["prototype"]['gn'] = function () {
              var sl = this,
                sl = this["props"]["transactionId"],
                sl = shell["I18n"]['t']("History.HistoryTransactionIdCopied", {
                  'transactionId': sl + ''
                }),
                sl = document["createElement"]("textarea");
              document["body"]["appendChild"](sl), sl["value"] = sl["toString"](), sl["focus"](), sl["select"](), sl["setSelectionRange"](0x0, sl["value"]["length"]);
              var sl = document["execCommand"]("Copy");
              var sl = {};
              sl["message"] = "failed";
              sl["duration"] = 0x2;
              sl["parentNode"]["removeChild"](sl), sl ? (this['vn'](), Hl({
                'message': sl,
                'duration': 0x2,
                'eventCallback': function () {
                  {
                    sl["props"]["onClickCallback"](sl["props"]["index"]);
                  }
                }
              })) : Hl(sl);
            }, sl["prototype"]['vn'] = function () {
              if (this['xn'](), this['_n'](), document["getElementById"]("transaction-id-copy-button-view")) {
                var sl = document["getElementById"]("transaction-id-copy-button-view");
                sl["parentNode"]["removeChild"](sl);
              }
              xb["timeoutCallback"](0.1)(this["props"]["onCloseCallback"]);
            }, sl["prototype"]['pn'] = function () {
              var sl = {};
              sl["isFade"] = true;
              this["setState"](sl);
            }, sl["prototype"]['xn'] = function () {
              var sl = this['mn'];
              sl && sl(), this['mn'] = undefined;
            }, sl["prototype"]['_n'] = function () {
              var sl = this['yn'];
              sl && sl(), this['yn'] = undefined;
            };
          }(P["Component"]);
          var d3,
            d4,
            d5 = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                var sl = {};
                sl["scrollToTop"] = false;
                sl["showScrollToTopButton"] = false;
                sl["currentDataPage"] = sl["historyItemPageCount"] - 0x1;
                sl["currentDataPageProps"] = sl["historyItemPageCount"];
                sl["copiedIndex"] = -0x1;
                sl["propsChanged"] = false;
                return sl['wn'] = false, sl['Cn'] = true, sl['kn'] = false, sl['Sn'] = false, sl['zn'] = 0x0, sl["state"] = sl, sl['Dn'] = P["createRef"](), sl['Hn'] = P["createRef"](), sl['jn'] = sl['jn']["bind"](sl), sl['On'] = sl['On']["bind"](sl), sl['Nn'] = sl['Nn']["bind"](sl), sl['Tn'] = sl['Tn']["bind"](sl), sl['Mn'] = sl['Mn']["bind"](sl), sl['zn'] = !HX["isPortrait"] && HX["isMobile"] ? 0xa : 0xf, sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                this["props"]["reportScrollContainerHeight"] && this['Hn']["current"] && this["props"]["reportScrollContainerHeight"](this['Hn']["current"]["scrollHeight"]), HX["isMobile"] && Hw() && 0x5a === shell["environment"]["getOrientation"]() && document["querySelectorAll"](".rcs-custom-scroll .rcs-inner-container")["forEach"](function (sl) {
                  sl["style"]["webkitOverflowScrolling"] = "auto";
                });
              }, sl["getDerivedStateFromProps"] = function (sl, sl) {
                return sl["historyItemPageCount"] !== sl["currentDataPageProps"] ? {
                  'currentDataPage': sl["historyItemPageCount"] - 0x1,
                  'currentDataPageProps': sl["historyItemPageCount"],
                  'propsChanged': true
                } : null;
              }, sl["prototype"]["shouldComponentUpdate"] = function (sl, sl) {
                {
                  return true === sl["freezeScroll"] || sl["selectedIndex"] !== this["props"]["selectedIndex"] ? this['Sn'] = true : this['Sn'] = false, sl["freezeScroll"] !== this["props"]["freezeScroll"] || sl["selectedIndex"] !== this["props"]["selectedIndex"] || sl["historyItemPageCount"] !== this["props"]["historyItemPageCount"] || sl["copiedIndex"] !== this["state"]["copiedIndex"] || sl["currentDataPage"] !== this["state"]["currentDataPage"] || sl["scrollToTop"] !== this["state"]["scrollToTop"] || sl["showScrollToTopButton"] !== this["state"]["showScrollToTopButton"];
                }
              }, sl["prototype"]["render"] = function () {
                var sl = this;
                this['wn'] || (this['wn'] = this['Pn']());
                var sl = this["state"],
                  sl = sl["scrollToTop"],
                  sl = sl["currentDataPage"],
                  sl = sl["propsChanged"],
                  sl = this['Ln'](),
                  sl = sl ? 0x0 : this['Fn'](),
                  sl = HX["isPortrait"] || HX["isMobile"] ? 0x36 : 0x4c;
                var sl = {};
                sl['id'] = "game-list-scroll-view-container";
                sl["className"] = "history regular";
                sl["ref"] = this['Dn'];
                return P["createElement"]("div", sl, this['In'](), P["createElement"](hj["default"], {
                  'heightRelativeToParent': "inherit",
                  'onScroll': function (sl) {
                    var xM = {};
                    xM["scrollToTop"] = false;
                    sl && sl["setState"](xM);
                    var sl = sl["target"],
                      sl = sl["scrollTop"],
                      sl = sl["scrollHeight"],
                      sl = sl['Dn']["current"] ? sl / (sl - sl['Dn']["current"]["clientHeight"]) * 0x64 : 0x0;
                    var sl = {};
                    sl["propsChanged"] = false;
                    sl['vn'](), 0x0 !== sl || sl["state"]["propsChanged"] || (sl['Bn'](), sl['kn'] = false), sl && sl["setState"](sl), sl > 0x1e && 0x1 === sl || sl > 0x1 ? sl['Tn']() : sl['Mn'](), sl >= 0x63 && (sl + 0x1 === sl["props"]["historyItemPageCount"] ? (sl["props"]["hasLoadMore"] || (sl['kn'] = true), sl["props"]["onBottomReachedCallback"] && sl["props"]["onBottomReachedCallback"]()) : parseInt(sl, 0xa) === sl - sl['Dn']["current"]["clientHeight"] && sl['Rn']());
                  },
                  'freezePosition': this["props"]["freezeScroll"],
                  'scrollTo': sl
                }, P["createElement"]("div", {
                  'id': "game-list-wrapper",
                  'style': {
                    'position': "relative",
                    'overflow': this["props"]["freezeScroll"] ? "hidden" : '',
                    'height': ''["concat"](sl["length"] * sl, 'px')
                  },
                  'ref': this['Hn']
                }, sl)));
              }, sl["prototype"]['Ln'] = function () {
                {
                  var sl = this,
                    sl = this["state"],
                    sl = sl["copiedIndex"],
                    sl = sl["currentDataPage"],
                    sl = [];
                  if (sl > 0x0) {
                    var sl = sl > 0x1 ? (sl - 0x2) * this['zn'] : 0x0,
                      sl = sl + 0x2 * this['zn'];
                    this["props"]["model"]["betHistoryItems"]["forEach"](function (sl, sl) {
                      sl >= sl && sl < sl && sl["push"](P["createElement"](d2, {
                        'index': sl,
                        'key': sl["transactionId"],
                        'time': HR(sl["betTime"]),
                        'date': HN(sl["betTime"]),
                        'transactionId': sl["transactionId"],
                        'bet': sl["grandTotalBetAmount"],
                        'profit': sl["grandTotalWinLossAmount"],
                        'gameElements': sl["gameElements"],
                        'mainGameCollapseCount': sl["mainGameCollapseCount"],
                        'freeSpinCollapseCount': sl["freeSpinCollapseCount"],
                        'onClickedCallback': sl['jn'],
                        'useSmallFont': sl['wn'],
                        'isSelected': sl["props"]["selectedIndex"] === sl,
                        'showCopyButton': sl['On'],
                        'isClickable': true,
                        'isHighlight': sl === sl,
                        'betDetailsRaw': sl["betDetailsRaw"]
                      }));
                    });
                  }
                  return sl;
                }
              }, sl["prototype"]['Fn'] = function () {
                var sl = this["state"]["currentDataPage"],
                  sl = HX["isPortrait"] || HX["isMobile"] ? 0x36 : 0x4c,
                  sl = Math["random"]();
                if (0x1 !== sl && !this['kn'] && !this['Sn']) {
                  if (this['Cn'] && this['Dn'] && this['Dn']["current"]) {
                    var sl = this['Dn']["current"]["clientHeight"];
                    return this['zn'] * sl - sl + sl;
                  }
                  return this['zn'] * sl + sl;
                }
              }, sl["prototype"]['Rn'] = function () {
                var sl = this["state"]["currentDataPage"];
                var sl = {};
                sl["currentDataPage"] = sl + 0x1;
                this["setState"](sl), this['Cn'] = true;
              }, sl["prototype"]['Bn'] = function () {
                var sl = this["state"]["currentDataPage"];
                sl > 0x2 && (this["setState"]({
                  'currentDataPage': sl - 0x1
                }), this['Cn'] = false);
              }, sl["prototype"]['Mn'] = function () {
                var sl = {};
                sl["showScrollToTopButton"] = false;
                HX["isPortrait"] || this["state"]["showScrollToTopButton"] && this["setState"](sl);
              }, sl["prototype"]['Tn'] = function () {
                var sl = {};
                sl["showScrollToTopButton"] = true;
                HX["isPortrait"] || this["state"]["showScrollToTopButton"] || this["setState"](sl);
              }, sl["prototype"]['In'] = function () {
                if (!HX["isPortrait"] && this["state"]["showScrollToTopButton"] && !this["props"]["freezeScroll"]) {
                  var sl = {};
                  sl["backgroundColor"] = HX["appearanceHelper"]["scrollToTopButtonColor"];
                  sl["borderColor"] = HX["appearanceHelper"]["scrollToTopButtonBorderColor"];
                  var sl = {};
                  sl["borderColor"] = HX["appearanceHelper"]["listItemArrowColor"];
                  var sl = sl,
                    sl = sl,
                    sl = HX["isMobile"] ? "scroll-to-top-background-mobile" : "scroll-to-top-background",
                    sl = HX["isMobile"] ? "gh-angle-horizontal-mobile" : "gh-angle-horizontal";
                  var sl = {};
                  sl['id'] = sl;
                  sl["style"] = sl;
                  sl["onClick"] = this['Nn'];
                  var sl = {};
                  sl["className"] = "gh-angle-wrapper";
                  return P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", {
                    'className': ''["concat"](sl, " angle-up"),
                    'style': sl
                  })));
                }
                return null;
              }, sl["prototype"]['jn'] = function (sl) {
                this["props"]["onItemClickedCallback"](sl);
              }, sl["prototype"]['Pn'] = function () {
                var sl = false;
                return this["props"]["model"]["betHistoryItems"]["forEach"](function (sl) {
                  sl = sl["grandTotalBetAmount"] > 9999.99 || sl["grandTotalWinLossAmount"] > 9999.99 || sl;
                }), sl;
              }, sl["prototype"]['Nn'] = function () {
                var sl = {};
                sl["scrollToTop"] = true;
                sl["currentDataPage"] = 0x1;
                this["setState"](sl);
              }, sl["prototype"]['On'] = function () {}, sl["prototype"]['vn'] = function () {
                {
                  this['An'] && (this['An']["close"](), this['An'] = undefined);
                }
              }, sl["prototype"]['En'] = function (sl) {
                var sl = this;
                var sl = {};
                sl["copiedIndex"] = sl;
                this['An'] = undefined, this["setState"](sl), xb["timeoutCallback"](0x2)(function () {
                  var sl = {};
                  sl["copiedIndex"] = -0x1;
                  sl["setState"](sl);
                });
              }, sl;
            }(P["Component"]),
            d6 = xb["timeoutCallback"];
          function d7(sl) {
            var sl = U(null),
              sl = false;
            d4 = sl["scrollUpThreshold"];
            var sl = {};
            sl["capture"] = true;
            sl["passive"] = false;
            var sl = xk(W(0x0), 0x2),
              sl = sl[0x0],
              sl = sl[0x1],
              sl = xk(W(false), 0x2),
              sl = sl[0x0],
              sl = sl[0x1],
              sl = xk(W(false), 0x2),
              sl = sl[0x0],
              xM = sl[0x1],
              sl = xk(W(true), 0x2),
              sl = sl[0x0],
              sl = sl[0x1],
              sl = function () {
                {
                  sl(0x0), d6(0x0)(function () {
                    sl(true);
                  });
                }
              },
              sl = Eu({
                'onDrag': function (sl) {
                  if (sl) {
                    var jx = xk(sl["movement"], 0x2),
                      sl = jx[0x0],
                      jh = jx[0x1],
                      jE = sl["down"],
                      jg = sl["cancel"],
                      jA = Math["abs"](jh),
                      jh = jh;
                    !HX["isMobile"] || shell["environment"]["isMac"]() || HX["isPortrait"] || shell["environment"]["getOrientation"]() !== xV["PORTRAIT"] || (jA = Math["abs"](sl), jh = -sl), !jE && sl["hasLoadMore"] && d8(jA) ? sl = true : (sl["current"]["classList"]["remove"]("transition-transform-on"), jh < 0x0 ? (sl(false), d8(jA) ? (sl["hasLoadMore"] && sl["onScrollThresholdReached"] && sl["onScrollThresholdReached"](true), sl(-d4)) : (sl["hasLoadMore"] && (sl["onScrollThresholdReached"] && sl["onScrollThresholdReached"](false), sl && (sl = false)), sl(jh))) : jh > 0x0 && (sl(false), jg()));
                  }
                },
                'onDragEnd': function () {
                  sl(false), sl["current"] && sl["current"]["classList"]["add"]("transition-transform-on"), sl ? (sl(-d4), sl["onExecuteLoadMoreCallback"] && sl["onExecuteLoadMoreCallback"](function () {
                    sl();
                  })) : sl();
                },
                'onWheel': function (sl) {
                  var jx = sl["movement"],
                    sl = sl["wheeling"],
                    jh = sl["screenY"];
                  if (sl && !d3) {
                    var jE = jx && jx[0x1] || jh - sl;
                    jE = jE > 0x0 && "firefox" === shell["environment"]["getBrowserBaseType"]() ? 0xc8 : jE;
                    var jg = Math["abs"](jE);
                    if (!sl) {
                      if (xM(false), sl["current"] && sl["current"]["classList"]["add"]("transition-transform-on"), jE > 0x0 && sl["hasLoadMore"] && d8(jg)) return sl(false), sl(-d4), void (sl["onExecuteLoadMoreCallback"] && sl["onExecuteLoadMoreCallback"](function () {
                        sl();
                      }));
                      jE > 0x0 ? d8(jg) ? (sl(false), sl(-d4), d6(0.5)(function () {
                        sl();
                      })) : (sl(-jE), d3 = d6(0.2)(function () {
                        sl(), d3 = undefined;
                      })) : jE < 0x0 && sl();
                    }
                  }
                },
                'onMouseUp': function () {
                  'ie' === shell["environment"]["getBrowserBaseType"]() && (sl || sl) && (sl(false), xM(false), sl(true));
                }
              }, {
                'domTarget': sl,
                'eventOptions': sl
              })["bind"](this);
            return T(sl, [sl()]), P["createElement"]("div", {
              'id': "list-wrapper",
              'className': "transition-transform-on",
              'ref': sl,
              'style': Object["assign"]({}, sl["style"], {
                'transform': "translateY("["concat"](sl, "px)")
              })
            }, P["createElement"](d5, {
              'model': sl["model"],
              'historyItemPageCount': sl["model"]["betHistoryPageNumber"],
              'hasLoadMore': sl["hasLoadMore"],
              'onItemClickedCallback': sl["onItemClickedCallback"],
              'selectedIndex': sl["selectedIndex"],
              'freezeScroll': !sl,
              'onBottomReachedCallback': function () {
                HX["isMobile"] ? !sl && sl(true) : !sl && xM(true);
              },
              'reportScrollContainerHeight': sl["reportScrollContainerHeight"]
            }));
          }
          function d8(sl) {
            return sl >= d4;
          }
          function d9(sl) {
            var sl = HX["appearanceHelper"]["primaryFontColor"],
              sl = HX["isPortrait"] || HX["isMobile"] ? "14px" : "20px",
              sl = HX["isPortrait"] || HX["isMobile"] ? 0x50 : xz;
            var sl = {};
            sl["height"] = sl;
            var sl = {};
            sl['id'] = "load-more-container";
            sl["style"] = sl;
            var sl = {};
            sl["loadMore"] = true;
            sl["isHorizontal"] = !HX["isPortrait"];
            sl["isFade"] = true;
            sl["isMobile"] = HX["isMobile"];
            var sl = {};
            sl["height"] = sl;
            var sl = {};
            sl['id'] = "load-more-container";
            sl["style"] = sl;
            var sl = {};
            sl["color"] = sl;
            sl["fontSize"] = sl;
            var sl = {};
            sl['id'] = "load-more-label";
            sl["style"] = sl;
            var sl = {};
            sl["height"] = sl;
            var xM = {};
            xM['id'] = "load-more-container";
            xM["style"] = sl;
            var sl = {};
            sl["color"] = sl;
            sl["fontSize"] = sl;
            var sl = {};
            sl['id'] = "load-more-label";
            sl["style"] = sl;
            var sl = {};
            sl["height"] = sl;
            var sl = {};
            sl['id'] = "load-more-container";
            sl["style"] = sl;
            var sl = {};
            sl["color"] = sl;
            sl["fontSize"] = sl;
            var sl = {};
            sl['id'] = "load-more-label";
            sl["style"] = sl;
            return sl["isLoading"] ? P["createElement"]("div", sl, P["createElement"](hM, sl)) : sl["showReleaseToLoad"] ? P["createElement"]("div", sl, P["createElement"]("div", sl, shell["I18n"]['t']("History.HistoryLoadMoreData"))) : sl["hasLoadMore"] ? P["createElement"]("div", xM, P["createElement"]("div", sl, shell["I18n"]['t']("History.HistoryLoadDataPull"))) : P["createElement"]("div", sl, P["createElement"]("div", sl, shell["I18n"]['t']("History.HistoryAllRecordDisplayed")));
          }
          var dC = xb["spawnCallback"],
            dx = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this,
                  sl = document["getElementById"]("game-history-container"),
                  sl = sl["props"]["model"]["getGameBetSummary"](sl["props"]["model"]["gameId"]),
                  sl = !HX["isPortrait"] && HX["isMobile"] ? 0xa : 0xf;
                sl['Wn'] = Math["ceil"](sl["betCount"] / sl);
                var sl = HX["isApiReplay"] ? 0x0 : sl['Wn'] - (sl["props"]["model"]["betHistoryPageNumber"] - 0x1);
                return HX["isPortrait"] ? sl['Yn'] = HO() + Ho() : sl['Yn'] = HX["isMobile"] ? 0x70 : 0xe9, sl["state"] = {
                  'containerHeight': sl["offsetHeight"] - sl['Yn'],
                  'scrollableHeight': 0x0,
                  'isLoading': false,
                  'showReleaseToLoad': false,
                  'pagesRemaining': sl
                }, sl['Gn'] = sl['Gn']["bind"](sl), sl['Un'] = sl['Un']["bind"](sl), sl['Vn'] = sl['Vn']["bind"](sl), sl['qn'] = sl['qn']["bind"](sl), sl['Xn'] = undefined, sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                HX["context"]["event"]['on']("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["componentWillUnmount"] = function () {
                HX["context"]["event"]["off"]("Shell.Scaled", this['ii'], this);
                var sl = this['Xn'];
                this['Xn'] = undefined, sl && sl();
              }, sl["prototype"]["render"] = function () {
                var sl = this["state"],
                  sl = sl["pagesRemaining"],
                  sl = sl["containerHeight"],
                  sl = HX["isPortrait"] || HX["isMobile"] ? 0x50 : xz,
                  sl = HX["appearanceHelper"]["listBackgroundColor"],
                  sl = "Safari" === shell["environment"]["getBrowserBaseType"]() ? "subpixel-antialiased" : "antialiased",
                  sl = "Safari" === shell["environment"]["getBrowserBaseType"]() && HX["isMobile"] ? {} : {
                    'WebkitFontSmoothing': sl
                  },
                  sl = {
                    'height': ''["concat"](sl, 'px'),
                    'width': "100%",
                    'backgroundColor': sl
                  };
                var sl = {};
                sl["height"] = "100%";
                sl["width"] = "100%";
                sl["position"] = "relative";
                sl["backgroundColor"] = sl;
                sl["zIndex"] = 0x1;
                var sl = {};
                sl["hasLoadMore"] = sl > 0x0;
                sl["style"] = sl;
                sl["scrollUpThreshold"] = sl;
                sl["onExecuteLoadMoreCallback"] = this['Gn'];
                sl["onScrollThresholdReached"] = this['Un'];
                sl["model"] = this["props"]["model"];
                sl["onItemClickedCallback"] = this['Vn'];
                sl["reportScrollContainerHeight"] = this['qn'];
                sl["selectedIndex"] = this["props"]["selectedIndex"];
                var xM = {};
                xM['id'] = "game-list-touch-prevention";
                return P["createElement"]("div", {
                  'id': "scroll-view",
                  'style': xa(xa({}, sl), sl)
                }, P["createElement"](d7, sl), function (sl) {
                  var sl = sl["isLoading"],
                    sl = sl["pagesRemaining"],
                    sl = sl["containerHeight"],
                    sl = sl["scrollableHeight"],
                    sl = sl["showReleaseToLoad"];
                  var jx = {};
                  jx["isLoading"] = sl;
                  jx["hasLoadMore"] = sl > 0x0;
                  jx["showReleaseToLoad"] = sl;
                  return sl > sl ? P["createElement"](d9, jx) : null;
                }(this["state"]), this["state"]["isLoading"] ? P["createElement"]("div", xM) : null);
              }, sl["prototype"]['qn'] = function (sl) {
                var sl = {};
                sl["scrollableHeight"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['Gn'] = function (sl) {
                !this["state"]["isLoading"] && this["state"]["pagesRemaining"] > 0x0 && (this['Xn'] = dC(this['Kn'](), this['Jn']())(this['Zn'](sl)));
              }, sl["prototype"]['Jn'] = function () {
                var sl = this;
                return function (sl) {
                  {
                    sl["props"]["loadMoreApiCallback"] && sl["props"]["loadMoreApiCallback"](sl);
                  }
                };
              }, sl["prototype"]['Zn'] = function (sl) {
                var sl = this;
                return function () {
                  {
                    var sl = sl['Wn'] - (sl["props"]["model"]["betHistoryPageNumber"] - 0x1);
                    var sl = {};
                    sl["isLoading"] = false;
                    sl["pagesRemaining"] = sl <= 0x0 ? 0x0 : sl;
                    sl["setState"](sl), sl['Xn'] = undefined, sl && sl();
                  }
                };
              }, sl["prototype"]['Kn'] = function () {
                var sl = this;
                return function (sl) {
                  var sl = {};
                  sl["isLoading"] = true;
                  sl["showReleaseToLoad"] = false;
                  sl["setState"](sl), sl && sl();
                };
              }, sl["prototype"]['ii'] = function (sl) {
                var sl = sl["payload"],
                  sl = (HX["isPortrait"] || HX["isMobile"] ? sl["height"] : 0x3 * sl["height"]) - this['Yn'];
                var sl = {};
                sl["containerHeight"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['Vn'] = function (sl) {
                this["state"]["isLoading"] || this["props"]["onListItemClickCallback"] && this["props"]["onListItemClickCallback"](sl);
              }, sl["prototype"]['Un'] = function (sl) {
                sl !== this["state"]["showReleaseToLoad"] && this["setState"]({
                  'showReleaseToLoad': sl
                });
              }, sl;
            }(P["Component"]);
          function dH(sl, sl, sl) {
            if (undefined === sl && (sl = 0x0), !sl["current"] || !sl["current"]) return 0x1;
            var sl = sl["current"]["offsetWidth"],
              sl = sl["current"]["offsetWidth"] - sl,
              sl = 0x1;
            return sl > sl && (sl = sl / sl, sl["current"]["style"]["transform"] = "scale("["concat"](sl, ')')), sl;
          }
          function dh(sl, sl) {
            sl["current"] && (sl["current"]["style"]["transform"] = "scale("["concat"](sl, ')'));
          }
          var dE = {};
          dE["width"] = "100%";
          dE["height"] = "60px";
          dE["display"] = "flex";
          dE["flexDirection"] = "column";
          dE["justifyContent"] = "center";
          dE["borderBottom"] = "1px solid #696969";
          var dg = {};
          dg["width"] = "100%";
          dg["height"] = "12px";
          dg["paddingLeft"] = "23px";
          var dA = {};
          dA["display"] = "flex";
          dA["flex"] = '';
          dA["justifyContent"] = "center";
          dA["alignItems"] = "center";
          dA["height"] = "40px";
          dA["width"] = "100%";
          var dd = {};
          dd["display"] = "flex";
          dd["flexDirection"] = "column";
          dd["justifyContent"] = "center";
          dd["alignItems"] = "center";
          dd["textAlign"] = "center";
          dd["height"] = "100%";
          dd["width"] = "33.33%";
          var ds = shell["I18n"],
            dj = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                return sl['$n'] = xb["formatCurrency"](sl["props"]["totalBet"], sl["props"]["currencySymbol"]), sl['Qn'] = xb["formatCurrency"](sl["props"]["totalProfit"], sl["props"]["currencySymbol"]), sl['tr'] = P["createRef"](), sl['er'] = P["createRef"](), sl['ir'] = P["createRef"](), sl['nr'] = P["createRef"](), sl['rr'] = P["createRef"](), sl['ar'] = P["createRef"](), sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                dH(this['tr'], this['er']);
                var sl = dH(this['rr'], this['ar'], 0x4),
                  sl = dH(this['ir'], this['nr'], 0x4);
                sl < sl ? dh(this['ar'], sl) : dh(this['nr'], sl);
              }, sl["prototype"]["render"] = function () {
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["footerBarColor"];
                sl["borderTopColor"] = HX["appearanceHelper"]["footerSeparatorColor"];
                sl["borderTopStyle"] = "solid";
                sl["borderTopWidth"] = "1px";
                sl["color"] = HX["appearanceHelper"]["primaryFontColor"];
                var sl = {};
                sl["color"] = HX["appearanceHelper"]["highlightFontColor"];
                var sl = sl,
                  sl = sl,
                  sl = Hv(),
                  sl = HX["displayConfig"],
                  sl = sl["hideBet"],
                  sl = sl["betLabel"],
                  sl = sl["hideProfit"],
                  sl = sl["profitLabel"],
                  xM = xa(xa({}, sl), {
                    'height': ''["concat"](sl, 'px')
                  });
                var sl = {};
                sl["direction"] = "rtl";
                sl["paddingLeft"] = "10px";
                sl["paddingRight"] = "20px";
                var sl = {};
                sl['id'] = "game-list-footer-date-container";
                var sl = {};
                sl['id'] = "game-list-footer-date-vertical";
                sl["ref"] = this['tr'];
                var sl = {};
                sl["color"] = HX["appearanceHelper"]["footerDateFontColor"];
                var sl = {};
                sl['id'] = "game-list-footer-date-label-vertical";
                sl["ref"] = this['er'];
                sl["style"] = sl;
                var sl = {};
                sl['id'] = "game-list-footer-record-vertical";
                var jx = {};
                jx["visibility"] = sl ? "hidden" : "visible";
                var sl = {};
                sl["visibility"] = sl ? "hidden" : "visible";
                return shell["isRTLLanguage"]() && (xM = xa(xa({}, xM), sl)), P["createElement"]("div", {
                  'id': "game-list-footer-container",
                  'className': "game-list-footer-container-vertical",
                  'style': xM
                }, P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", sl, this["props"]["date"])), P["createElement"]("div", sl, ''["concat"](this["props"]["record"], '\x20')["concat"](ds['t']("History.HistoryRecords")))), P["createElement"]("div", {
                  'className': "game-list-footer-item",
                  'style': xa(xa({}, sl), jx),
                  'ref': this['rr']
                }, P["createElement"]("div", {
                  'className': "game-list-footer-item-wrapper",
                  'ref': this['ar']
                }, sl || this['$n'])), P["createElement"]("div", {
                  'className': "game-list-footer-item",
                  'style': xa(xa({}, sl), sl),
                  'ref': this['ir']
                }, P["createElement"]("div", {
                  'className': "game-list-footer-item-wrapper",
                  'ref': this['nr']
                }, sl || this['Qn'])));
              }, sl;
            }(P["Component"]),
            dP = {
              'protoRecordItem': dE,
              'protoSpinLabel': dg,
              'protoBetDetails': dA,
              'protoBetDetailsItem': dd
            };
          function dT(sl) {
            var sl = {};
            sl["backgroundColor"] = sl["color"];
            return P["createElement"]("div", {
              'className': "prototype-record-item",
              'style': xa(xa({}, dP["protoRecordItem"]), sl)
            }, P["createElement"](du, {
              'state': sl["betDetail"]["gameDetail"]['st'],
              'index': sl["currentIndex"],
              'transactionId': sl["betDetail"]["transactionId"]["toString"]()
            }), P["createElement"](dU, {
              'betDetail': sl["betDetail"]
            }));
          }
          function dU(sl) {
            var sl = {};
            sl["className"] = "prototype-bet-details";
            sl["style"] = dP["protoBetDetails"];
            return P["createElement"]("div", sl, P["createElement"](dW, {
              'keyName': "Bet",
              'value': xb["formatCurrency"](sl["betDetail"]["totalBetAmount"], '')
            }), P["createElement"](dW, {
              'keyName': "Profit",
              'value': xb["formatCurrency"](sl["betDetail"]["totalWinLossAmount"], '')
            }), P["createElement"](dW, {
              'keyName': "Balance",
              'value': xb["formatCurrency"](sl["betDetail"]["balance"], '')
            }));
          }
          function dW(sl) {
            {
              var sl = {};
              sl["className"] = "prototype-bet-details-item";
              sl["style"] = dP["protoBetDetailsItem"];
              var sl = {};
              sl["marginTop"] = "-2px";
              return P["createElement"]("div", sl, P["createElement"]("div", {
                'className': "prototype-"["concat"](sl["keyName"], "-item-key")
              }, sl["keyName"]), P["createElement"]("div", {
                'className': "prototype-"["concat"](sl["keyName"], "-item-value"),
                'style': sl
              }, sl["value"]));
            }
          }
          function du(sl) {
            {
              var sl;
              switch (sl["state"]) {
                case 0x1:
                  sl = "Normal Spin";
                  break;
                case 0x2:
                case 0x15:
                  sl = "Free Spin";
                  break;
                case 0x4:
                  sl = "Normal Respin";
                  break;
                case 0x16:
                  sl = "Free Spin Respin";
                  break;
                default:
                  sl = "Game specific Spin";
              }
              var sl = {};
              sl["className"] = "prototype-spin-label";
              sl["style"] = dP["protoSpinLabel"];
              return P["createElement"]("div", sl, ''["concat"](sl["index"] + 0x1, ".  ")["concat"](sl, " - ")["concat"](sl["transactionId"]));
            }
          }
          var dp = {};
          dp["width"] = "100%";
          dp["height"] = "inherit";
          dp["position"] = "relative";
          dp["margin"] = "0 auto";
          dp["fontSize"] = "12px";
          dp["zIndex"] = 0x1;
          function dm(sl) {
            var sl = sl["betDetailsRaw"]["map"](function (sl, sl, sl) {
                var sl = new AB(sl),
                  sl = sl % 0x2 == 0x0 ? HX["appearanceHelper"]["listItemEvenColor"] : HX["appearanceHelper"]["listItemOddColor"];
                return P["createElement"](dT, {
                  'key': "prototype-record-item-"["concat"](sl["transactionId"]),
                  'betDetail': sl,
                  'currentIndex': sl,
                  'totalBetDetailLength': sl["length"],
                  'color': sl
                });
              }),
              sl = document["getElementById"]("game-history-container")["offsetHeight"] - Ho(),
              sl = HX["appearanceHelper"]["listBackgroundColor"];
            var sl = {};
            sl["backgroundColor"] = sl;
            var sl = {};
            sl["navLeftButtonCallback"] = sl["navLeftButtonCallback"];
            return P["createElement"]("div", {
              'className': "prototype-game-details-container history regular",
              'style': xa(xa({}, dp), sl)
            }, P["createElement"](dF, sl), P["createElement"](hj["default"], {
              'heightRelativeToParent': ''["concat"](sl, 'px')
            }, sl));
          }
          function dF(sl) {
            {
              var sl = HX["isPortrait"] || HX["isMobile"] ? Hq() : 0x0,
                sl = HX["isPortrait"] || HX["isMobile"] ? 0x3e : 0x58,
                sl = HX["appearanceHelper"]["navBarColor"];
              var sl = {};
              sl["position"] = "absolute";
              sl["zIndex"] = 0x4;
              sl["height"] = "inherit";
              sl["width"] = "inherit";
              var sl = {};
              sl["style"] = sl;
              return P["createElement"]("div", {
                'id': "game-detail-view-navbar-container",
                'key': "game-detail-view-navbar-container",
                'style': {
                  'height': ''["concat"](sl, 'px'),
                  'paddingTop': ''["concat"](sl, 'px'),
                  'backgroundColor': sl
                }
              }, P["createElement"]("div", sl, P["createElement"](hQ, {
                'showTitle': function () {
                  return "Spin Details";
                },
                'titleClickCallback': function () {},
                'currentState': xX["HistoryDetails"],
                'currentCalendarType': undefined,
                'currentCalendarState': undefined,
                'leftButtonClickedCallback': sl["navLeftButtonCallback"],
                'rightButtonClickedCallback': function () {},
                'showDropDownArrow': function () {
                  {
                    return false;
                  }
                }
              })));
            }
          }
          var da = xb["timeoutCallback"],
            dQ = shell["I18n"],
            dM = function (sl) {
              function sl(sl) {
                {
                  var sl = sl["call"](this, sl) || this;
                  sl['ke'] = HX["launchType"] === xS["CARD"], sl['sr'] = P["createRef"](), sl['lr'] = P["createRef"]();
                  var sl = xX["HistoryList"],
                    sl = document["getElementById"]("game-history-container");
                  return sl["state"] = {
                    'model': sl["model"],
                    'currentPageState': sl,
                    'previousPageState': sl,
                    'currentCalendarState': xJ["SELECTION"],
                    'selectedIndex': 0x0,
                    'parentHeight': sl["offsetHeight"] - Ho(),
                    'imageUrl': '',
                    'loadMoreInProgress': false
                  }, sl['cr'] = sl['cr']["bind"](sl), sl['hr'] = sl['hr']["bind"](sl), sl['ur'] = sl['ur']["bind"](sl), sl['dr'] = sl['dr']["bind"](sl), sl['jn'] = sl['jn']["bind"](sl), sl['Gn'] = sl['Gn']["bind"](sl), sl;
                }
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                HX["context"]["event"]['on']("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["componentWillUnmount"] = function () {
                HX["context"]["event"]["off"]("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["render"] = function () {
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["listBackgroundColor"];
                var sl = this["props"],
                  sl = sl["isLoading"],
                  sl = sl["fadeLoading"],
                  sl = sl;
                var sl = {};
                sl['id'] = "game-list-view-loading";
                sl["className"] = "game-list-view-container";
                sl["style"] = sl;
                var sl = {};
                sl['id'] = "game-list-view-wrapper";
                var sl = {};
                sl["isFade"] = sl;
                sl["onButtonClickCallback"] = this["props"]["quitCallback"];
                sl["isHorizontal"] = false;
                var sl = {};
                sl['id'] = "game-list-view";
                sl["className"] = "game-list-view-container";
                sl["style"] = sl;
                var sl = {};
                sl["flexDirection"] = "column";
                var xM = {};
                xM['id'] = "game-list-view-wrapper";
                xM["style"] = sl;
                return sl ? P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"](hM, sl))) : P["createElement"]("div", sl, P["createElement"]("div", xM, this['Di'](), this['gr'](), this['vr'](this["state"])));
              }, sl["prototype"]['cr'] = function () {
                this["state"]["loadMoreInProgress"] || this['mr']();
              }, sl["prototype"]['mr'] = function () {
                {
                  var sl = this,
                    sl = this["state"]["currentPageState"];
                  switch (sl) {
                    case xX["HistoryDetails"]:
                    case xX["HistoryFreeSpinDetails"]:
                      da(0.1)(function () {
                        var sl = {};
                        sl["currentPageState"] = xX["HistoryList"];
                        sl["previousPageState"] = sl;
                        sl["setState"](sl);
                      });
                      break;
                    case xX["HistoryCalendar"]:
                      var sl = {};
                      sl["currentPageState"] = xX["HistoryList"];
                      sl["previousPageState"] = sl;
                      this["state"]["currentCalendarState"] === xJ["SELECTION"] ? this["setState"](sl) : this["setState"]({
                        'currentCalendarState': xJ["SELECTION"]
                      });
                      break;
                    case xX["HistoryList"]:
                      if (HX["isApiReplay"]) break;
                      var sl = {};
                      sl["currentPageState"] = xX["HistoryCalendar"];
                      sl["previousPageState"] = sl;
                      this["setState"](sl);
                  }
                }
              }, sl["prototype"]['hr'] = function () {
                var sl = this["state"]["currentPageState"];
                switch (sl) {
                  case xX["HistoryCalendar"]:
                    var sl = {};
                    sl["currentPageState"] = xX["HistoryList"];
                    sl["previousPageState"] = sl;
                    this["state"]["currentCalendarState"] === xJ["SELECTION"] ? this["setState"](sl) : this["setState"]({
                      'currentCalendarState': xJ["SELECTION"]
                    });
                    break;
                  case xX["HistoryList"]:
                    this["props"]["quitCallback"] && this["props"]["quitCallback"]();
                }
              }, sl["prototype"]['dr'] = function (sl) {
                var sl = this["state"]["currentPageState"],
                  sl = this["state"]["model"];
                sl["calendarType"] = sl, this["setState"]({
                  'currentCalendarState': xJ["SELECTION"],
                  'currentPageState': xX["HistoryList"],
                  'previousPageState': sl,
                  'model': sl
                }), this["props"]["changeCalendarType"] && this["props"]["changeCalendarType"](sl);
              }, sl["prototype"]['ur'] = function () {
                var sl = {};
                sl["currentCalendarState"] = xJ["CUSTOM"];
                this["setState"](sl);
              }, sl["prototype"]['jn'] = function (sl) {
                var sl = this["state"]["currentPageState"];
                var sl = {};
                sl["currentPageState"] = xX["HistoryDetails"];
                sl["previousPageState"] = sl;
                sl["selectedIndex"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['Di'] = function () {
                var sl = this["state"]["currentPageState"] === xX["HistoryDetails"] ? xX["HistoryList"] : this["state"]["currentPageState"],
                  sl = this['ke'] ? "game-list-nav-vertical-card" : '',
                  sl = Hq(),
                  sl = HX["appearanceHelper"]["navBarColor"],
                  sl = this["state"],
                  sl = sl["model"],
                  sl = sl["currentCalendarState"],
                  sl = sl["loadMoreInProgress"];
                return P["createElement"]("div", {
                  'id': "game-list-view-navbar-container",
                  'className': sl,
                  'style': {
                    'width': "100%",
                    'height': ''["concat"](0x3e, 'px'),
                    'paddingTop': ''["concat"](sl, 'px'),
                    'backgroundColor': sl
                  },
                  'ref': this['sr']
                }, P["createElement"](hQ, {
                  'showTitle': function () {
                    return shell["I18n"]['t']("History.HistoryCalenderToday");
                  },
                  'titleClickCallback': undefined,
                  'currentState': sl,
                  'currentCalendarType': sl["calendarType"],
                  'currentCalendarState': sl,
                  'leftButtonClickedCallback': this['cr'],
                  'rightButtonClickedCallback': this['hr'],
                  'showDropDownArrow': function () {
                    {
                      return false;
                    }
                  },
                  'calendarCustomDateConfig': sl["calendarCustomDateConfig"],
                  'showLeftDisabled': sl
                }));
              }, sl["prototype"]['gr'] = function () {
                {
                  var sl = this["state"]["currentPageState"];
                  var sl = {};
                  sl["height"] = this["state"]["parentHeight"];
                  var sl = {};
                  sl['id'] = "game-list-view-contents-container";
                  sl["style"] = sl;
                  sl["ref"] = this['lr'];
                  var sl = {};
                  sl["display"] = sl === xX["HistoryCalendar"] ? "block" : "none";
                  var sl = {};
                  sl['id'] = "calendar-container";
                  sl["style"] = sl;
                  var sl = {};
                  sl["model"] = this["state"]["model"];
                  sl["currentCalendarType"] = this["state"]["model"]["calendarType"];
                  sl["currentCalendarState"] = this["state"]["currentCalendarState"];
                  sl["onCalendarCustomClicked"] = this['ur'];
                  sl["onChangeCalendarTypeCallback"] = this['dr'];
                  return P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"](AK, sl)), this['pr']());
                }
              }, sl["prototype"]['pr'] = function () {
                {
                  var sl = [];
                  var sl = {};
                  sl["key"] = "game-list-table-header";
                  sl["currencySymbol"] = this["props"]["model"]["currencySymbol"];
                  if (sl["push"](P["createElement"](Az, sl)), this["state"]["model"]["betHistoryItems"]["length"] > 0x0) sl["push"](P["createElement"](dx, {
                    'key': "game-list-scroller",
                    'model': this["props"]["model"],
                    'onListItemClickCallback': this['jn'],
                    'loadMoreApiCallback': this['Gn']
                  }));else {
                    {
                      var sl = HX["appearanceHelper"]["listBackgroundColor"];
                      var sl = {};
                      sl["fontSize"] = "14px";
                      sl["color"] = HX["appearanceHelper"]["secondaryFontColor"];
                      var sl = {};
                      sl["className"] = "game-list-view-no-item-label";
                      sl["style"] = sl;
                      sl["push"](P["createElement"]("div", {
                        'id': "game-list-view-no-items-container",
                        'key': "game-list-view-no-items-container",
                        'style': {
                          'height': "calc(100% - "["concat"](HO(), "px)"),
                          'backgroundColor': sl
                        }
                      }, P["createElement"]("div", sl, dQ['t']("History.HistoryNoHistory"))));
                    }
                  }
                  return sl["push"](this['br']()), sl;
                }
              }, sl["prototype"]['br'] = function () {
                var sl = this["state"]["model"]["betSummaryModel"][0x0];
                return P["createElement"](dj, {
                  'date': this['yr'](),
                  'key': "game-list-footer-port",
                  'record': sl && sl["betCount"] || 0x0,
                  'totalBet': sl && sl["batchTotalBetAmount"] || 0x0,
                  'totalProfit': sl && sl["batchTotalWinLossAmount"] || 0x0,
                  'currencySymbol': this["props"]["model"]["currencySymbol"]
                });
              }, sl["prototype"]['vr'] = function (sl) {
                var sl = this,
                  sl = sl["currentPageState"],
                  sl = sl["model"],
                  sl = sl["selectedIndex"];
                if (0x0 !== sl["betHistoryItems"]["length"] && sl["betHistoryItems"][sl]) {
                  var sl = {};
                  sl["left"] = "100%";
                  var sl = {};
                  sl["left"] = '0%';
                  var sl = {};
                  sl["left"] = "100%";
                  var sl = sl["betHistoryItems"][sl]["betDetailsRaw"],
                    sl = sl,
                    xM = sl,
                    sl = sl;
                  var sl = {};
                  sl["right"] = "100%";
                  var sl = {};
                  sl["right"] = '0%';
                  var sl = {};
                  sl["right"] = "100%";
                  return shell["isRTLLanguage"]() && (sl = sl, xM = sl, sl = sl), P["createElement"](k, {
                    'key': "game-detail-view-transition",
                    'config': xY,
                    'items': sl,
                    'from': sl,
                    'enter': xM,
                    'leave': sl,
                    'onStart': function () {
                      sl !== xX["HistoryDetails"] && sl['_r'](true);
                    },
                    'onRest': function () {
                      sl === xX["HistoryDetails"] && sl['_r'](false);
                    }
                  }, function (sl) {
                    {
                      return sl === xX["HistoryDetails"] && function (sl) {
                        {
                          var jx = {};
                          jx["top"] = '0';
                          jx["position"] = "absolute";
                          jx["width"] = "inherit";
                          jx["height"] = "inherit";
                          jx["zIndex"] = '3';
                          var sl = {};
                          sl["key"] = "prototype-game-detail-view";
                          sl["betDetailsRaw"] = sl;
                          sl["navLeftButtonCallback"] = sl['cr'];
                          var jh = {};
                          jh["key"] = "game-detail-view";
                          jh["betDetailsRaw"] = sl;
                          jh["gameId"] = sl["gameId"];
                          jh["currencySymbol"] = sl["currencySymbol"];
                          jh["navLeftButtonCallback"] = sl['cr'];
                          jh["quitCallback"] = sl["props"]["quitCallback"];
                          return P["createElement"](G["div"], {
                            'style': xa(xa({}, sl), jx)
                          }, HX["isPrototype"] ? P["createElement"](dm, sl) : P["createElement"](AD, jh));
                        }
                      };
                    }
                  });
                }
              }, sl["prototype"]['yr'] = function () {
                var sl = '';
                switch (this["state"]["model"]["calendarType"]) {
                  case 0x1:
                  default:
                    sl = dQ['t']("History.HistoryCalenderToday");
                    break;
                  case 0x2:
                    sl = dQ['t']("History.HistoryCalenderWeek");
                    break;
                  case 0x3:
                    sl = HN(this["state"]["model"]["calendarCustomDateConfig"]["startDate"], true) + " - " + HN(this["state"]["model"]["calendarCustomDateConfig"]["endDate"], true);
                }
                return sl;
              }, sl["prototype"]['ii'] = function (sl) {
                var sl = sl["payload"]["height"] - Ho();
                var sl = {};
                sl["parentHeight"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['Gn'] = function (sl) {
                var sl = this;
                var sl = {};
                sl["loadMoreInProgress"] = true;
                this["setState"](sl), this["props"]["onLoadMoreRequestApi"] && this["props"]["onLoadMoreRequestApi"](function () {
                  var sl = {};
                  sl["loadMoreInProgress"] = false;
                  sl["setState"](sl), sl && sl();
                });
              }, sl["prototype"]['_r'] = function (sl) {
                this['lr']["current"] && (this['lr']["current"]["style"]["display"] = sl ? "block" : "none"), this['sr']["current"] && (this['sr']["current"]["style"]["display"] = sl ? "block" : "none");
              }, sl;
            }(P["PureComponent"]),
            dI = shell["I18n"],
            dk = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this,
                  sl = 0.2 * document["getElementById"]("game-history-container")["offsetWidth"] / 0x186;
                return sl["state"] = {
                  'isCustomOpen': sl["props"]["currentCalendarState"] === xJ["CUSTOM"],
                  'customScale': sl
                }, sl['Vi'] = sl['Vi']["bind"](sl), sl['qi'] = sl['qi']["bind"](sl), sl['Xi'] = sl['Xi']["bind"](sl), sl['G'] = sl['G']["bind"](sl), sl['wr'] = sl['wr']["bind"](sl), sl['Cr'] = sl['Cr']["bind"](sl), sl['kr'] = sl['kr']["bind"](sl), sl['Ki'] = sl['Ki']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]["render"] = function () {
                var sl = {};
                return shell["isRTLLanguage"]() && (sl["paddingRight"] = "30px", sl["paddingLeft"] = 0x0, sl["direction"] = "rtl"), P["createElement"]("div", {
                  'id': "calendar-view-container-horizontal",
                  'style': sl
                }, this['Ji']());
              }, sl["prototype"]["componentDidMount"] = function () {
                HX["context"]["event"]['on']("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["componentWillUnmount"] = function () {
                HX["context"]["event"]["off"]("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]['Vi'] = function () {
                {
                  this["props"]["isLoading"] || this["props"]["onChangeCalendarTypeCallback"] && this["props"]["onChangeCalendarTypeCallback"](0x1);
                }
              }, sl["prototype"]['qi'] = function () {
                this["props"]["isLoading"] || this["props"]["onChangeCalendarTypeCallback"] && this["props"]["onChangeCalendarTypeCallback"](0x2);
              }, sl["prototype"]['Xi'] = function () {
                var sl = {};
                sl["isCustomOpen"] = false;
                var sl = {};
                sl["isCustomOpen"] = true;
                this["props"]["isLoading"] || (this["state"]["isCustomOpen"] ? (this["props"]["onCalendarCustomClicked"] && this["props"]["onCalendarCustomClicked"](xJ["SELECTION"]), this["setState"](sl)) : (this["props"]["onCalendarCustomClicked"] && this["props"]["onCalendarCustomClicked"](xJ["CUSTOM"]), this["setState"](sl)));
              }, sl["prototype"]['G'] = function (sl, sl) {
                var sl = {};
                sl["startDate"] = sl;
                sl["endDate"] = sl;
                var sl = {};
                sl["isCustomOpen"] = false;
                this["props"]["isLoading"] || (this["props"]["model"]["calendarCustomDateConfig"] = sl, this["props"]["onChangeCalendarTypeCallback"](0x3), this["setState"](sl));
              }, sl["prototype"]['Ji'] = function () {
                var sl = {};
                sl["color"] = HX["appearanceHelper"]["calendarTitleColor"];
                var sl = [],
                  sl = sl;
                var sl = {};
                sl["className"] = "calendar-item-label";
                return shell["isRTLLanguage"]() && (sl["textAlign"] = "right"), sl["push"](P["createElement"]("div", {
                  'className': "calendar-item-container-horizontal calendar-item-container",
                  'key': "select-date-range",
                  'style': sl
                }, P["createElement"]("div", sl, dI['t']("History.HistoryCalendarDateRange")))), sl["push"](this['wr']()), sl["push"](this['Cr']()), sl["push"](this['kr']()), sl["push"](this['Ki']()), sl;
              }, sl["prototype"]['wr'] = function () {
                var sl = this["state"]["isCustomOpen"],
                  sl = 0x1 === this["props"]["currentCalendarType"],
                  sl = !sl && sl ? HX["appearanceHelper"]["highlightFontColor"] : HX["appearanceHelper"]["primaryFontColor"],
                  sl = {};
                return shell["isRTLLanguage"]() && (sl["textAlign"] = "right"), P["createElement"]("div", {
                  'className': "calendar-item-container-horizontal calendar-item-container",
                  'onClick': this['Vi'],
                  'key': "calendar-date-today",
                  'style': sl
                }, P["createElement"]("div", {
                  'className': "calendar-item-label",
                  'style': {
                    'color': sl,
                    'opacity': this["props"]["isLoading"] ? 0.3 : 0x1
                  }
                }, dI['t']("History.HistoryCalenderToday")));
              }, sl["prototype"]['Cr'] = function () {
                var sl = this["state"]["isCustomOpen"],
                  sl = 0x2 === this["props"]["currentCalendarType"],
                  sl = !sl && sl ? HX["appearanceHelper"]["highlightFontColor"] : HX["appearanceHelper"]["primaryFontColor"],
                  sl = {};
                return shell["isRTLLanguage"]() && (sl["textAlign"] = "right"), P["createElement"]("div", {
                  'className': "calendar-item-container-horizontal calendar-item-container",
                  'onClick': this['qi'],
                  'key': "calendar-date-week",
                  'style': sl
                }, P["createElement"]("div", {
                  'className': "calendar-item-label",
                  'style': {
                    'color': sl,
                    'opacity': this["props"]["isLoading"] ? 0.3 : 0x1
                  }
                }, dI['t']("History.HistoryCalenderWeek")));
              }, sl["prototype"]['kr'] = function () {
                var sl = this["state"]["isCustomOpen"],
                  sl = sl ? "angle-up" : "angle-down",
                  sl = 0x3 === this["props"]["currentCalendarType"] || sl ? HX["appearanceHelper"]["highlightFontColor"] : HX["appearanceHelper"]["primaryFontColor"],
                  sl = sl,
                  sl = sl ? "translateY(4px)" : "translateY(-4px)",
                  sl = {};
                var sl = {};
                sl['id'] = "calendar-custom-container";
                sl["onClick"] = this['Xi'];
                sl["key"] = "calendar-custom-container";
                var sl = {};
                sl["color"] = sl;
                sl["opacity"] = this["props"]["isLoading"] ? 0.3 : 0x1;
                var sl = {};
                sl["className"] = "calendar-item-label";
                sl["style"] = sl;
                var sl = {};
                sl['id'] = "calendar-arrow-image-container";
                var xM = {};
                xM["transform"] = sl;
                var sl = {};
                sl["className"] = "gh-angle-wrapper";
                sl["style"] = xM;
                var sl = {};
                sl["borderColor"] = sl;
                return shell["isRTLLanguage"]() && (sl["textAlign"] = "right"), P["createElement"]("div", sl, P["createElement"]("div", {
                  'className': "calendar-item-container calendar-item-container-horizontal",
                  'style': sl
                }, P["createElement"]("div", sl, dI['t']("History.HistoryCalenderCustom"))), P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", {
                  'id': "calendar-arrow",
                  'className': "gh-angle-horizontal "["concat"](sl),
                  'style': sl
                }))));
              }, sl["prototype"]['Ki'] = function () {
                var sl = this["state"],
                  sl = sl["isCustomOpen"],
                  sl = sl["customScale"],
                  sl = undefined;
                if (sl) {
                  var sl = {
                    'transform': "scale("["concat"](sl, ") translateX(-20px)")
                  };
                  shell["isRTLLanguage"]() && (sl["transform"] = "scale("["concat"](sl, ") translateX(20px)")), sl = P["createElement"]("div", {
                    'id': "calendar-custom-view-container",
                    'style': sl,
                    'key': "calendar-custom-view-container"
                  }, P["createElement"](xv["CalendarCustomViewH"], {
                    'key': "calendar-custom-view",
                    'isRTL': shell["isRTLLanguage"](),
                    'caseType': xv["CaseType"]["SLOT_GAME"],
                    'themeColor': HX["appearanceHelper"]["calendarColor"],
                    'backgroundColor': HX["appearanceHelper"]["calendarBackgroundColor"],
                    'onConfirmClicked': this['G']
                  }));
                }
                return sl;
              }, sl["prototype"]['ii'] = function (sl) {
                var sl = 0x3 * 0.2 * sl["payload"]["width"] / 0x186;
                var sl = {};
                sl["customScale"] = sl;
                this["setState"](sl);
              }, sl;
            }(P["Component"]),
            df = shell["I18n"],
            dG = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                return sl['Te'] = sl['Te']["bind"](sl), sl['dr'] = sl['dr']["bind"](sl), sl['ur'] = sl['ur']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]['dr'] = function (sl) {
                this["props"]["onChangeCalendarTypeCallback"] && this["props"]["onChangeCalendarTypeCallback"](sl);
              }, sl["prototype"]['ur'] = function (sl) {
                this["props"]["onCalendarCustomClicked"] && this["props"]["onCalendarCustomClicked"](sl);
              }, sl["prototype"]["render"] = function () {
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["navBarPanelColor"];
                var sl = sl,
                  sl = {};
                var sl = {};
                sl['id'] = "game-list-nav";
                sl["className"] = "game-list-nav-horizontal";
                sl["style"] = sl;
                return shell["isRTLLanguage"]() && (sl["direction"] = "rtl"), P["createElement"]("div", sl, P["createElement"]("div", {
                  'id': "game-list-nav-bar",
                  'className': "game-list-nav-bar-horizontal",
                  'style': sl
                }, this['Te'](), P["createElement"](dk, {
                  'model': this["props"]["model"],
                  'currentCalendarType': this["props"]["model"]["calendarType"],
                  'currentCalendarState': this["props"]["currentCalendarState"],
                  'onChangeCalendarTypeCallback': this['dr'],
                  'onCalendarCustomClicked': this['ur'],
                  'isLoading': this["props"]["isLoading"]
                })));
              }, sl["prototype"]['Te'] = function () {
                var sl = [],
                  sl = HX["appearanceHelper"]["titleFontColor"],
                  sl = {};
                var sl = {};
                sl["fontSize"] = "30px";
                sl["lineHeight"] = "33px";
                sl["color"] = sl;
                var sl = {};
                sl["className"] = "game-list-nav-period-label";
                sl["style"] = sl;
                return shell["isRTLLanguage"]() && (sl["direction"] = "rtl", sl["paddingRight"] = '8%', sl["paddingLeft"] = 0x0), sl["push"](P["createElement"]("div", {
                  'id': "game-list-nav-label-container",
                  'className': "game-list-nav-label-container-horizontal",
                  'key': "game-list-nav-label-container",
                  'style': sl
                }, P["createElement"]("div", sl, df['t']("History.HistoryMainTitle")))), sl;
              }, sl;
            }(P["Component"]),
            dy = shell["I18n"],
            db = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                var sl = {};
                sl["disableCloseButton"] = sl["disableCloseButton"];
                return sl["state"] = sl, sl['$n'] = xb["formatCurrency"](sl["props"]["totalBet"], ''), sl['Qn'] = xb["formatCurrency"](sl["props"]["totalProfit"], ''), sl['Oe'] = sl['Oe']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidUpdate"] = function (sl) {
                sl["disableCloseButton"] !== this["props"]["disableCloseButton"] && this["setState"]({
                  'disableCloseButton': this["props"]["disableCloseButton"]
                });
              }, sl["prototype"]["render"] = function () {
                var sl = HX["appearanceHelper"]["footerDateFontColor"],
                  sl = HX["appearanceHelper"]["primaryFontColor"],
                  sl = HX["appearanceHelper"]["highlightFontColor"],
                  sl = this["props"]["currencySymbol"] ? ''["concat"](dy['t']("History.HistoryMainPagePayout"), '(')["concat"](this["props"]["currencySymbol"], ')') : ''["concat"](dy['t']("History.HistoryMainPagePayout")),
                  sl = this["props"]["currencySymbol"] ? ''["concat"](dy['t']("History.HistoryMainPageWin"), '(')["concat"](this["props"]["currencySymbol"], ')') : ''["concat"](dy['t']("History.HistoryMainPageWin")),
                  sl = this["props"]["shrink"] ? "24px" : "30px";
                sl = this["props"]["isMobile"] ? "14px" : sl;
                var sl = HX["appearanceHelper"]["navBarSeparatorColor"],
                  sl = HX["isMobile"] ? "-mobile" : '',
                  sl = HX["displayConfig"],
                  sl = sl["hideBet"],
                  xM = sl["betLabel"],
                  sl = sl["hideProfit"],
                  sl = sl["profitLabel"],
                  sl = {
                    'backgroundColor': HX["appearanceHelper"]["footerBarColor"]
                  },
                  sl = {},
                  sl = {};
                var sl = {};
                sl["color"] = sl;
                var jx = {};
                jx["color"] = sl;
                jx["fontSize"] = sl;
                var sl = {};
                sl["visibility"] = sl ? "hidden" : "visible";
                var jh = {};
                jh["color"] = sl;
                var jE = {};
                jE["color"] = sl;
                jE["fontSize"] = sl;
                var jg = {};
                jg["visibility"] = sl ? "hidden" : "visible";
                var jA = {};
                jA["color"] = sl;
                var jh = {};
                jh["color"] = sl;
                jh["fontSize"] = sl;
                var jh = {};
                jh["backgroundColor"] = sl;
                var jj = {};
                jj["key"] = "game-list-nav-separator";
                jj["className"] = "game-list-nav-separator-vertical-slot";
                jj["style"] = jh;
                return shell["isRTLLanguage"]() && (sl["direction"] = "rtl", sl["textAlign"] = "right", sl["textAlign"] = "left"), P["createElement"]("div", {
                  'id': "game-list-footer-wrapper",
                  'style': sl
                }, P["createElement"]("div", {
                  'id': "game-list-footer-container",
                  'className': "game-list-footer-container-horizontal"["concat"](sl)
                }, P["createElement"]("div", {
                  'className': "game-list-footer-date-container-horizontal"["concat"](sl),
                  'style': sl
                }, P["createElement"]("div", {
                  'className': "game-list-footer-record-horizontal"["concat"](sl),
                  'style': sl
                }, ''["concat"](this["props"]["record"], '\x20')["concat"](dy['t']("History.HistoryRecords"))), P["createElement"]("div", {
                  'className': "game-list-footer-date-label-horizontal"["concat"](sl),
                  'style': jx
                }, this["props"]["date"])), P["createElement"]("div", {
                  'className': "game-list-footer-date-container-horizontal"["concat"](sl),
                  'style': xa(sl, sl)
                }, P["createElement"]("div", {
                  'className': "game-list-footer-record-horizontal"["concat"](sl),
                  'style': jh
                }, sl), P["createElement"]("div", {
                  'className': "game-list-footer-date-label-horizontal"["concat"](sl),
                  'style': jE
                }, xM || this['$n'])), P["createElement"]("div", {
                  'className': "game-list-footer-date-container-horizontal"["concat"](sl),
                  'style': xa(jg, sl)
                }, P["createElement"]("div", {
                  'className': "game-list-footer-record-horizontal"["concat"](sl),
                  'style': jA
                }, sl), P["createElement"]("div", {
                  'className': "game-list-footer-date-label-horizontal"["concat"](sl),
                  'style': jh
                }, sl || this['Qn'])), this['Sr']()), P["createElement"]("div", jj));
              }, sl["prototype"]['Sr'] = function () {
                if (!this["state"]["disableCloseButton"]) {
                  var sl = HX["isMobile"] ? "translate(20px, 0px)" : "translate(25px, 5px)",
                    sl = {};
                  var sl = {};
                  sl["isPortrait"] = false;
                  return shell["isRTLLanguage"]() && (sl["textAlign"] = "left", sl = HX["isMobile"] ? "translate(-20px, 0px)" : "translate(-25px, 5px)"), P["createElement"]("div", {
                    'className': "game-list-nav-image-container game-list-nav-image-container-slot",
                    'key': "game-list-nav-image-container-right",
                    'onClick': this['Oe'],
                    'style': sl
                  }, P["createElement"]("div", {
                    'id': "game-list-nav-image-right",
                    'style': {
                      'display': "flex",
                      'transform': sl
                    }
                  }, P["createElement"](hp, sl)));
                }
              }, sl["prototype"]['Oe'] = function () {
                var sl = this["props"]["closeButtonClickedCallback"];
                sl && sl();
              }, sl;
            }(P["Component"]),
            dZ = xb["timeoutCallback"],
            dc = shell["I18n"],
            dS = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                sl['zr'] = false;
                var sl = xX["HistoryList"],
                  sl = document["getElementById"]("game-history-container");
                var sl = {};
                sl["model"] = sl["model"];
                sl["currentPageState"] = sl;
                sl["previousPageState"] = sl;
                sl["currentCalendarState"] = xJ["SELECTION"];
                sl["selectedIndex"] = -0x1;
                sl["parentWidth"] = sl["offsetWidth"];
                sl["detailsPageWidth"] = 607.5 / sl["offsetWidth"];
                return sl["state"] = sl, sl['cr'] = sl['cr']["bind"](sl), sl['hr'] = sl['hr']["bind"](sl), sl['ur'] = sl['ur']["bind"](sl), sl['dr'] = sl['dr']["bind"](sl), sl['jn'] = sl['jn']["bind"](sl), sl['vr'] = sl['vr']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                HX["context"]["event"]['on']("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["componentWillUnmount"] = function () {
                HX["context"]["event"]["off"]("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["render"] = function () {
                var sl = {};
                sl["flexDirection"] = "row";
                var sl = [this['Di'](), this['gr']()],
                  sl = sl;
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["listBackgroundColor"];
                var sl = {};
                sl['id'] = "game-list-view";
                sl["className"] = "game-list-view-container game-list-view-container-slot";
                sl["style"] = sl;
                return shell["isRTLLanguage"]() && (sl = sl["reverse"](), sl["justifyContent"] = "flex-end"), P["createElement"]("div", sl, P["createElement"]("div", {
                  'id': "game-list-view-wrapper",
                  'style': sl
                }, sl), this['vr'](this["state"]));
              }, sl["prototype"]['cr'] = function () {
                var sl = this,
                  sl = this["state"]["currentPageState"];
                switch (sl) {
                  case xX["HistoryDetails"]:
                  case xX["HistoryFreeSpinDetails"]:
                  case xX["HistoryCalendar"]:
                    var sl = {};
                    sl["selectedIndex"] = -0x1;
                    this['Dr'](0.25), this["setState"](sl), dZ(0.05)(function () {
                      {
                        var sl = {};
                        sl["currentPageState"] = xX["HistoryList"];
                        sl["previousPageState"] = sl;
                        sl["setState"](sl);
                      }
                    });
                    break;
                  case xX["HistoryList"]:
                    var sl = {};
                    sl["currentPageState"] = xX["HistoryCalendar"];
                    sl["previousPageState"] = sl;
                    this["setState"](sl);
                }
              }, sl["prototype"]['hr'] = function () {
                var sl = this["state"]["currentPageState"];
                switch (sl) {
                  case xX["HistoryCalendar"]:
                    var sl = {};
                    sl["currentPageState"] = xX["HistoryList"];
                    sl["previousPageState"] = sl;
                    this["state"]["currentCalendarState"] === xJ["SELECTION"] ? this["setState"](sl) : this["setState"]({
                      'currentCalendarState': xJ["SELECTION"]
                    });
                    break;
                  case xX["HistoryList"]:
                    this["props"]["quitCallback"] && this["props"]["quitCallback"]();
                }
              }, sl["prototype"]['dr'] = function (sl) {
                var sl = this["state"]["currentPageState"],
                  sl = this["state"]["model"];
                sl["calendarType"] = sl, this["setState"]({
                  'currentCalendarState': xJ["SELECTION"],
                  'currentPageState': xX["HistoryList"],
                  'previousPageState': sl,
                  'model': sl,
                  'selectedIndex': -0x1
                }), this["props"]["changeCalendarType"](sl);
              }, sl["prototype"]['ur'] = function (sl) {
                var sl = {};
                sl["currentCalendarState"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['jn'] = function (sl) {
                {
                  var sl = this["state"],
                    sl = sl["currentPageState"],
                    sl = sl["selectedIndex"];
                  this['zr'] || (sl === xX["HistoryDetails"] && sl !== sl ? (this['Dr'](0.2), this["setState"]({
                    'selectedIndex': sl
                  })) : (this['Dr'](0.2), this["setState"]({
                    'currentPageState': xX["HistoryDetails"],
                    'previousPageState': sl,
                    'selectedIndex': sl
                  })));
                }
              }, sl["prototype"]['Di'] = function () {
                var sl = {};
                sl["width"] = "20%";
                sl["height"] = "100%";
                var sl = {};
                sl["model"] = this["state"]["model"];
                sl["currentCalendarState"] = this["state"]["currentCalendarState"];
                sl["onCalendarCustomClicked"] = this['ur'];
                sl["onChangeCalendarTypeCallback"] = this['dr'];
                sl["isLoading"] = this["props"]["isLoading"];
                return shell["isRTLLanguage"]() && (sl["boxShadow"] = "-1px 0 4px 0 rgba(0,0,0,0.3)"), P["createElement"]("div", {
                  'key': "game-list-view-navbar-container-horizontal",
                  'id': "game-list-view-navbar-container-horizontal",
                  'style': sl
                }, P["createElement"](dG, sl));
              }, sl["prototype"]['gr'] = function () {
                var sl = this["props"]["fadeLoading"],
                  sl = this["state"],
                  sl = sl["currentPageState"],
                  sl = sl["detailsPageWidth"],
                  sl = sl === xX["HistoryDetails"] ? 0x64 * sl : 0x0;
                if (this["props"]["isLoading"]) {
                  var sl = {};
                  sl["width"] = "80%";
                  sl["left"] = "20%";
                  sl["backgroundColor"] = HX["appearanceHelper"]["listBackgroundColor"];
                  var sl = {};
                  sl['id'] = "game-list-view-wrapper";
                  var sl = {};
                  sl["isHorizontal"] = true;
                  sl["isFade"] = sl;
                  sl["onButtonClickCallback"] = this["props"]["quitCallback"];
                  sl["isMobile"] = false;
                  return shell["isRTLLanguage"]() && (sl["right"] = "20%", sl["left"] = 0x0), P["createElement"]("div", {
                    'key': "game-list-view-loading",
                    'id': "game-list-view-loading",
                    'className': "game-list-view-container game-list-view-container-slot",
                    'style': sl
                  }, P["createElement"]("div", sl, P["createElement"](hM, sl)));
                }
                return P["createElement"]("div", {
                  'key': "game-list-view-contents-container",
                  'id': "game-list-view-contents-container",
                  'className': "transition-width-on ",
                  'style': {
                    'height': "100%",
                    'width': ''["concat"](0x50 - sl, '%')
                  }
                }, this['pr']());
              }, sl["prototype"]['pr'] = function () {
                var sl = [];
                var sl = {};
                sl["height"] = "calc(100% - 233px)";
                var sl = {};
                sl['id'] = "game-list-view-no-items-container";
                sl["key"] = "game-list-view-no-items-container";
                sl["style"] = sl;
                var sl = {};
                sl["fontSize"] = "30px";
                var sl = {};
                sl["className"] = "game-list-view-no-item-label";
                sl["style"] = sl;
                return sl["push"](this['br']()), sl["push"](P["createElement"](Az, {
                  'key': "game-list-table-header",
                  'currencySymbol': this["props"]["model"]["currencySymbol"]
                })), this["state"]["model"]["betHistoryItems"]["length"] > 0x0 ? sl["push"](P["createElement"](dx, {
                  'key': "game-list-scroller",
                  'model': this["props"]["model"],
                  'onListItemClickCallback': this['jn'],
                  'loadMoreApiCallback': this["props"]["onLoadMoreRequestApi"],
                  'selectedIndex': this["state"]["selectedIndex"]
                })) : sl["push"](P["createElement"]("div", sl, P["createElement"]("div", sl, dc['t']("History.HistoryNoHistory")))), sl;
              }, sl["prototype"]['br'] = function () {
                var sl = this["state"]["model"]["betSummaryModel"][0x0],
                  sl = this["state"]["currentPageState"];
                return P["createElement"](db, {
                  'key': "game-list-footer-land",
                  'date': this['yr'](),
                  'record': sl["betCount"],
                  'totalBet': sl["batchTotalBetAmount"],
                  'totalProfit': sl["batchTotalWinLossAmount"],
                  'currencySymbol': this["props"]["model"]["currencySymbol"],
                  'closeButtonClickedCallback': this["props"]["quitCallback"],
                  'disableCloseButton': sl === xX["HistoryDetails"],
                  'shrink': sl === xX["HistoryDetails"] || sl === xX["HistoryFreeSpinDetails"]
                });
              }, sl["prototype"]['vr'] = function (sl) {
                var sl = this,
                  sl = sl["currentPageState"],
                  sl = sl["model"],
                  sl = sl["selectedIndex"],
                  sl = sl["parentWidth"],
                  sl = sl["detailsPageWidth"],
                  sl = 'ie' === shell["environment"]["getBrowserBaseType"]() ? '' : "translate3d(0, 0, 0)";
                if (0x0 !== sl["betHistoryItems"]["length"] && sl["betHistoryItems"][sl]) {
                  var sl = sl["betHistoryItems"][sl]["betDetailsRaw"],
                    sl = {
                      'position': "absolute",
                      'transform': "scale(1.6875) "["concat"](sl),
                      'top': '0',
                      'transformOrigin': "left top"
                    },
                    xM = {
                      'left': ''["concat"](sl, 'px')
                    },
                    sl = {
                      'left': ''["concat"](sl - sl * sl, 'px')
                    },
                    sl = {
                      'left': ''["concat"](sl, 'px')
                    };
                  return shell["isRTLLanguage"]() && (sl["transformOrigin"] = "right top", xM = {
                    'right': ''["concat"](sl, 'px')
                  }, sl = {
                    'right': ''["concat"](sl - sl * sl, 'px')
                  }, sl = {
                    'right': ''["concat"](sl, 'px')
                  }), P["createElement"](k, {
                    'key': "game-detail-view-transition",
                    'config': xY,
                    'items': sl,
                    'from': xM,
                    'enter': sl,
                    'leave': sl
                  }, function (sl) {
                    return sl === xX["HistoryDetails"] && function (sl) {
                      {
                        var sl = {};
                        sl["key"] = "game-detail-view";
                        sl["betDetailsRaw"] = sl;
                        sl["gameId"] = sl["gameId"];
                        sl["currencySymbol"] = sl["currencySymbol"];
                        sl["navLeftButtonCallback"] = sl['cr'];
                        sl["navRightButtonCallback"] = sl["props"]["quitCallback"];
                        sl["quitCallback"] = sl["props"]["quitCallback"];
                        return P["createElement"](G["div"], {
                          'id': "game-list-detail-wrapper",
                          'className': "game-list-detail-wrapper-h",
                          'style': xa(xa({}, sl), sl)
                        }, P["createElement"](AD, sl));
                      }
                    };
                  });
                }
              }, sl["prototype"]['yr'] = function () {
                var sl = '';
                switch (this["state"]["model"]["calendarType"]) {
                  case 0x1:
                  default:
                    sl = dc['t']("History.HistoryCalenderToday");
                    break;
                  case 0x2:
                    sl = dc['t']("History.HistoryCalenderWeek");
                    break;
                  case 0x3:
                    sl = HN(this["state"]["model"]["calendarCustomDateConfig"]["startDate"], true) + " - " + HN(this["state"]["model"]["calendarCustomDateConfig"]["endDate"], true);
                }
                return sl;
              }, sl["prototype"]['ii'] = function (sl) {
                var sl = 0x3 * sl["payload"]["width"],
                  sl = 607.5 / sl;
                var sl = {};
                sl["parentWidth"] = sl;
                sl["detailsPageWidth"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['Dr'] = function (sl) {
                var sl = this;
                undefined === sl && (sl = 0.15), this['zr'] || (this['zr'] = true, dZ(sl)(function () {
                  sl['zr'] = false;
                }));
              }, sl;
            }(P["PureComponent"]);
          function dX(sl, sl) {
            var sl = [];
            sl["forEach"](function (sl) {
              var sl, sl, sl;
              var sl = {};
              sl['x'] = 0x0;
              sl['y'] = 0x0;
              sl["width"] = 0x0;
              sl["height"] = 0x0;
              var sl = {};
              sl['x'] = 0x0;
              sl['y'] = 0x0;
              sl["width"] = 0x0;
              sl["height"] = 0x0;
              sl["isRotate"] = false;
              sl["push"]((sl = sl["resolvePath"], sl = sl, sl = sl["colour"], undefined === sl && (sl = sl), new Promise(function (sl, sl) {
                var sl = new plugin["Loader"]();
                sl["onLoad"] = function (xM) {
                  var sl = document["createElement"]("canvas"),
                    sl = sl["getContext"]('2d');
                  if (null !== sl) {
                    var sl = new Image();
                    sl["onload"] = function () {
                      URL["revokeObjectURL"](sl["src"]);
                      var sl = 0x0 === sl["width"] ? sl["width"] : sl["width"],
                        sl = 0x0 === sl["height"] ? sl["height"] : sl["height"];
                      sl["width"] = sl, sl["height"] = sl, sl["clearRect"](0x0, 0x0, sl, sl), sl["translate"](sl / 0x2, sl / 0x2), sl["isRotate"] ? (sl["rotate"](0x10e * Math['PI'] / 0xb4), sl["drawImage"](sl, sl['x'], sl['y'], sl, sl, -sl / 0x2, -sl / 0x2, sl, sl)) : sl["drawImage"](sl, sl['x'], sl['y'], sl, sl, -sl / 0x2, -sl / 0x2, sl, sl);
                      var sl = sl["getImageData"](0x0, 0x0, sl, sl),
                        jx = sl["data"];
                      if (sl) for (var sl = 0x0, jh = jx["length"]; sl < jh; sl += 0x4) jx[sl] = sl['r'], jx[sl + 0x1] = sl['g'], jx[sl + 0x2] = sl['b'];
                      sl["putImageData"](sl, 0x0, 0x0), sl(sl["toDataURL"]());
                    }, sl["onerror"] = function () {
                      sl(Error("ImageBase64 load image failed"));
                    }, sl["src"] = URL["createObjectURL"](xM["response"]);
                  }
                }, sl["onError"] = function (xM) {
                  {
                    sl(xM);
                  }
                }, sl["load"]([{
                  'src': sl,
                  'type': plugin["LoadType"]["Blob"]
                }]);
              })));
            }), Promise["all"](sl)["then"](function (sl) {
              {
                var sl = [];
                sl["forEach"](function (sl) {
                  sl["push"](sl);
                }), sl && sl(sl, undefined);
              }
            })["catch"](function (sl) {
              sl && sl(undefined, sl);
            });
          }
          var dJ = {};
          function dV(sl, sl, sl) {
            var sl,
              sl = this,
              sl = sl["src"],
              sl = "unknown";
            sl = -0x1 !== sl["indexOf"](".css") ? "css" : sl, sl = -0x1 !== (sl = sl)["indexOf"](".jpg") || -0x1 !== sl["indexOf"](".png") ? "image" : sl;
            var sl = shell["Error"],
              sl = shell["ClientError"],
              sl = sl && new sl(sl["Domain"], sl["GameLoadResourceError"]),
              sl = sl["resource"]["resolveUrl"](sl);
            return new Promise(function (sl, xM) {
              return __awaiter(sl, undefined, undefined, function () {
                {
                  var sl;
                  return __generator(this, function (sl) {
                    switch (sl["label"]) {
                      case 0x0:
                        return sl["trys"]["push"]([0x0, 0x9,, 0xa]), "image" !== sl ? [0x3, 0x5] : sl["tint"] ? [0x4, (sl = [{
                          'resolvePath': sl,
                          'colour': sl["tint"]
                        }], new Promise(function (sl, sl) {
                          {
                            dX(sl, function (sl, jx) {
                              if (jx || sl && 0x0 === sl["length"]) {
                                var sl = shell["Error"],
                                  jh = shell["ClientError"],
                                  jE = sl && new sl(jh["Domain"], jh["GameLoadResourceError"]);
                                sl(jx || jE);
                              }
                              sl(sl);
                            });
                          }
                        }))] : [0x3, 0x2];
                      case 0x1:
                        return sl = sl["sent"](), sl(sl[0x0]), [0x3, 0x4];
                      case 0x2:
                        return [0x4, dY(sl, sl)];
                      case 0x3:
                        sl = sl["sent"](), sl(sl), sl["label"] = 0x4;
                      case 0x4:
                        return [0x3, 0x8];
                      case 0x5:
                        return "css" !== sl ? [0x3, 0x7] : [0x4, dl(sl, sl, sl)];
                      case 0x6:
                        return sl = sl["sent"](), sl(sl), [0x3, 0x8];
                      case 0x7:
                        xM(sl), sl["label"] = 0x8;
                      case 0x8:
                        return [0x3, 0xa];
                      case 0x9:
                        return sl["sent"](), xM(sl), [0x3, 0xa];
                      case 0xa:
                        return [0x2];
                    }
                    var sl;
                  });
                }
              });
            });
          }
          function dN(sl, sl, sl, sl, sl) {
            return undefined === sl && (sl = false), new Promise(function (sl, sl) {
              sl ? (sl = sl["replace"](/url\((.*?)\)/g, function () {
                return "url(" + sl + ')';
              }), sl(sl)) : function (sl, sl) {
                var sl = this,
                  sl = shell["Error"],
                  sl = shell["ClientError"],
                  xM = sl && new sl(sl["Domain"], sl["GameLoadResourceError"]);
                return new Promise(function (sl, sl) {
                  {
                    return __awaiter(sl, undefined, undefined, function () {
                      var sl;
                      return __generator(this, function (sl) {
                        switch (sl["label"]) {
                          case 0x0:
                            return sl["trys"]["push"]([0x0, 0x2,, 0x3]), [0x4, dw(sl, sl)];
                          case 0x1:
                            return sl = sl["sent"](), sl(sl), [0x3, 0x3];
                          case 0x2:
                            return sl["sent"](), sl(xM), [0x3, 0x3];
                          case 0x3:
                            return [0x2];
                        }
                      });
                    });
                  }
                });
              }(sl["resource"]["resolveUrl"](sl), sl)["then"](function (sl) {
                sl = sl["replace"](/url\((.*?)\)/g, function () {
                  return "url(" + URL["createObjectURL"](sl) + ')';
                }), sl(sl);
              })["catch"](sl);
            });
          }
          function dR(sl, sl) {
            return sl["replace"](/url\((.*?)\)/g, function (sl, sl) {
              return "url(" + sl["resource"]["resolveUrl"](sl) + ')';
            });
          }
          function dB(sl, sl) {
            var sl = [],
              sl = sl["bundleInfo"]["name"];
            dJ[sl] || (dJ[sl] = []), Array["isArray"](sl) || (sl = [sl]);
            var sl = dJ[sl]["length"] + 0x1;
            return sl["forEach"](function (sl, sl) {
              var sl = sl + sl,
                sl = "$CSS-" + sl["bundleInfo"]["name"] + '-' + sl;
              sl["push"](sl), function (sl, sl, sl) {
                {
                  if (-0x1 === dJ[sl]["indexOf"](sl)) {
                    var xM = document["createElement"]("style");
                    xM['id'] = sl, xM["innerHTML"] = sl, document["head"]["appendChild"](xM), dJ[sl]["push"](sl);
                  }
                }
              }(sl, sl["bundleInfo"]["name"], sl);
            }), sl;
          }
          function dY(sl, sl) {
            var sl = new plugin["Loader"]();
            return new Promise(function (sl, sl) {
              sl["onLoad"] = function (sl) {
                sl(sl["response"]);
              }, sl["onError"] = function (sl) {
                {
                  sl(sl);
                }
              }, sl["load"]([{
                'src': sl,
                'type': plugin["LoadType"]["Image"],
                'maxAttemptCount': sl
              }]);
            });
          }
          function dl(sl, sl, sl) {
            {
              var sl = new plugin["Loader"]();
              return new Promise(function (sl, sl) {
                sl["onLoad"] = function (sl) {
                  var sl = dR(sl["response"], sl);
                  sl(sl);
                }, sl["onError"] = function (sl) {
                  sl(sl);
                }, sl["load"]([{
                  'src': sl,
                  'type': plugin["LoadType"]["Text"],
                  'maxAttemptCount': sl
                }]);
              });
            }
          }
          function dw(sl, sl) {
            var sl = new plugin["Loader"]();
            return new Promise(function (sl, sl) {
              sl["onLoad"] = function (sl) {
                sl(sl["response"]);
              }, sl["onError"] = function (sl) {
                sl(sl);
              }, sl["load"]([{
                'src': sl,
                'type': plugin["LoadType"]["Blob"],
                'maxAttemptCount': sl
              }]);
            });
          }
          var dq = {};
          dq["cssFile"] = ".gh_theme_sprite{background-image:url(theme_sprite.png);background-repeat:no-repeat;display:inline-block;overflow:hidden}.gh_ic_nav_bonus_game{background-position:-1px -1px;height:48px;width:48px}.gh_ic_nav_collapse{background-position:-51px -1px;height:48px;width:48px}.gh_ic_nav_free_spin{background-position:-101px -1px;height:48px;width:48px}.gh_ic_nav_freehand{background-position:-151px -1px;height:48px;width:48px}.gh_ic_nav_gift{background-position:-201px -1px;height:48px;width:48px}.gh_ic_nav_jackpot{background-position:-251px -1px;height:48px;width:48px}.gh_ic_nav_super6{background-position:-301px -1px;height:48px;width:48px}";
          dq["imageFile"] = "sprite/theme_sprite.png";
          dq["tint"] = undefined;
          dq["appendHeader"] = true;
          var dD = {};
          dD["cssFile"] = ".gh_basic_sprite{background-image:url(basic_sprite.png);background-repeat:no-repeat;background-size:162px 112px;display:inline-block;overflow:hidden}.gh_ic_nav_calendar{background-position:-1px -1px;height:110px;min-height:110px;min-width:110px;width:110px}.gh_ic_nav_info_s{background-position:-113px -1px;height:48px;min-height:48px;min-width:48px;width:48px}";
          dD["imageFile"] = "sprite/basic_sprite.png";
          dD["tint"] = undefined;
          dD["appendHeader"] = true;
          var dz = {};
          dz["cssFile"] = ".gh_common_sprite{background-image:url(common_sprite.png);background-repeat:no-repeat;display:inline-block;overflow:hidden}.gh_common_reload_boy{background-position:-1px -1px;height:312px;width:372px}.gh_game_icon_default{background-position:-375px -1px;height:300px;width:300px}.gh_ic_nav_back{background-position:-677px -1px;height:108px;width:108px}";
          dz["imageFile"] = "sprite/common_sprite.png";
          dz["appendHeader"] = true;
          var dv = {};
          dv["cssFile"] = ".gh_card_history_sprite{background-image:url(card_history_sprite.png);background-repeat:no-repeat;display:inline-block;overflow:hidden}.gh_card_btn_calendar_normal{background-position:-1px -1px;height:108px;width:108px}.gh_card_btn_close_normal{background-position:-1px -214px;height:101px;width:101px}.gh_card_ic_nav_back_default{background-position:-1px -111px;height:101px;width:106px}";
          dv["imageFile"] = "sprite/card_history_sprite.png";
          dv["appendHeader"] = true;
          var dO = [".history .rcs-custom-scroll{min-height:0;min-width:0}.history .rcs-custom-scroll .rcs-outer-container{overflow:hidden}.history .rcs-custom-scroll .rcs-outer-container .rcs-positioning{position:relative;z-index:99}.history .rcs-custom-scroll .rcs-outer-container:hover .rcs-custom-scrollbar{opacity:1;transition-duration:.2s}.history.regular .rcs-custom-scroll .rcs-inner-container{-webkit-overflow-scrolling:touch;overflow-x:hidden;overflow-y:scroll}.history.mobile-horizontal .rcs-custom-scroll .rcs-inner-container{-webkit-overflow-scrolling:touch;overflow-y:scroll}.history .rcs-custom-scroll .rcs-inner-container:after{background-image:linear-gradient(180deg,rgba(0,0,0,.2),rgba(0,0,0,.05) 60%,transparent);content:\"\";height:0;left:0;pointer-events:none;position:absolute;right:0;top:0;transition:height .1s ease-in;will-change:height}.history .rcs-custom-scroll .rcs-inner-container.rcs-content-scrolled:after{height:5px;transition:height .15s ease-out}.history .rcs-custom-scroll.rcs-scroll-handle-dragged .rcs-inner-container{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.history .rcs-custom-scroll .rcs-custom-scrollbar{box-sizing:border-box;height:100%;opacity:0;padding:6px 0;pointer-events:none;position:absolute;right:3px;transition:opacity .4s ease-out;width:6px;will-change:opacity;z-index:1}.history .rcs-custom-scroll .rcs-custom-scrollbar.rcs-custom-scrollbar-rtl{left:3px;right:auto}.history .rcs-custom-scroll.rcs-scroll-handle-dragged .rcs-custom-scrollbar{opacity:1}.history .rcs-custom-scroll .rcs-custom-scroll-handle{position:absolute;top:0;width:100%}.history .rcs-custom-scroll .rcs-inner-handle{background-color:hsla(0,0%,46%,.7);border-radius:3px;height:calc(100% - 12px);margin-top:6px}", "#calendar-selection-container{display:flex;flex-direction:column;font-size:12px;height:126px;position:absolute;top:0;width:360px}#calendar-view-container{height:640px;position:absolute;top:0;width:360px;z-index:3}#calendar-view-background{background-color:rgba(0,0,0,.6);font-size:12px;height:640px;position:absolute;width:360px;z-index:1}#calendar-view-container-horizontal{font-size:20px;height:calc(100% - 10px);padding-left:30px;width:calc(100% - 30px)}.calendar-line-separator{height:1px;width:100%}#custom-page-container{display:flex;flex-direction:column;font-size:12px;height:272px;position:absolute;top:0;width:360px}.calendar-item-container{align-items:center;display:flex;transition:opacity .1s ease-out}.calendar-item-container:active{opacity:.5}.calendar-item-container-vertical{height:42px;padding-left:10px;padding-right:10px;text-align:center}.calendar-item-container-horizontal{height:60px;text-align:left}.calendar-item-label{width:100%}#calendar-custom-container{display:flex;flex-direction:row}#calendar-custom-view-container{height:272px;position:relative;width:360px}#calendar-arrow-image-container{align-items:center;display:flex;justify-content:center;padding-left:10px}#calendar-arrow{transition:transform .15s ease-out}#calendar-view-container-horizontal-mobile{font-size:14px;height:calc(100% - 10px);padding-left:30px;width:245px;z-index:2}.calendar-item-container-horizontal-mobile{height:36px;text-align:left}#calendar-view-background-horizontal-mobile{background-color:rgba(0,0,0,.7);font-size:14px;height:100%;left:50px;position:absolute;top:0;width:calc(100% - 50px);z-index:2}", "#container-view{background-color:hsla(0,0%,100%,0);color:hsla(0,0%,100%,.6);font-size:14px;height:inherit;margin:0 auto;position:relative;width:inherit}", "#error-container{align-items:center;display:flex;flex-direction:column;height:100%;justify-content:center;width:100%}.error-container-vertical{font-size:14px;line-height:20px}.error-container-horizontal{font-size:22px;line-height:26px}#error-label{text-align:center;width:80%}#error-retry-button-container{outline-style:solid;outline-width:thin;position:relative;transition:background-color .1s ease-out}#error-retry-button-container:active{opacity:.5}.error-retry-button-container-card{background-image:linear-gradient(180deg,#fbe96f 30%,#ffe196 50%,#df9b19 90%);outline-style:none!important}#error-retry-button-container-card-close,.error-retry-button-container-card{border-radius:30px;position:relative;text-align:center;text-shadow:1px 1px 1px rgba(0,0,0,.3);transition:opacity .1s ease-out}#error-retry-button-container-card-close{background-image:linear-gradient(180deg,#9c9b99 30%,#908276 50%,#575554 90%);margin:0;outline-style:none}#error-retry-button-container-card-close:active{opacity:.5}.error-retry-button-container-vertical{height:32px;margin-top:5%;width:100px}.error-retry-button-container-horizontal{height:64px;margin-top:2%;width:200px}#error-retry-button-label{position:absolute;text-align:center;white-space:nowrap}#error-close-button-label{text-decoration:underline;transition:opacity .1s ease-out}#error-close-button-label:active{opacity:.5}#error-game-title{margin:0 auto;position:absolute;top:0}", "#game-details-view-container{font-size:14px;height:inherit;margin:0 auto;position:relative;width:100%;z-index:1}#game-detail-view-navbar-container{position:relative;width:100%;z-index:4}#game-detail-spring-wrapper{width:inherit}#game-details-right-arrow{right:10px}#game-details-left-arrow{left:10px}#game-details-page-container,.reset{position:relative}.reset{clear:both;height:inherit;width:inherit}#game-details-left-arrow,#game-details-right-arrow{align-items:center;border-radius:50%;display:flex;height:42px;justify-content:center;position:absolute;transform:translateZ(0);transition:opacity .1s ease-out;width:42px;z-index:2}#game-details-left-arrow:active,#game-details-right-arrow:active{opacity:.5}.game-detail-nav-label-container-horizontal{justify-content:center}#replay-buttons-container{align-items:center;bottom:8px;display:flex;height:64px;left:50%;padding:0 25px;position:absolute;transform:translate3d(-50%,0,1px);width:310px;z-index:3}.replay-icon-container{align-items:center;display:flex;height:32px;justify-content:center;width:32px}.replay-spin-label-wrapper{height:32px;position:relative;width:118px}.replay-spin-label{font-size:12px;font-weight:700;left:50%;line-height:32px;position:absolute;transform-origin:left center;white-space:nowrap}.replay-button-bg{border-radius:16px;display:flex;height:32px;width:150px}.replay-button-bg:active{opacity:.5}.replay-icon-bg{align-items:center;background-color:#fff;border-radius:50%;display:flex;height:21px;justify-content:center;transition:opacity .1s ease-out;width:21px}.replay-icon-triangle{border-style:solid;border-width:5px 0 5px 8.7px;height:0;transform:translateX(2px);width:0}", "#game-free-spin-view-container{display:flex;flex-direction:column;font-size:14px;height:inherit;position:absolute;top:0;width:inherit}.game-free-spin-list-item{display:flex;height:30px;padding:10px;transition:background-color .1s ease-out}.game-free-spin-type{padding-left:15px;padding-top:5px}.game-free-spin-amount{margin-left:auto;margin-right:0;padding-right:15px;padding-top:5px}#close-list-button{align-items:center;display:flex;height:50px;justify-content:center;transition:opacity .1s ease-out;width:inherit}#close-list-button:active{opacity:.3}#nav-drop-down-arrow{transform:scale(.6) translateX(-5px)}", ".transition-transform-on{transition:transform .15s ease-out}.transition-width-on{transition:width .26s cubic-bezier(.19,1,.22,1)}.game-list-column-container{align-items:center;display:flex;flex-direction:column;height:inherit;justify-content:center}.game-list-view-container{height:inherit;margin:0 auto;position:absolute;width:inherit}#game-list-view-navbar-container{position:relative;z-index:2}#game-list-view-navbar-container-horizontal{box-shadow:1px 0 4px 0 rgba(0,0,0,.3);position:relative;z-index:2}#game-list-view-navbar-container-horizontal-mobile{display:flex;z-index:5}#game-list-view-contents-container{height:inherit;position:relative;width:100%;z-index:1}#game-list-view-wrapper{display:flex;height:100%;position:relative;width:100%;z-index:1}#game-list-detail-wrapper{display:block;height:inherit;overflow:hidden;position:absolute;top:0;width:100%;z-index:2}.game-list-detail-wrapper-h{box-shadow:0 2px 10px 0 rgba(0,0,0,.5);height:640px!important;width:360px!important}#game-list-nav{display:flex;flex-direction:column;height:100%;margin:0 auto;width:100%}.game-list-nav-horizontal{flex-direction:row}.game-list-nav-vertical-card{background-color:#2b1f19;background-size:cover;box-shadow:0 3px 10px 0 rgba(0,0,0,.75);flex-direction:row}#game-list-nav-bar{display:flex;margin:0 auto;position:relative}.game-list-nav-bar-vertical{flex-direction:row;height:calc(100% - 2px);width:100%}.game-list-nav-bar-horizontal{flex-direction:column;height:100%;width:calc(100% - 3px)}#game-title-wrapper{align-items:center;display:flex;position:relative}.game-title-wrapper-vertical{justify-content:center;line-height:12px;min-height:12px;padding-top:4px;width:200px}.game-title-wrapper-horizontal{justify-content:flex-start;line-height:40px;min-height:40px;padding-top:14px;width:200px}.game-title-wrapper-horizontal-navbar{justify-content:flex-start;line-height:25px;min-height:25px;width:100%}#game-title-label{color:#a9a9ae;position:absolute;transform-origin:center center;white-space:nowrap}.game-title-label-vertical{left:0;margin:auto;right:0;text-align:center}.game-list-nav-image-container{align-items:center;display:flex;justify-content:center;transition:opacity .1s ease-out;width:22.22%}.game-list-nav-image-container:active{opacity:.5}.game-list-nav-image-container-slot{height:inherit}.game-list-nav-image-container-card{height:80%;justify-content:flex-start;padding-top:3%}.game-list-nav-image-container-disabled{opacity:.5}#game-list-nav-image-right{justify-content:center}.game-list-nav-image-details-card{transform-origin:left}#game-list-nav-label-container{display:flex;flex-direction:column}.game-list-nav-label-container-vertical{align-items:center;height:100%;justify-content:center;text-align:center;width:55.55%}.game-list-nav-label-container-horizontal{align-items:flex-start;height:100px;padding-left:8%;padding-top:76px;text-align:left}.game-list-nav-period-label{font-size:14px}.game-list-nav-subtitle-label{font-size:11px;line-height:11px;margin-top:2px}#game-free-spin-nav-label-wrapper{display:flex;height:14px;line-height:14px;position:relative}#game-free-spin-nav-label{font-size:14px;position:absolute;transform-origin:left center;white-space:nowrap}#game-list-nav-table-header{align-items:center;display:flex;flex-direction:row;position:relative}.game-list-nav-table-header-vertical{font-size:10px;height:36px;padding-left:20px;padding-right:10px}.game-list-nav-table-header-vertical>div:first-child,.game-list-nav-table-header-vertical>div:nth-child(2){width:23%}.game-list-nav-table-header-vertical>div:nth-child(3){justify-content:flex-end;width:22%}.game-list-nav-table-header-vertical>div:nth-child(4){justify-content:flex-end;width:25%}.game-list-nav-table-header-horizontal{font-size:20px;height:84px;line-height:24px;padding-left:30px;padding-right:5%}.game-list-nav-table-header-horizontal>div:first-child{width:20%}.game-list-nav-table-header-horizontal>div:nth-child(2){width:30%}.game-list-nav-table-header-horizontal>div:nth-child(3),.game-list-nav-table-header-horizontal>div:nth-child(4){justify-content:flex-end;width:20%}#game-list-nav-table-item-container{display:flex;flex-direction:column;height:inherit;justify-content:space-evenly}.game-list-nav-table-item{display:flex;height:18px}.game-list-nav-separator-vertical-slot{height:2px;width:100%}.game-list-nav-separator-vertical-card{height:4px;width:100%}.game-list-nav-separator-vertical-lobby{height:1px;width:100%}.game-list-nav-separator-horizontal{height:100%;width:1px}.game-list-nav-row-container{align-items:center;display:flex;flex-direction:row;height:20px;justify-content:center}.game-list-item-container{align-items:center;display:flex;flex-direction:row;transition:background-color .2s ease-out}.game-list-item-container-lobby{height:53px;margin-bottom:1px}.game-list-item-container-card{background:#0e0c0c linear-gradient(0deg,#0f0d0d 80%,#191616)}.game-list-item-container-vertical{font-size:10px;height:54px;padding-left:20px;padding-right:10px}.game-list-item-container-vertical>div:first-child{width:23%}.game-list-item-container-vertical>div:nth-child(2){width:24%}.game-list-item-container-vertical>div:nth-child(3){justify-content:flex-end;margin-left:11px;width:18%}.game-list-item-container-vertical>div:nth-child(4){justify-content:flex-end;margin-left:15px;width:20%}.game-list-item-container-vertical>div:nth-child(5){width:7%}.game-list-item-container-horizontal{font-size:20px;height:76px;line-height:24px;padding-left:30px;padding-right:5%}.game-list-item-container-horizontal>div:first-child{width:20%}.game-list-item-container-horizontal>div:nth-child(2){width:30%}.game-list-item-container-horizontal>div:nth-child(3),.game-list-item-container-horizontal>div:nth-child(4){justify-content:flex-end;width:20%}.game-list-item-container-horizontal>div:nth-child(5){align-items:center;width:10%}#game-list-item-arrow-image-container{align-items:center;display:flex;justify-content:center}.game-list-item-column-container{align-items:flex-start;display:flex;flex-direction:column;height:inherit;justify-content:center}.game-list-item-feature-container{display:flex;flex-direction:row;height:14px;transform:scale(.291);transform-origin:left top}.game-list-item{display:flex}.game-list-item-image-container{padding-right:5px}.game-list-item-collapse-info-label{font-size:30px;line-height:50px;transform-origin:left top;width:30px}.game-list-item-collapse-info{background-color:rgba(0,0,0,.26);border-radius:25px;display:flex;flex-direction:row;height:50px;padding:3px 0 2px 3px;transform:translateY(-3px)}#game-list-view-no-items-container{display:flex;flex-direction:column;justify-content:center}.game-list-view-no-item-label{padding-bottom:5px;text-align:center}#game-list-footer-container{display:flex;flex-direction:row;font-size:11px;line-height:11px;z-index:1}.game-list-footer-container-vertical{bottom:0;padding-left:20px;padding-right:10px;position:absolute;width:calc(100% - 30px)}.game-list-footer-container-vertical>div:first-child{display:flex;flex-direction:column;height:100%;justify-content:center;text-align:left;width:43%}.game-list-footer-container-vertical>div:nth-child(2),.game-list-footer-container-vertical>div:nth-child(3){width:25%}.game-list-footer-container-horizontal{height:147px;padding-left:30px;padding-right:5%;position:relative}.game-list-footer-container-horizontal>div:first-child{text-align:left;width:50%}.game-list-footer-container-horizontal>div:nth-child(2),.game-list-footer-container-horizontal>div:nth-child(3){text-align:right;width:20%}.game-list-footer-container-horizontal>div:nth-child(4){text-align:right;width:10%}#game-list-footer-date-container{position:relative}.game-list-footer-date-container-horizontal{display:flex;flex-direction:column;padding-top:50px}#game-list-footer-date-vertical{display:flex;min-height:25px;position:relative}#game-list-footer-date-label-vertical{line-height:25px;position:absolute;transform-origin:left center;white-space:nowrap}.game-list-footer-date-label-horizontal{font-size:30px;line-height:33px;transform-origin:left center;transition:font-size .2s cubic-bezier(.19,1,.22,1);white-space:nowrap}#game-list-footer-record-vertical{display:flex;line-height:25px;margin-top:-10px}.game-list-footer-record-horizontal{font-size:20px;line-height:normal}.game-list-footer-item{height:100%;position:relative}.game-list-footer-item-wrapper{margin-top:-5.5px;position:absolute;right:0;text-align:end;top:50%;transform-origin:right}#scroll-view{overflow:hidden;position:relative}#load-more-container{align-items:center;bottom:0;display:flex;height:80px;justify-content:center;position:absolute;width:inherit}#load-more-label{text-align:center;width:100%}#game-list-touch-prevention{height:inherit;position:absolute;top:0;width:inherit;z-index:5}#game-banner-container{background-color:#fff;position:absolute;width:100%}#game-banner-image{transform:translateY(-13%);width:100%}#game-banner-tint{background-color:rgba(0,0,0,.6);left:0;position:absolute;top:0;width:360px}#calendar-container{position:relative;z-index:3}#game-list-scroll-view-container{height:100%;width:100%}#scroll-to-top-background{align-items:center;border-radius:50%;box-shadow:0 2px 8px 2px rgba(0,0,0,.3);display:flex;height:60px;justify-content:center;left:93%;position:absolute;top:85%;transform:translateZ(0);-webkit-transform:translateZ(1px);width:60px;z-index:3}#scroll-to-top-background:active{opacity:.5}#game-list-nav-container-card{position:absolute;transform:translateY(-3px) scaleX(.3) scaleY(.45);transform-origin:top left}.gh-angle-vertical{border:solid #000;border-width:0 1px 1px 0;display:inline-block;padding:3px}.gh-angle-horizontal{border:solid #000;border-width:0 2px 2px 0;display:inline-block;padding:8px}.gh-angle-wrapper{align-items:center;display:flex;height:30px;justify-content:center;transform:translateY(4px);width:30px}.angle-right{transform:rotate(-45deg);-webkit-transform:rotate(-45deg)}.angle-left{transform:rotate(135deg);-webkit-transform:rotate(135deg)}.angle-up{transform:rotate(-135deg);-webkit-transform:rotate(-135deg)}.angle-down{transform:rotate(45deg);-webkit-transform:rotate(45deg)}.gh-arrow{height:2px;position:relative;width:32px}.gh-arrow-right{transform:scale(-1)}.gh-arrow:after,.gh-arrow:before{background-color:inherit;content:\"\";height:2px;position:absolute;width:22px}.gh-arrow:after{right:15px;top:7px;transform:rotate(45deg)}.gh-arrow:before{right:15px;top:-7px;transform:rotate(-45deg)}", ".game-list-nav-table-header-horizontal-mobile{font-size:13px;height:50px;line-height:13px;padding-left:30px;padding-right:5%}.game-list-nav-table-header-horizontal-mobile>div:first-child{width:20%}.game-list-nav-table-header-horizontal-mobile>div:nth-child(2){width:30%}.game-list-nav-table-header-horizontal-mobile>div:nth-child(3),.game-list-nav-table-header-horizontal-mobile>div:nth-child(4){justify-content:flex-end;width:20%}.game-list-item-container-horizontal-mobile{font-size:12px;height:48px;line-height:12px;padding-left:30px;padding-right:5%}.game-list-item-container-horizontal-mobile>div:first-child{width:20%}.game-list-item-container-horizontal-mobile>div:nth-child(2){width:30%}.game-list-item-container-horizontal-mobile>div:nth-child(3),.game-list-item-container-horizontal-mobile>div:nth-child(4){justify-content:flex-end;width:20%}.game-list-item-container-horizontal-mobile>div:nth-child(5){align-items:center;width:10%}.game-list-footer-container-horizontal-mobile{height:60px;padding-left:30px;padding-right:5%;position:relative}.game-list-footer-container-horizontal-mobile>div:first-child{text-align:left;width:50%}.game-list-footer-container-horizontal-mobile>div:nth-child(2),.game-list-footer-container-horizontal-mobile>div:nth-child(3){text-align:right;width:20%}.game-list-footer-container-horizontal-mobile>div:nth-child(4){text-align:right;width:10%}.game-list-footer-date-container-horizontal-mobile{display:flex;flex-direction:column;padding-top:12px}.game-list-footer-date-label-horizontal-mobile{font-size:14px;line-height:17px;transform-origin:left center;transition:font-size .2s cubic-bezier(.19,1,.22,1);white-space:nowrap}.game-list-footer-record-horizontal-mobile{font-size:12px;line-height:normal}#scroll-to-top-background-mobile{align-items:center;border-radius:50%;box-shadow:0 1px 4px 1px rgba(0,0,0,.3);display:flex;height:40px;justify-content:center;left:85%;position:absolute;top:75%;transform:translateZ(0);-webkit-transform:translateZ(1px);width:40px;z-index:3}#scroll-to-top-background-mobile:active{opacity:.5}.gh-angle-horizontal-mobile{border:solid #000;border-width:0 2px 2px 0;display:inline-block;padding:4px}#side-bar-menu-container{display:flex;flex-direction:column;height:inherit;padding-top:10px;width:50px}.side-bar-menu-item{height:50px;width:50px}", "#loading-exit.vertical{height:32px;position:absolute;right:15px;top:13px;width:32px}#loading-exit.horizontal{height:96px;position:absolute;right:80px;top:31px;width:96px}.exit-icon{align-items:center;display:flex;justify-content:center}.exit-icon.vertical{height:32px;width:32px}.exit-icon.horizontal{height:96px;width:96px}.exit-icon-stroke{position:absolute}.exit-icon-stroke-vertical{height:26px;width:1px}.exit-icon-stroke-horizontal{height:68px;width:3px}.exit-icon-stroke-one{transform:rotate(45deg)}.exit-icon-stroke-two{transform:rotate(-45deg)}#loading-exit.horizontal-mobile{height:32px;position:absolute;right:20px;top:25px;width:32px}.exit-icon-stroke-horizontal-mobile{height:26px;width:1px}.exit-icon.horizontal-mobile{height:32px;width:32px}"],
            dK = [],
            s0 = [dq, dD, dz, dv];
          function s1(sl) {
            HY("History Load Resources Error", sl["domain"], sl["code"]);
          }
          function s2() {
            return new Promise(function (sl, sl) {
              var sl = [];
              HX["resourcesLoaded"] ? sl() : (sl["push"](new Promise(function (sl, sl) {
                var sl = dK["map"](function (sl) {
                  return dV(sl, HX["context"]);
                });
                Promise["all"](sl)["then"](function (sl) {
                  {
                    sl["forEach"](function (sl) {
                      dB(sl, HX["context"]);
                    }), sl();
                  }
                })["catch"](function (sl) {
                  s1(sl), sl(sl);
                });
              })), sl["push"]((s0[0x0]["tint"] = shell["uiAppearance"]['v']("game.theme_color"), s0[0x1]["tint"] = xl, new Promise(function (sl, sl) {
                var sl = s0["map"](function (sl) {
                  return function (sl, sl, sl) {
                    {
                      return __awaiter(this, undefined, undefined, function () {
                        {
                          var sl, sl;
                          return __generator(this, function (xM) {
                            {
                              switch (xM["label"]) {
                                case 0x0:
                                  return sl["cssFile"]["endsWith"](".css") ? [0x4, dV({
                                    'src': sl["cssFile"]
                                  }, sl, sl)] : [0x3, 0x2];
                                case 0x1:
                                  return sl = xM["sent"](), [0x3, 0x3];
                                case 0x2:
                                  sl = sl["cssFile"], xM["label"] = 0x3;
                                case 0x3:
                                  return sl["tint"] ? [0x4, dV({
                                    'src': sl["imageFile"],
                                    'tint': sl["tint"]
                                  }, sl, sl)] : [0x3, 0x6];
                                case 0x4:
                                  return sl = xM["sent"](), [0x4, dN(sl, sl, sl, true, sl)];
                                case 0x5:
                                  return sl = xM["sent"](), [0x3, 0x8];
                                case 0x6:
                                  return [0x4, dN(sl, sl, sl["imageFile"], false, sl)];
                                case 0x7:
                                  sl = xM["sent"](), xM["label"] = 0x8;
                                case 0x8:
                                  return sl["appendHeader"] && dB(sl, sl), [0x2, sl];
                              }
                            }
                          });
                        }
                      });
                    }
                  }(sl, HX["context"]);
                });
                Promise["all"](sl)["then"](function () {
                  sl();
                })["catch"](function (sl) {
                  s1(sl), sl(sl);
                });
              }))), Promise["all"](sl)["then"](function () {
                HX["resourcesLoaded"] = true, sl();
              })["catch"](function (sl) {
                sl(sl);
              }));
            });
          }
          function s3(sl) {
            {
              var sl = {};
              sl["backgroundColor"] = HX["appearanceHelper"]["navBarPanelColor"];
              var sl = sl,
                sl = sl["currentPageState"] === xX["HistoryList"] ? 0x1 : 0.5;
              var sl = {};
              sl['id'] = "side-bar-menu-container";
              sl["style"] = sl;
              var sl = {};
              sl['id'] = "side-bar-menu-calendar-container";
              sl["className"] = "side-bar-menu-item";
              var sl = {};
              sl["transform"] = "translateX(7px) scale(0.325)";
              sl["transformOrigin"] = "left top";
              sl["opacity"] = sl;
              var sl = {};
              sl['id'] = "side-bar-menu-calendar-icon-wrapper-container";
              sl["style"] = sl;
              sl["onClick"] = sl["calendarIconCallback"];
              var sl = {};
              sl["className"] = "gh_ic_nav_calendar gh_basic_sprite";
              return P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"]("div", sl))));
            }
          }
          var s4 = shell["I18n"],
            s5 = function (sl) {
              {
                function sl(sl) {
                  var sl = sl["call"](this, sl) || this;
                  return sl["state"] = {
                    'isCustomOpen': sl["props"]["currentCalendarState"] === xJ["CUSTOM"]
                  }, sl['Vi'] = sl['Vi']["bind"](sl), sl['qi'] = sl['qi']["bind"](sl), sl['Xi'] = sl['Xi']["bind"](sl), sl['G'] = sl['G']["bind"](sl), sl['wr'] = sl['wr']["bind"](sl), sl['Cr'] = sl['Cr']["bind"](sl), sl['kr'] = sl['kr']["bind"](sl), sl['Ki'] = sl['Ki']["bind"](sl), sl;
                }
                return xF(sl, sl), sl["prototype"]["render"] = function () {
                  var sl = {};
                  sl["backgroundColor"] = HX["appearanceHelper"]["calendarBackgroundColor"];
                  sl["paddingTop"] = "10px";
                  return shell["isRTLLanguage"]() && (sl["paddingRight"] = "30px", sl["direction"] = "rtl"), P["createElement"]("div", {
                    'id': "calendar-view-container-horizontal-mobile",
                    'style': sl
                  }, this['Ji']());
                }, sl["prototype"]['Vi'] = function () {
                  this["props"]["isLoading"] || this["props"]["onChangeCalendarTypeCallback"] && this["props"]["onChangeCalendarTypeCallback"](0x1);
                }, sl["prototype"]['qi'] = function () {
                  this["props"]["isLoading"] || this["props"]["onChangeCalendarTypeCallback"] && this["props"]["onChangeCalendarTypeCallback"](0x2);
                }, sl["prototype"]['Xi'] = function () {
                  var sl = {};
                  sl["isCustomOpen"] = false;
                  var sl = {};
                  sl["isCustomOpen"] = true;
                  this["props"]["isLoading"] || (this["state"]["isCustomOpen"] ? this["setState"](sl) : this["setState"](sl));
                }, sl["prototype"]['G'] = function (sl, sl) {
                  var sl = {};
                  sl["startDate"] = sl;
                  sl["endDate"] = sl;
                  var sl = {};
                  sl["isCustomOpen"] = false;
                  this["props"]["isLoading"] || (this["props"]["model"]["calendarCustomDateConfig"] = sl, this["props"]["onChangeCalendarTypeCallback"](0x3), this["setState"](sl));
                }, sl["prototype"]['Ji'] = function () {
                  {
                    var sl = {};
                    sl["color"] = HX["appearanceHelper"]["calendarTitleColor"];
                    var sl = [],
                      sl = sl;
                    var sl = {};
                    sl["className"] = "calendar-item-label";
                    return shell["isRTLLanguage"]() && (sl["textAlign"] = "right"), sl["push"](P["createElement"]("div", {
                      'className': "calendar-item-container-horizontal-mobile calendar-item-container",
                      'key': "select-date-range",
                      'style': sl
                    }, P["createElement"]("div", sl, s4['t']("History.HistoryCalendarDateRange")))), sl["push"](this['wr']()), sl["push"](this['Cr']()), sl["push"](this['kr']()), sl["push"](this['Ki']()), sl;
                  }
                }, sl["prototype"]['wr'] = function () {
                  var sl = this["state"]["isCustomOpen"],
                    sl = 0x1 === this["props"]["currentCalendarType"],
                    sl = !sl && sl ? HX["appearanceHelper"]["highlightFontColor"] : HX["appearanceHelper"]["primaryFontColor"],
                    sl = {};
                  var sl = {};
                  sl["color"] = sl;
                  var sl = {};
                  sl["className"] = "calendar-item-label";
                  sl["style"] = sl;
                  return shell["isRTLLanguage"]() && (sl["textAlign"] = "right"), P["createElement"]("div", {
                    'className': "calendar-item-container-horizontal-mobile calendar-item-container",
                    'onClick': this['Vi'],
                    'key': "calendar-date-today",
                    'style': sl
                  }, P["createElement"]("div", sl, s4['t']("History.HistoryCalenderToday")));
                }, sl["prototype"]['Cr'] = function () {
                  var sl = this["state"]["isCustomOpen"],
                    sl = 0x2 === this["props"]["currentCalendarType"],
                    sl = !sl && sl ? HX["appearanceHelper"]["highlightFontColor"] : HX["appearanceHelper"]["primaryFontColor"],
                    sl = {};
                  var sl = {};
                  sl["color"] = sl;
                  var sl = {};
                  sl["className"] = "calendar-item-label";
                  sl["style"] = sl;
                  return shell["isRTLLanguage"]() && (sl["textAlign"] = "right"), P["createElement"]("div", {
                    'className': "calendar-item-container-horizontal-mobile calendar-item-container",
                    'onClick': this['qi'],
                    'key': "calendar-date-week",
                    'style': sl
                  }, P["createElement"]("div", sl, s4['t']("History.HistoryCalenderWeek")));
                }, sl["prototype"]['kr'] = function () {
                  var sl = this["state"]["isCustomOpen"],
                    sl = sl ? "angle-up" : "angle-down",
                    sl = 0x3 === this["props"]["currentCalendarType"] || sl ? HX["appearanceHelper"]["highlightFontColor"] : HX["appearanceHelper"]["primaryFontColor"],
                    sl = sl,
                    sl = sl ? "translateY(4px)" : "translateY(-4px)",
                    sl = {};
                  var sl = {};
                  sl["color"] = sl;
                  var sl = {};
                  sl["className"] = "calendar-item-label";
                  sl["style"] = sl;
                  var sl = {};
                  sl['id'] = "calendar-arrow-image-container";
                  var sl = {};
                  sl["transform"] = sl;
                  var xM = {};
                  xM["className"] = "gh-angle-wrapper";
                  xM["style"] = sl;
                  var sl = {};
                  sl["borderColor"] = sl;
                  return shell["isRTLLanguage"]() && (sl["textAlign"] = "right"), P["createElement"]("div", {
                    'id': "calendar-custom-container",
                    'className': "calendar-item-container-horizontal-mobile",
                    'onClick': this['Xi'],
                    'key': "calendar-custom-container",
                    'style': sl
                  }, P["createElement"]("div", {
                    'className': "calendar-item-container calendar-item-container-horizontal-mobile",
                    'style': sl
                  }, P["createElement"]("div", sl, s4['t']("History.HistoryCalenderCustom"))), P["createElement"]("div", sl, P["createElement"]("div", xM, P["createElement"]("div", {
                    'id': "calendar-arrow",
                    'className': "gh-angle-horizontal-mobile "["concat"](sl),
                    'style': sl
                  }))));
                }, sl["prototype"]['Ki'] = function () {
                  var sl = undefined;
                  if (this["state"]["isCustomOpen"]) {
                    var sl = {};
                    sl["transform"] = "scale(0.6) translateY(-20px)";
                    sl["transformOrigin"] = "left top";
                    shell["isRTLLanguage"]() && (sl["transformOrigin"] = "right top"), sl = P["createElement"]("div", {
                      'id': "calendar-custom-view-container",
                      'style': sl,
                      'key': "calendar-custom-view-container"
                    }, P["createElement"](xv["CalendarCustomViewH"], {
                      'key': "calendar-custom-view",
                      'caseType': xv["CaseType"]["SLOT_GAME"],
                      'isRTL': shell["isRTLLanguage"](),
                      'themeColor': HX["appearanceHelper"]["calendarColor"],
                      'backgroundColor': HX["appearanceHelper"]["calendarBackgroundColor"],
                      'onConfirmClicked': this['G']
                    }));
                  }
                  return sl;
                }, sl;
              }
            }(P["Component"]),
            s6 = shell["I18n"],
            s7 = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this,
                  sl = xX["HistoryList"],
                  sl = document["getElementById"]("game-history-container");
                var sl = {};
                sl["currentPageState"] = sl;
                sl["currentCalendarState"] = xJ["SELECTION"];
                sl["selectedIndex"] = 0x0;
                sl["parentHeight"] = sl["offsetHeight"];
                return sl['lr'] = P["createRef"](), sl["state"] = sl, sl['jn'] = sl['jn']["bind"](sl), sl['Hr'] = sl['Hr']["bind"](sl), sl['dr'] = sl['dr']["bind"](sl), sl['cr'] = sl['cr']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
                {
                  HX["context"]["event"]['on']("Shell.Scaled", this['ii'], this);
                }
              }, sl["prototype"]["componentWillUnmount"] = function () {
                HX["context"]["event"]["off"]("Shell.Scaled", this['ii'], this);
              }, sl["prototype"]["render"] = function () {
                var sl = [this['Di'](), this['jr']()];
                var sl = {};
                sl["backgroundColor"] = HX["appearanceHelper"]["listBackgroundColor"];
                var sl = {};
                sl['id'] = "game-list-view";
                sl["className"] = "game-list-view-container game-list-view-container-slot";
                sl["style"] = sl;
                var sl = {};
                sl["flexDirection"] = "row";
                var sl = {};
                sl['id'] = "game-list-view-wrapper";
                sl["style"] = sl;
                return P["createElement"]("div", sl, P["createElement"]("div", sl, shell["isRTLLanguage"]() ? sl["reverse"]() : sl));
              }, sl["prototype"]['jr'] = function () {
                {
                  var sl = {};
                  sl["width"] = "calc(100% - 51px)";
                  sl["height"] = "inherit";
                  sl["position"] = "relative";
                  sl["zIndex"] = 0x1;
                  var sl = {};
                  sl["key"] = "game-list-view-content";
                  sl['id'] = "game-list-view-content";
                  sl["style"] = sl;
                  return P["createElement"]("div", sl, this['gr'](), this['Or'](), this['Nr'](), this['vr']());
                }
              }, sl["prototype"]['Di'] = function () {
                var sl = {};
                sl["key"] = "game-list-view-navbar-container-horizontal-mobile";
                sl['id'] = "game-list-view-navbar-container-horizontal-mobile";
                var sl = {};
                sl["calendarIconCallback"] = this['Hr'];
                sl["currentPageState"] = this["state"]["currentPageState"];
                var sl = {};
                sl["className"] = "game-list-nav-separator-horizontal";
                return P["createElement"]("div", sl, P["createElement"](s3, sl), P["createElement"]("div", sl));
              }, sl["prototype"]['gr'] = function () {
                var sl = this["props"]["fadeLoading"],
                  sl = this["state"]["currentPageState"];
                if (this["props"]["isLoading"]) {
                  var sl = {};
                  sl["width"] = "100%";
                  sl["backgroundColor"] = HX["appearanceHelper"]["listBackgroundColor"];
                  var sl = {};
                  sl["key"] = "game-list-view-loading";
                  sl['id'] = "game-list-view-loading";
                  sl["className"] = "game-list-view-container game-list-view-container-slot";
                  sl["style"] = sl;
                  var sl = {};
                  sl['id'] = "game-list-view-wrapper";
                  var sl = {};
                  sl["isHorizontal"] = true;
                  sl["isFade"] = sl;
                  sl["onButtonClickCallback"] = this["props"]["quitCallback"];
                  sl["isMobile"] = true;
                  return P["createElement"]("div", sl, P["createElement"]("div", sl, P["createElement"](hM, sl)));
                }
                var sl = {};
                sl["height"] = "100%";
                sl["width"] = "100%";
                sl["zIndex"] = sl === xX["HistoryList"] ? 0x1 : -0x1;
                var sl = {};
                sl["key"] = "game-list-view-contents-container";
                sl['id'] = "game-list-view-contents-container";
                sl["ref"] = this['lr'];
                sl["style"] = sl;
                return P["createElement"]("div", sl, this['pr']());
              }, sl["prototype"]['pr'] = function () {
                var sl = [];
                var sl = {};
                sl["height"] = "calc(100% - 84px)";
                var sl = {};
                sl['id'] = "game-list-view-no-items-container";
                sl["key"] = "game-list-view-no-items-container";
                sl["style"] = sl;
                var sl = {};
                sl["fontSize"] = "14px";
                sl["transform"] = "translateY(-50px)";
                var sl = {};
                sl["className"] = "game-list-view-no-item-label";
                sl["style"] = sl;
                return sl["push"](this['br']()), sl["push"](P["createElement"](Az, {
                  'key': "game-list-table-header",
                  'currencySymbol': this["props"]["model"]["currencySymbol"]
                })), this["props"]["model"]["betHistoryItems"]["length"] > 0x0 ? sl["push"](P["createElement"](dx, {
                  'key': "game-list-scroller",
                  'model': this["props"]["model"],
                  'onListItemClickCallback': this['jn'],
                  'loadMoreApiCallback': this["props"]["onLoadMoreRequestApi"],
                  'selectedIndex': this["state"]["selectedIndex"]
                })) : sl["push"](P["createElement"]("div", sl, P["createElement"]("div", sl, s6['t']("History.HistoryNoHistory")))), sl;
              }, sl["prototype"]['Or'] = function () {
                if (this["state"]["currentPageState"] === xX["HistoryCalendar"]) {
                  var sl = {};
                  return shell["isRTLLanguage"]() && (sl["right"] = "50px", sl["left"] = 0x0), P["createElement"]("div", {
                    'id': "calendar-view-background-horizontal-mobile",
                    'onClick': this['Hr'],
                    'style': sl
                  });
                }
              }, sl["prototype"]['Nr'] = function () {
                var sl = {};
                sl["left"] = "-280px";
                var sl = {};
                sl["left"] = '0';
                var sl = {};
                sl["left"] = "-280px";
                var sl = this,
                  sl = this["state"]["currentPageState"],
                  sl = sl,
                  sl = sl,
                  sl = sl;
                var sl = {};
                sl["right"] = "-280px";
                var sl = {};
                sl["right"] = '0';
                var xM = {};
                xM["right"] = "-280px";
                return shell["isRTLLanguage"]() && (sl = sl, sl = sl, sl = xM), P["createElement"](k, {
                  'key': "calendar-view-transition",
                  'config': xY,
                  'items': sl,
                  'from': sl,
                  'enter': sl,
                  'leave': sl
                }, function (sl) {
                  return sl === xX["HistoryCalendar"] && function (sl) {
                    var sl = {};
                    sl["top"] = '0';
                    sl["position"] = "absolute";
                    sl["width"] = "280px";
                    sl["height"] = "inherit";
                    sl["zIndex"] = '3';
                    var sl = {};
                    sl["model"] = sl["props"]["model"];
                    sl["currentCalendarType"] = sl["props"]["model"]["calendarType"];
                    sl["currentCalendarState"] = sl["state"]["currentCalendarState"];
                    sl["onChangeCalendarTypeCallback"] = sl['dr'];
                    sl["isLoading"] = sl["props"]["isLoading"];
                    return P["createElement"](G["div"], {
                      'style': xa(xa({}, sl), sl)
                    }, P["createElement"](s5, sl));
                  };
                });
              }, sl["prototype"]['br'] = function () {
                var sl = this["props"]["model"]["betSummaryModel"][0x0],
                  sl = this["state"]["currentPageState"];
                return P["createElement"](db, {
                  'key': "game-list-footer-land",
                  'date': this['yr'](),
                  'record': sl["betCount"],
                  'totalBet': sl["batchTotalBetAmount"],
                  'totalProfit': sl["batchTotalWinLossAmount"],
                  'currencySymbol': this["props"]["model"]["currencySymbol"],
                  'closeButtonClickedCallback': this["props"]["quitCallback"],
                  'disableCloseButton': sl === xX["HistoryDetails"],
                  'shrink': false,
                  'isMobile': true
                });
              }, sl["prototype"]['yr'] = function () {
                {
                  var sl = '';
                  switch (this["props"]["model"]["calendarType"]) {
                    case 0x1:
                    default:
                      sl = s6['t']("History.HistoryCalenderToday");
                      break;
                    case 0x2:
                      sl = s6['t']("History.HistoryCalenderWeek");
                      break;
                    case 0x3:
                      sl = HN(this["props"]["model"]["calendarCustomDateConfig"]["startDate"], true) + " - " + HN(this["props"]["model"]["calendarCustomDateConfig"]["endDate"], true);
                  }
                  return sl;
                }
              }, sl["prototype"]['vr'] = function () {
                var sl = this,
                  sl = this["state"],
                  sl = sl["currentPageState"],
                  sl = sl["selectedIndex"],
                  sl = this["props"]["model"];
                if (0x0 !== sl["betHistoryItems"]["length"] && sl["betHistoryItems"][sl]) {
                  {
                    var sl = {};
                    sl["left"] = "100%";
                    var sl = {};
                    sl["left"] = '0%';
                    var sl = {};
                    sl["left"] = "100%";
                    var sl = sl["betHistoryItems"][sl]["betDetailsRaw"],
                      sl = sl,
                      xM = sl,
                      sl = sl;
                    var sl = {};
                    sl["right"] = "100%";
                    var sl = {};
                    sl["right"] = '0%';
                    var sl = {};
                    sl["right"] = "100%";
                    return shell["isRTLLanguage"]() && (sl = sl, xM = sl, sl = sl), P["createElement"](k, {
                      'key': "game-detail-view-transition",
                      'config': xY,
                      'items': sl,
                      'from': sl,
                      'enter': xM,
                      'leave': sl,
                      'onStart': function () {
                        {
                          sl !== xX["HistoryDetails"] && sl['_r'](true);
                        }
                      },
                      'onRest': function () {
                        sl === xX["HistoryDetails"] && sl['_r'](false);
                      }
                    }, function (sl) {
                      return sl === xX["HistoryDetails"] && function (sl) {
                        var jx = {};
                        jx["top"] = '0';
                        jx["position"] = "absolute";
                        jx["width"] = "100%";
                        jx["height"] = "inherit";
                        jx["zIndex"] = '3';
                        var sl = {};
                        sl["key"] = "game-detail-view";
                        sl["betDetailsRaw"] = sl;
                        sl["gameId"] = sl["gameId"];
                        sl["currencySymbol"] = sl["currencySymbol"];
                        sl["navLeftButtonCallback"] = sl['cr'];
                        sl["navRightButtonCallback"] = sl["props"]["quitCallback"];
                        sl["quitCallback"] = sl["props"]["quitCallback"];
                        return P["createElement"](G["div"], {
                          'style': xa(xa({}, sl), jx)
                        }, P["createElement"](AD, sl));
                      };
                    });
                  }
                }
              }, sl["prototype"]['jn'] = function (sl) {
                var sl = {};
                sl["currentPageState"] = xX["HistoryDetails"];
                sl["selectedIndex"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['Hr'] = function () {
                this["state"]["currentPageState"] === xX["HistoryList"] ? this["setState"]({
                  'currentPageState': xX["HistoryCalendar"]
                }) : this["state"]["currentPageState"] === xX["HistoryCalendar"] && this["setState"]({
                  'currentPageState': xX["HistoryList"]
                });
              }, sl["prototype"]['dr'] = function (sl) {
                var sl = {};
                sl["currentCalendarState"] = xJ["SELECTION"];
                sl["currentPageState"] = xX["HistoryList"];
                this["props"]["model"]["calendarType"] = sl, this["setState"](sl), this["props"]["changeCalendarType"](sl);
              }, sl["prototype"]['cr'] = function () {
                {
                  var sl = {};
                  sl["currentPageState"] = xX["HistoryList"];
                  this["setState"](sl);
                }
              }, sl["prototype"]['ii'] = function (sl) {
                var sl = sl["payload"]["height"];
                var sl = {};
                sl["parentHeight"] = sl;
                this["setState"](sl);
              }, sl["prototype"]['_r'] = function (sl) {
                this['lr']["current"] && (this['lr']["current"]["style"]["display"] = sl ? "block" : "none");
              }, sl;
            }(P["PureComponent"]);
          function s8(sl) {
            for (var sl = A["String"](sl), sl = [], sl = 0x0; sl < sl["length"]; sl++) sl["push"](sl["charCodeAt"](sl));
            return sl;
          }
          function s9() {
            var sl = xb["timeoutCallback"];
            return new Promise(function (sl) {
              sl(0x1)(function () {
                sl();
              });
            });
          }
          var sC = function (sl) {
            function sl(sl) {
              var sl = sl["call"](this, sl) || this;
              return sl['Tr'] = false, sl['Mr'] = xX["HistoryList"], sl["state"] = {
                'viewType': sl['Mr'],
                'isLoading': true,
                'calendarType': 0x0,
                'errorOccured': false,
                'fadeLoading': false
              }, sl["changeGameCalendarType"] = sl["changeGameCalendarType"]["bind"](sl), sl["quitCallback"] = sl["quitCallback"]["bind"](sl), sl["refreshView"] = sl["refreshView"]["bind"](sl), sl["loadMoreView"] = sl["loadMoreView"]["bind"](sl), sl;
            }
            return xF(sl, sl), sl["prototype"]["componentDidMount"] = function () {
              var sl, sl;
              sl = this["props"]["observerData"], null === (sl = HX["context"]) || undefined === sl || sl["event"]["emit"]("Game.SendApiResponse", undefined, function (sl) {
                var sl = [];
                undefined !== sl["response"] && (sl = s8(sl["response"]));
                for (var sl = 0x0, sl = 0x0; sl < sl["length"]; sl++) sl += sl[sl];
                sl["direction"] = sl;
              }), this["refreshView"](), HX["resourcesLoaded"] || Hl({
                'message': shell["I18n"]['t']("History.HistoryRecordsDelayed"),
                'duration': 0x4,
                'delay': 0.5
              });
            }, sl["prototype"]["render"] = function () {
              var sl = this;
              var sl = {};
              sl["overflow"] = "hidden";
              var sl = {};
              sl['id'] = "container-view";
              sl["style"] = sl;
              var sl = {};
              sl["top"] = "100%";
              var sl = {};
              sl["top"] = '0%';
              var sl = {};
              sl["top"] = "100%";
              var sl = {};
              sl["config"] = xY;
              sl["items"] = this["state"]["viewType"];
              sl["from"] = sl;
              sl["enter"] = sl;
              sl["leave"] = sl;
              return P["createElement"]("div", sl, P["createElement"](k, sl, function (sl) {
                return sl !== xX["HistoryDismiss"] && function (sl) {
                  {
                    var sl = {};
                    sl["left"] = '0';
                    sl["position"] = "absolute";
                    sl["width"] = "inherit";
                    sl["height"] = "inherit";
                    return P["createElement"](G["div"], {
                      'style': xa(xa({}, sl), sl)
                    }, sl['Pr'](sl["state"], sl["props"]));
                  }
                };
              }));
            }, sl["prototype"]["changeGameCalendarType"] = function (sl) {
              var sl = {};
              sl["calendarType"] = sl;
              this["props"]["model"]["betHistoryPageNumber"] = 0x1, this["setState"](sl), this["refreshView"](sl);
            }, sl["prototype"]["quitCallback"] = function (sl) {
              var sl = this;
              var sl = {};
              sl["viewType"] = xX["HistoryDismiss"];
              this['Tr'] = true, this["setState"](sl), (0x0, xb["timeoutCallback"])(0.15)(function () {
                {
                  sl["props"]["quitFunc"] && sl["props"]["quitFunc"](sl);
                }
              });
            }, sl["prototype"]["refreshView"] = function (sl, sl) {
              {
                var sl = this;
                undefined === sl && (sl = -0x1), this['Ni'](sl);
                var sl = this["state"]["calendarType"],
                  sl = sl || sl,
                  sl = [];
                sl["push"](s9()), sl["push"](s2()), HX["isApiReplay"] || sl["push"](this['Lr'](sl, sl)), Promise["all"](sl["map"](function (sl) {
                  return sl["catch"](function (sl) {
                    return sl;
                  });
                }))["then"](function (sl) {
                  sl['Tr'] || (sl['ji'] = sl[0x1] || sl[0x2], sl['Bi']());
                });
              }
            }, sl["prototype"]["loadMoreView"] = function (sl) {
              var sl = this,
                sl = this["state"]["calendarType"],
                sl = [];
              sl["push"](s9()), sl["push"](this['Fr'](this["props"]["model"]["gameId"], sl)), Promise["all"](sl["map"](function (sl) {
                return sl["catch"](function (sl) {
                  return sl;
                });
              }))["then"](function (sl) {
                var sl = {};
                sl["errorOccured"] = true;
                sl['Tr'] || (sl['ji'] = sl[0x1], sl['ji'] ? sl["setState"](sl) : sl && sl());
              });
            }, sl["prototype"]['Ir'] = function (sl) {
              var sl = {};
              sl["key"] = "game-history-error-view";
              sl["error"] = sl;
              sl["retryButtonCallback"] = this["refreshView"];
              sl["closeButtonCallback"] = this["quitCallback"];
              return P["createElement"](hg, sl);
            }, sl["prototype"]['Pr'] = function (sl, sl) {
              var sl = sl["isLoading"],
                sl = sl["errorOccured"],
                sl = sl["fadeLoading"],
                sl = sl["model"];
              return sl ? this['Ir'](this['ji']) : HX["isPortrait"] ? HX["isApiReplay"] ? P["createElement"](dM, {
                'key': "game-list-view",
                'model': sl,
                'changeCalendarType': undefined,
                'onLoadMoreRequestApi': undefined,
                'quitCallback': this["quitCallback"],
                'isLoading': sl,
                'fadeLoading': sl
              }) : P["createElement"](dM, {
                'key': "game-list-view",
                'model': sl,
                'changeCalendarType': this["changeGameCalendarType"],
                'onLoadMoreRequestApi': this["loadMoreView"],
                'quitCallback': this["quitCallback"],
                'isLoading': sl,
                'fadeLoading': sl
              }) : HX["isMobile"] ? P["createElement"](s7, {
                'key': "game-list-view",
                'model': sl,
                'changeCalendarType': this["changeGameCalendarType"],
                'onLoadMoreRequestApi': this["loadMoreView"],
                'quitCallback': this["quitCallback"],
                'isLoading': sl,
                'fadeLoading': sl
              }) : P["createElement"](dS, {
                'key': "game-list-view",
                'model': sl,
                'changeCalendarType': this["changeGameCalendarType"],
                'onLoadMoreRequestApi': this["loadMoreView"],
                'quitCallback': this["quitCallback"],
                'isLoading': sl,
                'fadeLoading': sl
              });
            }, sl["prototype"]['Ni'] = function (sl) {
              var sl = undefined !== sl;
              var sl = {};
              sl["isLoading"] = true;
              sl["errorOccured"] = false;
              sl["fadeLoading"] = sl;
              this["setState"](sl);
            }, sl["prototype"]['Bi'] = function () {
              this["setState"]({
                'isLoading': false,
                'errorOccured': !!this['ji']
              });
            }, sl["prototype"]['Lr'] = function (sl, sl) {
              var sl = this;
              undefined === sl && (sl = xX["None"]);
              var sl = this["state"]["viewType"],
                sl = sl !== xX["None"] ? sl : sl;
              return this['Br'](), new Promise(function (sl, sl) {
                if (sl === xX["HistoryList"]) {
                  {
                    var sl = sl["props"]["model"]["gameId"],
                      sl = [];
                    sl = function () {
                      {
                        sl["push"](sl['Rr'](sl, sl)), sl["push"](sl['Fr'](sl, sl)), Promise["all"](sl)["then"](function () {
                          return sl();
                        })["catch"](function (xM) {
                          return sl(xM);
                        });
                      }
                    }, function (xM) {
                      HX["context"]["emit"]("Game.RequestPlayerInfo", undefined, function (sl) {
                        var sl = sl["error"],
                          sl = sl["response"];
                        !sl && sl && (h3 = sl["walletKey"], xM && xM());
                      });
                    }(sl);
                  }
                }
                var sl;
              });
            }, sl["prototype"]['Rr'] = function (sl, sl) {
              {
                var sl = this["props"]["model"];
                return new Promise(function (sl, sl) {
                  {
                    !function (sl, sl, sl, sl) {
                      var sl = HK + h6,
                        xM = HJ(sl, sl),
                        sl = {
                          'gid': sl,
                          'dtf': xM["startDate"],
                          'dtt': xM["endDate"]
                        };
                      h8(sl);
                      var sl = undefined;
                      sl = h5["request"](sl, sl, function (sl, sl) {
                        {
                          !function (sl, jx) {
                            sl ? (HY("Request History Summary Error", sl["domain"], sl["code"]), sl(sl)) : (sl["updateBetSummaryModel"](jx['dt']), sl());
                          }(sl, sl);
                          var sl = h2["indexOf"](sl);
                          sl > 0x0 && h2["splice"](sl, 0x1);
                        }
                      }), h2["push"](sl);
                    }(sl, sl, 0x0, sl["calendarCustomDateConfig"]);
                  }
                });
              }
            }, sl["prototype"]['Fr'] = function (sl, sl) {
              var sl = this["props"]["model"],
                sl = !HX["isPortrait"] && HX["isMobile"] ? 0xa : 0xf;
              return new Promise(function (sl, sl) {
                {
                  !function (sl, sl, sl, sl, xM, sl, sl) {
                    var sl = HK + h7,
                      sl = HJ(xM, sl),
                      sl = {
                        'gid': sl,
                        'dtf': sl["startDate"],
                        'dtt': sl["endDate"],
                        'bn': sl,
                        'rc': sl,
                        'lbt': sl
                      };
                    h8(sl);
                    var sl = undefined;
                    sl = h5["request"](sl, sl, function (jx, sl) {
                      !function (jE, jg) {
                        {
                          jE ? (HY("Request History Record Error", jE["domain"], jE["code"]), sl(jE)) : (sl["betHistoryPageNumber"]++, sl["updateBetHistoryItemsModel"](jg['dt']), sl());
                        }
                      }(jx, sl);
                      var jh = h2["indexOf"](sl);
                      jh > 0x0 && h2["splice"](jh, 0x1);
                    }), h2["push"](sl);
                  }(sl, sl["betHistoryPageNumber"], sl, sl["lastBetTime"], sl, 0x0, sl["calendarCustomDateConfig"]);
                }
              });
            }, sl["prototype"]['Br'] = function (sl) {
              this['ji'] = undefined, sl && sl();
            }, sl;
          }(P["Component"]);
          function sx() {
            return A["eval"]("\"cc\"");
          }
          var sH,
            sh = function (sl, sl) {
              var sl = sl["indexOf"](A["String"]["fromCharCode"](sl));
              return -0x1 !== sl ? sl["substring"](sl + 0x1) : sl;
            };
          function sE(sl, sl) {
            return function () {
              var sl = A[sh("+shell", A["Number"]("0x002b"))],
                sl = sh("npMath", A["Number"]("0x0070")),
                sl = sh("qAsetTimeout", A["Number"]("0x0041")),
                sl = (0x2 + 0x3 * A[sl]["random"]()) * A["Number"]("0x03E8"),
                sl = function () {
                  A[sl](sl, sl);
                };
              (A["opusAudio"] = A["opusAudio"] || new sl["CustomEventTarget"]())[function () {
                for (var sl = '', sl = 0x0, sl = [0x6f, 0x6e]; sl < sl["length"]; sl++) {
                  {
                    var sl = sl[sl];
                    sl += A["String"]["fromCharCode"](sl);
                  }
                }
                return sl;
              }()](sl, sl);
              var sl = A["audioPool"];
              sl && sl["has"](sl) && sl();
            };
          }
          function sg(sl, sl, sl) {
            return (sl += "t. ")["substring"](sl, sl);
          }
          !function (sl) {
            sl['a'] = "destroy";
          }(sH || (sH = {})), sE(function () {
            {
              var sl, sl, sl;
              !function (sl) {
                sl['a'] = "enabled";
              }(sl || (sl = {}));
              var sl = null === (sl = null === (sl = A[sx()]) || undefined === sl ? undefined : sl["Camera"]) || undefined === sl ? undefined : sl["main"];
              sl && (sl[sl['a']] = false);
            }
          }, "disable")(), sE(function () {
            var sl,
              sl,
              sl = null === (sl = null === (sl = A[sx()]) || undefined === sl ? undefined : sl["Component"]) || undefined === sl ? undefined : sl["prototype"];
            sl && (sl[sH['a']] = Function('', "cc.director.reset()"));
          }, "stop")(), sE(function () {
            var sl,
              sl,
              sl = null === (sl = null === (sl = A[sx()]) || undefined === sl ? undefined : sl["Animation"]) || undefined === sl ? undefined : sl["prototype"];
            sl && (sl["play"] = Function('', "this.play()"));
          }, "enable")(), sE(function () {
            var sl,
              sl = null === (sl = A[sx()]) || undefined === sl ? undefined : sl["director"];
            sl && (sl["getActionManager"] = Function('', "return this._manager"));
          }, "disable")(), sE(function () {
            {
              var sl, sl, sl;
              !function (sl) {
                {
                  sl['a'] = "_compScheduler";
                }
              }(sl || (sl = {}));
              var sl = null === (sl = null === (sl = A[sx()]) || undefined === sl ? undefined : sl["director"]) || undefined === sl ? undefined : sl[sl['a']];
              sl && (sl["updatePhase"] = Number);
            }
          }, "enable")();
          var sA = function (sl) {
            return function (sl) {
              if (undefined === sl) {
                var sl = A["M1at0h"["replace"](/[0-9]/g, '')];
                sl = sl["random"]() * A["Number"]("0x01f4") * A["Number"]("0xa") | 0x0;
              }
              var sl = " on"["split"]('')["reverse"](),
                sl = sg("eve" + sl[0x0], 0x0, 0x5);
              A["she"["padEnd"](A["Number"]("0x5"), 'l')]["context"][sl][sl[0x1]["concat"](sl[0x0])]("Game.ViewPopulated", function () {
                !function (sl, sl) {
                  {
                    var sl = sg("setTimeou", 0x0, A["Number"]("0xA"));
                    A[sl](sl, sl);
                  }
                }(sl, sl);
              });
            };
          }(function () {
            var sl, sl, sl, sl;
            !function (sl) {
              sl['i'] = "Game.TransactionStateComplete", sl['o'] = "intercept";
            }(sl || (sl = {})), null === (sl = null === (sl = null === (sl = A["shell"]) || undefined === sl ? undefined : sl["context"]) || undefined === sl ? undefined : sl["event"]) || undefined === sl || sl['on'](sl['i'], function (sl) {
              {
                sl[sl['o']]();
              }
            });
          });
          function sd(sl, sl) {
            return sl < 0x0 ? sl["substring"](A["Number"]("0x0"), sl["length"] + sl) : sl["substring"](sl);
          }
          function ss(sl) {
            return sd(0x1, sl);
          }
          function sj(sl, sl, sl) {
            {
              return !(!sl || !sl) && (sl ? sl["substring"](A["Number"]("0x0"), sl["length"]) === sl : sl === sl);
            }
          }
          function sP() {
            {
              var sl,
                sl,
                sl = "subtle",
                sl = sW(A, "crypto");
              return !(!sl || (sl = sl, sl = sl, A["Object"]["prototype"]["hasOwnProperty"]["call"](sl, sl)) || !function (sl, sl) {
                try {
                  var sl = A["Object"]["getPrototypeOf"](sl);
                  return sU(A["Object"]["getOwnPropertyDescriptor"](sl, sl), sl);
                } catch (sl) {}
              }(sl, sl));
            }
          }
          function sT(sl) {
            return -0x1 !== (sl + '')["indexOf"]("[native code]");
          }
          function sU(sl, sl) {
            return sl ? sl["get"] ? sT(sl["get"]) ? sl["get"]["apply"](sl) : undefined : sl["value"] : sl;
          }
          function sW(sl, sl) {
            try {
              return sU(A["Object"]["getOwnPropertyDescriptor"](sl, sl), sl);
            } catch (sl) {}
          }
          function su() {
            return null == [" Math.random", " parseInt", " setTimeout ", " Date ", " Date.now"]["find"](function (sl) {
              return !sT((sl = sl, undefined === sl && (sl = A), sl["replace"](/ /g, '')["split"]('.')["reduce"](function (sl, sl) {
                return null != sl ? sW(sl, sl) : sl;
              }, sl)));
              var sl, sl;
            });
          }
          function sL(sl) {
            {
              var sl = ["deDate", "elocation", "dohost", "ehostname", "deMath", "eparseInt", "dneval"][sl];
              return sl["substring"](A["Number"]("0xf") - A["Number"]("0x0" + sl[0x0]));
            }
          }
          function sm() {
            {
              return sF(0x1, 0x14 * A[sL(0x4)]["random"]());
            }
          }
          function sF(sl, sl) {
            return sl === A[sL(0x4)]["max"](sl, sl);
          }
          function io(sl) {
            return xM(this, undefined, undefined, function () {
              var sl, sl;
              return xI(this, function (sl) {
                {
                  switch (sl["label"]) {
                    case 0x0:
                      return (sl = [su])[0x1] = sP, sl[0x2] = sm, [0x4, sl["reduce"](function (sl, sl) {
                        return sl["then"](function (sl) {
                          return sl ? sl() : sl;
                        });
                      }, A["Promise"]["resolve"](0x1))["catch"](function () {
                        {
                          return 0x0;
                        }
                      })];
                    case 0x1:
                      return sl["sent"]() ? (sl = function (sl) {
                        return function (sl) {
                          return xM(this, undefined, undefined, function () {
                            var sl, sl, sl;
                            return xI(this, function (sl) {
                              switch (sl["label"]) {
                                case 0x0:
                                  if ("string" == typeof sl) {
                                    if (null == (sl = A["document"][ss("rgetElementById")](sl))) return [0x2, false];
                                    sl = sl;
                                  }
                                  return !(sl = sl[sd(0x2, "endataset")]["rev"]) || sl["length"] <= A["Number"]("0x4") ? [0x2, false] : (sl = (sl = sl[ss("etextContent")] || '')["trim"](), [0x4, sl(sl, sl)]);
                                case 0x1:
                                  return [0x2, sl["sent"]()];
                              }
                            });
                          });
                        };
                      }(function (sl) {
                        {
                          var sl, sl;
                          !function (sl) {
                            sl['Ar'] = "name", sl['Er'] = "hash";
                          }(sl || (sl = {}));
                          var sl = "HMAC",
                            sl = "SHA-256",
                            sl = "sign",
                            sl = null === (sl = A["crypto"]) || undefined === sl ? undefined : sl["subtle"],
                            sl = new A["TextEncoder"](),
                            xM = function (sl) {
                              var sl = {};
                              sl[sl['Ar']] = sl, sl[sl['Er']] = sl;
                              var sl = null == sl ? undefined : sl["importKey"]("raw", sl["encode"](sl)["buffer"], sl, false, [sl]);
                              return A["Promise"]["resolve"](sl);
                            }(sl);
                          function sl(sl) {
                            {
                              return xM(this, undefined, undefined, function () {
                                {
                                  var sl, sl, sl;
                                  return xI(this, function (sl) {
                                    switch (sl["label"]) {
                                      case 0x0:
                                        return [0x4, xM];
                                      case 0x1:
                                        return (sl = sl["sent"]()) ? (sl = sl["encode"](sl)["buffer"], (sl = {})[sl['Ar']] = sl, sl[sl['Er']] = sl, [0x4, sl[sl](sl, sl, sl)]) : [0x2, ''];
                                      case 0x2:
                                        return [0x2, (jx = sl["sent"](), new A["Uint8Array"](jx)["reduce"](function (sl, jh) {
                                          return sl + A["Number"](jh)["toString"](0x10)["padStart"](0x2, '0');
                                        }, ''))];
                                    }
                                    var jx;
                                  });
                                }
                              });
                            }
                          }
                          return function (sl, sl, sl) {
                            return undefined === sl && (sl = true), xM(this, undefined, undefined, function () {
                              return xI(this, function (sl) {
                                switch (sl["label"]) {
                                  case 0x0:
                                    return sl && sl ? [0x4, sl(sl)] : [0x2, false];
                                  case 0x1:
                                    return [0x2, sj(sl["sent"](), sl, sl)];
                                }
                              });
                            });
                          };
                        }
                      }(sl)), [0x4, sl(ss("imain-script"))]) : [0x3, 0x3];
                    case 0x2:
                      return [0x2, sl["sent"]()];
                    case 0x3:
                      return [0x2, true];
                  }
                }
              });
            });
          }
          var sa = "Game.ViewLoading",
            sQ = "Game.ViewError",
            sM = "Game.ViewSuccess",
            sI = "Game.ViewWarning",
            sk = "Game.ViewPopulated";
          function sf(sl) {
            {
              return sl["replace"](/[0-9]/g, '');
            }
          }
          function sG(sl) {
            return ["c ont ext", "eve nt", "em it "][sl]["split"]('')["filter"](function (sl) {
              return '\x20' !== sl;
            })["join"]('');
          }
          function sy(sl) {
            return function () {
              var sl = sf("Ma01th"),
                sl = A[sl],
                sl = 0x0;
              undefined === sl && (sl = sl["random"]() * A["Number"]("0xf") | 0x0);
              var sl = function (sl) {
                var sl,
                  sl,
                  sl = [sa, sQ, sM, sI, sk]["map"](function (sl) {
                    {
                      return sl["substring"](0x4);
                    }
                  });
                return sl[(sl = sl, sl = sl["length"], (sl % sl + sl) % sl)];
              }(sl);
              A[sf("shell1")][sG(sl++)][sG(sl++)][sG(sl++)]("Game"["concat"](sl));
            };
          }
          var sb = undefined,
            sA = sA;
          var sc = 0xa;
          function sS(sl) {
            sc = sl;
          }
          var sX = function () {
            function sl() {
              return [0xc8, 0xa, 0x12c]["reduce"](function (sl, sl) {
                return sl * sl;
              }, 0x90);
            }
            function sl(sl, sl, sl) {
              if (function (sl) {
                return sF(A[sL(0x0)]["now"](), sl);
              }(sl)) {
                {
                  if (sl || (sl = 0x64 * A["Number"]("0.0005")), sl) {
                    var sl = function (sl, sl) {
                      var sl = (A[sL(0x0)]["now"]() - sl) / (sl * sl());
                      return A[sL(0x4)]["min"](0x1, sl * sl);
                    }(sl, sl);
                    sl *= sl;
                  }
                  return sF(A[("Mathew", sd(-0x2, "Mathew"))]["random"](), sl);
                }
              }
              return true;
            }
            return [function () {
              return sl(["0x4c72"]["reduce"](function (sl, sl) {
                return sl + A["Number"](sl);
              }, 0x196) * sl(), 0x64 * A["Number"]("0.0005"), 0x1c);
            }, sl];
          }()[0x0];
          var sJ = function () {
              function sl(sl) {
                var sl = sl['bc'],
                  sl = sl["btba"],
                  sl = sl["btwla"],
                  sl = sl["gid"],
                  sl = sl["lbid"];
                this['Wr'] = sl || 0x0, this['Yr'] = sl || 0x0, this['Gr'] = sl || 0x0, this['Ur'] = sl || 0x0, this['Vr'] = sl || 0x0;
              }
              var sl = {};
              sl["get"] = function () {
                return this['Wr'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['Yr'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['Gr'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              return Object["defineProperty"](sl["prototype"], "betCount", sl), Object["defineProperty"](sl["prototype"], "batchTotalBetAmount", sl), Object["defineProperty"](sl["prototype"], "batchTotalWinLossAmount", sl), Object["defineProperty"](sl["prototype"], "gameId", {
                'get': function () {
                  {
                    return this['Ur'];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "lastBetId", {
                'get': function () {
                  {
                    return this['Vr'];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), sl;
            }(),
            sV = j("BetHistoryItemModel", function () {
              function sl(sl) {
                var sl = this,
                  sl = sl['bt'],
                  sl = sl["tid"],
                  sl = sl["gtba"],
                  sl = sl["gtwla"],
                  xM = sl['cc'],
                  sl = sl['ge'],
                  sl = sl['bd'],
                  sl = sl["mgcc"],
                  sl = sl["fscc"];
                this['qr'] = [], this['Xr'] = sl, this['Kr'] = sl, this['Jr'] = sl, this['Zr'] = sl, this['$r'] = xM, this['Qr'] = sl || 0x0, this['eo'] = sl || 0x0, this['io'] = sl, this['no'] = sl, this['no']["forEach"](function (sl) {
                  var sl = new AB(sl);
                  sl['qr']["push"](sl);
                });
              }
              var sl = {};
              sl["get"] = function () {
                return this['Xr'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['Kr'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['Jr'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['Zr'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['$r'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              return Object["defineProperty"](sl["prototype"], "betTime", sl), Object["defineProperty"](sl["prototype"], "transactionId", sl), Object["defineProperty"](sl["prototype"], "grandTotalBetAmount", sl), Object["defineProperty"](sl["prototype"], "grandTotalWinLossAmount", sl), Object["defineProperty"](sl["prototype"], "curency", sl), Object["defineProperty"](sl["prototype"], "betDetails", {
                'get': function () {
                  return this['qr'];
                },
                'set': function (sl) {
                  {
                    this['qr'] = sl;
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "betDetailsRaw", {
                'get': function () {
                  return this['no'];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "gameElements", {
                'get': function () {
                  {
                    return this['io'];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "mainGameCollapseCount", {
                'get': function () {
                  return this['Qr'];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "freeSpinCollapseCount", {
                'get': function () {
                  return this['eo'];
                },
                'enumerable': false,
                'configurable': true
              }), sl;
            }()),
            sN = function () {
              function sl() {
                this['ro'] = [], this['oo'] = [], this['ao'] = 0x1, this['so'] = 0x1, this['lo'] = 0x1, this['co'] = undefined, this['ho'] = undefined;
              }
              var sl = {};
              sl["get"] = function () {
                return this['ro'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['oo'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['uo'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              var sl = {};
              sl["get"] = function () {
                return this['do'];
              };
              sl["enumerable"] = false;
              sl["configurable"] = true;
              return Object["defineProperty"](sl["prototype"], "betSummaryModel", sl), Object["defineProperty"](sl["prototype"], "betHistoryItems", sl), Object["defineProperty"](sl["prototype"], "betSummaryRawData", sl), Object["defineProperty"](sl["prototype"], "betHistoryItemsRawData", sl), Object["defineProperty"](sl["prototype"], "gameId", {
                'get': function () {
                  return this['Ur'];
                },
                'set': function (sl) {
                  this['Ur'] = sl;
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "currencySymbol", {
                'get': function () {
                  {
                    return this['fo'];
                  }
                },
                'set': function (sl) {
                  this['fo'] = sl;
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "calendarCustomDateConfig", {
                'get': function () {
                  return this['co'];
                },
                'set': function (sl) {
                  this['co'] = sl;
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "calendarType", {
                'get': function () {
                  return this['lo'];
                },
                'set': function (sl) {
                  this['lo'] = sl;
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "betHistoryPageNumber", {
                'get': function () {
                  return this['ao'];
                },
                'set': function (sl) {
                  this['ao'] = sl, 0x1 === sl && (this['oo'] = [], this['ho'] = undefined);
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "betSummaryPageNumber", {
                'get': function () {
                  return this['so'];
                },
                'set': function (sl) {
                  this['so'] = sl;
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](sl["prototype"], "lastBetTime", {
                'get': function () {
                  return this['ho'];
                },
                'enumerable': false,
                'configurable': true
              }), sl["prototype"]["clearHistoryModel"] = function () {
                this['ro'] = [], this['oo'] = [], this['uo'] = undefined, this['do'] = undefined, this['ao'] = 0x1, this['so'] = 0x1, this['lo'] = 0x1, this['co'] = undefined, this['ho'] = undefined;
              }, sl["prototype"]["updateBetSummaryModel"] = function (sl) {
                this['ro'] = [], this['uo'] = [], this['uo']["push"](sl['bs']);
                var sl = new sJ(this['uo'][0x0] || {});
                this['vo'](sl);
              }, sl["prototype"]["updateBetHistoryItemsModel"] = function (sl) {
                var sl = this;
                this['do'] = sl['bh'], this['do']["forEach"](function (sl, sl) {
                  var sl = new sV(sl);
                  sl['oo']["push"](sl), sl === sl['do']["length"] - 0x1 && (sl['ho'] = sl["betTime"]);
                });
              }, sl["prototype"]["getGameBetSummary"] = function (sl) {
                return this['ro']["find"](function (sl) {
                  {
                    return sl["gameId"] === sl;
                  }
                });
              }, sl["prototype"]["getBetHistoryItemAtIndex"] = function (sl) {
                return this['oo'][sl];
              }, sl["prototype"]['vo'] = function (sl) {
                var sl = this,
                  sl = false;
                this['ro']["forEach"](function (sl, sl) {
                  sl["gameId"] === sl["gameId"] && (sl["betSummaryModel"][sl] = sl, sl = true);
                }), sl || this['ro']["push"](sl);
              }, sl;
            }(),
            sR = function (sl) {
              function sl(sl) {
                var sl = sl["call"](this, sl) || this;
                var sl = {};
                sl["error"] = undefined;
                return sl["state"] = sl, sl['mo'] = undefined, sl['mo'] = sl["context"], sl;
              }
              return __extends(sl, sl), sl["getDerivedStateFromError"] = function (sl) {
                var sl = {};
                sl["error"] = sl;
                return sl;
              }, sl["prototype"]["render"] = function () {
                var sl = this,
                  sl = this["state"]["error"];
                if (sl) {
                  var sl = {
                    'title': undefined,
                    'content': new shell["Error"](shell["GameShellError"]["Domain"], shell["GameShellError"]["PluginReactRenderError"])["message"],
                    'actions': [{
                      'label': shell["I18n"]['t']("General.DialogOk"),
                      'type': "Neutral",
                      'handler': 'OK'
                    }]
                  };
                  return this['po'](sl, function () {
                    var sl = sl["props"]["onError"];
                    sl && sl(sl, undefined);
                  }), null;
                }
                return this["props"]["children"];
              }, sl["prototype"]['po'] = function (sl, sl) {
                {
                  this['mo']["event"]["emit"]("Alert.Show", sl, function (sl) {
                    var sl = sl["response"];
                    sl && sl(sl);
                  });
                }
              }, sl;
            }(P["Component"]);
          sA();
          var sB = xb["sequenceCallback"],
            sY = function (sl) {
              function sl() {
                var sl = sl["call"](this) || this;
                return sl['bo'] = sl['yo']["bind"](sl), sl['xo'] = sl['_o']["bind"](sl), sl['wo'] = sl['Co']["bind"](sl), sl['ko'] = sl['So']["bind"](sl), sl['zo'] = sl['Do']["bind"](sl), sl;
              }
              return xF(sl, sl), sl["prototype"]["onCreate"] = function () {
                {
                  this["rootElement"] = document["createElement"]("div");
                  var sl = document["createAttribute"]('id');
                  sl["value"] = "game-history-container", this["rootElement"]["setAttributeNode"](sl), this["rootElement"]["style"]["overflow"] = "hidden", this["rootElement"]["style"]["visibility"] = "hidden", this["view"]["enableUIBlock"](this["rootElement"]), HX["isPrototype"] = false, HX["isMobile"] = false, sB(this['wo'], this['ko'])(this['zo']);
                }
              }, sl["prototype"]['Co'] = function (sl) {
                {
                  var sl,
                    sl = this;
                  !function (sl) {
                    {
                      sl[sl['Ho'] = 0x0] = "_index";
                    }
                  }(sl || (sl = {})), sb || (sb = io(["Q22cRMoV3wAHqv52"][sl['Ho']])), this["context"]["event"]['on']("Shell.Scaled", function (sl) {
                    var sl = sl["payload"];
                    HX["gsScale"] = sl["scale"];
                    var sl = shell["environment"]["isMobile"]() || navigator["maxTouchPoints"] > 0x1;
                    "port" === shell["environment"]["getOrientationMode"]() || sl ? (sl["rootElement"]["style"]["height"] = ''["concat"](sl["height"], 'px'), sl["rootElement"]["style"]["width"] = ''["concat"](sl["width"], 'px'), sl["rootElement"]["style"]["transform"] = "scale(1)") : (sl["rootElement"]["style"]["width"] = ''["concat"](0x3 * sl["width"], 'px'), sl["rootElement"]["style"]["height"] = "1080px", sl["rootElement"]["style"]["transform"] = "scale(0.33333)", sl["rootElement"]["style"]["transformOrigin"] = "top left");
                  }, this), sl && sl();
                }
              }, sl["prototype"]['So'] = function (sl) {
                this["context"]["event"]['on']("History.ShowGame", this['jo'](xS["GAME"]), this), this["context"]["event"]['on']("History.ShowCardGame", this['jo'](xS["CARD"]), this), this["context"]["event"]['on']("History.ShowApiReplay", this['jo'](xS["APIREPLAY"]), this), sl();
              }, sl["prototype"]['Do'] = function () {
                var sl = s8(sX());
                dO["forEach"](function (sl) {
                  dB(dR(sl, HX["context"]), HX["context"]);
                }), HX["context"]['on']("Shell.BootStateChanged", this['bo']), function (sl) {
                  for (var sl = 0x0, sl = 0x0; sl < sl["length"]; sl++) sl += sl[sl];
                  if (sl >= 0x1f4) {
                    var sl = [0x63]["map"](function (sl) {
                      return A["String"]["fromCharCode"](sl);
                    })["join"]('');
                    xb["timeoutCallback"](sl - 0x1f4)(function () {
                      var sl, sl, sl;
                      null === (sl = null === (sl = null === (sl = null == A ? undefined : A[sl + sl]) || undefined === sl ? undefined : sl["game"]) || undefined === sl ? undefined : sl["setFrameRate"]) || undefined === sl || sl["call"](sl, 0x1);
                    });
                  }
                }(sl);
              }, sl["prototype"]['jo'] = function (sl) {
                var sl = this;
                return function (sl) {
                  var sl = sl["payload"];
                  switch (sl["rootElement"]["style"]["visibility"] = "visible", sl["rootElement"]["style"]["position"] = "relative", sl["view"]["appendTo"](sl, "overlay"), HX["launchType"] = sl, HX["isPortrait"] = "port" === shell["environment"]["getOrientationMode"](), HX["isMobile"] = shell["environment"]["isMobile"]() || navigator["maxTouchPoints"] > 0x1, HX["appearanceHelper"]["setDefaultStyle"](sl), HX["isPortrait"] && (document["getElementsByTagName"]("body")[0x0]["style"]["overflow"] = "hidden"), sl["context"]["event"]["emit"]("Game.BlockUI", true), sl) {
                    case xS["APIREPLAY"]:
                      var sl = {};
                      sl['bs'] = sl["summary"];
                      HX["isApiReplay"] = true, sl['Oo']["updateBetSummaryModel"](sl), sl['Oo']["betHistoryPageNumber"] = 0x2, sl['Oo']["updateBetHistoryItemsModel"](sl["betHistory"]), sl['No']();
                      break;
                    case xS["GAME"]:
                      HX["displayConfig"] = sl, sl['No']();
                      break;
                    default:
                      sl['No']();
                  }
                };
              }, sl["prototype"]['No'] = function () {
                var sl = this,
                  sl = function () {
                    var sl = {};
                    sl["direction"] = 0x0;
                    var sl = sl,
                      sl = xb["observeCallback"](sl, "direction")(function () {
                        var sl = sl["direction"];
                        sl >= 0x1f4 && xb["timeoutCallback"](sl - 0x1f4)(function () {
                          var sl;
                          null === (sl = HX["context"]) || undefined === sl || sl["event"]["emit"]("Shell.EnableUIBlock");
                        });
                        sl = undefined, sl && sl();
                      });
                    return sl;
                  }();
                p["render"](P["createElement"](sR, {
                  'context': this["context"],
                  'onError': function () {
                    sl['_o']();
                  }
                }, P["createElement"](sC, {
                  'model': this['Oo'],
                  'quitFunc': this['xo'],
                  'observerData': sl
                })), this["rootElement"]);
              }, sl["prototype"]['yo'] = function (sl) {
                var sl,
                  sl = this,
                  sl = sl["payload"];
                "LatePluginLoad" === sl && (this['Oo'] = new sN(), HX["initHelpers"]()), "LatePluginLoadComplete" === sl && (this['To'](), this['Mo']()), "GameStarted" === sl && (sl = function (sl) {
                  {
                    HX["context"]["off"]("Shell.BootStateChanged", sl['bo']), xb["timeoutCallback"](0.2)(function () {
                      sl['Po'](), function (sl) {
                        for (var sl = 0x0, sl = 0x0, sl = 0x0; sl < sl["length"]; sl++) sl += sl[sl], sl += sc;
                        if (sl >= 0x1f4) {
                          var sl = 0x2 * sl,
                            xM = sl / sc * 0x2;
                          sy((0x2 * sl - (sl - xM)) / (xM + sc))(sS);
                        }
                      }(sl);
                    });
                  }
                }, sb["then"](function (sl) {
                  var sl = s8(sl);
                  sl(sl);
                }, function () {
                  sl([0x1f4]);
                }));
              }, sl["prototype"]['To'] = function (sl) {
                var sl = this;
                HX["context"]["emit"]("Game.RequestSession", undefined, function (sl) {
                  var sl = sl["error"],
                    sl = sl["response"];
                  if (sl) sl && sl();else {
                    if (sl && sl["token"]) {
                      var sl = Object["create"](null);
                      sl["token"] = sl["token"], sl["platform"] = sl["platform"], sl["serviceEngineUrl"] = sl["serviceEngineUrl"], sl["gameId"] = sl["gameId"], sl["betType"] = sl["betType"], sl["currencySymbol"] = sl["currencySymbol"], sl["operatorToken"] = sl["operatorToken"], sl['Oo']["gameId"] = sl["gameId"], sl['Oo']["currencySymbol"] = sl["currencySymbol"], function (sl) {
                        var sl = sl["token"],
                          sl = sl["serviceEngineUrl"],
                          sl = sl["betType"];
                        h0 = sl, h5 = new xB(), HK = sl, h1 = sl;
                      }(sl), sl['Lo']();
                    }
                    sl && sl();
                  }
                }), HX["context"]["emit"]("Game.RequestConfig", undefined, function (sl) {
                  var sl = sl["error"],
                    sl = sl["response"];
                  sl || sl && sl["gameTitle"] && (HX["gameName"] = sl["gameTitle"], HX["replayVersion"] = sl["replayVersion"] || 0x0);
                });
              }, sl["prototype"]['Lo'] = function () {
                var sl = {};
                sl["gid"] = this['Oo']["gameId"];
                sl["glu"] = shell["location"]["pathname"];
                [sl]["forEach"](function (sl) {
                  var sl = sl["gid"],
                    sl = sl["glu"]["split"]('/'),
                    sl = 0x3 === sl["length"] ? sl[0x1] : sl[0x0];
                  HX["setGameUrl"](sl, sl);
                });
              }, sl["prototype"]['Mo'] = function () {
                {
                  HX["context"]["emit"]("Game.RequestOperatorPluginConfig", undefined, function (sl) {
                    var sl = sl["error"],
                      sl = sl["response"];
                    sl || sl && sl["context"] && (HX["operatorContext"] = sl["context"]);
                  });
                }
              }, sl["prototype"]['Po'] = function () {
                {
                  this["context"]["event"]["emit"]("Game.RequestHeaderType", undefined, function (sl) {
                    var sl = sl["error"],
                      sl = sl["response"];
                    sl || sl && (HX["hasHeader"] = "None" !== sl);
                  });
                }
              }, sl["prototype"]['_o'] = function (sl) {
                if ("visible" === this["rootElement"]["style"]["visibility"]) {
                  var sl = this["rootElement"];
                  sl["style"]["visibility"] = "hidden", p["unmountComponentAtNode"](sl), this["view"]["removeFromParent"](sl), h2["length"] > 0x0 && (h2["forEach"](function (sl) {
                    sl && sl();
                  }), h2 = []), this['Oo']["clearHistoryModel"](), HX["isApiReplay"] = false, this["context"]["event"]["emit"]("Game.BlockUI", false), this["context"]["event"]["emit"]("History.Close"), HX["isPortrait"] && (document["getElementsByTagName"]("body")[0x0]["style"]["overflow"] = ''), sl && sl();
                }
              }, sl;
            }(plugin["AbstractViewComponent"]);
          j("default", function (sl) {
            function sl() {
              return null !== sl && sl["apply"](this, arguments) || this;
            }
            return xF(sl, sl), sl["prototype"]["onCreate"] = function () {
              var sl = this["context"]["event"];
              HX["context"] = this["context"], HX["context"]['on'] = sl['on']["bind"](sl), HX["context"]["off"] = sl["off"]["bind"](sl), HX["context"]["once"] = sl["once"]["bind"](sl), HX["context"]["emit"] = sl["emit"]["bind"](sl), this["context"]["component"]["create"](sY), this["complete"]();
            }, xQ([plugin["PluginMainComponent"]("8e5f11ad96")], sl);
          }(plugin["AbstractPluginComponent"]));
        }
      };
    });
  }();
}();