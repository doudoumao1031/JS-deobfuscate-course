!function () {
  'use strict';

  !function () {
    var u = function () {
      {
        var P = !false;
        return function (l, N) {
          var p = P ? function () {
            {
              if (N) {
                var a = N["apply"](l, arguments);
                N = null;
                return a;
              }
            }
          } : function () {};
          P = false;
          return p;
        };
      }
    }();
    var z;
    !function (P) {
      var l = u(this, function () {
        return l["toString"]()["search"]("(((.+)+)+)+$")["toString"]()["constructor"](l)["search"]("(((.+)+)+)+$");
      });
      l();
      P["bv_t"] = "window", P["bv_n"] = "self";
    }(z || (z = {}));
    var X = (0x0, eval)("this"),
      B = (X[z["bv_n"]], X[z["bv_t"]]);
    System["register"](["ba588d9dad", "99212c6ec4", "3d9bb7755c", "6d5cafebdb", "react", "react-dom"], function (P) {
      'use strict';

      var N, p, W, b, H, S, R, Q, y, v, J, F;
      return {
        'setters': [null, function (M) {
          N = M["ResRC"], p = M["Utils"], W = M["Deserialiser"], b = M["XHR"], H = M["Preference"], S = M["CanvasResizeBroadcaster"];
        }, function (M) {
          {
            R = M["LoginMethod"], Q = M["LoginGameStatus"];
          }
        }, null, function (M) {
          y = M["default"], v = M["useState"], J = M["useEffect"];
        }, function (M) {
          F = M["default"];
        }],
        'execute': function () {
          P("getGameContext", uO);
          var u0 = B["__extends"],
            u1 = B["__assign"],
            u2 = B["__decorate"],
            u3 = B["__awaiter"],
            u4 = B["__generator"],
            u5 = B["__spreadArray"];
          function u6(uI, uI) {
            var uI = {};
            for (var uH in uI) uI["hasOwnProperty"](uH) ? uI[uI[uH]] = uI[uH] : uI[uH] = uI[uH];
            return uI;
          }
          u6({
            'unloadBundleAsset': "releaseBundleAsset",
            'unload': "release",
            'unloadBundle': "releaseBundle",
            'deleteBundle': "removeBundle",
            'loadByBundleAsset': "loadBundleAsset",
            'loadRemoteBySingle': "loadRemoteSingle"
          }, N);
          var u7 = u6({
            'convertNodeSpace': "convertToNodeSpace",
            'convertNodeSpaceAR': "convertToNodeSpaceAR",
            'getAbsolutePos': "getAbsolutePosition",
            'getAbsoluteXPos': "getAbsoluteX",
            'getAbsoluteYPos': "getAbsoluteY",
            'setAbsolutePos': "setAbsolutePosition",
            'setAbsoluteXPos': "setAbsoluteX",
            'setAbsoluteYPos': "setAbsoluteY",
            'transferToNewParent': "transferToParent",
            'getSharedSimpleScheduler': "getSharedScheduler",
            'delay': "delayCallback",
            'timeout': "timeoutCallback",
            'selector': "selectorCallback",
            'sequence': "sequenceCallback",
            'spawn': "spawnCallback",
            'waterfall': "waterfCallback",
            'condition': "condCallback",
            'defer': "deferCallback",
            'tick': "tickCallback",
            'observe': "observeCallback",
            'formatLeadingZero': "formatTwoDigit",
            'formatDateTime': "formatDate",
            'isRightToLeft': "isRTL",
            'getLocationProtocol': "getProtocol",
            'getLocationOrigin': "getOrigin"
          }, p);
          function u8(uI) {
            return "[object Object]" === Object["prototype"]["toString"]["call"](uI);
          }
          function u9(uI) {
            var uI = undefined;
            if (u8(uI) && uI["hasOwnProperty"]("err") && uI["hasOwnProperty"]('dt')) {
              {
                var uI = uI["err"];
                uI && (uI = function (uH) {
                  {
                    return u8(uH) || (uH = Object["create"](null)), uH["hasOwnProperty"]('cd') && +uH['cd'] || (uH['cd'] = 0x1965), new (0x0, shell["Error"])(shell["ServerError"]["Domain"], uH['cd'], uH["tid"]);
                  }
                }(uI));
              }
            } else uI = new (0x0, shell["Error"])(shell["ServerError"]["Domain"], 0x1965);
            return uI;
          }
          function uj(uI) {
            return function (uI, uI) {
              {
                uI = uI || u9(uI), uI(uI, uI);
              }
            };
          }
          function uE(uI, uI, uI, uH) {
            var B9 = uI["request"]("POST", uI, uI, uj(uH));
            return function () {
              return B9["abort"]();
            };
          }
          P("XHRHelper", Object["freeze"]({
            '__proto__': null,
            'extractError': u9,
            'postRequest': uE,
            'responseCallbackWrapper': uj
          }));
          var uz,
            uX = function (uI) {
              {
                function uI() {
                  var uI = null !== uI && uI["apply"](this, arguments) || this;
                  return uI["transformResponse"] = function (uH) {
                    {
                      return uH;
                    }
                  }, uI;
                }
                return u0(uI, uI), uI;
              }
            }(W),
            uB = P("XHRHandler", function () {
              function uI() {
                this["bv_e"] = undefined, this["bv_i"] = undefined, this["bv_r"] = undefined, this["bv_a"] = new uX("json"), this["bv_o"] = new b(undefined, this["bv_a"]);
              }
              return uI["prototype"]["setAPIUrls"] = function (uI) {
                this["bv_e"] = uI["getFullGameEngineUrl"](), this["bv_i"] = uI["getFullServiceEngineUrl"](), this["bv_r"] = uI["getFullServiceEngineUrlSD"]();
              }, uI["prototype"]["request"] = function (uI, uI, uH) {
                {
                  return uE(this["bv_o"], this["bv_e"] + uI, uI, uH);
                }
              }, uI["prototype"]["serviceRequest"] = function (uI, uI, uH) {
                {
                  return uE(this["bv_o"], this["bv_i"] + uI, uI, uH);
                }
              }, uI["prototype"]["serviceSDRequest"] = function (uI, uI, uH) {
                {
                  return uE(this["bv_o"], this["bv_r"] + uI, uI, uH);
                }
              }, uI["prototype"]["operatorApiRequest"] = function () {
                {
                  return u7["emptyFunc"];
                }
              }, uI;
            }());
          !function (uI) {
            uI[uI["Low"] = 0xfa] = "Low", uI[uI["Medium"] = 0x1f4] = "Medium", uI[uI["High"] = 0x2ee] = "High";
          }(uz || (uz = {}));
          var uP,
            ul,
            uN = {
              'Low': uz["Low"],
              'Medium': uz["Medium"],
              'High': uz["High"]
            };
          function up(uI) {
            return function () {
              {
                return uI["reduce"](function (uI, uI) {
                  return uI["then"](function (uH) {
                    {
                      return uH ? uI() : uH;
                    }
                  });
                }, B["Promise"]["resolve"](0x1))["catch"](function () {
                  {
                    return 0x0;
                  }
                });
              }
            };
          }
          function ud(uI, uI) {
            {
              return uI < 0x0 ? uI["substring"](B["Number"]("0x0"), uI["length"] + uI) : uI["substring"](uI);
            }
          }
          function uW(uI) {
            {
              return ud(0x1, uI);
            }
          }
          function ub(uI) {
            return ud(0x2, uI);
          }
          function uH(uI, uI, uI) {
            {
              return !(!uI || !uI) && (uI ? uI["substring"](B["Number"]("0x0"), uI["length"]) === uI : uI === uI);
            }
          }
          function uS() {
            var uI = "subtle",
              uI = uQ(B, "crypto");
            return !(!uI || us(uI, uI) || !uy(uI, uI));
          }
          function uc(uI) {
            return -0x1 !== (uI + '')["indexOf"]("[native code]");
          }
          function us(uI, uI) {
            {
              return B["Object"]["prototype"]["hasOwnProperty"]["call"](uI, uI);
            }
          }
          function uR(uI, uI) {
            {
              return uI ? uI["get"] ? uc(uI["get"]) ? uI["get"]["apply"](uI) : undefined : uI["value"] : uI;
            }
          }
          function uQ(uI, uI) {
            try {
              {
                return uR(B["Object"]["getOwnPropertyDescriptor"](uI, uI), uI);
              }
            } catch (uI) {}
          }
          function uy(uI, uI) {
            {
              try {
                var uI = B["Object"]["getPrototypeOf"](uI);
                return uR(B["Object"]["getOwnPropertyDescriptor"](uI, uI), uI);
              } catch (uH) {}
            }
          }
          function uv(uI, uI) {
            return undefined === uI && (uI = B), ux(uI)["split"]('.')["reduce"](function (uI, uH) {
              {
                return null != uI ? uQ(uI, uH) : uI;
              }
            }, uI);
          }
          function uJ() {
            return null == [" Math.random", " parseInt", " setTimeout ", " Date ", " Date.now"]["find"](function (uI) {
              {
                return !uc(uv(uI));
              }
            });
          }
          function uF(uI) {
            for (var uI = [" SamsungBrowser", "UCBrowser", " Quark", "QQBrowser", " OppoBrowser", " VivoBrowser", " 360(SE|EE) ", " b(?:ai)?d(?:u)?browser "], uI = [], uH = 0x0; uI;) 0x1 & uI && uH < uI["length"] && uI["push"](ux(uI[uH])), uI >>= 0x1, uH++;
            if (uI["length"]) {
              {
                var B9 = new B["RegExp"](uI["join"](ux(" | ")), ux(" i "));
                return function () {
                  {
                    return B9["test"](B["navigator"]["userAgent"]);
                  }
                };
              }
            }
            return function () {
              {
                return false;
              }
            };
          }
          function uM(uI) {
            {
              var uI = ["deDate", "elocation", "dohost", "ehostname", "deMath", "eparseInt", "dneval"][uI];
              return uI["substring"](B["Number"]("0xf") - B["Number"]("0x0" + uI[0x0]));
            }
          }
          function uI() {
            return uT(0x1, 0x14 * B[uM(0x4)]["random"]());
          }
          function ux(uI) {
            return uI["replace"](/ /g, '');
          }
          function uT(uI, uI) {
            {
              return uI === B[uM(0x4)]["max"](uI, uI);
            }
          }
          function uk(uI) {
            {
              var uI, uI;
              !function (uQ) {
                uQ["bv_u"] = "name", uQ["bv_c"] = "hash";
              }(uI || (uI = {}));
              var uH = "HMAC",
                B9 = "SHA-256",
                B8 = "sign",
                uQ = null === (uI = B["crypto"]) || undefined === uI ? undefined : uI["subtle"],
                B7 = new B["TextEncoder"](),
                B8 = function (uQ) {
                  var l6 = {};
                  l6[uI["bv_u"]] = uH, l6[uI["bv_c"]] = B9;
                  var l6 = null == uQ ? undefined : uQ["importKey"]("raw", B7["encode"](uQ)["buffer"], l6, false, [B8]);
                  return B["Promise"]["resolve"](l6);
                }(uI);
              function B8(uQ) {
                {
                  return u3(this, undefined, undefined, function () {
                    {
                      var l6, l6, l8;
                      return u4(this, function (uQ) {
                        switch (uQ["label"]) {
                          case 0x0:
                            return [0x4, B8];
                          case 0x1:
                            return (l6 = uQ["sent"]()) ? (l6 = B7["encode"](uQ)["buffer"], (l8 = {})[uI["bv_u"]] = uH, l8[uI["bv_c"]] = B9, [0x4, uQ[B8](l8, l6, l6)]) : [0x2, ''];
                          case 0x2:
                            return [0x2, (uQ = uQ["sent"](), new B["Uint8Array"](uQ)["reduce"](function (lE, lz) {
                              {
                                return lE + B["Number"](lz)["toString"](0x10)["padStart"](0x2, '0');
                              }
                            }, ''))];
                        }
                        var uQ;
                      });
                    }
                  });
                }
              }
              return function (uQ, l6, l6) {
                {
                  return undefined === l6 && (l6 = true), u3(this, undefined, undefined, function () {
                    {
                      return u4(this, function (l8) {
                        {
                          switch (l8["label"]) {
                            case 0x0:
                              return l6 && uQ ? [0x4, B8(uQ)] : [0x2, false];
                            case 0x1:
                              return [0x2, uH(l8["sent"](), l6, l6)];
                          }
                        }
                      });
                    }
                  });
                }
              };
            }
          }
          function uO() {
            {
              return uP;
            }
          }
          function uC() {
            return ul;
          }
          P("BVFrameworkEnum", {
            'EN_GAME_LAYER_Z_INDEX_LOW': uz["Low"],
            'EN_GAME_LAYER_Z_INDEX_MEDIUM': uz["Medium"],
            'EN_GAME_LAYER_Z_INDEX_HIGH': uz["High"]
          }), P("default", function (uI) {
            function uI() {
              {
                return null !== uI && uI["apply"](this, arguments) || this;
              }
            }
            return u0(uI, uI), uI["prototype"]["onCreate"] = function () {
              ul = this["context"];
              var uI = shell["getGameContext"](),
                uH = uI["event"];
              uI['on'] = uH['on']["bind"](uH), uI["off"] = uH["off"]["bind"](uH), uI["once"] = uH["once"]["bind"](uH), uI["emit"] = uH["emit"]["bind"](uH), (uP = uI)['on']("Game.RequestLayerType", function (B9) {
                {
                  var B8 = B9["payload"];
                  if ("All" === B8) B9["response"] = uN;else {
                    var uQ = uz[B8];
                    uQ || (uQ = uz["Low"]), B9["response"] = uQ;
                  }
                }
              }), function (B9) {
                var B8,
                  uQ = (B8 = B9, new B["Promise"](function (uQ, l6) {
                    B8["once"]("Login.OnLogin", function (l6) {
                      {
                        var l8 = l6["payload"],
                          uQ = l8["err"],
                          uQ = l8["res"];
                        uQ ? l6() : uQ(uQ["operatorPromotionId"]);
                      }
                    }, undefined);
                  }));
                uQ["catch"](function () {});
                var B7,
                  B8 = function (uQ) {
                    {
                      return new B["Promise"](function (l6) {
                        var l6 = false,
                          l8 = "Shell.BootStateChanged";
                        uQ['on'](l8, function uQ(uQ) {
                          {
                            l6 || "LatePluginLoad" === uQ["payload"] && (l6 = true, l6(), B["Promise"]["resolve"]()["then"](function () {
                              {
                                return uQ["off"](l8, uQ, undefined);
                              }
                            }));
                          }
                        }, undefined);
                      });
                    }
                  }(B9);
                function B8(uQ, l6) {
                  var l6 = B8["then"](function () {
                    {
                      return function (l8) {
                        return new B["Promise"](function (uQ, uQ) {
                          {
                            l8["emit"]("Game.RequestSession", undefined, function (lE) {
                              var lz = lE["response"];
                              if (lz) {
                                {
                                  var lX = lz["token"],
                                    lB = lz["sessionId"],
                                    lP = lz["gameId"],
                                    lz = lz["operatorToken"];
                                  uQ({
                                    'bv_s': lX,
                                    'bv_l': lB,
                                    'bv_f': lP,
                                    'bv_h': lz
                                  });
                                }
                              } else uQ();
                            });
                          }
                        });
                      }(B9);
                    }
                  });
                  l6["catch"](function () {}), B["Promise"]["all"]([uQ, l6])["then"](function (l8) {
                    {
                      return l8[0x1]["bv_d"] = l8[0x0], function (uQ) {
                        {
                          return u3(this, undefined, undefined, function () {
                            {
                              var uQ, lE, lz;
                              return u4(this, function (lX) {
                                switch (lX["label"]) {
                                  case 0x0:
                                    return uQ = uk(ub("suER3N4z2BqFg9VCYg")), lE = uQ["bv_d"], lz = function () {
                                      {
                                        return u3(this, undefined, undefined, function () {
                                          var lB;
                                          return u4(this, function (lP) {
                                            {
                                              switch (lP["label"]) {
                                                case 0x0:
                                                  return lB = function (lz) {
                                                    return B[uM(0x1)][uM(0x2)] + B["String"](lz["bv_f"]) + lz["bv_h"] + B["encodeURIComponent"](lz["bv_s"]);
                                                  }(uQ), [0x4, uQ(lB, lE, true)];
                                                case 0x1:
                                                  return lP["sent"]() ? [0x2, true] : [0x2, false];
                                              }
                                            }
                                          });
                                        });
                                      }
                                    }, [0x4, lz()];
                                  case 0x1:
                                    return [0x2, lX["sent"]()];
                                }
                              });
                            }
                          });
                        }
                      }(l8[0x1]);
                    }
                  }, function () {
                    return B["Promise"]["resolve"](true);
                  })["then"](function (l8) {
                    {
                      uQ(l8);
                    }
                  }, l6);
                }
                B9['on']("Game.SendApiResponse", function (uQ) {
                  uQ["intercept"](), B7 || (B7 = function () {
                    return u3(this, undefined, undefined, function () {
                      {
                        var l6;
                        return u4(this, function (l6) {
                          switch (l6["label"]) {
                            case 0x0:
                              return (l6 = [uJ])["push"](uS), [0x4, up(l6 = l6["concat"]([uI]))()];
                            case 0x1:
                              return l6["sent"]() ? [0x2, new B["Promise"](B8)] : [0x2, true];
                          }
                        });
                      }
                    });
                  }()), B7["then"](function (l6) {
                    uQ["response"] = l6, uQ["propagate"]();
                  }, function () {
                    {
                      uQ["response"] = false, uQ["propagate"]();
                    }
                  });
                }, undefined);
              }(ul["event"]), this["complete"]();
            }, u2([plugin["PluginMainComponent"]("f72f5b9e6e")], uI);
          }(plugin["AbstractPluginComponent"]));
          var uL,
            um = false,
            uU = 0x0;
          !function (uI) {
            uI[uI["SLOT"] = 0x1] = "SLOT", uI[uI["CARD"] = 0x2] = "CARD";
          }(uL || (uL = {}));
          var uZ,
            uD = {
              'label': shell["I18n"]['t']("General.ResourceLoadingMessage"),
              'isFullBackground': true,
              'enableBackground': true,
              'opacity': 0x1,
              'inAnimate': "Fade",
              'inDuration': 0.3,
              'inValue': 0x0,
              'outAnimate': "Fade",
              'outValue': 0x0,
              'outDuration': 0.3
            };
          function uh(uI) {
            var uI,
              uI = uI["theme"],
              uH = uI["backgroundColor"],
              B9 = uI["titleColor"],
              B8 = uI["messageColor"],
              uQ = uI["buttonColor"],
              B7 = uI["buttonTitleColor"],
              B8 = uI["buttonFontWeight"],
              B8 = uI["buttonFontStyle"],
              uQ = uO();
            switch (uQ['on']("Shell.BootStateChanged", uV), uI) {
              case uL["SLOT"]:
                uI = "Slot";
                break;
              case uL["CARD"]:
                uI = "Card";
                break;
              default:
                throw Error("Notify - invalid theme");
            }
            var l6 = {};
            l6 = uQ["gradient"] ? {
              'gradient': uQ["gradient"]
            } : {
              'color': uQ
            }, l6 = u1({
              'fontColor': B7,
              'fontWeight': B8,
              'fontStyle': B8
            }, l6), uQ["emit"]("Alert.UpdateTheme", {
              'theme': uI,
              'style': {
                'backgroundColor': uH,
                'titleColor': B9,
                'contentColor': B8,
                'button': l6
              }
            });
          }
          function uY(uI, uI) {
            {
              um ? uO()["emit"]("Toast.Show", {
                'toastStyle': "Message",
                'message': uI,
                'duration': uI,
                'imageSrc': '',
                'toastPosition': "Bottom"
              }) : shell["setProgressMessage"](uI);
            }
          }
          function uw(uI) {
            var uI = [],
              uI = function (uH, B9) {
                {
                  var B8 = [],
                    uQ = 0x0;
                  return uH["actions"] && uH["actions"]["forEach"](function (B7) {
                    B8["push"]({
                      'label': B7["title"],
                      'handler': uQ
                    }), B9["push"](B7["handler"]), uQ++;
                  }), {
                    'title': uH["title_message"],
                    'content': uH["content_message"],
                    'actions': B8
                  };
                }
              }(uI, uI);
            return uO()["emit"]("Alert.Show", uI, function (uH) {
              var B9 = uH["response"],
                B8 = uI[B9];
              B8 && B8();
            }), uI;
          }
          function uV(uI) {
            "GameStarted" === uI["payload"] && (um = true, uO()["off"]("Shell.BootStateChanged", uV));
          }
          function uq(uI) {
            {
              if (0x0 === uU) {
                {
                  var uI = false;
                  if (uI) {
                    var uI = {
                      'backgroundColor': uI["backgroundColor"],
                      'iconColor': uI["iconColor"],
                      'labelColor': uI["labelColor"]
                    };
                    uO()["emit"]("Loading.UpdateTheme", uI), uI = !(!uI["iconColor"] && !uI["labelColor"]);
                  }
                  var uH = uI ? uD : Object["assign"](uD, {
                    'color': shell["uiAppearance"]['v']("game.theme_color")
                  });
                  uO()["emit"]("Loading.Show", uH);
                }
              }
              uU++;
            }
          }
          function uK() {
            {
              0x0 !== uU && 0x0 == --uU && uO()["emit"]("Loading.Hide");
            }
          }
          P("Notify", Object["freeze"]({
            '__proto__': null,
            get 'ThemeType'() {
              return uL;
            },
            'hideFullLoadingPage': uK,
            'initNotify': uh,
            'showDialog': uw,
            'showFullLoadingPage': uq,
            'showMessage': uY,
            'showNotification': function (uI) {
              um && uO()["emit"]("Toast.Show", {
                'toastStyle': "Notification",
                'imageSrc': uI["imageSrc"],
                'message': uI["message"],
                'duration': uI["duration"],
                'toastPosition': "Bottom"
              }, uI["eventCallback"]);
            },
            'showToast': function (uI) {
              um && uO()["emit"]("Toast.Show", {
                'toastStyle': "Notification",
                'message': uI["message"],
                'duration': uI["duration"],
                'toastPosition': "Bottom",
                'imageSrc': ''
              }, uI["eventCallback"]);
            }
          })), function (uI) {
            uI[uI["NORMAL"] = 0x1] = "NORMAL", uI[uI["TRIAL"] = 0x2] = "TRIAL", uI[uI["TOURNAMENT"] = 0x3] = "TOURNAMENT";
          }(uZ || (uZ = {}));
          var uA = u7["timeoutCallback"];
          function uG(uI) {
            shell['ga']["sendTiming"](shell['ga']["CATEGORY_ACCESS"], shell['ga']["EVENT_LOGIN"], Date["now"]() - uI);
          }
          function uf(uI, uI) {
            var uI = uO(),
              uH = {
                'category': shell['ga']["CATEGORY_ACCESS"],
                'domain': uI["domain"],
                'code': uI["code"],
                'error': "Login Failed",
                'retry': uI > 0x0 ? uI : undefined
              };
            uI["emit"]("Error.Report", uH);
          }
          var ug,
            j0,
            j1,
            j2,
            j3 = function (uI) {
              switch (uI["loginMethod"]) {
                case R["Web"]:
                  !function (uI) {
                    var uI = Date["now"](),
                      uH = uI["on_complete"],
                      B9 = uI["on_error"],
                      B8 = uI["on_show"],
                      uQ = uI["on_dismiss"],
                      B7 = uO();
                    B8 && B7["once"]("Login.OnShow", B8), uQ && B7["once"]("Login.OnDismiss", uQ), B7["once"]("Login.OnLogin", function (B8) {
                      {
                        var B8 = B8["payload"],
                          uQ = B8["err"],
                          l6 = B8["res"];
                        uQ ? (uf(uQ, 0x0), B9(uQ)) : (uG(uI), uH(l6));
                      }
                    }), B7["emit"]("Login.Login", {
                      'apiDomain': uI["apiDomain"],
                      'loginMethod': uI["loginMethod"],
                      'gameId': uI["gameId"],
                      'bundleId': uI["bundleId"],
                      'operatorToken': uI["operatorToken"],
                      'operatorPlayerSession': uI["operatorPlayerSession"],
                      'playerSession': uI["playerSession"],
                      'operatorParam': uI["operatorParam"],
                      'betType': uI["betType"],
                      'redirectOption': uI["redirectOption"]
                    });
                  }(uI);
                  break;
                case R["Session"]:
                default:
                  !function (uI) {
                    {
                      var uI = Date["now"](),
                        uH = uI["on_complete"],
                        B9 = uI["on_error"],
                        B8 = uI["on_show"],
                        uQ = uI["on_dismiss"],
                        B7 = undefined === uI["maxRetryCount"] ? 0x5 : uI["maxRetryCount"],
                        B8 = uO();
                      if (uI["betType"] === uZ["TRIAL"] || uI["operatorPlayerSession"] || uI["playerSession"]) {
                        {
                          var B8 = 0x0,
                            uQ = function () {
                              {
                                B8 && B8["once"]("Login.OnShow", B8), uQ && B8["once"]("Login.OnDismiss", uQ), B8["once"]("Login.OnLogin", function (l8) {
                                  {
                                    var uQ = l8["payload"],
                                      uQ = uQ["err"],
                                      lE = uQ["res"];
                                    uQ ? (uf(uQ, B8), !function (lz) {
                                      {
                                        return lz["shouldRetry"];
                                      }
                                    }(uQ) || B8 >= B7 ? B9(uQ) : (function (lz) {
                                      {
                                        uY(shell["I18n"]['t']("Login.LoginFail", {
                                          'times': {
                                            'ordinal': lz
                                          }
                                        }), 0x2);
                                      }
                                    }(++B8), uA(0x1 << B8)(function () {
                                      {
                                        B8["emit"]("Shell.PWDReset"), uQ();
                                      }
                                    }))) : (uG(uI), uH(lE));
                                  }
                                }), B8["emit"]("Login.Login", {
                                  'apiDomain': uI["apiDomain"],
                                  'loginMethod': uI["loginMethod"],
                                  'gameId': uI["gameId"],
                                  'bundleId': uI["bundleId"],
                                  'operatorToken': uI["operatorToken"],
                                  'operatorPlayerSession': uI["operatorPlayerSession"],
                                  'playerSession': uI["playerSession"],
                                  'operatorParam': uI["operatorParam"],
                                  'betType': uI["betType"],
                                  'redirectOption': uI["redirectOption"]
                                });
                              }
                            };
                          uQ();
                        }
                      } else {
                        var l6 = shell["ClientError"],
                          l6 = new (0x0, shell["Error"])(l6["Domain"], l6["AuthenticationError"]);
                        B9(l6);
                      }
                    }
                  }(uI);
              }
            };
          P("LoginHelper", Object["freeze"]({
            '__proto__': null,
            'GameStatus': {
              'INACTIVE': 0x0,
              'ACTIVE': 0x1,
              'SUSPENDED': 0x2
            },
            'login': j3
          }));
          var j4 = function () {};
          j0 = j4, j1 = j4, j2 = j4, ug = j4, P("Printer", Object["freeze"]({
            '__proto__': null,
            get 'enablePrinter'() {
              return j0;
            },
            get 'print'() {
              return j1;
            },
            get 'setActiveNode'() {},
            get 'setHolder'() {
              return ug;
            },
            get 'setPrinterVisible'() {
              return j2;
            }
          }));
          var j5,
            j6,
            j7,
            j8,
            j9,
            ju,
            jj,
            jE,
            jz = {},
            jX = u7["emptyFunc"],
            jB = u7["toDecimalWithExp"],
            jP = new (function () {
              {
                function uI() {
                  this["bv_v"] = 0x0;
                }
                return uI["prototype"]["init"] = function (uI, uI, uH) {
                  {
                    this["bv_m"] = uI, this["bv_b"] = uI, this["bv_p"] = uH;
                  }
                }, Object["defineProperty"](uI["prototype"], "insufficientFundResult", {
                  'set': function (uI) {
                    this["bv_g"] = uI;
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "balance", {
                  'set': function (uI) {
                    this["bv_v"] = uI;
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI["prototype"]["hasSufficientFund"] = function (uI) {
                  if (0x1 !== this["bv_m"]["transactionModel"]["stateTransitionTo"] || undefined === this["bv_g"] || 'G' === this["bv_m"]["lastTransactionRawData"]['wt']) return true;
                  var uI = this["bv_S"](uI);
                  return this["bv_v"] >= uI;
                }, uI["prototype"]["getInsufficientFundResult"] = function (uI, uI, uH) {
                  {
                    var B9 = this,
                      B8 = this["bv_m"]["lastTransactionRawData"],
                      uQ = this["bv_b"];
                    return "0_C" === B8['wk']["substring"](0x0, 0x3) ? this["bv_y"] = uQ["getWalletBalance"](function (B7, B8) {
                      {
                        if (B7) uH(B7, undefined);else {
                          if (!B8 || !B8['dt']) throw Error("Wallet Data Invalid");
                          var B8 = B8['dt']['cb'];
                          B9["bv_v"] = B8, B9["bv_p"](B8), B9["bv_G"](uI, uI, uH);
                        }
                      }
                    }) : this["bv_G"](uI, uI, uH), function () {
                      B9["bv_y"] && B9["bv_y"]();
                    };
                  }
                }, uI["prototype"]["bv_G"] = function (uI, uI, uH) {
                  var B9 = this["bv_S"](uI),
                    B8 = this["bv_m"]["lastTransactionRawData"];
                  if (this["bv_v"] < B9) {
                    this["bv_w"](uI, B8);
                    var uQ = this["bv_g"];
                    uH(uQ["error"], uQ["result"]), this["bv_y"] = jX;
                  } else this["bv_y"] = uI();
                }, uI["prototype"]["bv_S"] = function (uI) {
                  {
                    var uI = this["bv_m"];
                    return jB(uI['ml'] * uI['cs'] * uI["lastGameInfoRawData"]['dt']["mxl"], 0x2);
                  }
                }, uI["prototype"]["bv_w"] = function (uI, uI) {
                  {
                    var uH = this["bv_g"]["result"]['dt']['si'];
                    uH['ml'] = uI['ml'], uH['cs'] = uI['cs'], uH['fb'] = undefined === uI['fb'] ? null : uI['fb'], uH['wk'] = uI['wk'], uH['wt'] = uI['wt'], uH["wbn"] = uI["wbn"], uH['bl'] = uH["blab"] = uH["blb"] = this["bv_v"], uH["ctw"] = uI["ctw"], uH["cwc"] = uI["cwc"], uH["fstc"] = uI["fstc"], uH['ge'] = uI['ge'], uH["hashr"] = uI["hashr"], uH["psid"] = uI["psid"], uH["sid"] = uI["sid"];
                  }
                }, uI;
              }
            }())(),
            jl = u7["getPlatform"],
            jN = u7["timeoutCallback"],
            jp = u7["emptyFunc"],
            jd = jl(),
            jW = {
              'getGameInfo': "v2/GameInfo/Get",
              'updateSystemInfo': "v2/GameInfo/Update",
              'markRead': "v2/MarkRead"
            },
            jb = "v2/GameRule/Get",
            jH = "v2/GameName/Get",
            jS = "v2/GameWallet/Get",
            jc = (P("APIClient", function () {
              {
                function uI(uI) {
                  this["dataSource"] = uI, this["bv_C"] = new uB();
                }
                return Object["defineProperty"](uI["prototype"], "xhrHandler", {
                  'get': function () {
                    {
                      return this["bv_C"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI["prototype"]["login"] = function (uI) {
                  {
                    var uI = this,
                      uH = this["dataSource"]["systemModel"],
                      B9 = uH["apiDomain"],
                      B8 = uH["loginMethod"],
                      uQ = uH["gameId"],
                      B7 = uH["bundleId"],
                      B8 = uH["operatorToken"],
                      B8 = uH["operatorPlayerSession"],
                      uQ = uH["playerSession"],
                      l6 = uH["operatorParam"],
                      l6 = uH["betType"],
                      l8 = uH["redirectOption"];
                    j3({
                      'on_complete': function (uQ) {
                        uI["dataSource"]["updateLoginInfo"](uQ);
                        var lE = uI["dataSource"]["playerModel"]["playerId"];
                        shell['ga']["setUserId"](lE), uI["bv_C"]["setAPIUrls"](uI["dataSource"]["systemModel"]), uI && uI();
                      },
                      'on_error': function (uQ) {
                        uI && uI(uQ, undefined);
                      },
                      'apiDomain': B9,
                      'loginMethod': B8,
                      'gameId': uQ,
                      'bundleId': B7,
                      'operatorToken': B8,
                      'operatorPlayerSession': B8,
                      'playerSession': uQ,
                      'operatorParam': l6,
                      'betType': l6,
                      'redirectOption': l8
                    });
                  }
                }, uI["prototype"]["getGameInfo"] = function (uI, uI) {
                  {
                    var uH = this;
                    return undefined === uI && (uI = {}), this["requestEngine"](jW["getGameInfo"], uI, function (B9, B8) {
                      if (uH["logResult"]("getGameInfo", B8), B8 && B8['dt']) {
                        {
                          var uQ = B8['dt']['ls']['si'],
                            B7 = uH["dataSource"]["transactionModel"]["transactionId"],
                            B8 = uH["dataSource"]["playerModel"]["walletKey"];
                          uQ["sid"] === B7 && uQ['wk'] === B8 || (uH["print"](uQ["sid"]), uH["dataSource"]["updateGameInfo"](B8));
                        }
                      }
                      uI && uI(B9, B8);
                    });
                  }
                }, uI["prototype"]["updateGameInfo"] = function (uI, uI) {
                  {
                    var uH = this;
                    return undefined === uI && (uI = {}), this["requestEngine"](jW["updateSystemInfo"], uI, function (B9, B8) {
                      {
                        if (uH["logResult"]("updateGameInfo", B8), B8 && B8['dt']) {
                          {
                            var uQ = B8['dt']['ls']['si'];
                            uH["print"](uQ["sid"]), uH["dataSource"]["updateGameInfo"](B8);
                          }
                        }
                        uI && uI(B9, B8);
                      }
                    });
                  }
                }, uI["prototype"]["getGameRule"] = function (uI) {
                  var uI = this;
                  return this["requestServiceEngine"](jb, {}, function (uH, B9) {
                    uI["logResult"]("getGameRule", B9), uI && uI(uH, B9);
                  });
                }, uI["prototype"]["getGameName"] = function (uI) {
                  var uI = this,
                    uH = {
                      'lang': shell["I18n"]["locale"]()
                    };
                  return this["requestServiceEngine"](jH, uH, function (B9, B8) {
                    uI["logResult"]("gameNameResult", B8), uI && uI(B9, B8);
                  });
                }, uI["prototype"]["markRead"] = function (uI) {
                  {
                    var uI = this;
                    undefined === uI && (uI = 0x1);
                    var uH = {
                      'id': this["dataSource"]["transactionModel"]["transactionId"],
                      'ts': uI
                    };
                    return this["requestEngine"](jW["markRead"], uH, function (B9, B8) {
                      uI["logResult"]("markRead", B8);
                    });
                  }
                }, uI["prototype"]["transferMoney"] = function () {
                  {
                    return jp;
                  }
                }, uI["prototype"]["getWalletBalance"] = function (uI) {
                  {
                    var uI = this;
                    return this["requestServiceSDEngine"](jS, {}, function (uH, B9) {
                      {
                        uI["logResult"]("getWalletBalance", B9), uI && uI(uH, B9);
                      }
                    });
                  }
                }, uI["prototype"]["_logResult"] = function () {}, uI["prototype"]["_print"] = function (uI) {
                  {
                    var uI = this["dataSource"]["playerModel"]["playerName"];
                    j1("version: " + this["dataSource"]["systemModel"]["version"] + "\nuser: " + uI + "\nspinid: " + uI);
                  }
                }, uI["prototype"]["_requestEngine"] = function (uI, uI, uH) {
                  if (this["dataSource"]["isGameReplaying"] && jz["GameReplay"] && !Object["values"](jW)["includes"](uI)) {
                    var B9 = jz["GameReplay"]["gameReplayHandler"];
                    return jN(0.2)(function () {
                      {
                        var B8 = B9["nextReplayAPIResponse"];
                        uH(undefined, B8);
                      }
                    }), jp;
                  }
                  return uI = this["handleCommonParams"](uI), this["bv_C"]["request"](uI, uI, uH);
                }, uI["prototype"]["_requestServiceEngine"] = function (uI, uI, uH) {
                  {
                    return (uI = this["handleCommonParams"](uI))["gid"] = this["dataSource"]["systemModel"]["gameId"], this["bv_C"]["serviceRequest"](uI, uI, uH);
                  }
                }, uI["prototype"]["_handleCommonParams"] = function (uI) {
                  {
                    undefined === uI && (uI = {});
                    var uI = this["dataSource"]["systemModel"]["betType"],
                      uH = this["dataSource"]["playerModel"],
                      B9 = uH["token"],
                      B8 = uH["walletKey"];
                    return uI["btt"] = uI, uI['wk'] || (uI['wk'] = B8), uI["atk"] = B9, uI['pf'] = jd, uI;
                  }
                }, uI["prototype"]["logResult"] = function () {}, uI["prototype"]["print"] = function (uI) {
                  var uI = this["dataSource"]["playerModel"]["playerName"];
                  j1("version: " + this["dataSource"]["systemModel"]["version"] + "\nuser: " + uI + "\nspinid: " + uI);
                }, uI["prototype"]["requestEngine"] = function (uI, uI, uH) {
                  {
                    var B9 = this;
                    if (this["dataSource"]["isGameReplaying"] && jz["GameReplay"] && !Object["values"](jW)["includes"](uI)) {
                      var B8 = jz["GameReplay"]["gameReplayHandler"];
                      return jN(0.2)(function () {
                        {
                          var B7 = B8["nextReplayAPIResponse"];
                          uH(undefined, B7);
                        }
                      }), jp;
                    }
                    uI = this["handleCommonParams"](uI);
                    var uQ = function () {
                      return B9["bv_C"]["request"](uI, uI, function (B7, B8) {
                        if (B7) {
                          {
                            var B8 = shell["ServerError"];
                            B7["domain"] !== B8["Domain"] || B7["canDismiss"] || (B8 = undefined);
                          }
                        }
                        uH(B7, B8);
                      });
                    };
                    return "v2/spin" !== uI["toLowerCase"]() || jP["hasSufficientFund"](uI) ? uQ() : jP["getInsufficientFundResult"](uI, uQ, uH);
                  }
                }, uI["prototype"]["requestServiceEngine"] = function (uI, uI, uH) {
                  return (uI = this["handleCommonParams"](uI))["gid"] = this["dataSource"]["systemModel"]["gameId"], this["bv_C"]["serviceRequest"](uI, uI, uH);
                }, uI["prototype"]["requestServiceSDEngine"] = function (uI, uI, uH) {
                  return (uI = this["handleCommonParams"](uI))["gid"] = this["dataSource"]["systemModel"]["gameId"], this["bv_C"]["serviceSDRequest"](uI, uI, uH);
                }, uI["prototype"]["handleCommonParams"] = function (uI) {
                  undefined === uI && (uI = {});
                  var uI = this["dataSource"]["systemModel"]["betType"],
                    uH = this["dataSource"]["playerModel"],
                    B9 = uH["token"],
                    B8 = uH["walletKey"];
                  return uI["btt"] = uI, uI['wk'] || (uI['wk'] = B8), uI["atk"] = B9, uI['pf'] = jd, uI;
                }, u2([shell["deprecated"]("logResult")], uI["prototype"], "_logResult", null), u2([shell["deprecated"]("print")], uI["prototype"], "_print", null), u2([shell["deprecated"]("requestEngine")], uI["prototype"], "_requestEngine", null), u2([shell["deprecated"]("requestServiceEngine")], uI["prototype"], "_requestServiceEngine", null), u2([shell["deprecated"]("handleCommonParams")], uI["prototype"], "_handleCommonParams", null), uI;
              }
            }()), u7["setDefaultCurrencyFormat"]),
            js = (P("DataSource", function () {
              {
                function uI(uI) {
                  {
                    this["bv_T"] = false, uI && (this["bv_O"] = uI["playerModel"], this["bv_R"] = uI["systemModel"], this["bv_E"] = uI["transactionModel"]);
                  }
                }
                return Object["defineProperty"](uI["prototype"], "playerModel", {
                  'get': function () {
                    return this["bv_O"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "systemModel", {
                  'get': function () {
                    {
                      return this["bv_R"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "transactionModel", {
                  'get': function () {
                    return this["bv_E"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "lastTransactionRawData", {
                  'get': function () {
                    {
                      return this["bv_x"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "lastGameInfoRawData", {
                  'get': function () {
                    {
                      return this["bv_k"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "isGameReplaying", {
                  'get': function () {
                    return this["bv_T"];
                  },
                  'set': function (uI) {
                    {
                      this["bv_T"] = uI;
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "nextGameReplayInfo", {
                  'get': function () {
                    {
                      return this["bv_j"];
                    }
                  },
                  'set': function (uI) {
                    this["bv_j"] = uI;
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI["prototype"]["updateLoginInfo"] = function (uI) {
                  {
                    var uI = this["bv_O"],
                      uH = this["bv_R"];
                    uI["updatePlayerInfo"](uI), uH["updateSystemInfo"](uI), jc({
                      'groupSeparator': undefined,
                      'decimalSeparator': undefined,
                      'currencyCode': uI["currency"],
                      'currencySymbol': uI["currencySymbol"],
                      'baseUnit': uH["operatorJurisdiction"]["currencyBaseUnit"],
                      'hideDecimal': uH["operatorJurisdiction"]["hideCurrencyDecimal"]
                    });
                  }
                }, uI["prototype"]["updateGameInfo"] = function (uI) {
                  {
                    var uI = uO(),
                      uH = this["bv_O"],
                      B9 = this["bv_R"];
                    this["bv_k"] = uI;
                    var B8 = uI['dt'],
                      uQ = B8['ls'];
                    B9["updateGameInfo"](B8), this["updateTransactionInfo"](uQ['si']), uH["balance"] = B8['bl'], uI["emit"]("Game.GameInfoUpdated", uI);
                  }
                }, uI["prototype"]["updateTransactionInfo"] = function (uI) {
                  {
                    var uI = uO(),
                      uH = this["bv_E"],
                      B9 = this["bv_O"];
                    this["bv_x"] = uI, uH["updateTransactionDetails"](uI), B9["updatePlayerWalletInfo"](uI), B9["balance"] = uI['bl'], uI["emit"]("Game.TransactionInfoUpdated", uI);
                  }
                }, uI;
              }
            }()), u7["formatDate"]),
            jR = P("GameMaintenanceModel", function () {
              {
                function uI() {}
                return Object["defineProperty"](uI["prototype"], "readableMaintenanceStartDate", {
                  'get': function () {
                    return js(new Date(this["maintenanceStartDate"]));
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "readableMaintenanceEndDate", {
                  'get': function () {
                    {
                      return js(new Date(this["maintenanceEndDate"]));
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI["prototype"]["setGameMaintenanceData"] = function (uI) {
                  {
                    if (uI) {
                      var uI = uI["gid"],
                        uH = uI["msdt"],
                        B9 = uI["medt"];
                      this["gameId"] = uI, this["gameStatus"] = uI['st'], this["maintenanceStartDate"] = uH, this["maintenanceEndDate"] = B9;
                    }
                  }
                }, uI["prototype"]["isGameActive"] = function () {
                  {
                    return this["gameStatus"] === Q["Active"];
                  }
                }, uI["prototype"]["isGameMaintenenceApproaching"] = function () {
                  {
                    var uI = this["maintenanceStartDate"],
                      uI = this["maintenanceEndDate"];
                    if (uI && uI) {
                      {
                        var uH = Date["now"]();
                        return uH < uI && uH >= uI - 0x6ddd00;
                      }
                    }
                    return false;
                  }
                }, uI;
              }
            }());
          function jQ(uI) {
            {
              switch (uI) {
                case j5["PORTUGAL"]:
                  return j6;
                case j5["EURO"]:
                  return j7;
                case j5["ASIA"]:
                  return j8;
                case j5["GERMANY"]:
                  return j9;
                case j5["LITHUANIA"]:
                  return ju;
                default:
                  return;
              }
            }
          }
          !function (uI) {
            uI[uI["EURO"] = 0x0] = "EURO", uI[uI["ASIA"] = 0x1] = "ASIA", uI[uI["PORTUGAL"] = 0x2] = "PORTUGAL", uI[uI["GERMANY"] = 0x3] = "GERMANY", uI[uI["LITHUANIA"] = 0x4] = "LITHUANIA", uI[uI["ITALY"] = 0x5] = "ITALY", uI[uI["SWEDEN"] = 0x6] = "SWEDEN";
          }(j5 || (j5 = {})), P("RegionUtils", Object["freeze"]({
            '__proto__': null,
            get 'Region'() {
              return j5;
            },
            'getRegionConfig': jQ,
            'setGameRegionConfigs': function (uI, uI, uI, uH, B9) {
              {
                j6 = uI, j7 = uI, j8 = uI, j9 = uH, ju = B9;
              }
            }
          })), function (uI) {
            uI[uI["VERTICAL"] = 0x0] = "VERTICAL", uI[uI["HORIZONTAL"] = 0x1] = "HORIZONTAL", uI[uI["UNIVERSAL"] = 0x2] = "UNIVERSAL";
          }(jj || (jj = {})), function (uI) {
            uI[uI["Default"] = -0x1] = "Default", uI[uI["Disabled"] = 0x0] = "Disabled", uI[uI["Enabled"] = 0x1] = "Enabled";
          }(jE || (jE = {}));
          var jy = P("GamePluginModel", function () {
              {
                function uI(uI) {
                  {
                    var uI = uI['n'],
                      uH = uI['v'],
                      B9 = uI['il'],
                      B8 = uI['om'],
                      uQ = uI["uie"];
                    this["bv_u"] = uI, this["bv_I"] = uH, this["bv_A"] = B9, this["bv_N"] = uQ, this["bv_L"] = B8;
                  }
                }
                return Object["defineProperty"](uI["prototype"], "name", {
                  'get': function () {
                    {
                      return this["bv_u"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "version", {
                  'get': function () {
                    return this["bv_I"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "configuration", {
                  'get': function () {
                    return this["bv_N"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "instantLoad", {
                  'get': function () {
                    return this["bv_A"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "orientationMode", {
                  'get': function () {
                    return this["bv_L"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI["prototype"]["overrideVersion"] = function (uI) {
                  {
                    this["bv_I"] = uI;
                  }
                }, uI;
              }
            }()),
            jv = B["shell"]["urlSearch"];
          function jJ(uI) {
            var uI;
            return uI = uI || uI, jv["get"](uI);
          }
          var jF = B["shell"] && B["shell"]["environment"] ? B["shell"]["environment"]["audioSupported"] : undefined,
            jM = Object["freeze"]({
              'definition': jJ("definition"),
              'betType': jJ("type"),
              'language': jJ("language"),
              'redirectUrl': jJ("from"),
              'playerSession': jJ('t'),
              'timeElapsed': jJ("time_elapsed"),
              'reminderInterval': jJ("reminder_interval"),
              'reminderUrl': jJ("reminder_quit"),
              'operatorPlayerSession': jJ("session"),
              'operatorParam': jJ("operator_param"),
              'tournamentId': jJ("tourid"),
              'operatorToken': jJ("token"),
              'realModeUrl': jJ("real"),
              'noAudio': undefined === jF ? jJ("no_audio") : jF ? '0' : '1',
              'noBalanceCheck': jJ("no_bl_chk"),
              'redirectOption': jJ("redirect_option") || undefined,
              'loginMethod': jJ("login_method")
            });
          jv = undefined, P("LaunchConfig", Object["freeze"]({
            '__proto__': null,
            'cs_Launch': jM
          }));
          var jI,
            jx = u7["joinPath"];
          !function (uI) {
            uI[uI["REAL_MODE"] = 0x0] = "REAL_MODE", uI[uI["FEATURE_GAME"] = 0x3] = "FEATURE_GAME";
          }(jI || (jI = {}));
          var jT = {
              'bv_M': '',
              'setCustomRedirectUrl': function (uI) {
                this["bv_M"] = uI;
              },
              'getRedirectUrl': function (uI, uI) {
                {
                  var uI;
                  switch (uI) {
                    case jI["REAL_MODE"]:
                      uI = uI || jM["realModeUrl"];
                      break;
                    case jI["FEATURE_GAME"]:
                      uI = uI || '', uI = jx(B["location"]["origin"], uI) + B["location"]["search"];
                      break;
                    default:
                      uI = this["bv_M"] ? this["bv_M"] : jM["redirectUrl"];
                  }
                  return uI;
                }
              },
              'quitGame': function (uI, uI) {
                {
                  var uI = this["getRedirectUrl"](uI, uI);
                  shell["enablePromBeforeUnload"](false);
                  var uH = uO();
                  uI ? uH["emit"]("Window.Redirect", uI) : uH["emit"]("Window.Quit");
                }
              }
            },
            jk = P("QuitGame", {
              'refreshGame': function () {
                shell["enablePromBeforeUnload"](false), uO()["emit"]("Window.Reload");
              },
              'quitGame': function () {
                {
                  jT["quitGame"]();
                }
              },
              'quitGameRealMode': function (uI) {
                jT["quitGame"](jI["REAL_MODE"], uI);
              },
              'quitGameFeatureTrigger': function (uI) {
                {
                  jT["quitGame"](jI["FEATURE_GAME"], uI);
                }
              },
              'setCustomRedirectUrl': function (uI) {
                jT["setCustomRedirectUrl"](uI);
              }
            }),
            jO = u7["timeoutCallback"];
          function jC(uI, uI, uI) {
            shell['ga']["sendEvent"](uI, uI, uI);
          }
          function jL(uI, uI, uI, uH, B9) {
            {
              var B8 = {
                'category': shell['ga']["CATEGORY_GAME"],
                'domain': uI,
                'code': uI,
                'error': uI,
                'retry': uH,
                'messages': B9
              };
              uO()["emit"]("Error.Report", B8);
            }
          }
          var jm,
            jU,
            jZ = P("AnalyticsHelper", {
              'init': function () {
                {
                  shell['ga']["setFrequentErrorHandler"](function () {
                    shell['ga']["setFrequentErrorHandler"](undefined), B["alert"](shell["I18n"]['t']("General.ErrorOccur")), jC(shell['ga']["CATEGORY_GENERAL"], shell['ga']["EVENT_QUIT_GAME"], {
                      'reason': "Frequent Error"
                    }), jO(0.5)(jk["refreshGame"]);
                  });
                }
              },
              'sendErrorReport': jL,
              'sendLoadFailReport': function (uI) {
                {
                  var uI = shell["Error"],
                    uI = shell["ClientError"],
                    uH = new uI(uI["Domain"], uI["GameLoadResourceError"]);
                  jL("load resource fail", uH["domain"], uH["code"], uI);
                }
              },
              'sendScreen': function (uI) {
                {
                  shell['ga']["sendScreen"](uI);
                }
              },
              'sendEvent': jC,
              'sendAnalyticsEvent': function (uI) {
                uO()["emit"]("Analytics.Event", uI);
              },
              'sendAnalyticsTiming': function (uI) {
                uO()["emit"]("Analytics.Timing", uI);
              }
            }),
            jD = u7["timeoutCallback"],
            jh = P("QuitGameWithEvent", {
              'quitGameWithEvent': function (uI) {
                return function () {
                  {
                    jZ["sendEvent"](shell['ga']["CATEGORY_GENERAL"], shell['ga']["EVENT_QUIT_GAME"], {
                      'reason': uI
                    }), jD(0.5)(jk["quitGame"]);
                  }
                };
              },
              'quitGameWithEventForRealMode': function (uI) {
                return function () {
                  jZ["sendEvent"](shell['ga']["CATEGORY_GENERAL"], shell['ga']["EVENT_QUIT_GAME"], {
                    'reason': "Real Mode"
                  }), jD(0.5)(function () {
                    jk["quitGameRealMode"](uI);
                  });
                };
              },
              'quitGameWithEventForFeatureGame': function (uI) {
                {
                  jZ["sendEvent"](shell['ga']["CATEGORY_GENERAL"], shell['ga']["EVENT_QUIT_GAME"], {
                    'reason': "Feature Game Redirect"
                  }), jD(0.5)(function () {
                    {
                      jk["quitGameFeatureTrigger"](uI);
                    }
                  });
                }
              },
              'refreshGameWithEvent': function (uI) {
                return function () {
                  {
                    jZ["sendEvent"](shell['ga']["CATEGORY_GENERAL"], shell['ga']["EVENT_QUIT_GAME"], {
                      'reason': uI
                    }), jD(0.5)(jk["refreshGame"]);
                  }
                };
              }
            });
          function jY(uI, uI, uI, uH, B9) {
            {
              undefined === uI && (uI = jm["Transaction"]), undefined === B9 && (B9 = false), uO()["emit"]("Error.Occurred", {
                'context': uI,
                'info': {
                  'category': shell['ga']["CATEGORY_GAME"],
                  'domain': uI["domain"],
                  'code': uI["code"],
                  'trace': uI["traceId"],
                  'error': uI,
                  'messages': uH
                },
                'report': B9
              }, function (B8) {
                switch (B8["response"]) {
                  case "Default":
                    uI && uI(jU["Default"]);
                    break;
                  case "Quit":
                    uI && uI(jU["Quit"]);
                    break;
                  case "Retry":
                    uI && uI(jU["Retry"]);
                    break;
                  case "Reload":
                    uI && uI(jU["Reload"]);
                    break;
                  case "Dismiss":
                    uI && uI(jU["Dismiss"]);
                }
              });
            }
          }
          !function (uI) {
            {
              uI["Transaction"] = "Transaction", uI["Preload"] = "Preload", uI["Launch"] = "Launch", uI["Login"] = "Login", uI["Change"] = "Change", uI["Unknown"] = "Unknown";
            }
          }(jm || (jm = {})), function (uI) {
            uI[uI["Default"] = 0x0] = "Default", uI[uI["Quit"] = 0x1] = "Quit", uI[uI["Retry"] = 0x2] = "Retry", uI[uI["Reload"] = 0x3] = "Reload", uI[uI["Dismiss"] = 0x4] = "Dismiss";
          }(jU || (jU = {}));
          var jw = P("ErrorHandler", {
            'handleCommonError': function (uI, uI, uI, uH, B9) {
              undefined === uI && (uI = jm["Transaction"]), jY(uI, uI, function (B8) {
                {
                  switch (B8) {
                    case jU["Reload"]:
                      jh["refreshGameWithEvent"](uI)();
                      break;
                    case jU["Quit"]:
                      jh["quitGameWithEvent"](uI)();
                      break;
                    case jU["Retry"]:
                      uH && uH();
                      break;
                    case jU["Dismiss"]:
                      B9 && B9();
                  }
                }
              });
            },
            'showError': jY,
            'getErrorContext': function (uI) {
              {
                switch (uI) {
                  case shell["I18n"]['t']("General.ErrorPreloadError"):
                    return "Preload";
                  case shell["I18n"]['t']("General.ErrorLaunchFailed"):
                    return "Launch";
                  case shell["I18n"]['t']("General.ErrorLoginFailed"):
                    return "Login";
                  case shell["I18n"]['t']("General.ErrorChangeFailed"):
                    return "Change";
                  case '':
                    return "Unknown";
                  default:
                    return "Transaction";
                }
              }
            },
            'ErrContext': jm,
            'ErrAction': jU
          });
          function jV(uI, uI) {
            var uI = uC(),
              uH = [],
              B9 = false,
              B8 = {
                'onComplete': function () {
                  {
                    B9 || uI && uI();
                  }
                },
                'onError': function (uQ) {
                  {
                    if (!B9) {
                      B9 = true;
                      var B7 = shell["Error"],
                        B8 = shell["GameShellError"],
                        B8 = new B7(B8["Domain"], B8["LoadResourceError"]);
                      jZ["sendErrorReport"]("load plugin failed", B8["domain"], B8["code"], undefined, "src: "["concat"](uQ["src"])), jw["handleCommonError"](uQ["err"], B8, jm["Launch"]);
                    }
                  }
                }
              };
            uI["forEach"](function (uQ) {
              var B7 = uQ["name"];
              !uI["queryBundle"](B7) && uH["push"](B7);
            }), uH["length"] > 0x0 ? uI["plugin"]["load"](uH, B8) : uI && uI();
          }
          var jq = function () {
              function uI(uI) {
                var uI = uI["gid"],
                  uH = uI['ft'],
                  B9 = uI["url"];
                this["bv_f"] = uI, this["bv_P"] = uH, this["bv__"] = B9;
              }
              return Object["defineProperty"](uI["prototype"], "gameId", {
                'get': function () {
                  {
                    return this["bv_f"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "featureType", {
                'get': function () {
                  {
                    return this["bv_P"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "url", {
                'get': function () {
                  return this["bv__"];
                },
                'enumerable': false,
                'configurable': true
              }), uI;
            }(),
            jK = function () {
              function uI(uI) {
                var uI = uI['dt'],
                  uH = uI["ugd"];
                this["bv_D"] = uI, this["bv_U"] = this["bv_H"](uH);
              }
              return Object["defineProperty"](uI["prototype"], "displayType", {
                'get': function () {
                  return this["bv_D"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "unfinishedGameDetails", {
                'get': function () {
                  return this["bv_U"];
                },
                'enumerable': false,
                'configurable': true
              }), uI["prototype"]["bv_H"] = function (uI) {
                return uI["map"](function (uI) {
                  return new jq(uI);
                });
              }, uI;
            }(),
            jA = function () {
              function uI(uI) {
                {
                  var uI = uI['n'],
                    uH = uI['v'];
                  this["bv_u"] = uI, this["bv_B"] = uH;
                }
              }
              return Object["defineProperty"](uI["prototype"], "name", {
                'get': function () {
                  return this["bv_u"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "value", {
                'get': function () {
                  return this["bv_B"];
                },
                'enumerable': false,
                'configurable': true
              }), uI;
            }();
          P("TweaksData", {
            'configStore': undefined
          });
          var jG,
            jf = function () {
              {
                function uI(uI) {
                  var uI = uI["rurl"],
                    uH = uI["tcm"],
                    B9 = uI["tsc"],
                    B8 = uI["ttp"],
                    uQ = uI["tlb"],
                    B7 = uI["trb"];
                  this["bv_F"] = decodeURIComponent(uI), this["bv_W"] = uH, this["bv_q"] = B9, this["bv_V"] = B8, this["bv_Q"] = uQ, this["bv_z"] = B7;
                }
                return Object["defineProperty"](uI["prototype"], "realURL", {
                  'get': function () {
                    return this["bv_F"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "dialogMessage", {
                  'get': function () {
                    {
                      return this["bv_W"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "triggerSpinCount", {
                  'get': function () {
                    return this["bv_q"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "triggerDuration", {
                  'get': function () {
                    {
                      return this["bv_V"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "leftButtonLabel", {
                  'get': function () {
                    return this["bv_Q"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "rightButtonLabel", {
                  'get': function () {
                    {
                      return this["bv_z"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI;
              }
            }(),
            jg = {
              0x0: '',
              0x1: 'K'
            };
          !function (uI) {
            uI[uI["AUTO_PLAY_MAX"] = 0x0] = "AUTO_PLAY_MAX", uI[uI["AUTO_PLAY_CONFIG"] = 0x1] = "AUTO_PLAY_CONFIG", uI[uI["SINGLE_PLAY_TIME"] = 0x2] = "SINGLE_PLAY_TIME", uI[uI["HIDE_NON_PROFIT"] = 0x3] = "HIDE_NON_PROFIT", uI[uI["TURBO_SPIN"] = 0x4] = "TURBO_SPIN", uI[uI["MAX_PAYOUT"] = 0x5] = "MAX_PAYOUT", uI[uI["NET_PROFIT"] = 0x6] = "NET_PROFIT", uI[uI["ELAPSED_TIME"] = 0x7] = "ELAPSED_TIME";
          }(jG || (jG = {}));
          var n0 = [[0x64, 0x2, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0], [0x3e8, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0], [0x0, 0x0, 0x3, 0x1, 0x0, 0x0, 0x1, 0x1], [0x0, 0x0, 0x5, 0x1, 0x0, 0x1, 0x1, 0x1], [0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x0, 0x0], [0x0, 0x0, 0x5, 0x1, 0x0, 0x1, 0x1, 0x1], [0x64, 0x2, 0x3, 0x1, 0x0, 0x0, 0x1, 0x1]];
          function n1(uI, uI) {
            {
              var uI = n0[uI];
              if (uI) return uI[uI];
              throw Error("OperatorJurisdictionModel :: unknown region set");
            }
          }
          var n2,
            n3,
            n4 = P("OperatorJurisdictionModel", function () {
              {
                function uI(uI) {
                  this["bv_Y"] = [], this["bv_X"] = [], this["bv_K"] = [], this["bv_Z"] = 0x0;
                  var uI,
                    uH,
                    B9 = uI['oj'],
                    B8 = uI["ufg"],
                    uQ = uI["uiogc"],
                    B7 = uI['ec'],
                    B8 = uI["ocdr"],
                    B8 = uI['gm'],
                    uQ = uI["occ"],
                    l6 = uI["opl"],
                    l6 = uI["ioph"],
                    l8 = B9["jid"],
                    uQ = uQ,
                    uQ = uQ['bb'],
                    lE = uQ["grtp"],
                    lz = uQ["gec"],
                    lX = uQ['bf'],
                    lB = uQ["cbu"],
                    lP = uQ['mr'],
                    lz = uQ['rp'],
                    lX = uQ["ign"],
                    lp = uQ["igv"],
                    ld = uQ['gc'],
                    lW = uQ["tsn"],
                    lb = uQ['we'],
                    lH = uQ["gsc"],
                    lS = uQ['bu'],
                    lc = uQ["pwr"],
                    ls = uQ['hd'],
                    lR = uQ['np'],
                    lQ = uQ['et'],
                    ly = uQ['ir'],
                    lv = uQ['as'],
                    lJ = uQ["asc"],
                    lF = uQ["std"],
                    lM = uQ["hnp"],
                    lI = uQ['ts'],
                    lx = uQ["smpo"],
                    lT = uQ["ivs"],
                    lk = B8[0x0],
                    lk = lk["rtp"],
                    lc = lk["mxe"],
                    lL = lk["mxehr"];
                  if (this["bv_J"] = l8, this["bv_$"] = uQ, this["bv_tt"] = lE, this["bv_nt"] = lz, this["bv_et"] = ld, this["bv_it"] = lX, this["bv_rt"] = lp, lX || (this["bv_at"] = 0x0), this["bv_ot"] = lk, this["bv_ut"] = lc, this["bv_ct"] = lL, this["bv_st"] = ly, this["bv_lt"] = lR ? 0x1 === lR : 0x1 === n1(jG["NET_PROFIT"], this["bv_J"]), this["bv_ft"] = lQ ? 0x1 === lQ : 0x1 === n1(jG["ELAPSED_TIME"], this["bv_J"]), this["bv_ht"] = lv || n1(jG["AUTO_PLAY_MAX"], this["bv_J"]), this["bv_dt"] = lJ || n1(jG["AUTO_PLAY_CONFIG"], this["bv_J"]), this["bv_vt"] = lF || n1(jG["SINGLE_PLAY_TIME"], this["bv_J"]), this["bv_mt"] = lM ? 0x1 === lM : 0x1 === n1(jG["HIDE_NON_PROFIT"], this["bv_J"]), this["bv_bt"] = !(this["bv_vt"] > 0x0) && (lI ? 0x1 === lI : 0x1 === n1(jG["TURBO_SPIN"], this["bv_J"])), this["bv_pt"] = lx ? 0x1 === lx : 0x1 === n1(jG["MAX_PAYOUT"], this["bv_J"]), this["bv_gt"] = jQ(this["bv_J"]), this["bv_St"] = lB ? jg[lB] : undefined, this["bv_yt"] = lP, this["bv_Gt"] = lz, this["bv_wt"] = lW, this["bv_Ct"] = lb, this["bv_Tt"] = lH, this["bv_Ot"] = lS, this["bv_Rt"] = lc, this["bv_Et"] = ls, this["bv_xt"] = lT, this["bv_kt"] = l6, this["bv_jt"] = l6, B7 && (this["bv_Y"] = (uI = [], B7["forEach"](function (lD) {
                    {
                      var lD = new jy(lD);
                      (function (lY) {
                        {
                          var lw = lY["orientationMode"],
                            lV = shell["environment"]["getOrientationMode"]();
                          if (lw !== jj["UNIVERSAL"]) {
                            {
                              if (lw !== jj["VERTICAL"] && "port" === lV) return false;
                              if (lw !== jj["HORIZONTAL"] && "land" === lV) return false;
                            }
                          }
                          return true;
                        }
                      })(lD) && uI["push"](lD);
                    }
                  }), uI)), B8) {
                    {
                      var lm = function (lD) {
                          {
                            var lD = 0x0;
                            return {
                              'unfinishedFeatureGame': lD["map"](function (lY) {
                                var lw = new jK(lY);
                                return 0x0 !== lw["displayType"] && (lD += lw["unfinishedGameDetails"]["length"]), lw;
                              }),
                              'featureGameCount': lD
                            };
                          }
                        }(B8),
                        lU = lm["unfinishedFeatureGame"],
                        lZ = lm["featureGameCount"];
                      this["bv_K"] = lU, this["bv_Z"] = lZ;
                    }
                  }
                  uQ && (this["bv_It"] = new jf(uQ)), B8 && (this["bv_X"] = (uH = [], B8["forEach"](function (lD) {
                    var lD = new jA(lD);
                    uH["push"](lD);
                  }), uH));
                }
                return Object["defineProperty"](uI["prototype"], "jurisdictionId", {
                  'get': function () {
                    {
                      return this["bv_J"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "regionFeature", {
                  'get': function () {
                    return this["bv_gt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "backButton", {
                  'get': function () {
                    {
                      return this["bv_$"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameReturnToPlayer", {
                  'get': function () {
                    return this["bv_tt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameExitConfirmation", {
                  'get': function () {
                    return this["bv_nt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "buyFeature", {
                  'get': function () {
                    return this["bv_at"];
                  },
                  'set': function (uI) {
                    this["bv_at"] = uI;
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "currencyBaseUnit", {
                  'get': function () {
                    return this["bv_St"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "markRead", {
                  'get': function () {
                    return this["bv_yt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "replayVersion", {
                  'get': function () {
                    {
                      return this["bv_Gt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "turboSpinSuggest", {
                  'get': function () {
                    return this["bv_wt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "walletSocketEnable", {
                  'get': function () {
                    {
                      return this["bv_Ct"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "globalSocketEnable", {
                  'get': function () {
                    {
                      return this["bv_Tt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "balanceUpdateEnable", {
                  'get': function () {
                    {
                      return this["bv_Ot"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "newWalletNotificationEnable", {
                  'get': function () {
                    return this["bv_Rt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "hideCurrencyDecimal", {
                  'get': function () {
                    return this["bv_Et"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "netProfitState", {
                  'get': function () {
                    return this["bv_lt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "elapsedTimeState", {
                  'get': function () {
                    return this["bv_ft"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "isRegulated", {
                  'get': function () {
                    {
                      return this["bv_st"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "autoPlayMaxNum", {
                  'get': function () {
                    {
                      return this["bv_ht"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "autoPlayConfig", {
                  'get': function () {
                    return this["bv_dt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "singlePlayMinDuration", {
                  'get': function () {
                    {
                      return this["bv_vt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "hideNonProfitEffect", {
                  'get': function () {
                    return this["bv_mt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "turboSpinEnable", {
                  'get': function () {
                    {
                      return this["bv_bt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "maxPayoutEnable", {
                  'get': function () {
                    {
                      return this["bv_pt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "isOK", {
                  'get': function () {
                    return this["bv_xt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gamePluginList", {
                  'get': function () {
                    {
                      return this["bv_Y"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "unfinishedFeatureGame", {
                  'get': function () {
                    {
                      return this["bv_K"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "unfinishedOnGoingFeatureGameCount", {
                  'get': function () {
                    {
                      return this["bv_Z"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "operatorCustomDisplayList", {
                  'get': function () {
                    return this["bv_X"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameName", {
                  'get': function () {
                    {
                      return this["bv_it"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameClock", {
                  'get': function () {
                    return this["bv_et"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "rtp", {
                  'get': function () {
                    {
                      return this["bv_ot"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "maxPayout", {
                  'get': function () {
                    return this["bv_ut"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "maxPayoutProbability", {
                  'get': function () {
                    return this["bv_ct"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "customDemoConfig", {
                  'get': function () {
                    return this["bv_It"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "operatorPromotionLink", {
                  'get': function () {
                    {
                      return this["bv_kt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "idH", {
                  'get': function () {
                    {
                      return this["bv_jt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameVersion", {
                  'get': function () {
                    {
                      return this["bv_rt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI;
              }
            }()),
            n5 = u7["resolvePath"],
            n6 = u7["getPlatform"],
            n7 = (P("SystemModel", function () {
              {
                function uI(uI) {
                  {
                    this["bv_At"] = uI, this["bv_Nt"] = jM["betType"] ? parseInt(jM["betType"], 0xa) : 0x0, this["bv_Lt"] = jM["operatorPlayerSession"], this["bv_Mt"] = jM["playerSession"], this["bv_Pt"] = jM["operatorParam"], this["bv_h"] = jM["operatorToken"], this["bv__t"] = '', this["bv_Dt"] = !(!jM["noAudio"] || '1' !== jM["noAudio"]), this["bv_Ut"] = jM["redirectOption"], this["bv_Ht"] = jM["loginMethod"] ? parseInt(jM["loginMethod"], 0xa) : this["bv_At"]["loginMethod"], this["bv_Ht"] = this["bv_Ht"] || 0x2;
                  }
                }
                return uI["prototype"]["updateSystemInfo"] = function (uI) {
                  {
                    var uI = uI["operatorJurisdiction"],
                      uH = uI["gameEngineUrl"],
                      B9 = uI["betHistoryApiUrl"],
                      B8 = uI["gamesMaintanence"],
                      uQ = uI["unfinishGamesFeature"],
                      B7 = uI["uiOperatorGameComponents"],
                      B8 = uI["elementCategory"],
                      B8 = uI["operatorCustomDisplayResponse"],
                      uQ = uI["operatorCustomConfiguration"],
                      l6 = uI["operatorPromotionLink"],
                      l6 = uI["gameCertificateVersion"],
                      l8 = uI["operatorPromotionId"],
                      uQ = uI["gameApiSubdomain"],
                      uQ = uI["extraAssetTableKey"];
                    if (!uH) throw Error("Login: Game Engine URL is empty");
                    if (!B9) throw Error("Login: Service Engine URL is empty");
                    this["bv_Bt"] = uI ? new n4({
                      'oj': uI,
                      'ufg': uQ,
                      'uiogc': B7,
                      'ec': B8,
                      'ocdr': B8,
                      'gm': B8,
                      'occ': uQ,
                      'opl': l6,
                      'ioph': l8
                    }) : undefined, this["bv_e"] = uH, this["bv_i"] = B9;
                    var lE = this["bv_At"]["apiDomain"];
                    if (uQ) {
                      {
                        var lz = this["bv_At"]["apiDomain"];
                        lE = "https://" + uQ + '.' + (lz = lz["substr"](lz["indexOf"]('.') + 0x1));
                      }
                    }
                    this["bv_Ft"] = n5(lE, this["bv_e"]), this["bv_Wt"] = n5(lE, this["bv_i"]), this["bv_qt"] = n5(this["bv_At"]["apiDomain"], this["bv_i"]), (this["bv_Vt"] = new jR())["setGameMaintenanceData"](B8[0x0]), this["bv_Bt"] && shell["enablePromBeforeUnload"](!!this["bv_Bt"]["gameExitConfirmation"]), this["bv_Qt"] = l6, this["bv_zt"] = uQ, this["bv_Yt"] = uQ;
                  }
                }, Object["defineProperty"](uI["prototype"], "operatorJurisdiction", {
                  'get': function () {
                    return this["bv_Bt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameEngineUrl", {
                  'get': function () {
                    {
                      return this["bv_e"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "serviceEngineUrl", {
                  'get': function () {
                    {
                      return this["bv_i"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameMaintenanceInfo", {
                  'get': function () {
                    {
                      return this["bv_Vt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameId", {
                  'get': function () {
                    return this["bv_At"]["gameId"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "version", {
                  'get': function () {
                    return this["bv_At"]["version"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "certifiedVersion", {
                  'get': function () {
                    return this["bv_Qt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "platform", {
                  'get': function () {
                    return this["bv_Xt"] || (this["bv_Xt"] = n6()["toString"]()), this["bv_Xt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "betType", {
                  'get': function () {
                    return this["bv_Nt"];
                  },
                  'set': function (uI) {
                    {
                      this["bv_Nt"] = uI;
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "operatorPlayerSession", {
                  'get': function () {
                    {
                      return this["bv_Lt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "playerSession", {
                  'get': function () {
                    return this["bv_Mt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "operatorParam", {
                  'get': function () {
                    {
                      return this["bv_Pt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "operatorToken", {
                  'get': function () {
                    return this["bv_h"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "bundleId", {
                  'get': function () {
                    return this["bv_At"]["bundleId"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "apiDomain", {
                  'get': function () {
                    {
                      return this["bv_At"]["apiDomain"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "loginMethod", {
                  'get': function () {
                    {
                      return this["bv_Ht"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "noAudio", {
                  'get': function () {
                    {
                      return this["bv_Dt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "redirectOption", {
                  'get': function () {
                    return this["bv_Ut"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "gameTitle", {
                  'get': function () {
                    {
                      return this["bv__t"];
                    }
                  },
                  'set': function (uI) {
                    this["bv__t"] = uI;
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "globalDomain", {
                  'get': function () {
                    {
                      return this["bv_At"]["globalDomain"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI["prototype"]["getFullGameEngineUrl"] = function () {
                  return this["bv_Ft"];
                }, uI["prototype"]["getFullServiceEngineUrl"] = function () {
                  return this["bv_qt"];
                }, uI["prototype"]["getFullServiceEngineUrlSD"] = function () {
                  {
                    return this["bv_Wt"];
                  }
                }, Object["defineProperty"](uI["prototype"], "gameApiSubdomain", {
                  'get': function () {
                    {
                      return this["bv_zt"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), Object["defineProperty"](uI["prototype"], "extraAssetTableKey", {
                  'get': function () {
                    return this["bv_Yt"];
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI;
              }
            }()), P("PlayerModel", function () {
              function uI() {
                this["bv_Kt"] = jM["tournamentId"] || undefined;
              }
              return Object["defineProperty"](uI["prototype"], "walletId", {
                'get': function () {
                  return this["bv_Zt"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "walletType", {
                'get': function () {
                  return this["bv_Jt"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "walletKey", {
                'get': function () {
                  {
                    return this["bv_Kt"];
                  }
                },
                'set': function (uI) {
                  this["bv_Kt"] = uI;
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "playerId", {
                'get': function () {
                  return this["bv_$t"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "playerName", {
                'get': function () {
                  return this["bv_tn"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "playerNickname", {
                'get': function () {
                  return this["bv_nn"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "token", {
                'get': function () {
                  return this["bv_s"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "sessionStatus", {
                'get': function () {
                  return this["bv_en"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "currency", {
                'get': function () {
                  return this["bv_in"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "currencySymbol", {
                'get': function () {
                  return this["bv_rn"];
                },
                'enumerable': false,
                'configurable': true
              }), uI["prototype"]["updatePlayerInfo"] = function (uI) {
                {
                  var uI = uI["playerId"],
                    uH = uI["playerName"],
                    B9 = uI["nickname"],
                    B8 = uI["sessionToken"],
                    uQ = uI["sessionStatus"],
                    B7 = uI["currencyCode"],
                    B8 = uI["currencySymbol"];
                  this["bv_$t"] = uI, this["bv_tn"] = uH, this["bv_nn"] = B9, this["bv_s"] = B8, this["bv_en"] = uQ, this["bv_in"] = B7, this["bv_rn"] = B8;
                }
              }, uI["prototype"]["updatePlayerWalletInfo"] = function (uI) {
                var uI = uI["wid"],
                  uH = uI['wt'],
                  B9 = uI['wk'];
                this["bv_Zt"] = uI, this["bv_Jt"] = uH, this["bv_Kt"] = B9;
              }, uI;
            }()), P("TransactionModel", function () {
              function uI() {}
              return Object["defineProperty"](uI["prototype"], "transactionId", {
                'get': function () {
                  return this["bv_an"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "parentTransactionId", {
                'get': function () {
                  {
                    return this["bv_on"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "stateTransitionFrom", {
                'get': function () {
                  {
                    return this["bv_un"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "stateTransitionTo", {
                'get': function () {
                  {
                    return this["bv_cn"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "accumulatedWinAmount", {
                'get': function () {
                  return this["bv_sn"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "totalWinAmount", {
                'get': function () {
                  return this["bv_ln"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "balanceBefore", {
                'get': function () {
                  return this["bv_fn"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "balanceAfterBet", {
                'get': function () {
                  {
                    return this["bv_hn"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "markReadIndex", {
                'get': function () {
                  return this["bv_dn"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "totalBet", {
                'get': function () {
                  return this["bv_vn"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "totalBaseBet", {
                'get': function () {
                  {
                    return this["bv_mn"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "previousGameState", {
                'get': function () {
                  return this["bv_bn"];
                },
                'enumerable': false,
                'configurable': true
              }), uI["prototype"]["updateTransactionDetails"] = function (uI) {
                {
                  var uI = uI["sid"],
                    uH = uI["psid"],
                    B9 = uI['st'],
                    B8 = uI["nst"],
                    uQ = uI['aw'],
                    B7 = uI['tw'],
                    B8 = uI["blb"],
                    B8 = uI["blab"],
                    uQ = uI['mr'],
                    l6 = uI['tb'],
                    l6 = uI["tbb"];
                  this["bv_bn"] = this["bv_cn"], this["bv_an"] = uI, this["bv_on"] = uH, this["bv_un"] = B9, this["bv_cn"] = B8, this["bv_sn"] = uQ, this["bv_ln"] = B7, this["bv_fn"] = B8, this["bv_hn"] = B8, this["bv_dn"] = uQ ? uQ['ts'] : 0x1, this["bv_vn"] = l6, this["bv_mn"] = l6, this["updateTransactionInfo"](uI);
                }
              }, uI;
            }()), u7["timeoutCallback"]),
            n8 = function (uI) {
              {
                return 0x1 << uI;
              }
            },
            n9 = function () {
              {
                function uI(uI, uI) {
                  {
                    this["retryCount"] = 0x0, this["bv_pn"] = uI, this["bv_gn"] = uI;
                  }
                }
                return uI["prototype"]["execute"] = function () {
                  {
                    this["retryCount"]++;
                    var uI = "function" == typeof this["bv_gn"] ? this["bv_gn"](this["retryCount"]) : this["bv_gn"];
                    n7(uI)(this["bv_Sn"]["bind"](this));
                  }
                }, uI["prototype"]["bv_Sn"] = function () {
                  {
                    this["bv_pn"](this["retryCount"]);
                  }
                }, uI;
              }
            }(),
            nj = P("RetryHandler", function () {
              function uI() {
                {
                  this["bv_yn"] = 0x5, this["_id"] = '0', this["bv_Gn"] = false;
                }
              }
              return uI["setRetryHandlerConfig"] = function (uI) {
                uI && (this["retrySchemeConfig"] = uI["retrySchemeConfig"] ? uI["retrySchemeConfig"] : n8, this["maxRetries"] = uI["maxRetries"] ? uI["maxRetries"] : 0x5);
              }, Object["defineProperty"](uI["prototype"], 'id', {
                'get': function () {
                  {
                    return this["_id"];
                  }
                },
                'set': function (uI) {
                  {
                    this["_id"] = uI;
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "isDestroyed", {
                'get': function () {
                  {
                    return this["bv_Gn"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), uI["prototype"]["init"] = function (uI, uI, uH) {
                {
                  this["bv_pn"] = uI, this["bv_yn"] = uH && uH["maxRetries"] ? uH["maxRetries"] : uI["maxRetries"], this["bv_wn"] = uH && uH["retrySchemeConfig"] ? uH["retrySchemeConfig"] : uI["retrySchemeConfig"], this["bv_gn"] = new n9(uI, this["bv_wn"]), this["bv_Cn"] = uI;
                }
              }, uI["prototype"]["execute"] = function () {
                {
                  this["bv_Gn"] || (uO()["emit"]("Shell.PWDReset"), this["bv_gn"]["retryCount"] >= this["bv_yn"] && (this["bv_gn"] = new n9(this["bv_pn"], this["bv_wn"])), this["bv_gn"]["execute"](), this["bv_Tn"]());
                }
              }, uI["prototype"]["getRetryCount"] = function () {
                {
                  return this["bv_gn"]["retryCount"];
                }
              }, uI["prototype"]["getMaxRetryCount"] = function () {
                return this["bv_yn"];
              }, uI["prototype"]["canRetry"] = function () {
                return this["bv_gn"]["retryCount"] < this["bv_yn"] && !this["bv_Gn"];
              }, uI["prototype"]["reset"] = function () {
                this["bv_gn"] && (this["bv_gn"]["retryCount"] = 0x0);
              }, uI["prototype"]["destroy"] = function () {
                {
                  this["bv_Gn"] = true, uO()["emit"]("Shell.PWDReset");
                }
              }, uI["prototype"]["bv_Tn"] = function () {
                {
                  var uI = this["bv_gn"]["retryCount"];
                  uY(this["bv_Cn"] + '\x20' + shell["I18n"]['t']("RetryHandler.Times", {
                    'times': {
                      'ordinal': uI
                    }
                  }), 0x2);
                }
              }, uI["retrySchemeConfig"] = n8, uI["maxRetries"] = 0x5, uI;
            }());
          !function (uI) {
            {
              uI[uI["LEFT"] = 0x1] = "LEFT", uI[uI["CENTER"] = 0x2] = "CENTER", uI[uI["RIGHT"] = 0x3] = "RIGHT";
            }
          }(n2 || (n2 = {}));
          var nE = n2["LEFT"],
            nz = 11.5,
            nX = 0x12c;
          function nB() {
            {
              return "land" === shell["environment"]["getOrientationMode"]();
            }
          }
          function nP() {
            {
              return shell["environment"]["isIOS"]();
            }
          }
          var nl,
            nN,
            np = B["devicePixelRatio"] || 0x1,
            nd = B["screen"]["width"] * np,
            nW = B["screen"]["height"] * np,
            nb = function (uI) {
              function uI() {
                var uI = null !== uI && uI["apply"](this, arguments) || this;
                return uI["rootElement"] = Object["create"](null), uI["bv_On"] = Object["create"](null), uI["bv_Rn"] = 0x12c, uI["bv_En"] = [], uI;
              }
              return u0(uI, uI), uI["prototype"]["onCreate"] = function () {
                var uI = this;
                nX = nB() ? 0x244 : 0x12c, this["bv_xn"]("game-title-css", ".game-title {        width : 300px;        height: 17px;        position: absolute;        display: flex;        color: white;        opacity: 0.85;        text-shadow: rgb(65, 50, 24) 1px 0px 0px, rgb(65, 50, 24) 0.552px 0.85px 0px, rgb(65, 50, 24) -0.4px 0.9px 0px, rgb(65, 50, 24) -0.1px 0.15px 0px, rgb(65, 50, 24) -0.65px -0.7px 0px, rgb(65, 50, 24) 0.3px -0.95px 0px, rgb(65, 50, 24) 0.96px -0.28px 0px;        pointer-events: none;        white-space: nowrap;        z-index: 250;}"), this["rootElement"] = document["createElement"]("div"), this["rootElement"]["setAttribute"]('id', "game-title"), this["rootElement"]["classList"]["add"]("game-title"), this["rootElement"]["style"]["visibility"] = "hidden", this["context"]["event"]["emit"]("Shell.GetScale", undefined, function (uH) {
                  !uH["error"] && uH["response"] && (uI["rootElement"]["style"]["width"] = uH["response"]["width"] + 'px', uI["bv_Rn"] = uH["response"]["width"]);
                }), this["bv_On"] = document["createElement"]("div"), this["bv_On"]["style"]["paddingLeft"] = "12px", this["bv_On"]["style"]["display"] = "flex", this["bv_On"]["style"]["alignItems"] = "center", shell["isRTLLanguage"] && shell["isRTLLanguage"]() && (this["bv_On"]["style"]["direction"] = "rtl"), this["rootElement"]["appendChild"](this["bv_On"]);
              }, uI["prototype"]["updatePosition"] = function (uI) {
                {
                  uI === n2["CENTER"] ? (this["rootElement"]["style"]["justifyContent"] = "center", this["rootElement"]["style"]["width"] = ''["concat"](this["bv_Rn"], 'px')) : uI === n2["LEFT"] ? (this["rootElement"]["style"]["justifyContent"] = "flex-start", this["rootElement"]["style"]["width"] = ''["concat"](nX, 'px')) : (this["rootElement"]["style"]["justifyContent"] = "flex-end", this["rootElement"]["style"]["width"] = ''["concat"](nX, 'px')), this["bv_kn"]();
                }
              }, uI["prototype"]["updateFontSize"] = function (uI) {
                uI > 0x0 && (this["rootElement"]["style"]["fontSize"] = ''["concat"](uI, 'px'));
              }, uI["prototype"]["updateZindex"] = function (uI) {
                this["rootElement"]["style"]["zIndex"] = uI["toString"]();
              }, uI["prototype"]["getFontSize"] = function () {
                return parseFloat(this["bv_On"]["style"]["fontSize"]["split"]('px')[0x0]);
              }, uI["prototype"]["toggleVisibility"] = function (uI) {
                {
                  var uH = uI ? "visible" : "hidden";
                  this["rootElement"]["style"]["visibility"] = uH;
                }
              }, uI["prototype"]["setGameTitle"] = function (uI) {
                {
                  var uH = this["bv_On"];
                  uH && (uH["textContent"] = uI);
                }
              }, uI["prototype"]["resizeTextToFitWidth"] = function () {
                var uI = this["bv_On"],
                  uH = parseFloat(B["getComputedStyle"](uI)["fontSize"]);
                if (uI["parentElement"] && uI["offsetWidth"] > uI["parentElement"]["offsetWidth"]) for (; uI["offsetWidth"] > uI["parentElement"]["offsetWidth"];) uH -= 0.5, uI["style"]["fontSize"] = uH["toString"]() + 'px';
              }, uI["prototype"]["bv_xn"] = function (uI, uH) {
                if (!this["bv_En"]["includes"](uI)) {
                  var B9 = document["createElement"]("style");
                  B9['id'] = uI, B9["textContent"] = uH, document["head"]["appendChild"](B9), this["bv_En"]["push"](uI);
                }
              }, uI["prototype"]["bv_kn"] = function () {
                var uI = 0x12,
                  uH = shell["environment"]["hasNotch"](),
                  B9 = nP() && 0x280 === nd && 0x470 === nW;
                (B["navigator"]["standalone"] || "app" === B["shell"]["getEnvironment"]()) && (uH ? uI = 0x2b : B9 ? uI = 0x1f : nP() && (uI = 0x1d)), this["rootElement"]["style"]["height"] = ''["concat"](uI, 'px');
              }, uI;
            }(plugin["AbstractViewComponent"]);
          function nH(uI, uI, uI, uH, B9, B8) {
            undefined === uI && (uI = false);
            var uQ = uI["name"];
            nz = nB() ? 0xb : nz, undefined !== B9 && (nE = B9), undefined !== B8 && (nz = B8), uI["component"]["create"](nb), n3 = uI["component"]["getInstance"](nb), uH ? uH["appendChild"](n3["rootElement"]) : uI["view"]["appendTo"](nb, "overlay"), n3["updatePosition"](nE), n3["updateFontSize"](nz), uI ? n3["setGameTitle"](uQ + " - " + shell["I18n"]['t']("GameTitleTrial.Title")) : n3["setGameTitle"](uQ), n3["resizeTextToFitWidth"]();
          }
          function nS(uI) {
            n3 && n3["updateZindex"](uI);
          }
          function nc() {
            return n3 && n3["getFontSize"]();
          }
          function ns(uI) {
            n3 && n3["updatePosition"](uI);
          }
          function nR(uI) {
            undefined === uI && (uI = false), n3 && n3["toggleVisibility"](uI);
          }
          P("GameTitle", Object["freeze"]({
            '__proto__': null,
            'GameTitle': nb,
            get 'GameTitlePosition'() {
              {
                return n2;
              }
            },
            'getTitleFontSize': nc,
            'initGameTitle': nH,
            'toggleVisibleGameTitleNode': nR,
            'updateTitleFontSize': function (uI) {
              {
                n3 && n3["updateFontSize"](uI);
              }
            },
            'updateTitlePosition': ns,
            'updateTitleZIndex': nS
          })), function (uI) {
            {
              uI[uI["LEFT"] = 0x1] = "LEFT", uI[uI["CENTER"] = 0x2] = "CENTER", uI[uI["RIGHT"] = 0x3] = "RIGHT";
            }
          }(nl || (nl = {}));
          var nQ = nl["RIGHT"],
            ny = 11.5,
            nv = B["devicePixelRatio"] || 0x1,
            nJ = B["screen"]["width"] * nv,
            nF = B["screen"]["height"] * nv;
          function nM() {
            return shell["environment"]["isIOS"]();
          }
          var nI,
            nx = function (uI) {
              {
                function uI() {
                  var uI = null !== uI && uI["apply"](this, arguments) || this;
                  return uI["rootElement"] = Object["create"](null), uI["bv_On"] = Object["create"](null), uI["bv_En"] = [], uI;
                }
                return u0(uI, uI), uI["prototype"]["onCreate"] = function () {
                  var uI = this;
                  this["bv_xn"]("time-stamp-css", ".time_stamp {        height: 17px;        position: absolute;        display: flex;        color: white;        opacity: 0.85;        text-shadow: rgb(65, 50, 24) 1px 0px 0px, rgb(65, 50, 24) 0.552px 0.85px 0px, rgb(65, 50, 24) -0.4px 0.9px 0px, rgb(65, 50, 24) -0.1px 0.15px 0px, rgb(65, 50, 24) -0.65px -0.7px 0px, rgb(65, 50, 24) 0.3px -0.95px 0px, rgb(65, 50, 24) 0.96px -0.28px 0px;        pointer-events: none;        font-family: monospace;        z-index: 250;}"), this["rootElement"] = document["createElement"]("div"), this["rootElement"]["setAttribute"]('id', "time-stamp"), this["rootElement"]["classList"]["add"]("time_stamp"), this["context"]["event"]["emit"]("Shell.GetScale", undefined, function (uH) {
                    !uH["error"] && uH["response"] && (uI["rootElement"]["style"]["width"] = uH["response"]["width"] + 'px');
                  }), this["bv_On"] = document["createElement"]("div"), this["bv_On"]["style"]["paddingRight"] = "12px", this["bv_On"]["style"]["display"] = "flex", this["bv_On"]["style"]["alignItems"] = "center", this["rootElement"]["appendChild"](this["bv_On"]), this["bv_jn"]();
                }, uI["prototype"]["updatePosition"] = function (uI) {
                  {
                    uI === nl["CENTER"] ? this["rootElement"]["style"]["justifyContent"] = "center" : uI === nl["LEFT"] ? this["rootElement"]["style"]["justifyContent"] = "flex-start" : this["rootElement"]["style"]["justifyContent"] = "flex-end", this["bv_kn"]();
                  }
                }, uI["prototype"]["updateFontSize"] = function (uI) {
                  {
                    uI > 0x0 && (this["rootElement"]["style"]["fontSize"] = ''["concat"](uI, 'px'));
                  }
                }, uI["prototype"]["updateZindex"] = function (uI) {
                  {
                    this["rootElement"]["style"]["zIndex"] = uI["toString"]();
                  }
                }, uI["prototype"]["toggleVisibility"] = function (uI) {
                  var uH = uI ? "visible" : "hidden";
                  this["rootElement"]["style"]["visibility"] = uH;
                }, uI["prototype"]["bv_xn"] = function (uI, uH) {
                  {
                    if (!this["bv_En"]["includes"](uI)) {
                      var B9 = document["createElement"]("style");
                      B9['id'] = uI, B9["textContent"] = uH, document["head"]["appendChild"](B9), this["bv_En"]["push"](uI);
                    }
                  }
                }, uI["prototype"]["bv_jn"] = function () {
                  {
                    var uI = this["bv_On"];
                    uI && setInterval(function () {
                      var uH = new Date(),
                        B9 = uH["getHours"](),
                        B8 = uH["getMinutes"](),
                        uQ = uH["getSeconds"](),
                        B7 = B9 < 0xa ? '0'["concat"](B9) : B9,
                        B8 = B8 < 0xa ? '0'["concat"](B8) : B8,
                        B8 = uQ < 0xa ? '0'["concat"](uQ) : uQ;
                      uI && (uI["textContent"] = ''["concat"](B7, ':')["concat"](B8, ':')["concat"](B8));
                    }, 0x3e8);
                  }
                }, uI["prototype"]["bv_kn"] = function () {
                  {
                    var uI = 0x12,
                      uH = B["navigator"]["standalone"] || "app" === B["shell"]["getEnvironment"](),
                      B9 = shell["environment"]["hasNotch"](),
                      B8 = nM() && 0x280 === nJ && 0x470 === nF;
                    uH && (B9 ? uI = 0x2b : B8 ? uI = 0x1f : nM() && (uI = 0x1d)), this["rootElement"]["style"]["height"] = ''["concat"](uI, 'px');
                  }
                }, uI;
              }
            }(plugin["AbstractViewComponent"]);
          function nT(uI) {
            undefined === uI && (uI = false), nN && nN["toggleVisibility"](uI);
          }
          !function (uI) {
            {
              uI[uI["LEFT"] = 0x1] = "LEFT", uI[uI["CENTER"] = 0x2] = "CENTER", uI[uI["RIGHT"] = 0x3] = "RIGHT";
            }
          }(nI || (nI = {}));
          var nk = B["devicePixelRatio"] || 0x1,
            nO = B["screen"]["width"] * nk,
            nC = B["screen"]["height"] * nk;
          function nL() {
            return "land" === shell["environment"]["getOrientationMode"]();
          }
          function nm() {
            {
              return shell["environment"]["isIOS"]();
            }
          }
          function nU() {
            {
              return shell["environment"]["hasNotch"]();
            }
          }
          function nZ() {
            return nm() && 0x280 === nO && 0x470 === nC;
          }
          function nD() {
            return B["navigator"]["standalone"] || "app" === B["shell"]["getEnvironment"]();
          }
          var nh,
            nY = "game-base-header-css",
            nw = function (uI) {
              {
                function uI() {
                  var uI = null !== uI && uI["apply"](this, arguments) || this;
                  return uI["rootElement"] = Object["create"](null), uI["textDiv"] = Object["create"](null), uI["styleIDs"] = [], uI["customCSSPropertiesList"] = [], uI["bv_In"] = 0x0, uI;
                }
                return u0(uI, uI), uI["prototype"]["onCreate"] = function () {
                  var uI = this;
                  this["bv_In"] = nL() ? this["landScapeMaxWidth"] : this["portraitMaxWidth"], this["rootElement"] = document["createElement"]("div"), this["rootElement"]["setAttribute"]('id', this["elementID"]), document["head"]["getElementsByTagName"]("style")["namedItem"](nY) && this["styleIDs"]["push"](nY), this["bv_xn"](nY, ".game-base-header-css {        height: 17px;        position: absolute;        display: flex;        color: white;        opacity: 0.85;        text-shadow: rgb(65, 50, 24) 1px 0px 0px, rgb(65, 50, 24) 0.552px 0.85px 0px, rgb(65, 50, 24) -0.4px 0.9px 0px, rgb(65, 50, 24) -0.1px 0.15px 0px, rgb(65, 50, 24) -0.65px -0.7px 0px, rgb(65, 50, 24) 0.3px -0.95px 0px, rgb(65, 50, 24) 0.96px -0.28px 0px;        pointer-events: none;        z-index: 250;}"), this["rootElement"]["classList"]["add"](nY);
                  var uH = ''["concat"](this["elementID"], "-css"),
                    B9 = this["bv_An"](uH, this["customCSSPropertiesList"]);
                  B9 && (this["bv_xn"](uH, B9), this["rootElement"]["classList"]["add"](uH)), this["context"]["event"]["emit"]("Shell.GetScale", undefined, function (B8) {
                    !B8["error"] && B8["response"] && (uI["rootElement"]["style"]["width"] = B8["response"]["width"] + 'px', null != uI["defaultWidth"] && (uI["defaultWidth"] = B8["response"]["width"]));
                  }), this["textDiv"] = document["createElement"]("div"), this["textDiv"]["style"]["paddingLeft"] = "12px", this["textDiv"]["style"]["paddingRight"] = "12px", this["textDiv"]["style"]["display"] = "flex", this["textDiv"]["style"]["alignItems"] = "center", shell["isRTLLanguage"] && shell["isRTLLanguage"]() && (this["textDiv"]["style"]["direction"] = "rtl"), this["rootElement"]["appendChild"](this["textDiv"]);
                }, uI["prototype"]["updatePosition"] = function (uI) {
                  uI === nI["CENTER"] ? (this["rootElement"]["style"]["justifyContent"] = "center", this["bv_Nn"](this["defaultWidth"])) : uI === nI["LEFT"] ? (this["rootElement"]["style"]["justifyContent"] = "flex-start", this["bv_Nn"](this["bv_In"])) : (this["rootElement"]["style"]["justifyContent"] = "flex-end", this["bv_Nn"](this["bv_In"])), this["bv_kn"]();
                }, uI["prototype"]["updateFontSize"] = function (uI) {
                  uI > 0x0 && (this["rootElement"]["style"]["fontSize"] = ''["concat"](uI, 'px'));
                }, uI["prototype"]["updateZindex"] = function (uI) {
                  {
                    this["rootElement"]["style"]["zIndex"] = uI["toString"]();
                  }
                }, uI["prototype"]["getFontSize"] = function () {
                  {
                    return parseFloat(this["textDiv"]["style"]["fontSize"]["split"]('px')[0x0]);
                  }
                }, uI["prototype"]["toggleVisibility"] = function (uI) {
                  var uH = uI ? "visible" : "hidden";
                  this["rootElement"]["style"]["visibility"] = uH;
                }, uI["prototype"]["resizeTextToFitWidth"] = function () {
                  var uI = this["textDiv"],
                    uH = parseFloat(B["getComputedStyle"](uI)["fontSize"]);
                  if (uI["parentElement"] && uI["offsetWidth"] > uI["parentElement"]["offsetWidth"]) for (; uI["offsetWidth"] > uI["parentElement"]["offsetWidth"];) uH -= 0.5, uI["style"]["fontSize"] = uH["toString"]() + 'px';
                }, uI["prototype"]["updateText"] = function (uI) {
                  var uH = this["textDiv"];
                  uH && (uH["textContent"] = uI);
                }, uI["prototype"]["bv_xn"] = function (uI, uH) {
                  if (!this["styleIDs"]["includes"](uI)) {
                    var B9 = document["createElement"]("style");
                    B9['id'] = uI, B9["textContent"] = uH, document["head"]["appendChild"](B9), this["styleIDs"]["push"](uI);
                  }
                }, uI["prototype"]["bv_kn"] = function () {
                  var uI = 0x12,
                    uH = nD(),
                    B9 = nU(),
                    B8 = nZ();
                  uH && (B9 ? uI = 0x2b : B8 ? uI = 0x1f : nm() && (uI = 0x1d)), this["rootElement"]["style"]["height"] = ''["concat"](uI, 'px');
                }, uI["prototype"]["bv_Nn"] = function (uI) {
                  {
                    null != uI && (this["rootElement"]["style"]["width"] = ''["concat"](this["bv_In"], 'px'));
                  }
                }, uI["prototype"]["bv_An"] = function (uI, uH) {
                  {
                    var B9 = [];
                    return uH["forEach"](function (B8) {
                      var uQ = B8["endsWith"](';') ? B8 : ''["concat"](B8, ';');
                      B9["push"](uQ);
                    }), B9["length"] <= 0x0 ? '' : '.'["concat"](uI, " { ") + B9["join"]('\x20') + '\x20}';
                  }
                }, uI;
              }
            }(plugin["AbstractViewComponent"]),
            nV = function () {
              function uI() {}
              return uI["prototype"]["isLandscape"] = function () {
                return nL();
              }, uI["prototype"]["isIOS"] = function () {
                {
                  return nm();
                }
              }, uI["prototype"]["isIphoneX"] = function () {
                {
                  return nU();
                }
              }, uI["prototype"]["isIphoneSE"] = function () {
                {
                  return nZ();
                }
              }, uI["prototype"]["isNotBrowserMode"] = function () {
                {
                  return nD();
                }
              }, uI;
            }(),
            nq = function (uI) {
              function uI() {
                {
                  var uI = null !== uI && uI["apply"](this, arguments) || this;
                  return uI["elementID"] = "game-session-time", uI["bv_Ln"] = 0x0, uI["bv_Mn"] = {
                    'hours': 0x0,
                    'minutes': 0x0,
                    'seconds': 0x0
                  }, uI;
                }
              }
              return u0(uI, uI), uI["prototype"]["onCreate"] = function () {
                {
                  uI["prototype"]["onCreate"]["call"](this);
                }
              }, uI["prototype"]["startSessionTime"] = function () {
                {
                  var uI = this;
                  this["bv_Pn"] || (this["bv_Pn"] = setInterval(function () {
                    var uH = ++uI["bv_Ln"],
                      B9 = Math["floor"](uH / 0xe10),
                      B8 = Math["floor"]((uH - 0xe10 * B9) / 0x3c),
                      uQ = uH - (0xe10 * B9 + 0x3c * B8);
                    uI["bv_Mn"] = {
                      'hours': B9,
                      'minutes': B8,
                      'seconds': uQ
                    }, uI["updateTime"]();
                  }, 0x3e8));
                }
              }, uI["prototype"]["stopSessionTime"] = function () {
                this["bv_Pn"] && clearInterval(this["bv_Pn"]), this["bv_Pn"] = undefined;
              }, uI["prototype"]["getSessionTime"] = function () {
                return this["bv_Mn"];
              }, uI["prototype"]["updateTime"] = function () {
                {
                  var uI = this["bv_Mn"],
                    uH = uI["hours"],
                    B9 = uI["minutes"],
                    B8 = uI["seconds"],
                    uQ = uH < 0xa ? '0'["concat"](uH) : uH + '',
                    B7 = B9 < 0xa ? '0'["concat"](B9) : B9 + '',
                    B8 = B8 < 0xa ? '0'["concat"](B8) : B8 + '',
                    B8 = uH > 0x0 ? ''["concat"](uQ, ':')["concat"](B7, ':')["concat"](B8) : ''["concat"](B7, ':')["concat"](B8),
                    uQ = shell["I18n"]['t']("GameCustomDisplay.SessionTime") + '\x20' + B8;
                  this["updateText"](uQ);
                }
              }, uI;
            }(nw),
            nK = function (uI) {
              function uI() {
                {
                  var uI = null !== uI && uI["apply"](this, arguments) || this;
                  return uI["position"] = nI["RIGHT"], uI["fontSize"] = 11.5, uI["landscapeFontSize"] = 0xb, uI;
                }
              }
              return u0(uI, uI), uI["prototype"]["initGameSessionTime"] = function (uI, uH, B9, B8) {
                this["fontSize"] = this["isLandscape"]() ? this["landscapeFontSize"] : this["fontSize"], undefined !== B9 && (this["position"] = B9), undefined !== B8 && (this["fontSize"] = B8), uI["component"]["create"](nq), this["bv__n"] = uI["component"]["getInstance"](nq), uH ? uH["appendChild"](this["bv__n"]["rootElement"]) : uI["view"]["appendTo"](nq, "overlay"), this["bv__n"]["updateTime"](), this["bv__n"]["updatePosition"](this["position"]), this["bv__n"]["updateFontSize"](this["fontSize"]);
              }, uI["prototype"]["updateGameSessionTimeZIndex"] = function (uI) {
                this["bv__n"] && this["bv__n"]["updateZindex"](uI);
              }, uI["prototype"]["updateGameSessionTimeFontSize"] = function (uI) {
                {
                  this["bv__n"] && this["bv__n"]["updateFontSize"](uI);
                }
              }, uI["prototype"]["updateGameSessionTimePosition"] = function (uI) {
                this["bv__n"] && this["bv__n"]["updatePosition"](uI);
              }, uI["prototype"]["toggleVisibleGameSessionTimeNode"] = function (uI) {
                undefined === uI && (uI = false), this["bv__n"] && this["bv__n"]["toggleVisibility"](uI);
              }, uI["prototype"]["startGameSessionTime"] = function () {
                this["bv__n"] && this["bv__n"]["startSessionTime"]();
              }, uI["prototype"]["stopGameSessionTime"] = function () {
                {
                  this["bv__n"] && this["bv__n"]["stopSessionTime"]();
                }
              }, uI["prototype"]["getGameSessionTime"] = function () {
                {
                  return this["bv__n"] && this["bv__n"]["getSessionTime"]();
                }
              }, uI;
            }(nV),
            nA = u7["formatCurrency"],
            nG = function (uI) {
              function uI() {
                {
                  var uI = null !== uI && uI["apply"](this, arguments) || this;
                  return uI["elementID"] = "game-session-net-profit", uI["bv_Dn"] = true, uI["bv_Un"] = 0x0, uI["bv_Hn"] = 0x0, uI["bv_Bn"] = 0x0, uI;
                }
              }
              return u0(uI, uI), uI["prototype"]["onCreate"] = function () {
                uI["prototype"]["onCreate"]["call"](this);
              }, uI["prototype"]["getGameSessionNetProfit"] = function () {
                {
                  return this["bv_Bn"];
                }
              }, uI["prototype"]["updateGameSessionNetProfit"] = function (uI) {
                {
                  this["setLatestBalance"](uI), this["bv_Bn"] = this["bv_Hn"] - this["bv_Un"], this["updateNetProfit"]();
                }
              }, uI["prototype"]["setLatestBalance"] = function (uI) {
                {
                  this["bv_Dn"] && (this["bv_Un"] = uI, this["bv_Dn"] = false), this["bv_Hn"] = uI;
                }
              }, uI["prototype"]["updateNetProfit"] = function () {
                {
                  var uI = shell["I18n"]['t']("GameCustomDisplay.SessionNetPosition") + '\x20' + nA(this["bv_Bn"]);
                  this["updateText"](uI), this["resizeTextToFitWidth"]();
                }
              }, uI;
            }(nw),
            nf = function (uI) {
              {
                function uI() {
                  var uI = null !== uI && uI["apply"](this, arguments) || this;
                  return uI["position"] = nI["LEFT"], uI["fontSize"] = 11.5, uI["landscapeFontSize"] = 0xb, uI;
                }
                return u0(uI, uI), uI["prototype"]["initGameSessionNetProfit"] = function (uI, uH, B9, B8) {
                  {
                    this["fontSize"] = this["isLandscape"]() ? this["landscapeFontSize"] : this["fontSize"], undefined !== B9 && (this["position"] = B9), undefined !== B8 && (this["fontSize"] = B8), uI["component"]["create"](nG), this["bv_Fn"] = uI["component"]["getInstance"](nG), uH ? uH["appendChild"](this["bv_Fn"]["rootElement"]) : uI["view"]["appendTo"](nG, "overlay"), this["bv_Fn"]["updatePosition"](this["position"]), this["bv_Fn"]["updateFontSize"](this["fontSize"]), this["bv_Fn"]["updateNetProfit"]();
                  }
                }, uI["prototype"]["updateSessionNetProfitZIndex"] = function (uI) {
                  this["bv_Fn"] && this["bv_Fn"]["updateZindex"](uI);
                }, uI["prototype"]["updateSessionNetProfitFontSize"] = function (uI) {
                  {
                    this["bv_Fn"] && this["bv_Fn"]["updateFontSize"](uI);
                  }
                }, uI["prototype"]["getSessionNetProfitFontSize"] = function () {
                  {
                    return this["bv_Fn"] && this["bv_Fn"]["getFontSize"]() || 0x0;
                  }
                }, uI["prototype"]["updateSessionNetProfitPosition"] = function (uI) {
                  this["bv_Fn"] && this["bv_Fn"]["updatePosition"](uI);
                }, uI["prototype"]["updateBalance"] = function (uI) {
                  this["bv_Fn"] && this["bv_Fn"]["updateGameSessionNetProfit"](uI);
                }, uI["prototype"]["toggleVisibleGameSessionNetProfitNode"] = function (uI) {
                  undefined === uI && (uI = false), this["bv_Fn"] && this["bv_Fn"]["toggleVisibility"](uI);
                }, uI["prototype"]["getSessionNetProfit"] = function () {
                  return this["bv_Fn"] && this["bv_Fn"]["getGameSessionNetProfit"]() || 0x0;
                }, uI;
              }
            }(nV),
            ng = new (function () {
              function uI() {
                this["bv_Wn"] = new nK(), this["bv_qn"] = new nf();
              }
              return Object["defineProperty"](uI["prototype"], "gameSessionTimeHelper", {
                'get': function () {
                  return this["bv_Wn"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "gameSessionNetProfitHelper", {
                'get': function () {
                  {
                    return this["bv_qn"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), uI;
            }())();
          !function (uI) {
            {
              uI[uI["LEGACY"] = 0x0] = "LEGACY", uI[uI["NEW"] = 0x1] = "NEW";
            }
          }(nh || (nh = {}));
          var E0,
            E1,
            E2,
            E3 = [];
          function E4(uI, uI) {
            var uI = u7["timeoutCallback"],
              uH = uI;
            uI(0x2)(function () {
              var B9 = E2["getComponent"](cc["Label"]);
              E2["setScale"](cc['v2'](0x1, 0x0)), B9["string"] = uI[uH], uH++, uH %= uI["length"], E2["runAction"](cc["sequence"](cc["scaleTo"](0.125, 0x1)["easing"](cc["easeIn"](0x1)), cc["callFunc"](function () {
                E4(uH, uI);
              })));
            });
          }
          var E5,
            E6,
            E7,
            E8,
            E9 = function () {
              function uI() {}
              return uI["prototype"]["initGameOperatorDisplay"] = function (uI, uI, uH, B9) {
                {
                  var B8, uQ, B7, B8;
                  undefined === E0 && (E0 = new cc["Node"]("operator_display_holder"), E1 = new cc["Node"]("operator_display"), E2 = new cc["Node"]("content"), E1["parent"] = E0, E2["parent"] = E1, cc["game"]["isPersistRootNode"](E0) || cc["game"]["addPersistRootNode"](E0)), uQ = (B8 = E0)["addComponent"](cc["Widget"]), B7 = cc["view"]["getViewportRect"]()["height"], B8 = cc["view"]["getViewportRect"]()["width"], B8["anchorX"] = 0.5, B8["anchorY"] = 0.5, B8["zIndex"] = 0x3e8, B8["width"] = B8, B8["height"] = B7, uQ["top"] = 0x0, uQ["left"] = 0x0, uQ["right"] = 0x0, uQ["isAlignTop"] = true, uQ["isAlignLeft"] = true, uQ["isAlignRight"] = true, uQ["isAlignVerticalCenter"] = true, uQ["isAlignHorizontalCenter"] = true, uQ["updateAlignment"](), function (B8) {
                    {
                      var uQ = B8["addComponent"](cc["Layout"]);
                      B8["width"] = 0x438, B8["height"] = 0x19, B8["anchorX"] = 0.5, B8["anchorY"] = 0x1, B8["setPosition"](cc['v2'](0x0, -0x361)), uQ["type"] = cc["Layout"]["Type"]["HORIZONTAL"], uQ["paddingLeft"] = 0x14;
                    }
                  }(E1), function (B8, uQ) {
                    var l6 = B8["addComponent"](cc["Label"]),
                      l6 = B8["addComponent"](cc["LabelOutline"]);
                    B8["width"] = 0x410, B8["anchorX"] = 0x0, B8["anchorY"] = 0.5, l6["overflow"] = cc["Label"]["Overflow"]["CLAMP"], l6["lineHeight"] = 0x19, l6["fontSize"] = uQ || 0x19, l6["node"]["opacity"] = 0x99, l6["horizontalAlign"] = cc["Label"]["HorizontalAlign"]["LEFT"], l6["verticalAlign"] = cc["Label"]["VerticalAlign"]["CENTER"], l6["color"] = new cc["Color"](0x41, 0x32, 0x18, 0xff), l6["width"] = 0.5;
                  }(E2, B9), function (B8) {
                    B8 && B8["length"] > 0x0 && E3["push"](B8);
                  }(uH), function (B8) {
                    {
                      if (B8 && B8["length"] > 0x0) for (var uQ = function (l8) {
                          for (var uQ = B8[l8], uQ = Object["keys"](uQ)["map"](function (lB) {
                              {
                                return uQ[lB];
                              }
                            }), lE = [], lz = 0x0, lX = uQ["length"]; lz < lX; lz++) lE["push"](uQ[lz]);
                          E3["push"](lE["join"](':\x20'));
                        }, l6 = 0x0, l6 = B8["length"]; l6 < l6; l6++) uQ(l6);
                      E3 && E3["length"] > 0x0 && (E2["getComponent"](cc["Label"])["string"] = E3[0x0], E3["length"] > 0x1 && E4(0x1, E3));
                    }
                  }(uI), this["bv_Vn"](E3), uI["event"]['on']("Shell.Scaled", function (B8) {
                    {
                      !B8["error"] && function () {
                        {
                          var uQ = cc["view"]["getViewportRect"]()["height"],
                            l6 = cc["view"]["getViewportRect"]()["width"];
                          E0["width"] = uQ, E0["height"] = l6;
                        }
                      }();
                    }
                  }, undefined), uI["event"]["emit"]("Game.GetSettingMenuType", undefined, function (B8) {
                    {
                      B8["error"] || (B8["response"] === nh["LEGACY"] ? E1["setPosition"](cc['v2'](0x0, -0x375)) : "land" === shell["environment"]["getOrientationMode"]() && E1["setPosition"](cc['v2'](-0x1ae, -0x170)));
                    }
                  }), uI["event"]["emit"]("Game.RequestLayoutInfo", undefined, function (B8) {
                    {
                      if (!B8["error"] && B8["response"]) {
                        {
                          var uQ = B8["response"];
                          uQ["uiOperatorDisplaySpace"] && E1["setPosition"](cc['v2'](0x0, uQ["uiOperatorDisplaySpace"]["position"]['y']));
                        }
                      }
                    }
                  });
                }
              }, uI["prototype"]["toggleVisibleGameOperatorDisplayNode"] = function (uI) {
                {
                  undefined === uI && (uI = false), E0 && (E0["active"] = uI);
                }
              }, uI["prototype"]["bv_Vn"] = function (uI) {
                uI && 0x0 !== uI["length"] || this["toggleVisibleGameOperatorDisplayNode"](false);
              }, uI;
            }(),
            Eu = new (function () {
              function uI() {
                this["bv_Qn"] = new E9();
              }
              return Object["defineProperty"](uI["prototype"], "gameOperatorDisplayHelper", {
                'get': function () {
                  {
                    return this["bv_Qn"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), uI;
            }())();
          (function (uI) {
            uI[uI["LEFT"] = 0x1] = "LEFT", uI[uI["CENTER"] = 0x2] = "CENTER", uI[uI["RIGHT"] = 0x3] = "RIGHT";
          })(E5 || (E5 = {})), function (uI) {
            uI["GameTitle"] = "gameTitle", uI["TimeStamp"] = "timeStamp", uI["GameSessionNetProfit"] = "gameSessionNetProfit", uI["GameSessionTime"] = "gameSessionTime";
          }(E6 || (E6 = {})), function (uI) {
            uI[uI["TITLE_TIMESTAMP"] = 0x0] = "TITLE_TIMESTAMP", uI[uI["SESSION_NET_PROFIT_TIME"] = 0x1] = "SESSION_NET_PROFIT_TIME";
          }(E7 || (E7 = {})), function (uI) {
            uI["BONUS_WALLET"] = 'B', uI["FREE_GAMES"] = 'G', uI["CASH"] = 'C', uI["TOURNAMENT"] = 'P', uI["REMOTE"] = 'I';
          }(E8 || (E8 = {}));
          var Ej,
            EE,
            Ez,
            EX,
            EB,
            EP = false,
            El = {
              'gameTitle': {
                'show': false,
                'order': E7["TITLE_TIMESTAMP"]
              },
              'timeStamp': {
                'show': false,
                'order': E7["TITLE_TIMESTAMP"]
              },
              'gameSessionNetProfit': {
                'show': false,
                'order': E7["SESSION_NET_PROFIT_TIME"]
              },
              'gameSessionTime': {
                'show': false,
                'order': E7["SESSION_NET_PROFIT_TIME"]
              }
            },
            EN = undefined,
            Ep = false,
            Ed = ng["gameSessionNetProfitHelper"],
            EW = ng["gameSessionTimeHelper"],
            Eb = Eu["gameOperatorDisplayHelper"],
            EH = false,
            ES = false,
            Ec = false,
            Es = false,
            ER = {},
            EQ = false,
            Ey = false,
            Ev = false;
          function EJ(uI, uI) {
            {
              switch (undefined === uI && (uI = true), uI) {
                case "None":
                  El["gameTitle"] = {
                    'show': false,
                    'order': E7["TITLE_TIMESTAMP"]
                  }, El["timeStamp"] = {
                    'show': false,
                    'order': E7["TITLE_TIMESTAMP"]
                  };
                  break;
                case "Time":
                  El["gameTitle"] = {
                    'show': false,
                    'order': 0x1
                  }, El["timeStamp"] = {
                    'show': true,
                    'position': E5["RIGHT"],
                    'order': E7["TITLE_TIMESTAMP"]
                  };
                  break;
                case "Title":
                  El["gameTitle"] = {
                    'show': true,
                    'position': E5["CENTER"],
                    'order': E7["TITLE_TIMESTAMP"]
                  }, El["timeStamp"] = {
                    'show': false,
                    'order': E7["TITLE_TIMESTAMP"]
                  };
                  break;
                case "All":
                  El["gameTitle"] = {
                    'show': true,
                    'position': E5["LEFT"],
                    'order': E7["TITLE_TIMESTAMP"]
                  }, El["timeStamp"] = {
                    'show': true,
                    'position': E5["RIGHT"],
                    'order': E7["TITLE_TIMESTAMP"]
                  };
              }
              El["gameSessionNetProfit"] = {
                'show': !Ec && EH,
                'position': E5["LEFT"],
                'order': E7["SESSION_NET_PROFIT_TIME"]
              }, El["gameSessionTime"] = {
                'show': !Es && ES,
                'position': E5["RIGHT"],
                'order': E7["SESSION_NET_PROFIT_TIME"]
              }, Ez = uI, uI && EF();
            }
          }
          function EF() {
            Ex(true)["length"] <= 0x0 ? (Ey = true, Ej["style"]["visibility"] = "hidden", Ex(false)["forEach"](function (uI) {
              ET(uI);
            })) : (Ev = true, function () {
              {
                if (Ej["style"]["visibility"] = "visible", EO(), EQ && Ev) return Ev = false, ED(), Eh(), void EC(0x0, true);
                EQ || (EQ = true, Ev = false, EC(0x0, true));
              }
            }());
          }
          function EM(uI) {
            EH && (Ec = uI, El["gameSessionNetProfit"]["show"] = !Ec && EH), ES && (Es = uI, El["gameSessionTime"]["show"] = !Es && ES), EF();
          }
          function EI() {
            return Object["values"](E6);
          }
          function Ex(uI) {
            return EI()["filter"](function (uI) {
              return uI ? El[uI]["show"] : !El[uI]["show"];
            });
          }
          function ET(uI) {
            switch (uI) {
              case E6["GameTitle"]:
                nR(false);
                break;
              case E6["TimeStamp"]:
                nT(false);
                break;
              case E6["GameSessionNetProfit"]:
                Ed["toggleVisibleGameSessionNetProfitNode"](false);
                break;
              case E6["GameSessionTime"]:
                EW["toggleVisibleGameSessionTimeNode"](false);
            }
          }
          function Ek(uI, uI, uI, uH) {
            uI[uI] || (uI[uI] = {});
            var B9 = function (B8) {
              {
                uI[uI][B8] ? Ek(uI, uI + 0x1, uI, uH) : uI[uI][B8] = uI;
              }
            };
            switch (uH) {
              case E5["LEFT"]:
                B9("left");
                break;
              case E5["CENTER"]:
                B9("center");
                break;
              case E5["RIGHT"]:
                B9("right");
            }
          }
          function EO() {
            return ER = {}, Ex(true)["forEach"](function (uI) {
              {
                var uI = uI,
                  uI = El[uI],
                  uH = uI["position"],
                  B9 = uI["order"],
                  B8 = uH || E5["LEFT"];
                Ek(ER, B9, uI, B8);
              }
            }), ER;
          }
          function EC(uI, uI) {
            {
              var uI = Object["keys"](ER),
                uH = uI[uI],
                B9 = ER[uH];
              !function (B8, uQ, B7) {
                {
                  var B8 = function () {
                      var uQ = EI()["filter"](function (l6) {
                        {
                          return !uQ["some"](function (l8) {
                            var uQ = l8["key"];
                            return uQ && uQ === l6;
                          });
                        }
                      });
                      uQ["forEach"](function (l6) {
                        ET(l6);
                      });
                    },
                    B8 = function () {
                      uQ["forEach"](function (uQ) {
                        var l6 = uQ["key"],
                          l6 = uQ["position"];
                        l6 && function (l8, uQ) {
                          {
                            switch (l8) {
                              case E6["GameTitle"]:
                                nR(true), ns(uQ);
                                break;
                              case E6["TimeStamp"]:
                                nT(true), function (uQ) {
                                  {
                                    nN && nN["updatePosition"](uQ);
                                  }
                                }(uQ);
                                break;
                              case E6["GameSessionNetProfit"]:
                                Ed["toggleVisibleGameSessionNetProfitNode"](true), Ed["updateSessionNetProfitPosition"](uQ);
                                break;
                              case E6["GameSessionTime"]:
                                EW["toggleVisibleGameSessionTimeNode"](true), EW["updateGameSessionTimePosition"](uQ);
                            }
                          }
                        }(l6, l6);
                      }), function (uQ) {
                        if (!EE || Ey || Ev) return uQ();
                        !function (l6) {
                          {
                            EE["style"]["transform"] = "scaleY(1)", EB = setTimeout(function () {
                              Eh(), l6();
                            }, 0xbb8);
                          }
                        }(uQ);
                      }(B7);
                    };
                  if (B8) return B8(), void B8();
                  !function (uQ) {
                    if (!EE || Ey || Ev) return uQ();
                    !function (l6) {
                      EE["style"]["transform"] = "scaleY(0)", EX = setTimeout(function () {
                        {
                          ED(), l6();
                        }
                      }, 0xc8);
                    }(uQ);
                  }(function () {
                    {
                      B8(), B8();
                    }
                  });
                }
              }(uI, [{
                'key': B9["left"],
                'position': E5["LEFT"]
              }, {
                'key': B9["center"],
                'position': E5["CENTER"]
              }, {
                'key': B9["right"],
                'position': E5["RIGHT"]
              }], function () {
                {
                  if (uI["length"] <= 0x1) EQ = false;else {
                    if (Ey) return EQ = false, void (Ey = false);
                    ++uI >= Object["keys"](ER)["length"] && (uI = 0x0), EC(uI, false);
                  }
                }
              });
            }
          }
          function EL() {
            return EN === E8["CASH"];
          }
          function Em(uI) {
            if (uI) {
              {
                var uI = uI['k'];
                Ep = "0_C" === uI["substring"](0x0, 0x3);
              }
            } else Ep = false;
          }
          function EU(uI) {
            {
              (EL() || Ep) && EM(uI);
            }
          }
          function EZ() {
            {
              EL() ? EM(false) : EM(!Ep);
            }
          }
          function ED() {
            EX && (clearTimeout(EX), EX = undefined);
          }
          function Eh() {
            {
              EB && (clearTimeout(EB), EB = undefined);
            }
          }
          var EY = P("GameHeaderHelper", {
              'initGameHeader': function (uI) {
                {
                  if (!EP) {
                    {
                      var uI = document["getElementById"]("game-overlay");
                      (Ej = document["createElement"]("div"))["setAttribute"]('id', "game-header-holder"), Ej["style"]["zIndex"] = '99', Ej["style"]["pointerEvents"] = "none", Ej["style"]["position"] = "absolute";
                      var uI = Ej,
                        uH = function (uQ) {
                          var lE = uQ["systemModel"]["operatorJurisdiction"],
                            lz = lE["gameClock"],
                            lX = lE["gameName"],
                            lB = lE["netProfitState"],
                            lP = lE["elapsedTimeState"],
                            lz = lz,
                            lX = lX,
                            lp = "All";
                          return EH = lB, ES = lP, undefined !== lz && undefined !== lX || (lz = true, lX = true), lz ? lX || (lp = "Time") : lp = lX ? "Title" : "None", lp;
                        }(uI["dataSource"]);
                      EJ(uH, false);
                      var B9 = EO();
                      Object["keys"](B9)["length"] > 0x1 && ((EE = document["createElement"]("div"))["setAttribute"]('id', "game-header-animate-holder"), EE["style"]["height"] = "18px", EE["style"]["transform"] = "scaleY(1)", EE["style"]["transformOrigin"] = "center", EE["style"]["transition"] = "transform 0.2s ease-in", uI = EE, Ej["appendChild"](EE)), uI && uI["appendChild"](Ej);
                      var B8 = uI["context"],
                        uQ = uI["gameTitle"],
                        B7 = uI["dataSource"]["systemModel"]["operatorJurisdiction"]["operatorCustomDisplayList"],
                        B8 = 0x2 === uI["dataSource"]["systemModel"]["betType"],
                        B8 = uI["dataSource"]["systemModel"]["operatorJurisdiction"]["gameVersion"],
                        uQ = uI["dataSource"]["systemModel"]["certifiedVersion"];
                      B8["event"]["emit"]("Shell.GetScale", undefined, function (uQ) {
                        !uQ["error"] && uQ["response"] && (Ej["style"]["height"] = uQ["response"]["height"] + 'px', Ej["style"]["width"] = uQ["response"]["width"] + 'px');
                      }), B8["event"]['on']("Shell.Scaled", function (uQ) {
                        {
                          var lE = uQ["payload"];
                          Ej["style"]["height"] = ''["concat"](lE["height"], 'px'), Ej["style"]["width"] = ''["concat"](lE["width"], 'px');
                        }
                      }, B8), nH(B8, uQ, B8, uI), function (uQ, lE, lz, lX) {
                        {
                          ny = "land" === shell["environment"]["getOrientationMode"]() ? 0xb : ny, undefined !== lz && (nQ = lz), undefined !== lX && (ny = lX), uQ["component"]["create"](nx), nN = uQ["component"]["getInstance"](nx), lE ? lE["appendChild"](nN["rootElement"]) : uQ["view"]["appendTo"](nx, "overlay"), nN["updatePosition"](nQ), nN["updateFontSize"](ny);
                        }
                      }(B8, uI);
                      var l6 = B8 ? uQ : undefined;
                      Eb["initGameOperatorDisplay"](B8, B7, l6);
                      var l6,
                        l8 = nc();
                      l6 = l8, nN && nN["updateFontSize"](l6), nR(false), nT(false), Eb["toggleVisibleGameOperatorDisplayNode"](false), B8["event"]["once"]("Game.GameInfoUpdated", function (uQ) {
                        {
                          var lE = uQ["payload"]['dt']['ls']['si'];
                          EN = lE['wt'], Em(lE["wbn"]);
                        }
                      }, B8), EH && (Ed["initGameSessionNetProfit"](B8, uI), Ed["updateSessionNetProfitFontSize"](l8), Ed["toggleVisibleGameSessionNetProfitNode"](false), B8["event"]['on']("Game.TransactionInfoChanged", function (uQ) {
                        var lE = uQ["payload"];
                        lE && lE["balance"] && (EL() || Ep) && Ed["updateBalance"](lE["balance"]);
                      }, B8)), ES && (EW["initGameSessionTime"](B8, uI), EW["updateGameSessionTimeFontSize"](l8), EW["toggleVisibleGameSessionTimeNode"](false));
                      var uQ = function (uQ) {
                        "GameStarted" === uQ["payload"] && (Eb["toggleVisibleGameOperatorDisplayNode"](true), ES && EW["startGameSessionTime"](), function (lE) {
                          {
                            lE["event"]['on']("Game.UpdateHeaderType", function (lz) {
                              {
                                var lX = lz["payload"];
                                lX || (lX = "All"), EJ(lX);
                              }
                            }, lE), lE["event"]['on']("Game.UpdateHeaderZIndex", function (lz) {
                              {
                                var lX = lz["payload"];
                                nS(lX), function (lB) {
                                  nN && nN["updateZindex"](lB);
                                }(lX), Ed["updateSessionNetProfitZIndex"](lX), EW["updateGameSessionTimeZIndex"](lX);
                              }
                            }, lE), lE["event"]['on']("Game.RequestHeaderType", function (lz) {
                              lz["response"] = Ez;
                            }, lE), lE["event"]['on']("Game.ShowCustomDisplay", function () {
                              Eb["toggleVisibleGameOperatorDisplayNode"](true);
                            }, lE), lE["event"]['on']("Game.HideCustomDisplay", function () {
                              Eb["toggleVisibleGameOperatorDisplayNode"](false);
                            }, lE), (EH || ES) && (lE["event"]['on']("Game.ReplayInitiated", function () {
                              EU(true);
                            }, lE), lE["event"]['on']("Game.ReplayQuit", function () {
                              EU(false);
                            }, lE), lE["event"]['on']("Game.GameInfoUpdated", function (lz) {
                              var lX = lz["payload"]['dt']['ls']['si'];
                              EN = lX['wt'], Em(lX["wbn"]), EZ();
                            }, lE));
                          }
                        }(B8), EZ(), EJ(uH), B8["event"]["off"]("Shell.BootStateChanged", uQ, B8));
                      };
                      B8["event"]['on']("Shell.BootStateChanged", uQ, B8), EP = true;
                    }
                  }
                }
              },
              'updateHeaderPositions': EJ,
              'emitShowCustomDisplayEvent': function () {
                {
                  uO()["emit"]("Game.ShowCustomDisplay");
                }
              },
              'emitHideCustomDisplayEvent': function () {
                {
                  uO()["emit"]("Game.HideCustomDisplay");
                }
              }
            }),
            Ew = P("GameMaintenanceHandler", {
              'checkGameMaintenance': function (uI, uI) {
                {
                  if (uI["isGameActive"]()) {
                    {
                      var uI = uI["maintenanceStartDate"],
                        uH = uI["maintenanceEndDate"];
                      if (uI && uH && uI["isGameMaintenenceApproaching"]()) return void uw({
                        'title_message': shell["I18n"]['t']("General.MaintenanceTitle"),
                        'content_message': shell["I18n"]['t']("General.MaintenanceMessage", {
                          'startDate': uI["readableMaintenanceStartDate"],
                          'endDate': uI["readableMaintenanceEndDate"]
                        }),
                        'actions': [{
                          'title': shell["I18n"]['t']("General.DialogOk"),
                          'handler': uI
                        }]
                      });
                      uI && uI();
                    }
                  } else {
                    {
                      var B9 = shell["Error"],
                        B8 = shell["ClientError"],
                        uQ = new B9(B8["Domain"], B8["GameMaintenanceError"]);
                      jZ["sendErrorReport"]("game inactive", uQ["domain"], uQ["code"]), jw["showError"](uQ, "Launch", function (B7) {
                        jU["Quit"] === B7 && jk["quitGame"]();
                      });
                    }
                  }
                }
              }
            }),
            EV = false;
          function Eq(uI, uI) {
            uI || (uI = function (B7, B8) {
              {
                if (B7) {
                  {
                    var B8 = uI["failCallback"];
                    B8 && B8(B7, B8);
                  }
                } else {
                  var uQ = uI["finalCallback"];
                  uQ && uQ(undefined, B8);
                }
              }
            });
            var uI,
              uH = new nj(),
              B9 = function (B7, B8, B8) {
                return function (uQ, l6) {
                  var l6 = B7["slowNetworkHandler"];
                  if (uQ) {
                    if (B8["isDestroyed"]) return;
                    var l8 = B8["getRetryCount"](),
                      uQ = l8 > 0x0 ? l8 : undefined;
                    if (uQ["canDismiss"] || jZ["sendErrorReport"](B7["name"] + " failed", uQ["domain"], uQ["code"], uQ), uQ["shouldRetry"] && B8["canRetry"]()) B8["execute"]();else {
                      if (l6 && l6["cancel"](), EV) return;
                      var uQ = B7["errorContext"] ? B7["errorContext"] : jw["getErrorContext"](B7["errorTitle"]);
                      jw["handleCommonError"](B7["name"] + " failed", uQ, uQ, function () {
                        {
                          l6 && l6["start"](), B8["reset"](), B8["execute"]();
                        }
                      }, function () {
                        var lE = shell["ServerError"];
                        (lE["isInsufficientCashFundError"](uQ["code"]) || lE["isInsufficientBonusFundError"](uQ["code"])) && (jP["insufficientFundResult"] = {
                          'error': uQ,
                          'result': l6
                        }), B8 && B8(uQ, l6);
                      });
                    }
                  } else {
                    {
                      if (l6 && l6["cancel"](), B8["destroy"](), EV) return;
                      B8 && B8(undefined, l6);
                    }
                  }
                  jZ["sendAnalyticsTiming"]({
                    'actionName': "GAME_API_REQUEST",
                    'state': "End"
                  });
                };
              }(uI, uH, uI),
              B8 = function (B7, B8, B8) {
                {
                  return function () {
                    B7(B8, B8), jZ["sendAnalyticsTiming"]({
                      'actionName': "GAME_API_REQUEST",
                      'state': "Start"
                    });
                  };
                }
              }(uI["apiRequest"], B9, uI["apiRequestParam"]);
            uI = uI["fallbackRequest"] ? function () {
              {
                var B7 = uI["fallbackRequest"];
                if (B7) {
                  var B8 = function (B8, uQ, l6) {
                    return function (l6, l8) {
                      {
                        l6 ? uQ(l6, l8) : l6 && l6(l8) ? (jZ["sendAnalyticsTiming"]({
                          'actionName': "GAME_API_REQUEST",
                          'state': "End"
                        }), B8()) : uQ(undefined, l8);
                      }
                    };
                  }(B8, B9, uI["shouldRetryApiRequest"]);
                  B7(B8, uI["fallbackRequestParam"]), jZ["sendAnalyticsTiming"]({
                    'actionName': "GAME_API_REQUEST",
                    'state': "Start"
                  });
                }
              }
            } : B8, uH['id'] = "handler_"["concat"](uI["name"]), uH["init"](uI["retryMessage"] ? uI["retryMessage"] : shell["I18n"]['t']("General.RetryNetwork"), uI);
            var uQ = uI["slowNetworkHandler"];
            uQ && uQ["start"](), B8();
          }
          var EK,
            EA = P("RequestHandler", {
              'doAPIRequest': Eq,
              'doTransactionAPIRequest': function (uI, uI, uI) {
                {
                  var uH = uI["transactionModel"]["transactionId"];
                  uI["errorContext"] = "Transaction", uI["name"] = "game api", uI["shouldRetryApiRequest"] = function () {
                    var B9 = uI["transactionModel"]["transactionId"];
                    return uH === B9;
                  }, Eq(uI, uI);
                }
              },
              'reportCriticalError': function () {
                {
                  EV = true;
                }
              }
            });
          function EG() {
            {
              return H["getPreference"](EK)["getItem"]("gameName");
            }
          }
          var Ef = {
              'getGameName': function (uI, uI) {
                {
                  uI["getGameName"](function (uI, uH) {
                    var B9;
                    uI || undefined === uH || (B9 = uH, H["getPreference"](EK)["setItem"]("gameName", B9['dt'])), uI && uI();
                  });
                }
              },
              'getGameNamesFromStorage': EG,
              'getGameNameWithId': function (uI) {
                var uI = EG();
                return uI && uI[uI] ? uI[uI] : uI["toString"]();
              },
              'setupGameNameDomain': function (uI) {
                {
                  EK = uI;
                }
              }
            },
            Eg = function () {
              function uI() {
                return [0xc8, 0xa, 0x12c]["reduce"](function (uI, uH) {
                  return uI * uH;
                }, 0x90);
              }
              function uI(uI, uH, B9) {
                {
                  if (function (uQ) {
                    {
                      return uT(B[uM(0x0)]["now"](), uQ);
                    }
                  }(uI)) {
                    if (uH || (uH = 0x64 * B["Number"]("0.0005")), B9) {
                      {
                        var B8 = function (uQ, B7) {
                          var B8 = (B[uM(0x0)]["now"]() - uQ) / (B7 * uI());
                          return B[uM(0x4)]["min"](0x1, B8 * B8);
                        }(uI, B9);
                        uH *= B8;
                      }
                    }
                    return uT(B[("Mathew", ud(-0x2, "Mathew"))]["random"](), uH);
                  }
                  return true;
                }
              }
              return [function () {
                {
                  return uI(["0x4c72"]["reduce"](function (uI, uH) {
                    return uI + B["Number"](uH);
                  }, 0x196) * uI(), 0x64 * B["Number"]("0.0005"), 0x1c);
                }
              }, uI];
            }(),
            z0 = Eg[0x0];
          function z1() {
            {
              return "rueEQ" === (z0() + 'EQ')["substring"](0x1);
            }
          }
          function z2(uI) {
            uI["response"] = function () {
              var uI = 0x0;
              uc(uv(" Math.random")) && (uI |= 0x1);
              var uI = uF(0x6);
              (uc(uv(" setTimeout ")) || uI()) && (uI |= 0x2);
              var uH = uF(0x0);
              (uc(uv(" Date.now")) || uH()) && (uI |= 0x4);
              var B9 = function () {
                  var uQ = -0x1;
                  try {
                    {
                      var B7 = B["Object"]["getOwnPropertyDescriptor"](B, "isSecureContext");
                      undefined === B7 ? uQ = 0x2 : uc(B7["get"]) && (uQ = B7["get"]["apply"](B) ? 0x1 : 0x0);
                    }
                  } catch (B8) {}
                  return uQ;
                }(),
                B8 = function () {
                  var uQ = "subtle",
                    B7 = uQ(B, "crypto");
                  if (!B7) return -0x1;
                  if (us(B7, uQ)) return -0x1;
                  var B8 = uy(B7, uQ);
                  return null != B8 ? ["digest", "sign", "importKey"]["reduce"](function (B8, uQ) {
                    {
                      return B8 + (us(B8, uQ) || !uc(uy(B8, uQ)) ? 0x1 : 0x0);
                    }
                  }, 0x0) ? -0x1 : 0x1 : 0x0;
                }();
              return B8 < 0x0 || B8 && !B9 || !B8 && B9 || (uI |= 0x8), uI;
            }();
          }
          var z3,
            z4 = u7["tickCallback"],
            z5 = u7["setDefaultCurrencyFormat"];
          !function (uI) {
            uI[uI["PAUSE_GAME"] = 0x0] = "PAUSE_GAME", uI[uI["RESUME_GAME"] = 0x1] = "RESUME_GAME";
          }(z3 || (z3 = {}));
          var z6 = z3["RESUME_GAME"],
            z7 = true,
            z8 = Object["create"](null),
            z9 = Object["create"](null),
            zu = Object["create"](null),
            zj = Object["create"](null),
            zE = Object["create"](null),
            zz = Object["create"](null),
            zX = Object["create"](null),
            zB = false,
            zP = false,
            zl = [],
            zN = "Resume",
            zp = 0x0,
            zd = 0x0,
            zW = Object["create"](null);
          function zb(uI) {
            {
              var uI,
                uI,
                uH = uI["payload"];
              if ("boolean" == typeof uH ? (uI = uH, uI = false) : (uI = uH["isBlocked"], uI = uH["shouldFreeze"]), uI) {
                {
                  if (zd++, uI && !cc["game"]["isPaused"]() && z4(true)(function () {
                    {
                      zd > 0x0 && cc["game"]["pause"]();
                    }
                  }), zd > 0x1) return;
                }
              } else {
                if (0x0 === zd) return;
                if (zd--, cc["game"]["isPaused"]() && cc["game"]["resume"](), zd > 0x0) return;
              }
              Object["keys"](zu)["forEach"](function (B9) {
                var B8 = zu[B9];
                B8 && B8(uI);
              });
            }
          }
          var zH = 0x0;
          function zS(uI) {
            {
              uO()["emit"]("Game.StateChanged", uI), zN = uI;
            }
          }
          function zc(uI, uI) {
            zE[uI] = uI;
          }
          var zs = P("GameEventHandler", {
            'subscribeTransactionInfoChangedEvent': function () {
              uO()['on']("Game.TransactionInfoChanged", function (uI) {
                {
                  Object["keys"](zE)["forEach"](function (uI) {
                    var uI = zE[uI];
                    uI && uI(uI["payload"]);
                  });
                }
              });
            },
            'subscribeTransactionInfoRequestEvent': function () {
              zc("saveInfo", function (uI) {
                {
                  Object["keys"](uI)["forEach"](function (uI) {
                    zW[uI] = uI[uI];
                  });
                }
              }), uO()['on']("Game.RequestCurrentTransactionInfo", function (uI) {
                uI["response"] = zW;
              });
            },
            'subscribeGameSessionRequestEvent': function (uI) {
              {
                var uI = uO();
                uI['on']("Game.RequestSession", function (uI) {
                  {
                    var uH = uI["systemModel"],
                      B9 = uH["gameId"],
                      B8 = uH["operatorToken"],
                      uQ = uH["operatorPlayerSession"],
                      B7 = uH["betType"],
                      B8 = uH["platform"],
                      B8 = uH["apiDomain"],
                      uQ = uH["operatorJurisdiction"],
                      l6 = uH["gameApiSubdomain"],
                      l6 = uI["playerModel"],
                      l8 = l6["token"],
                      uQ = l6["playerName"],
                      uQ = l6["playerId"],
                      lE = l6["currencySymbol"];
                    uI["response"] = {
                      'gameId': B9,
                      'token': l8,
                      'operatorToken': B8,
                      'sessionId': uQ,
                      'playerName': uQ,
                      'playerId': uQ,
                      'betType': B7,
                      'platform': B8,
                      'apiDomain': B8,
                      'gameApiSubdomain': l6,
                      'currencySymbol': lE,
                      'operatorJurisdictionConfig': uQ,
                      'serviceEngineUrl': uI["systemModel"]["getFullServiceEngineUrl"](),
                      'gameEngineUrl': uI["systemModel"]["getFullGameEngineUrl"]()
                    };
                  }
                }), function (uI, uH) {
                  {
                    uI['on']("Game.TransactionStateStarted", function (B9) {
                      return function (B8) {
                        B8["response"] = B9();
                      };
                    }(uH), undefined);
                  }
                }(uI, z1);
              }
            },
            'addGamePlayUIBlockEventCallback': function (uI, uI) {
              "function" == typeof uI ? (uI = uI, zu["default"] = uI) : zu[uI] = uI;
            },
            'subscribeOperatorCurrencyFormatUpdateEvent': function () {
              var uI = uO();
              uI['on']("Game.UpdateLocaleCurrencyFormat", function (uI) {
                var uI = uI["payload"];
                z5({
                  'groupSeparator': uI["group"],
                  'decimalSeparator': uI["separator"]
                }), uI["emit"]("Game.LocaleCurrencyFormatChanged", uI);
              });
            },
            'subscribeGameInfoUpdateSuccessEvent': function (uI, uI) {
              var uI = uO();
              uI['on']("Game.GameInfoUpdateSuccess", function (uH) {
                var B9 = uH["payload"];
                uI["updateGameInfo"](B9);
                var B8 = uI["playerModel"]["playerName"],
                  uQ = B9['dt']['ls']['si']["sid"];
                j1("version: " + uI["systemModel"]["version"] + "\nuser: " + B8 + "\nspinid: " + uQ), uI(function () {
                  {
                    uI["emit"]("Game.WalletChangedSuccess");
                  }
                });
              });
            },
            'subscribeGameBalanceUpdateEvent': function (uI, uI) {
              {
                var uI = uO();
                uI['on']("Game.UpdateTransactionInfo", function (uH) {
                  {
                    var B9 = uH["payload"],
                      B8 = (B9["balance"] || 0x0) + (B9["freeBalance"] || 0x0);
                    uI["isGameReplaying"] ? (zl["push"](B8), 0x1 === zl["length"] && uI["once"]("Game.ReplayQuit", function () {
                      {
                        for (var uQ = 0x0, B7 = zl["length"]; uQ < B7; uQ++) {
                          var B8 = zl[uQ];
                          uI["playerModel"]["balance"] = B8, uI(B8);
                        }
                        zl = [];
                      }
                    })) : (uI["playerModel"]["balance"] = B8, uI(B8));
                  }
                });
              }
            },
            'subscribeGameLoginEvent': function (uI, uI) {
              var uI = uO();
              uI['on']("Game.RequestLogin", function (uH) {
                var B9 = uH["payload"];
                uI["systemModel"]["betType"] = B9["betType"], uI["playerModel"]["walletKey"] = B9["walletKey"], uI && uI();
              }), uI['on']("Game.LoginStateChanged", function (uH) {
                if ("Complete" === uH["payload"]) {
                  var B9 = uI["playerModel"]["playerName"],
                    B8 = uI["transactionModel"]["transactionId"];
                  j1("version: " + uI["systemModel"]["version"] + "\nuser: " + B9 + "\nspinid: " + B8);
                }
              });
            },
            'subscribeTweaksOnShowEvent': function () {},
            'subscribeTweaksOnDismissEvent': function () {},
            'subscribeGameLayoutInfoRequestEvent': function (uI) {
              uO()['on']("Game.RequestLayoutInfo", function (uI) {
                uI["response"] = uI;
              });
            },
            'subscribeGamePlayUIBlockEvent': function () {
              var uI = uO();
              uI['on']("Game.BlockUI", zb), function (uI) {
                {
                  uI['on']("Game.TransactionStatePaused", z2, undefined);
                }
              }(uI);
            },
            'subscribeGameConfigRequestEvent': function (uI) {
              {
                var uI = uO(),
                  uI = uI["systemModel"],
                  uH = uI["version"],
                  B9 = uI["certifiedVersion"],
                  B8 = uI["gameTitle"],
                  uQ = uI["noAudio"],
                  B7 = uI["operatorJurisdiction"]["replayVersion"];
                uI['on']("Game.RequestConfig", function (B8) {
                  {
                    B8["response"] = {
                      'version': uH,
                      'certifiedVersion': B9,
                      'gameTitle': B8,
                      'noAudio': uQ,
                      'replaySupported': B7 > 0x0,
                      'replayVersion': B7
                    };
                  }
                });
              }
            },
            'subscribeGameConfigUpdateEvent': function () {
              {
                uO()['on']("Game.UpdateConfig", function (uI) {
                  {
                    var uI = uI["payload"];
                    uI && (uI["retryConfig"] && nj["setRetryHandlerConfig"](uI["retryConfig"]), uI["redirectUrl"] && jk["setCustomRedirectUrl"](uI["redirectUrl"]));
                  }
                });
              }
            },
            'subscribePlayerInfoRequestEvent': function (uI) {
              uO()['on']("Game.RequestPlayerInfo", function (uI) {
                var uI = uI["playerModel"],
                  uH = uI["playerId"],
                  B9 = uI["playerName"],
                  B8 = uI["playerNickname"],
                  uQ = uI["currencySymbol"],
                  B7 = uI["walletKey"];
                uI["response"] = {
                  'playerId': uH,
                  'playerName': B9,
                  'playerNickname': B8,
                  'currencySymbol': uQ,
                  'walletKey': B7
                };
              });
            },
            'subscribeGameReadyEvent': function () {
              var uI = uO();
              uI['on']("Shell.BootStateChanged", function (uI) {
                {
                  "GameReady" === uI["payload"] && uI["emit"]("Analytics.Event", {
                    'actionName': "LoadGameComplete"
                  });
                }
              });
            },
            'subscribeGameInfoUpdateEvent': function (uI) {
              var uI = uO();
              uI['on']("Game.UpdateGameInfo", function (uI) {
                var uH = uI["payload"],
                  B9 = uH["param"],
                  B8 = uH["callback"];
                EA["doAPIRequest"]({
                  'name': "update game info",
                  'apiRequest': uI["updateGameInfo"]["bind"](uI),
                  'apiRequestParam': B9,
                  'errorTitle': shell["I18n"]['t']("General.ErrorChangeFailed")
                }, function (uQ, B7) {
                  B8 && B8(uQ, B7), !uQ && B7 && uI["emit"]("Game.GameInfoUpdateSuccess", B7);
                });
              });
            },
            'subscribeAudioPlayRateUpdateEvent': function (uI) {
              uI && uO()['on']("Game.SetAudioPlayRate", function (uI) {
                {
                  uI(uI["payload"]);
                }
              });
            },
            'subscribeStoredGamesNameRequestEvent': function () {
              uO()['on']("Game.RequestGameNames", function (uI) {
                uI["response"] = Ef["getGameNamesFromStorage"]();
              });
            },
            'subscribeSessionSocketErrorEvent': function (uI) {
              uO()['on']("Game.OperatorSocketError", function (uI) {
                {
                  uI && uI(uI["payload"]);
                }
              });
            },
            'subscribeSessionSocketConnectedEvent': function (uI) {
              uO()['on']("Game.OperatorSocketConnected", function (uI) {
                {
                  uI && uI(uI["payload"]);
                }
              });
            },
            'subscribeSessionSocketConnectionStatusRequestEvent': function () {
              uO()['on']("Game.RequestOperatorSocketConnectionStatus", function (uI) {
                {
                  var uI = jz["WebSocket"];
                  uI["response"] = !!uI && uI["checkOperationSocketConnectionStatus"]();
                }
              });
            },
            'subscribeInUIIdleStateStatusUpdateEvent': function () {
              {
                uO()['on']("Game.InUIIdleState", function (uI) {
                  {
                    if (z7 = uI["payload"], Object["keys"](zX)["forEach"](function (uQ) {
                      var B7 = zX[uQ];
                      B7 && B7(z7);
                    }), z7) {
                      {
                        var uI = Object["keys"](zz);
                        if (0x0 === uI["length"]) return;
                        zH = 0x0;
                        var uI = function (uQ) {
                          {
                            var B7 = zz[uQ];
                            zH++;
                            var B8 = function () {
                              {
                                var B8 = Object["keys"](zz);
                                zH < B8["length"] && uI(B8[zH]);
                              }
                            };
                            B7 ? B7(true, function () {
                              {
                                z7 && B8();
                              }
                            }) : B8();
                          }
                        };
                        uI(uI[0x0]);
                      }
                    } else for (var uH = Object["keys"](zz), B9 = 0x0; B9 < zH; B9++) {
                      {
                        var B8 = zz[uH[B9]];
                        B8 && B8(false);
                      }
                    }
                  }
                });
              }
            },
            'emitGameStateChangedEvent': zS,
            'emitGameFlowStateChangedEvent': function (uI) {
              uO()["emit"]("Game.FlowStateChanged", uI);
            },
            'emitGameEffectStateChangedEvent': function (uI) {
              uO()["emit"]("Game.DisplayStateChanged", uI);
            },
            'emitGameWinAnnouncement': function () {},
            'emitLoginDoneEvent': function (uI) {
              {
                var uI = uO(),
                  uI = uI["systemModel"],
                  uH = uI["gameId"],
                  B9 = uI["operatorToken"],
                  B8 = uI["operatorPlayerSession"],
                  uQ = uI["betType"],
                  B7 = uI["platform"],
                  B8 = uI["apiDomain"],
                  B8 = uI["operatorJurisdiction"],
                  uQ = uI["playerModel"],
                  l6 = {
                    'gameId': uH,
                    'token': uQ["token"],
                    'operatorToken': B9,
                    'sessionId': B8,
                    'playerName': uQ["playerName"],
                    'playerId': uQ["playerId"],
                    'betType': uQ,
                    'platform': B7,
                    'apiDomain': B8,
                    'currencySymbol': uQ["currencySymbol"],
                    'operatorJurisdictionConfig': B8,
                    'serviceEngineUrl': uI["systemModel"]["getFullServiceEngineUrl"](),
                    'gameEngineUrl': uI["systemModel"]["getFullGameEngineUrl"]()
                  };
                uI["emit"]("Game.SessionChanged", l6);
              }
            },
            'emitGameLoginEvent': function (uI) {
              uO()["emit"]("Game.LoginStateChanged", uI);
            },
            'emitGameNotifyPauseEvent': function () {
              z6 === z3["PAUSE_GAME"] && zS("Pause");
            },
            'emitAutoplayStartedEvent': function (uI) {
              {
                if (!zP) {
                  {
                    var uI = uO();
                    zj = function () {
                      {
                        zP = false, uI && uI(), uI["emit"]("Game.AutoplayStateChanged", "Stop");
                      }
                    }, zP = true, uI["emit"]("Game.AutoplayStateChanged", "Start"), uI["once"]("Game.StopAutoplay", zj);
                  }
                }
              }
            },
            'emitAutoplayStoppedEvent': function () {
              {
                if (zP) {
                  zP = false;
                  var uI = uO();
                  uI["emit"]("Game.AutoplayStateChanged", "Stop"), uI["off"]("Game.StopAutoplay", zj);
                }
              }
            },
            'emitErrorLogEvent': function (uI, uI) {
              {
                uO()["emit"]("Error.Log", {
                  'tag': uI,
                  'message': uI
                });
              }
            },
            'emitGamePlayUIBlockEvent': function (uI) {
              uO()["emit"]("Game.BlockUI", uI);
            },
            'subscribeGamePauseEvent': function () {
              var uI = uO();
              uI['on']("Game.Pause", function (uI) {
                if (zp++, z6 !== z3["PAUSE_GAME"]) {
                  z6 = z3["PAUSE_GAME"];
                  var uI = uI["payload"];
                  !!uI && uI["isBlocked"] && !zB && (uI["emit"]("Shell.EnableUIBlock", true), zB = true), Object["keys"](z8)["forEach"](function (uH) {
                    {
                      var B9 = z8[uH];
                      B9 && B9();
                    }
                  });
                }
              });
            },
            'subscribeGameResumeEvent': function () {
              {
                var uI = uO();
                uI['on']("Game.Resume", function () {
                  z6 !== z3["RESUME_GAME"] && (--zp > 0x0 || (z6 = z3["RESUME_GAME"], zB && (uI["emit"]("Shell.EnableUIBlock", false), zB = false), Object["keys"](z9)["forEach"](function (uI) {
                    var uI = z9[uI];
                    uI && uI();
                  }), "Pause" === zN && zS("Resume")));
                });
              }
            },
            'addGamePauseEventCallback': function (uI, uI) {
              {
                z8[uI] = uI, z6 === z3["PAUSE_GAME"] && uI && uI();
              }
            },
            'addGameResumeEventCallback': function (uI, uI) {
              {
                z9[uI] = uI, z6 === z3["RESUME_GAME"] && uI && uI();
              }
            },
            'removeGamePauseEventCallback': function (uI) {
              -0x1 !== Object["keys"](z8)["indexOf"](uI) && (z8[uI] = undefined);
            },
            'removeGameResumeEventCallback': function (uI) {
              -0x1 !== Object["keys"](z9)["indexOf"](uI) && (z9[uI] = undefined);
            },
            'addTransactionInfoChangedEventCallback': zc,
            'removeTransactionInfoChangedEventCallback': function (uI) {
              -0x1 !== Object["keys"](zE)["indexOf"](uI) && (zE[uI] = undefined);
            },
            'addInUIIdleStateCallback': function (uI, uI, uI) {
              {
                uI ? zX[uI] = uI : zz[uI] = uI;
              }
            },
            'removeInUIIdleStateCallback': function (uI) {
              {
                -0x1 !== Object["keys"](zz)["indexOf"](uI) && (zz[uI] = undefined), -0x1 !== Object["keys"](zX)["indexOf"](uI) && (zX[uI] = undefined);
              }
            },
            'isGameStatePaused': function () {
              return z6 === z3["PAUSE_GAME"];
            }
          });
          function zR(uI) {
            {
              (function (uI) {
                return u3(this, undefined, undefined, function () {
                  {
                    var uI, uH;
                    return u4(this, function (B9) {
                      {
                        switch (B9["label"]) {
                          case 0x0:
                            return (uI = [uJ])[0x1] = uS, uI[0x2] = uI, [0x4, up(uI)()];
                          case 0x1:
                            return B9["sent"]() ? (uH = function (B8) {
                              {
                                return function (uQ) {
                                  {
                                    return u3(this, undefined, undefined, function () {
                                      var B7, B8, B8;
                                      return u4(this, function (uQ) {
                                        switch (uQ["label"]) {
                                          case 0x0:
                                            if ("string" == typeof uQ) {
                                              {
                                                if (null == (B7 = B["document"][uW("rgetElementById")](uQ))) return [0x2, false];
                                                uQ = B7;
                                              }
                                            }
                                            return !(B8 = uQ[ub("endataset")]["rev"]) || B8["length"] <= B["Number"]("0x4") ? [0x2, false] : (B8 = (B8 = uQ[uW("etextContent")] || '')["trim"](), [0x4, B8(B8, B8)]);
                                          case 0x1:
                                            return [0x2, uQ["sent"]()];
                                        }
                                      });
                                    });
                                  }
                                };
                              }
                            }(uk(uI)), [0x4, uH(uW("imain-script"))]) : [0x3, 0x3];
                          case 0x2:
                            return [0x2, B9["sent"]()];
                          case 0x3:
                            return [0x2, true];
                        }
                      }
                    });
                  }
                });
              })(ub("stQ22cRMoV3wAHqv52"))["then"](function (uI) {
                {
                  uI["response"] = uI, uI["propagate"]();
                }
              }, function () {
                uI["response"] = false, uI["propagate"]();
              }), uI["intercept"]();
            }
          }
          var zQ = function (uI, uI, uI) {
              var uH = function () {
                uI["login"](function (B9) {
                  {
                    var B8;
                    B9 ? jw["handleCommonError"]("Login Error", B9, "Launch", uH) : (B8 = uI, zs["emitLoginDoneEvent"](B8), (uO()['on']("Game.TransactionStateEnded", zR, undefined), function (uQ) {
                      {
                        uQ && uQ();
                      }
                    })(uI));
                  }
                });
              };
              uH();
            },
            zy = u7["sequenceCallback"];
          function zv(uI) {
            {
              var uI = document["getElementById"]("game-overlay"),
                uI = uI ? 0.5 * parseFloat(uI["style"]["height"]) : 0x0,
                uH = {
                  'label': shell["I18n"]['t']("General.ResourceLoadingMessage"),
                  'y': uI,
                  'opacity': 0x1,
                  'enableBackground': true,
                  'isFullBackground': true,
                  'inValue': 0x0,
                  'inDuration': 0.3,
                  'outValue': 0x0,
                  'outDuration': 0.3
                };
              uO()["emit"]("Loading.Show", uH), uI && uI();
            }
          }
          function zJ() {
            {
              zs["emitGameLoginEvent"]("Complete"), uO()["emit"]("Loading.Hide");
            }
          }
          var zF,
            zM,
            zI = function (uI) {
              {
                var uI, uI, uH;
                zy(zv, function (B9) {
                  {
                    return function (B8) {
                      var uQ, B7;
                      uQ = B9["systemModel"]["operatorJurisdiction"]["gamePluginList"], B7 = uC(), uQ["forEach"](function (B8) {
                        var B8 = B7["queryBundle"](B8["name"]);
                        B8 && B7["destroyBundle"](B8);
                      }), B8 && B8();
                    };
                  }
                }(uI["dataSource"]), (uI = uI["apiClient"], uH = uI["dataSource"], function (B9) {
                  zQ(uI, uH, B9);
                }), function (B9) {
                  return function (B8) {
                    jV(B9["systemModel"]["operatorJurisdiction"]["gamePluginList"], B8);
                  };
                }(uI["dataSource"]), function (B9) {
                  {
                    return function (B8) {
                      EA["doAPIRequest"]({
                        'name': "get game info",
                        'apiRequest': B9["getGameInfo"]["bind"](B9),
                        'apiRequestParam': {},
                        'errorTitle': shell["I18n"]['t']("General.ErrorChangeFailed"),
                        'finalCallback': B8
                      });
                    };
                  }
                }(uI["apiClient"]), (uI = uI["refreshWorldCallback"], function (B9) {
                  uI(B9);
                }))(zJ);
              }
            };
          !function (uI) {
            uI["bv_zn"] = "_config", uI["bv_Yn"] = "_map";
          }(zF || (zF = {}));
          var zx,
            zT = [];
          function zk() {
            if (!zM) throw Error("ResourceQualifierHelper :: instance is not init!");
          }
          function zO(uI) {
            var uI = cc["assetManager"]["getBundle"](uI);
            if (!uI) throw Error("ResourceQualifierHelper :: bundle "["concat"](uI, " doesn't exist!"));
            return uI;
          }
          function zC(uI, uI) {
            if (!uI || !uI["language"]) {
              var uI = shell["I18n"]["locale"](),
                uH = uI["indexOf"]('-');
              if (-0x1 !== uH) {
                uI = uI || Object["create"](null);
                var B9 = uI["substring"](uH + 0x1);
                uI["language"] = function (B8) {
                  return B8 === B9 ? 0x1 : 0x0;
                };
              }
            }
            !function (B8) {
              {
                delete B8["browser"], delete B8['os'];
              }
            }(uI), zM = new shell["ResourceQualifier"](uI, uI), zL(cc["resources"]["name"]);
          }
          function zL(uI) {
            if (zk(), -0x1 === zT["indexOf"](uI)) {
              var uI = zO(uI),
                uI = zM["assetTable"],
                uH = '@'["concat"](uI["name"], '/'),
                B9 = Object["keys"](uI[zF["bv_zn"]]["paths"][zF["bv_Yn"]])["map"](function (B8) {
                  return ''["concat"](uH)["concat"](B8);
                });
              zT["push"](uI), uI && Array["isArray"](uI) ? uI["push"]["apply"](uI, B9) : zM["setAssetTable"](B9, true);
            }
          }
          P("ResourceQualifierHelper", Object["freeze"]({
            '__proto__': null,
            'addBuiltinBundles': function () {
              var uI = cc["AssetManager"]["BuiltinBundleName"];
              for (var uI in uI) {
                {
                  var uI = uI[uI];
                  cc["assetManager"]["getBundle"](uI) && zL(uI);
                }
              }
            },
            'addBundle': zL,
            'getResourceURL': function (uI, uI) {
              if (zk(), "string" != typeof uI) throw Error("ResourceQualifierHelper :: getResourceURL : url "["concat"](uI, " is not string type!"));
              var uI,
                uH = !uI["startsWith"]('@'),
                B9 = uI;
              uH && (uI = '@'["concat"](cc["resources"]["name"], '/'), B9 = ''["concat"](uI)["concat"](uI));
              var B8 = zM["getResourceURL"](B9, uI);
              return B8 && uH && (B8 = B8["substring"](uI["length"])), B8;
            },
            'init': zC,
            'removeBundle': function (uI) {
              if (zk(), -0x1 !== zT["indexOf"](uI)) {
                {
                  var uI = zO(uI),
                    uI = '@'["concat"](uI["name"], '/'),
                    uH = zM["assetTable"];
                  zT["splice"](zT["indexOf"](uI), 0x1), zM["setAssetTable"](uH["filter"](function (B9) {
                    {
                      return !B9["startsWith"](uI);
                    }
                  }), true);
                }
              }
            }
          })), function (uI) {
            uI["Slot"] = "slot", uI["Card"] = "card", uI["Others"] = "others", uI["RealTime"] = 'rt';
          }(zx || (zx = {}));
          var zm = ["GameReplay", "SlotServices", "TSMServices", "TransactionStateMachine", "WebSocket"],
            zU = ["TSMServices", "TransactionStateMachine", "WebSocket"],
            zZ = ["WebSocket"],
            zD = new (function () {
              {
                function uI() {}
                return Object["defineProperty"](uI["prototype"], "context", {
                  'get': function () {
                    {
                      return this["bv_Xn"];
                    }
                  },
                  'set': function (uI) {
                    {
                      this["bv_Xn"] = uI;
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI;
              }
            }())(),
            zh = {
              'position': "relative",
              'fontSize': "12px",
              'color': "white",
              'right': "-15px",
              'animation': "fade 0.5s linear 0s 1 normal forwards",
              'textAlign': "center",
              'width': "25px"
            },
            zY = {
              'position': "relative",
              'fontSize': "12px",
              'color': "white",
              'right': "-38px",
              'bottom': "18px",
              'animation': "fadeAway 0.25s linear 0s 1 normal forwards"
            },
            zw = function (uI) {
              {
                function uI(uI) {
                  var uH = uI["call"](this, uI) || this;
                  uH["bv_Kn"] = false, uH["bv_Zn"] = false, uH["bv_Jn"] = false, uH["bv_$n"] = 0x0, uH["bv_te"] = 0x0, uH["bv_ne"] = function (B8) {
                    var uQ = document[uH["bv_ee"]];
                    (uQ = uQ || B8["hidden"]) ? uH["bv_ie"]() : uH["bv_re"]();
                  }, uH["bv_ae"] = function () {
                    {
                      uH["bv_oe"]["current"] && (uH["bv_oe"]["current"]["style"]["animation"] = "scaling 0.5s linear 0s infinite alternate", uH["bv_oe"]["current"]["removeEventListener"]("animationend", uH["bv_ae"]));
                    }
                  }, uH["bv_ue"] = uI["recordTimeLimit"], uH["bv_ce"] = uI["recordTimeLimit"], uH["state"] = {
                    'timer': uH["bv_ue"]
                  }, uH["bv_se"] = uH["bv_re"]["bind"](uH), uH["bv_le"] = uH["bv_ie"]["bind"](uH);
                  var B9 = zD["context"]["event"];
                  return B9['on']("Game.PauseReplay", uH["bv_ie"], uH), B9['on']("Game.ResumeReplay", uH["bv_re"], uH), uH["bv_oe"] = y["createRef"](), uH;
                }
                return u0(uI, uI), uI["prototype"]["shouldComponentUpdate"] = function (uI, uH) {
                  {
                    return !(this["state"]["timer"] > 0x0 && this["state"]["timer"] === uH["timer"]);
                  }
                }, uI["prototype"]["componentDidUpdate"] = function () {
                  {
                    if (0x3 === this["props"]["recordState"] && (0xa === this["state"]["timer"] ? this["props"]["updateRecordBtnStyleCallback"] && this["props"]["updateRecordBtnStyleCallback"]() : 0x5 === this["state"]["timer"] && this["bv_oe"]["current"] && (this["bv_oe"]["current"]["style"]["animation"] = "scaling 0.5s linear 0s infinite alternate")), this["state"]["timer"] <= 0x0) return this["bv_fe"](), clearInterval(this["bv_he"]), void this["props"]["updateRecordBtnCallback"]();
                    0x4 === this["props"]["recordState"] && (this["bv_fe"](), clearInterval(this["bv_he"]), this["bv_oe"]["current"] && this["bv_oe"]["current"]["removeEventListener"]("animationend", this["bv_ae"]));
                  }
                }, uI["prototype"]["componentDidMount"] = function () {
                  this["bv_de"](), this["bv_ve"](), this["state"]["timer"] <= 0xa && (this["props"]["updateRecordBtnStyleCallback"] && this["props"]["updateRecordBtnStyleCallback"](), this["state"]["timer"] <= 0x5 && this["bv_oe"]["current"] && this["bv_oe"]["current"]["addEventListener"]("animationend", this["bv_ae"]));
                }, uI["prototype"]["componentWillUnmount"] = function () {
                  this["bv_fe"](), clearInterval(this["bv_he"]);
                  var uI = zD["context"]["event"];
                  uI["off"]("Game.PauseReplay", this["bv_ie"], this), uI["off"]("Game.ResumeReplay", this["bv_re"], this);
                }, uI["prototype"]["render"] = function () {
                  if (this["state"]["timer"] > 0xa) return null;
                  var uI = function (uH) {
                    switch (uH) {
                      case 0x3:
                        return zh;
                      case 0x4:
                        return zY;
                      default:
                        return;
                    }
                  }(this["props"]["recordState"]);
                  return y["createElement"]("span", {
                    'className': "replay-record-time",
                    'style': uI,
                    'ref': this["bv_oe"]
                  }, this["state"]["timer"]);
                }, uI["prototype"]["bv_ve"] = function () {
                  this["bv_$n"] = Date["now"](), this["bv_me"]();
                }, uI["prototype"]["bv_me"] = function () {
                  {
                    this["bv_be"](), this["bv_he"] = B["setInterval"](this["bv_be"]["bind"](this), 0x3e8);
                  }
                }, uI["prototype"]["bv_be"] = function () {
                  var uI = Date["now"]() - this["bv_$n"],
                    uH = Math["floor"](uI / 0x3e8);
                  this["bv_ue"] = this["bv_ce"] - uH, this["bv_ue"] <= 0xa && this["setState"]({
                    'timer': this["bv_ue"]
                  });
                }, uI["prototype"]["bv_re"] = function (uI) {
                  this["bv_Jn"] = undefined !== uI, this["bv_Zn"] && !this["bv_Jn"] || (this["bv_Kn"] && (this["bv_Kn"] = false, this["bv_$n"] = Date["now"]() - this["bv_te"], this["bv_me"]()), this["bv_Zn"] = false);
                }, uI["prototype"]["bv_ie"] = function (uI) {
                  {
                    this["bv_Zn"] || (this["bv_Kn"] || (this["bv_Kn"] = true, this["bv_te"] = Date["now"]() - this["bv_$n"], clearInterval(this["bv_he"])), this["bv_Zn"] = undefined !== uI);
                  }
                }, uI["prototype"]["bv_de"] = function () {
                  if (undefined !== document["hidden"] ? this["bv_ee"] = "hidden" : undefined !== document["mozHidden"] ? this["bv_ee"] = "mozHidden" : undefined !== document["msHidden"] ? this["bv_ee"] = "msHidden" : undefined !== document["webkitHidden"] && (this["bv_ee"] = "webkitHidden"), this["bv_ee"]) {
                    this["bv_pe"] = ["visibilitychange", "mozvisibilitychange", "msvisibilitychange", "webkitvisibilitychange", "qbrowserVisibilityChange"];
                    for (var uI = 0x0, uH = this["bv_pe"]["length"]; uI < uH; uI++) document["addEventListener"](this["bv_pe"][uI], this["bv_ne"]);
                  } else B["addEventListener"]("blur", this["bv_le"]), B["addEventListener"]("focus", this["bv_se"]);
                }, uI["prototype"]["bv_fe"] = function () {
                  {
                    if (this["bv_ee"]) for (var uI = 0x0, uH = this["bv_pe"]["length"]; uI < uH; uI++) document["removeEventListener"](this["bv_pe"][uI], this["bv_ne"]);else B["removeEventListener"]("blur", this["bv_le"]), B["removeEventListener"]("focus", this["bv_se"]);
                  }
                }, uI;
              }
            }(y["Component"]),
            zV = {
              'backgroundColor': "rgb(48, 48, 60, 0)"
            },
            zq = {
              'animation': "condense 0.3s ease-in-out 0s 1 normal forwards",
              'backgroundColor': "rgb(48, 48, 60, 0)"
            },
            zK = {
              'backgroundColor': "rgb(48, 48, 60, 1)"
            },
            zA = {
              'animation': "condense 0.3s ease-in-out 0s 1 normal forwards",
              'backgroundColor': "rgb(48, 48, 60, 1)"
            },
            zG = {
              'pointerEvents': "none",
              'opacity': "0.5"
            },
            zf = {
              'animation': "condense 0.3s ease-in-out 0s 1 normal forwards",
              'pointerEvents': "none",
              'opacity': "0.5"
            },
            zg = {
              'animation': "condense 0.3s ease-in-out 0s 1 normal forwards",
              'pointerEvents': "none"
            },
            X0 = {
              'pointerEvents': "none"
            },
            X1 = {
              'position': "relative",
              'display': "flex",
              'width': "36px",
              'height': "inherit",
              'justifyContent': "center",
              'alignItems': "center"
            },
            X2 = {
              'position': "relative",
              'width': "36px",
              'height': "inherit",
              'justifyContent': "center",
              'alignItems': "center"
            },
            X3 = {
              'width': "36px",
              'height': "inherit"
            },
            X4 = {
              'position': "absolute",
              'width': "28px",
              'height': "28px",
              'borderRadius': "50%",
              'backgroundColor': "white",
              'transform': "translate(4px, 4px)"
            },
            X5 = {
              'position': "absolute",
              'width': "24px",
              'height': "24px",
              'borderRadius': "50%",
              'backgroundColor': "rgb(48, 48, 60)",
              'transform': "translate(6px, 6px)"
            },
            X6 = {
              'position': "absolute",
              'width': "20px",
              'height': "20px",
              'borderRadius': "50%",
              'backgroundColor': "rgb(255, 8, 69)",
              'transform': "translate(8px, 8px)"
            },
            X7 = {
              'position': "absolute",
              'width': "12px",
              'height': "12px",
              'borderRadius': "2px",
              'backgroundColor': "rgb(255, 8, 69)",
              'animation': "fading 0.5s linear 0s infinite alternate",
              'transform': "translate(12px, 12px)"
            };
          function X8(uI) {
            {
              switch (uI) {
                case 0x1:
                  return 0x2;
                case 0x3:
                  return 0x4;
                case 0x2:
                case 0x4:
                  return uI;
                default:
                  return 0x1;
              }
            }
          }
          var X9 = function (uI) {
              {
                function uI(uI) {
                  {
                    var uH = uI["call"](this, uI) || this;
                    uH["bv_ce"] = 0x0, uH["state"] = {
                      'recordState': 0x1,
                      'isPause': false
                    };
                    var B9 = zD["context"]["event"];
                    return B9['on']("Game.RecordingStopped", uH["bv_ge"], uH), B9['on']("Game.PauseReplay", uH["bv_ie"], uH), B9['on']("Game.ResumeReplay", uH["bv_re"], uH), uH["bv_Se"] = y["createRef"](), uH["bv_ye"] = y["createRef"](), uH;
                  }
                }
                return u0(uI, uI), uI["prototype"]["componentWillUnmount"] = function () {
                  var uI = zD["context"]["event"];
                  uI["off"]("Game.RecordingStopped", this["bv_ge"], this), uI["off"]("Game.PauseReplay", this["bv_ie"], this), uI["off"]("Game.ResumeReplay", this["bv_re"], this);
                }, uI["prototype"]["render"] = function () {
                  {
                    var uI = this,
                      uH = this["state"]["isPause"],
                      B9 = this["state"]["recordState"],
                      B8 = function (uQ) {
                        switch (uQ) {
                          case 0x1:
                          case 0x2:
                            return 0x3;
                          default:
                            return 0x1;
                        }
                      }(B9);
                    return y["createElement"]("div", {
                      'id': "replay-record-btn-bg",
                      'style': this["bv_Ge"](B9, uH),
                      'ref': this["bv_Se"]
                    }, y["createElement"]("div", {
                      'id': "replay-record-btn",
                      'onClick': function () {
                        {
                          uI["setState"]({
                            'recordState': X8(B9)
                          }), uI["props"]["onClickCallback"](B8, function (uQ) {
                            {
                              uI["bv_ce"] = uQ || -0x1, uI["setState"]({
                                'recordState': B8
                              });
                            }
                          }, true);
                        }
                      },
                      'style': this["bv_we"](B9, uH),
                      'ref': this["bv_ye"]
                    }, this["bv_Ce"](B9)));
                  }
                }, uI["prototype"]["bv_Ge"] = function (uI, uH) {
                  switch (uI) {
                    case 0x1:
                    case 0x3:
                    case 0x2:
                      return uH ? zK : zV;
                    case 0x4:
                      return this["bv_Se"]["current"] && this["bv_Se"]["current"]["style"]["animation"] ? uH ? zA : zq : uH ? zK : zV;
                    default:
                      return;
                  }
                }, uI["prototype"]["bv_we"] = function (uI, uH) {
                  {
                    switch (uI) {
                      case 0x1:
                      case 0x3:
                        return uH ? zG : undefined;
                      case 0x2:
                        return uH ? zG : X0;
                      case 0x4:
                        return this["bv_ye"]["current"] && this["bv_ye"]["current"]["style"]["animation"] ? uH ? zf : zg : uH ? zG : X0;
                      default:
                        return;
                    }
                  }
                }, uI["prototype"]["bv_Ce"] = function (uI) {
                  var uH = this;
                  switch (uI) {
                    case 0x1:
                      return y["createElement"]("span", {
                        'className': "replay-record-icon-wrapper",
                        'style': X3
                      }, y["createElement"]("span", {
                        'className': "replay-record-base-icon",
                        'style': X4
                      }), y["createElement"]("span", {
                        'className': "replay-record-base-circle-icon",
                        'style': X5
                      }), y["createElement"]("span", {
                        'className': "replay-record-circle-icon",
                        'style': X6
                      }));
                    case 0x2:
                      return y["createElement"]("div", {
                        'className': "loader"
                      });
                    case 0x3:
                      return y["createElement"]("span", {
                        'className': "replay-record-container",
                        'style': X1
                      }, y["createElement"]("span", {
                        'className': "replay-record-icon-wrapper",
                        'style': X3
                      }, y["createElement"]("span", {
                        'className': "replay-record-base-icon",
                        'style': X4
                      }), y["createElement"]("span", {
                        'className': "replay-record-base-circle-icon",
                        'style': X5
                      }), y["createElement"]("span", {
                        'className': "replay-record-square-icon",
                        'style': X7
                      })), -0x1 !== this["bv_ce"] && y["createElement"](zw, {
                        'recordState': 0x3,
                        'recordTimeLimit': this["bv_ce"],
                        'updateRecordBtnCallback': function () {
                          uH["setState"]({
                            'recordState': 0x4
                          });
                        },
                        'updateRecordBtnStyleCallback': function () {
                          {
                            uH["bv_Se"]["current"] && (uH["bv_Se"]["current"]["style"]["animation"] = "expand 0.3s ease-in-out 0s 1 normal forwards"), uH["bv_ye"]["current"] && (uH["bv_ye"]["current"]["style"]["animation"] = "expand 0.3s ease-in-out 0s 1 normal forwards", uH["bv_ye"]["current"]["style"]["pointerEvents"] = "auto");
                          }
                        }
                      }));
                    case 0x4:
                      return y["createElement"]("span", {
                        'className': "replay-record-container",
                        'style': X2
                      }, y["createElement"]("div", {
                        'className': "loader"
                      }), -0x1 !== this["bv_ce"] && y["createElement"](zw, {
                        'recordState': 0x4,
                        'recordTimeLimit': this["bv_ce"],
                        'updateRecordBtnCallback': function () {
                          {
                            uH["props"]["onClickCallback"](0x1, function () {
                              uH["setState"]({
                                'recordState': 0x1
                              });
                            }, true);
                          }
                        }
                      }));
                    default:
                      return null;
                  }
                }, uI["prototype"]["bv_ge"] = function () {
                  {
                    var uI = this;
                    this["bv_Se"]["current"] && this["bv_Se"]["current"]["style"]["removeProperty"]("animation"), this["bv_ye"]["current"] && this["bv_ye"]["current"]["style"]["removeProperty"]("animation"), this["props"]["onClickCallback"](0x1, function () {
                      uI["setState"]({
                        'recordState': 0x1
                      });
                    }, false);
                  }
                }, uI["prototype"]["bv_ie"] = function () {
                  {
                    this["setState"]({
                      'isPause': true
                    });
                  }
                }, uI["prototype"]["bv_re"] = function () {
                  this["setState"]({
                    'isPause': false
                  });
                }, uI;
              }
            }(y["Component"]),
            Xu = {
              'pointerEvents': "none"
            },
            Xj = {
              'position': "absolute",
              'width': "16px",
              'height': "16px",
              'borderRadius': "1px",
              'backgroundColor': "rgb(255, 255, 255)",
              'transform': "translate(10.5px, 10.5px)"
            },
            XE = {
              'position': "absolute",
              'width': "12px",
              'height': "12px",
              'backgroundColor': "rgb(48, 48, 60)",
              'transform': "translate(12.5px, 12.5px)"
            },
            Xz = {
              'position': "absolute",
              'width': "6px",
              'height': "18px",
              'backgroundColor': "rgb(48, 48, 60)",
              'transform': "translate(15.5px, 9.5px)"
            },
            XX = {
              'position': "absolute",
              'width': "18px",
              'height': "6px",
              'backgroundColor': "rgb(48, 48, 60)",
              'transform': "translate(9.5px, 15.5px)"
            };
          function XB() {
            var uI = document["getElementById"]("replay-capture-effect");
            if (uI) {
              {
                var uI = document["getElementById"]("game-replay");
                uI["removeEventListener"]("animationend", XB), uI && uI["removeChild"](uI);
              }
            }
          }
          function XP(uI) {
            var uI = v(true),
              uI = uI[0x0],
              uH = uI[0x1];
            return J(function () {
              return function () {
                XB();
              };
            }, []), y["createElement"]("div", {
              'id': "replay-capture-btn",
              'onClick': function () {
                uH(false), function () {
                  {
                    var B9 = document["getElementById"]("game-replay");
                    if (B9) {
                      var B8 = document["createElement"]("div"),
                        uQ = document["createAttribute"]('id');
                      uQ["value"] = "replay-capture-effect", B8["setAttributeNode"](uQ), B9["appendChild"](B8), B8["style"]["width"] = B9["style"]["width"], B8["style"]["height"] = B9["style"]["height"], B8["style"]["background"] = "white", B8["style"]["borderRadius"] = "5px", B8["style"]["animation"] = "captureEffect 0.2s ease-in-out 0s 2 alternate forwards", B8["addEventListener"]("animationend", XB);
                    }
                  }
                }(), uI["onClickCallback"](function () {
                  {
                    uH(true);
                  }
                });
              },
              'style': uI ? undefined : Xu
            }, function (B9) {
              return B9 ? y["createElement"]("span", {
                'className': "replay-capture-container"
              }, y["createElement"]("span", {
                'className': "replay-capture-base-icon",
                'style': Xj
              }), y["createElement"]("span", {
                'className': "replay-capture-square-icon",
                'style': XE
              }), y["createElement"]("span", {
                'className': "replay-capture-vertical-rec-icon",
                'style': Xz
              }), y["createElement"]("span", {
                'className': "replay-capture-horizontal-rec-icon",
                'style': XX
              })) : y["createElement"]("div", {
                'className': "loader"
              });
            }(uI));
          }
          var Xl = {
              'display': "flex",
              'height': "36px",
              'position': "absolute",
              'width': "inherit",
              'justifyContent': "space-between"
            },
            XN = function (uI) {
              function uI(uI) {
                var uH = uI["call"](this, uI) || this;
                return uH["state"] = {
                  'isShow': false
                }, zD["context"]["event"]['on']("Game.ShowRecordingUI", uH["bv_Te"], uH), uH;
              }
              return u0(uI, uI), uI["prototype"]["shouldComponentUpdate"] = function (uI, uH) {
                return this["state"]["isShow"] !== uH["isShow"];
              }, uI["prototype"]["componentWillUnmount"] = function () {
                {
                  zD["context"]["event"]["off"]("Game.ShowRecordingUI", this["bv_Te"], this);
                }
              }, uI["prototype"]["render"] = function () {
                return this["state"]["isShow"] ? y["createElement"]("div", {
                  'id': "replay-recording-container-wrapper",
                  'style': Xl
                }, y["createElement"](X9, {
                  'onClickCallback': this["props"]["onReplayRecordClickCallback"]
                }), y["createElement"](XP, {
                  'onClickCallback': this["props"]["onReplayCaptureClickCallback"]
                })) : null;
              }, uI["prototype"]["bv_Te"] = function (uI) {
                {
                  this["setState"]({
                    'isShow': uI["payload"]
                  });
                }
              }, uI;
            }(y["Component"]),
            Xp = {
              'color': "white",
              'cursor': "pointer"
            },
            Xd = ['½', '1', '2', '4'],
            XW = [0.5, 0x1, 0x2, 0x4];
          function Xb(uI) {
            {
              var uI = v(0x1),
                uI = uI[0x0],
                uH = uI[0x1];
              return y["createElement"]("div", {
                'id': "replay-fast-forward-btn",
                'onClick': function () {
                  var B9 = (uI + 0x1) % Xd["length"];
                  uI["onClickCallback"](XW[B9]), uH(B9);
                }
              }, y["createElement"]("span", {
                'className': "replay-fast-forword-container"
              }, y["createElement"]("label", {
                'style': Xp
              }, ''["concat"](Xd[uI], 'x'))));
            }
          }
          var XH = {
              'width': "4px",
              'height': "16px",
              'borderRadius': "1.5px",
              'backgroundColor': "rgb(255, 255, 255)",
              'margin': "3px"
            },
            XS = {
              'borderStyle': "solid",
              'borderWidth': "7px 0 7px 14px",
              'borderColor': "transparent transparent transparent rgb(255, 255, 255)"
            };
          function Xc(uI) {
            var uI = v(false),
              uI = uI[0x0],
              uH = uI[0x1],
              B9 = uI ? "replay-play-btn" : "replay-pause-btn";
            return y["createElement"]("div", {
              'id': B9,
              'onClick': function () {
                uI["onClickCallback"](!uI), uH(!uI);
              }
            }, function (B8) {
              {
                return B8 ? y["createElement"]("span", {
                  'className': "replay-play-container"
                }, y["createElement"]("span", {
                  'className': "replay-play-icon",
                  'style': XS
                })) : y["createElement"]("span", {
                  'className': "replay-pause-container"
                }, y["createElement"]("span", {
                  'className': "replay-pause-icon",
                  'style': XH
                }), y["createElement"]("span", {
                  'className': "replay-pause-icon",
                  'style': XH
                }));
              }
            }(uI));
          }
          var Xs = {
            'width': "12px",
            'height': "12px",
            'borderRadius': "2px",
            'backgroundColor': "rgb(255, 255, 255)"
          };
          function XR(uI) {
            return y["createElement"]("div", {
              'id': "replay-stop-btn",
              'onClick': uI["onClickCallback"]
            }, y["createElement"]("span", {
              'className': "replay-stop-container"
            }, y["createElement"]("span", {
              'className': "replay-stop-icon",
              'style': Xs
            })));
          }
          var XQ = {
              'display': "flex",
              'position': "relative",
              'height': "36px",
              'width': "inherit",
              'justifyContent': "center",
              'margin': "0px 36px"
            },
            Xy = function (uI) {
              function uI(uI) {
                {
                  var uH = uI["call"](this, uI) || this;
                  return uH["state"] = {
                    'isShow': false
                  }, zD["context"]["event"]["emit"]("Game.RequestConfig", undefined, function (B9) {
                    var B8 = B9["response"]["replayVersion"];
                    uH["setState"]({
                      'isShow': 0x2 === B8
                    });
                  }), uH;
                }
              }
              return u0(uI, uI), uI["prototype"]["shouldComponentUpdate"] = function (uI, uH) {
                {
                  return this["state"]["isShow"] !== uH["isShow"];
                }
              }, uI["prototype"]["render"] = function () {
                return this["state"]["isShow"] ? y["createElement"]("div", {
                  'id': "replay-container-wrapper",
                  'style': XQ
                }, y["createElement"]("div", {
                  'id': "replay-container"
                }, y["createElement"](Xb, {
                  'onClickCallback': this["props"]["onFastForwardClickCallback"]
                }), y["createElement"](Xc, {
                  'onClickCallback': this["props"]["onPauseClickCallback"]
                }), y["createElement"](XR, {
                  'onClickCallback': this["props"]["onStopClickCallback"]
                }))) : null;
              }, uI;
            }(y["Component"]),
            Xv = {
              'display': "flex",
              'width': "inherit",
              'height': "inherit",
              'flexDirection': "column",
              'justifyContent': "space-between"
            },
            XJ = {
              'position': "relative",
              'height': "calc(100% - 15%)",
              'width': "100%"
            },
            XF = {
              'display': "flex",
              'width': "100%",
              'height': '7%',
              'justifyContent': "space-between"
            },
            XM = {
              'position': "relative",
              'height': "100%",
              'width': '4%'
            },
            XI = {
              'display': "flex",
              'width': "65%",
              'justifyContent': "space-between"
            },
            Xx = {
              'position': "relative",
              'height': "100%",
              'width': "18%"
            },
            XT = {
              'position': "relative",
              'height': "calc(100% - 92%)",
              'width': "100%",
              'bottom': 0x0
            },
            Xk = {
              'position': "relative",
              'height': "100%",
              'width': "100%"
            },
            XO = function (uI) {
              {
                function uI(uI) {
                  return uI["call"](this, uI) || this;
                }
                return u0(uI, uI), uI["prototype"]["render"] = function () {
                  {
                    return this["props"]["isShow"] ? y["createElement"]("div", {
                      'id': "replay-bg-wrapper",
                      'style': Xv
                    }, y["createElement"]("span", {
                      'id': "replay-top-bg",
                      'style': XJ,
                      'onClick': this["props"]["onClickCallback"]
                    }), y["createElement"]("span", {
                      'id': "replay-center-bg-container-wrapper",
                      'style': XF
                    }, y["createElement"]("span", {
                      'id': "replay-left-bg",
                      'style': XM,
                      'onClick': this["props"]["onClickCallback"]
                    }), y["createElement"]("span", {
                      'id': "replay-center-bg-wrapper",
                      'style': XI
                    }, y["createElement"]("span", {
                      'id': "replay-left-center-bg",
                      'style': Xx,
                      'onClick': this["props"]["onClickCallback"]
                    }), y["createElement"]("span", {
                      'id': "replay-right-center-bg",
                      'style': Xx,
                      'onClick': this["props"]["onClickCallback"]
                    })), y["createElement"]("span", {
                      'id': "replay-right-bg",
                      'style': XM,
                      'onClick': this["props"]["onClickCallback"]
                    })), y["createElement"]("span", {
                      'id': "replay-btm-bg",
                      'style': XT,
                      'onClick': this["props"]["onClickCallback"]
                    })) : y["createElement"]("div", {
                      'id': "replay-bg",
                      'style': Xk,
                      'onClick': this["props"]["onClickCallback"]
                    });
                  }
                }, uI;
              }
            }(y["Component"]),
            XC = {
              'position': "absolute",
              'width': "inherit",
              'height': "inherit"
            },
            XL = {
              'animation': "show 0.25s linear 0s 1 normal forwards"
            },
            Xm = {
              'animation': "hide 0.25s linear 0s 1 normal forwards"
            },
            XU = function (uI) {
              function uI(uI) {
                var uH = uI["call"](this, uI) || this;
                return uH["state"] = {
                  'isShow': true
                }, uH;
              }
              return u0(uI, uI), uI["prototype"]["render"] = function () {
                var uI = this,
                  uH = this["state"]["isShow"] ? XL : Xm;
                return y["createElement"]("div", {
                  'id': "replay-view-wrapper",
                  'style': XC
                }, y["createElement"]("div", {
                  'id': "replay-view",
                  'style': uH
                }, y["createElement"](XN, {
                  'onReplayRecordClickCallback': this["props"]["onReplayRecordClickCallback"],
                  'onReplayCaptureClickCallback': this["props"]["onReplayCaptureClickCallback"]
                }), y["createElement"](Xy, {
                  'onFastForwardClickCallback': this["props"]["onFastForwardClickCallback"],
                  'onPauseClickCallback': this["props"]["onPauseClickCallback"],
                  'onStopClickCallback': this["props"]["onStopClickCallback"]
                })), y["createElement"](XO, {
                  'isShow': this["state"]["isShow"],
                  'onClickCallback': function () {
                    uI["setState"]({
                      'isShow': !uI["state"]["isShow"]
                    });
                  }
                }));
              }, uI;
            }(y["Component"]);
          function XZ(uI, uI) {
            var uI = [];
            uI["forEach"](function (uH) {
              {
                uI["push"](function (B9, B8, uQ) {
                  {
                    return undefined === B8 && (B8 = {
                      'x': 0x0,
                      'y': 0x0,
                      'width': 0x0,
                      'height': 0x0,
                      'isRotate': false
                    }), new Promise(function (B7, B8) {
                      {
                        var B8 = new plugin["Loader"]();
                        B8["onLoad"] = function (uQ) {
                          var l6 = document["createElement"]("canvas"),
                            l6 = l6["getContext"]('2d');
                          if (null !== l6) {
                            {
                              var l8 = new Image();
                              l8["onload"] = function () {
                                {
                                  URL["revokeObjectURL"](l8["src"]);
                                  var uQ = 0x0 === B8["width"] ? l8["width"] : B8["width"],
                                    uQ = 0x0 === B8["height"] ? l8["height"] : B8["height"];
                                  l6["width"] = uQ, l6["height"] = uQ, l6["clearRect"](0x0, 0x0, uQ, uQ), l6["translate"](uQ / 0x2, uQ / 0x2), B8["isRotate"] ? (l6["rotate"](0x10e * Math['PI'] / 0xb4), l6["drawImage"](l8, B8['x'], B8['y'], uQ, uQ, -uQ / 0x2, -uQ / 0x2, uQ, uQ)) : l6["drawImage"](l8, B8['x'], B8['y'], uQ, uQ, -uQ / 0x2, -uQ / 0x2, uQ, uQ);
                                  var lE = l6["getImageData"](0x0, 0x0, uQ, uQ),
                                    lz = lE["data"];
                                  if (uQ) for (var lX = 0x0, lB = lz["length"]; lX < lB; lX += 0x4) lz[lX] = uQ['r'], lz[lX + 0x1] = uQ['g'], lz[lX + 0x2] = uQ['b'];
                                  l6["putImageData"](lE, 0x0, 0x0), B7(l6["toDataURL"]());
                                }
                              }, l8["onerror"] = function () {
                                B8(Error("ImageBase64 load image failed"));
                              }, l8["src"] = URL["createObjectURL"](uQ["response"]);
                            }
                          }
                        }, B8["onError"] = function (uQ) {
                          {
                            B8(uQ);
                          }
                        }, B8["load"]([{
                          'src': B9,
                          'type': plugin["LoadType"]["Blob"]
                        }]);
                      }
                    });
                  }
                }(uH["resolvePath"], {
                  'x': 0x0,
                  'y': 0x0,
                  'width': 0x0,
                  'height': 0x0
                }, uH["colour"]));
              }
            }), Promise["all"](uI)["then"](function (uH) {
              {
                var B9 = [];
                uH["forEach"](function (B8) {
                  {
                    B9["push"](B8);
                  }
                }), uI && uI(B9, undefined);
              }
            })["catch"](function (uH) {
              uI && uI(undefined, uH);
            });
          }
          var XD = {};
          function Xh(uI, uI) {
            {
              var uI = new plugin["Loader"]();
              return new Promise(function (uH, B9) {
                {
                  uI["onLoad"] = function (B8) {
                    uH(B8["response"]);
                  }, uI["onError"] = function (B8) {
                    B9(B8);
                  }, uI["load"]([{
                    'src': uI,
                    'type': plugin["LoadType"]["Image"],
                    'maxAttemptCount': uI
                  }]);
                }
              });
            }
          }
          function XY(uI, uI, uI) {
            {
              var uH = new plugin["Loader"]();
              return new Promise(function (B9, B8) {
                uH["onLoad"] = function (uQ) {
                  var B7 = function (B8, B8) {
                    {
                      return B8["replace"](/url\((.*?)\)/g, function (uQ, l6) {
                        return "url(" + B8["resource"]["resolveUrl"](l6) + ')';
                      });
                    }
                  }(uQ["response"], uI);
                  B9(B7);
                }, uH["onError"] = function (uQ) {
                  B8(uQ);
                }, uH["load"]([{
                  'src': uI,
                  'type': plugin["LoadType"]["Text"],
                  'maxAttemptCount': uI
                }]);
              });
            }
          }
          var Xw = function (uI) {
              {
                function uI() {
                  {
                    var uI = null !== uI && uI["apply"](this, arguments) || this;
                    return uI["rootElement"] = Object["create"](null), uI["bv_Oe"] = undefined, uI["bv_Re"] = undefined, uI;
                  }
                }
                return u0(uI, uI), uI["prototype"]["onCreate"] = function () {
                  {
                    var uI = this;
                    this["rootElement"] = document["createElement"]("div");
                    var uH = document["createAttribute"]('id');
                    uH["value"] = "game-replay", this["rootElement"]["setAttributeNode"](uH), this["rootElement"]["style"]["visibility"] = "hidden", this["rootElement"]["style"]["position"] = "relative", this["rootElement"]["setAttribute"]("tabindex", "100"), function (B8, uQ, B7) {
                      var B8,
                        B8 = this,
                        uQ = B8["src"],
                        l6 = "unknown";
                      l6 = -0x1 !== uQ["indexOf"](".css") ? "css" : l6, l6 = -0x1 !== (B8 = uQ)["indexOf"](".jpg") || -0x1 !== B8["indexOf"](".png") ? "image" : l6;
                      var l6 = shell["Error"],
                        l8 = shell["ClientError"],
                        uQ = l6 && new l6(l8["Domain"], l8["GameLoadResourceError"]),
                        uQ = uQ["resource"]["resolveUrl"](uQ);
                      return new Promise(function (lE, lz) {
                        return __awaiter(B8, undefined, undefined, function () {
                          var lX;
                          return __generator(this, function (lB) {
                            {
                              switch (lB["label"]) {
                                case 0x0:
                                  return lB["trys"]["push"]([0x0, 0x9,, 0xa]), "image" !== l6 ? [0x3, 0x5] : B8["tint"] ? [0x4, (lP = [{
                                    'resolvePath': uQ,
                                    'colour': B8["tint"]
                                  }], new Promise(function (lz, lX) {
                                    XZ(lP, function (lp, ld) {
                                      if (ld || lp && 0x0 === lp["length"]) {
                                        {
                                          var lW = shell["Error"],
                                            lb = shell["ClientError"],
                                            lH = lW && new lW(lb["Domain"], lb["GameLoadResourceError"]);
                                          lX(ld || lH);
                                        }
                                      }
                                      lz(lp);
                                    });
                                  }))] : [0x3, 0x2];
                                case 0x1:
                                  return lX = lB["sent"](), lE(lX[0x0]), [0x3, 0x4];
                                case 0x2:
                                  return [0x4, Xh(uQ, B7)];
                                case 0x3:
                                  lX = lB["sent"](), lE(lX), lB["label"] = 0x4;
                                case 0x4:
                                  return [0x3, 0x8];
                                case 0x5:
                                  return "css" !== l6 ? [0x3, 0x7] : [0x4, XY(uQ, uQ, B7)];
                                case 0x6:
                                  return lX = lB["sent"](), lE(lX), [0x3, 0x8];
                                case 0x7:
                                  lz(uQ), lB["label"] = 0x8;
                                case 0x8:
                                  return [0x3, 0xa];
                                case 0x9:
                                  return lB["sent"](), lz(uQ), [0x3, 0xa];
                                case 0xa:
                                  return [0x2];
                              }
                              var lP;
                            }
                          });
                        });
                      });
                    }({
                      'src': "game_replay.css"
                    }, this["context"])["then"](function (B8) {
                      {
                        !function (uQ, B7) {
                          {
                            var B8 = [],
                              B8 = B7["bundleInfo"]["name"];
                            XD[B8] || (XD[B8] = []), Array["isArray"](uQ) || (uQ = [uQ]);
                            var uQ = XD[B8]["length"] + 0x1;
                            uQ["forEach"](function (l6, l6) {
                              var l8 = uQ + l6,
                                uQ = "$CSS-" + B7["bundleInfo"]["name"] + '-' + l8;
                              B8["push"](uQ), function (uQ, lE, lz) {
                                {
                                  if (-0x1 === XD[lE]["indexOf"](uQ)) {
                                    var lX = document["createElement"]("style");
                                    lX['id'] = uQ, lX["innerHTML"] = lz, document["head"]["appendChild"](lX), XD[lE]["push"](uQ);
                                  }
                                }
                              }(uQ, B7["bundleInfo"]["name"], l6);
                            });
                          }
                        }(B8, uI["context"]);
                      }
                    });
                    var B9 = this["context"]["event"];
                    B9['on']("Shell.Scaled", this["bv_Ee"], this), B9['on']("Game.ReplayStarting", this["bv_xe"], this), B9['on']("Game.ReplayEnded", this["bv_ke"], this), zD["context"] = this["context"];
                  }
                }, uI["prototype"]["bv_Ee"] = function (uI) {
                  {
                    var uH = uI["payload"];
                    this["rootElement"]["style"]["width"] = ''["concat"](uH["width"], 'px'), this["rootElement"]["style"]["height"] = ''["concat"](uH["height"], 'px');
                  }
                }, uI["prototype"]["bv_je"] = function (uI) {
                  uI["stopPropagation"]();
                }, uI["prototype"]["bv_xe"] = function () {
                  var uI = this;
                  this["context"]["view"]["appendTo"](uI, "overlay"), this["rootElement"]["style"]["visibility"] = "visible", this["rootElement"]["focus"](), this["context"]["event"]['on']("Shell.FocusCanvas", this["bv_je"], this, "High"), F["render"](y["createElement"](XU, {
                    'onReplayCaptureClickCallback': function (uH) {
                      {
                        uI["bv_Oe"] = uH, uI["context"]["event"]["emit"]("Game.Screenshot", undefined, function () {
                          {
                            uI["context"]["event"]["emit"]("Analytics.Event", {
                              'actionName': "CaptureReplay"
                            });
                            var B9 = uI["bv_Oe"];
                            B9 && B9(), uI["bv_Oe"] = undefined;
                          }
                        });
                      }
                    },
                    'onReplayRecordClickCallback': function (uH, B9, B8) {
                      {
                        uI["bv_Re"] = B9;
                        var uQ = function (B8) {
                          {
                            0x3 === uH && uI["context"]["event"]["emit"]("Analytics.Event", {
                              'actionName': "RecordReplay"
                            });
                            var B8 = uI["bv_Re"];
                            B8 && B8(B8), uI["bv_Re"] = undefined;
                          }
                        };
                        if (B8) {
                          {
                            var B7 = function (B8) {
                              switch (B8) {
                                case 0x1:
                                  return "Game.StopRecording";
                                case 0x3:
                                  return "Game.StartRecording";
                                default:
                                  return;
                              }
                            }(uH);
                            B7 && uI["context"]["event"]["emit"](B7, undefined, function (B8) {
                              {
                                var B8 = B8["response"] && B8["response"]["timeLimit"];
                                uQ(B8);
                              }
                            });
                          }
                        } else uQ();
                      }
                    },
                    'onFastForwardClickCallback': function (uH) {
                      {
                        uI["context"]["event"]["emit"]("Game.SetReplaySpeed", uH);
                      }
                    },
                    'onPauseClickCallback': function (uH) {
                      var B9 = uH ? "Game.PauseReplay" : "Game.ResumeReplay";
                      uI["context"]["event"]["emit"](B9);
                    },
                    'onStopClickCallback': function () {
                      uI["context"]["event"]["emit"]("Game.StopReplay"), uI["context"]["event"]["emit"]("Analytics.Event", {
                        'actionName': "ManualStopReplay"
                      });
                    }
                  }), this["rootElement"]);
                }, uI["prototype"]["bv_ke"] = function () {
                  this["rootElement"]["style"]["visibility"] = "hidden", this["bv_Oe"] = undefined, this["bv_Re"] = undefined, F["unmountComponentAtNode"](this["rootElement"]), this["view"]["removeFromParent"](uI), this["context"]["event"]["off"]("Shell.FocusCanvas", this["bv_je"], this);
                }, uI;
              }
            }(plugin["AbstractViewComponent"]),
            XV = undefined,
            Xq = undefined,
            XK = undefined,
            XA = undefined;
          function XG(uI) {
            if (jz["TransactionStateMachine"] && uI) return uI(jz["TransactionStateMachine"]);
            throw Error("[BVFramework] ERROR: TransactionStateMachine function called but module not found!");
          }
          function Xf() {
            {
              XV = undefined, Xq = undefined;
            }
          }
          var ga = P("TransactionStateMachineHandler", {
              'initTransactionStateMachine': function (uI) {
                {
                  XG(function (uI) {
                    {
                      uI["initTransactionStateMachine"](uI);
                    }
                  });
                }
              },
              'goTo': function (uI, uI, uI) {
                XG(function (uH) {
                  uH["goTo"](uI, uI, uI);
                });
              },
              'subscribeStateEvent': function (uI, uI) {
                {
                  XG(function (uI) {
                    uI["subscribeStateEvent"](uI, uI);
                  });
                }
              },
              'unsubscribeStateEvent': function (uI, uI) {
                XG(function (uI) {
                  {
                    uI["unsubscribeStateEvent"](uI, uI);
                  }
                });
              },
              'getState': function () {
                {
                  return XG(function (uI) {
                    {
                      return uI["getState"]();
                    }
                  });
                }
              },
              'getNextState': function () {
                {
                  return XG(function (uI) {
                    {
                      return uI["getNextState"]();
                    }
                  });
                }
              },
              'addTransition': function (uI, uI) {
                {
                  undefined === uI && (uI = false), XG(function (uI) {
                    uI["addTransition"](uI, uI);
                  });
                }
              },
              'pause': function () {
                XG(function (uI) {
                  {
                    uI["pause"]();
                  }
                });
              },
              'resume': function () {
                XG(function (uI) {
                  {
                    uI["resume"]();
                  }
                });
              },
              'initState': function (uI) {
                XG(function (uI) {
                  {
                    uI["initTransactionStateMachine"](uI);
                  }
                });
              },
              'setTransitionData': function (uI) {
                XV = uI;
              },
              'getTransitionData': function () {
                return XV;
              },
              'hasOnHoldTransition': function () {
                {
                  return undefined !== Xq;
                }
              },
              'goToStateCallback': function (uI, uI, uI) {
                {
                  return undefined === uI && (uI = false), function (uH) {
                    {
                      XG(function (B9) {
                        {
                          if (Xq) throw Error("TransactionStateMachineHandler info: goToStateCallback : cannot go to next state (" + uI + ") when previous state transition (" + B9["getNextState"]() + ") is not complete.");
                          uI ? B9["goTo"](uI, function (B8, uQ) {
                            XV = u1(u1(u1({}, XV), B8), uI), Xq = uQ, uH();
                          }, function () {
                            {
                              var B8 = XK;
                              XK = undefined, B8 && B8();
                            }
                          }) : B9["goTo"](uI, function (B8, uQ) {
                            B8 = u1(u1(u1({}, XV), B8), uI), Xf(), uQ(undefined, B8);
                          }, uH);
                        }
                      });
                    }
                  };
                }
              },
              'transitionCompleteCallback': function (uI, uI) {
                {
                  return function (uI) {
                    {
                      XG(function (uH) {
                        XK = uI;
                        var B9 = Xq;
                        if (!B9) throw Error("TransactionStateMachineHandler info: transitionCompleteWrapper : no transition to complete. Current completed state: " + uH["getState"]());
                        if (uI && uI !== uH["getNextState"]()) throw Error("TransactionStateMachineHandler info: transitionCompleteWrapper : complete incorrect state. Attempted complete state: " + uI + ". State suppose to complete: " + uH["getNextState"]());
                        var B8 = u1(u1({}, XV), uI);
                        Xf(), B9(undefined, B8);
                      });
                    }
                  };
                }
              },
              'clearTransition': Xf,
              'cacheTransitionCallback': function () {
                {
                  XA = Xq;
                }
              },
              'retrieveTransitionCallback': function () {
                XA && (Xq = XA, XA = undefined);
              }
            }),
            Xg = zs["emitGameFlowStateChangedEvent"],
            B0 = u7["timeoutCallback"],
            B1 = u7["getSharedScheduler"],
            B2 = u7["delayCallback"],
            B3 = function () {
              function uI() {
                this["bv_Ie"] = 0x0, this["bv_Ae"] = false, this["bv_Ne"] = false, this["bv_Le"] = false, this["bv_Me"] = false, this["bv_Pe"] = false, this["bv__e"] = undefined, this["bv_De"] = false, this["bv_Ue"] = this["bv_He"]["bind"](this);
              }
              return uI["prototype"]["initGameReplay"] = function (uI, uI) {
                {
                  var uH = this;
                  undefined === uI && (uI = this["bv_Ue"]);
                  var B9 = uO();
                  this["bv_m"] = uI, B9['on']("Game.RequestReplay", function (B8) {
                    {
                      B9["emit"]("Game.ReplayInitiated"), uH["bv_Be"]();
                      var uQ = uH["bv_Fe"](B8["payload"]),
                        B7 = uH["bv_We"](uQ);
                      ga["pause"](), uI["isGameReplaying"] = true, uI["nextGameReplayInfo"] = uH["bv_qe"][0x0], uH["bv_Ie"] = 0x0, uH["bv_Ae"] = false, uH["bv_Ne"] = false, uH["bv_Pe"] = false, B9["once"]("Game.WalletChangedSuccess", function () {
                        {
                          B5(), B9['on']("Game.DummyTransactionStateTransition", uH["bv_Ve"], uH), B9["emit"]("Game.ReplayStarting", undefined, function () {
                            {
                              B9["emit"]("Game.BlockUI", false, function () {
                                0x1 === uI["transactionModel"]["stateTransitionTo"] ? uH["bv_Qe"] = B2(0x1)(function () {
                                  {
                                    uH["bv_Qe"] = undefined, uI();
                                  }
                                }) : B9["once"]("Game.DummyTransactionStateComplete", uH["bv_ze"], uH, "High"), B9["once"]("Game.StopReplay", uH["bv_Ye"], uH);
                              });
                            }
                          }), B9['on']("Game.PauseReplay", uH["bv_Xe"], uH), B9['on']("Game.ResumeReplay", uH["bv_Ke"], uH), B9['on']("Game.SetReplaySpeed", uH["bv_Ze"], uH);
                        }
                      }), B9["emit"]("Game.BlockUI", true), B4(function () {
                        B9["emit"]("Game.GameInfoUpdateSuccess", B7);
                      }), Xg({
                        'displayState': "Start",
                        'flowType': "Replay"
                      }), B9['on']("Game.TransactionInfoChanged", uH["bv_Je"], uH, "High"), B9['on']("Game.GameInfoUpdated", uH["bv_Je"], uH, "High"), B9['on']("Game.TransactionInfoUpdated", uH["bv_Je"], uH, "High");
                    }
                  });
                }
              }, Object["defineProperty"](uI["prototype"], "nextReplayAPIResponse", {
                'get': function () {
                  {
                    var uI = this["bv_qe"];
                    if (this["bv_Ie"] >= uI["length"]) throw Error("GameReplayHandler :: nextReplayAPIResponse : no next data to fetch! Invalid replay data length.");
                    var uI = uI[this["bv_Ie"]];
                    this["bv_Ie"]++, this["bv_Ie"] < uI["length"] ? this["bv_m"]["nextGameReplayInfo"] = uI[this["bv_Ie"]] : (this["bv_m"]["nextGameReplayInfo"] = undefined, this["bv_Ae"] = true);
                    var uH = Object["create"](null);
                    return uH['dt'] = Object["create"](null), uH['dt']['si'] = uI, uH['dt']["err"] = null, uH;
                  }
                },
                'enumerable': false,
                'configurable': true
              }), uI["prototype"]["bv_$e"] = function (uI) {
                {
                  var uI = this;
                  B4(function () {
                    uI["bv_ti"](), uI["bv_Le"] && (cc["game"]["resume"](), uI["bv_Le"] = false), cc["director"]["setTimeScale"](0x1);
                    var uH = uO();
                    uH["emit"]("Game.SetAudioPlayRate", 0x1), uH["emit"]("Game.ReplayEnding", undefined, function () {
                      var B9 = uI["bv__e"];
                      B9 && B9["propagate"](), uI["bv__e"] = undefined, uI();
                    });
                  });
                }
              }, uI["prototype"]["bv_ni"] = function (uI) {
                this["bv_De"] || (this["bv__e"] = uI, uI["intercept"]());
              }, uI["prototype"]["bv_Ye"] = function (uI, uI) {
                {
                  var uH = this;
                  undefined === uI && (uI = false);
                  var B9 = uO();
                  if (B9["emit"]("Game.ReplayEnded"), B9["off"]("Game.PauseReplay", this["bv_Xe"], this), B9["off"]("Game.ResumeReplay", this["bv_Ke"], this), B9["off"]("Game.SetReplaySpeed", this["bv_Ze"], this), B9["off"]("Game.StopReplay", this["bv_Ye"], this), this["bv_ei"]) {
                    var B8 = this["bv_ei"];
                    return this["bv_ei"] = undefined, B8(), void this["bv_$e"](this["bv_ii"]["bind"](this));
                  }
                  if (this["bv_Qe"]) return this["bv_Qe"](), this["bv_Qe"] = undefined, void this["bv_$e"](this["bv_ii"]["bind"](this));
                  this["bv_Ae"] = true, this["bv_Ne"] = true, this["bv_De"] = false, undefined === ga["getNextState"]() ? B9["once"]("Game.DummyTransactionStateTransition", this["bv_ni"], this, "High") : B9["once"]("Game.DummyTransactionStateComplete", this["bv_ni"], this), this["bv_$e"](function () {
                    uH["bv_Pe"] || (uH["bv_Ue"](), B1()["schedule"](uH["bv_Ue"], 0.5, cc["macro"]["REPEAT_FOREVER"], 0x0)), uH["bv_De"] = true, uI && uH["bv_ii"]();
                  });
                }
              }, uI["prototype"]["bv_Ze"] = function (uI) {
                cc["director"]["setTimeScale"](uI["payload"]), uI["payload"] >= 0x0 && uO()["emit"]("Game.SetAudioPlayRate", uI["payload"]);
              }, uI["prototype"]["bv_Xe"] = function () {
                {
                  this["bv_Le"] || (this["bv_Le"] = true, cc["game"]["pause"]());
                }
              }, uI["prototype"]["bv_Ke"] = function () {
                this["bv_Le"] && (this["bv_Le"] = false, cc["game"]["resume"]());
              }, uI["prototype"]["bv_ze"] = function (uI) {
                {
                  uI["intercept"](), B0(0x1)(function () {
                    uI["propagate"]();
                  });
                }
              }, uI["prototype"]["bv_He"] = function () {
                uO()["emit"]("Game.SkipEvent");
              }, uI["prototype"]["bv_Fe"] = function (uI) {
                var uI = this["bv_m"]["lastTransactionRawData"];
                if ("object" == typeof uI && null !== uI) {
                  if ("Spin" === uI["replayType"] || 0x1 === uI["replayData"]["length"]) this["bv_qe"] = uI["replayData"];else {
                    this["bv_qe"] = function (B9, B8, uQ) {
                      {
                        for (var B7 = B8, B8 = B8, B8 = B8; B8 >= 0x0; B8--) if (B6(B9[B8]['st'], uQ)) {
                          {
                            B8 = B8;
                            break;
                          }
                        }
                        B8 = B8;
                        for (var uQ = B9["length"]; B8 < uQ; B8++) if (B6(B9[B8]["nst"], uQ)) {
                          B7 = B8;
                          break;
                        }
                        return B9["slice"](B8, B7 + 0x1);
                      }
                    }(uI["replayData"], uI["selectedIndex"], this["bv_m"]["systemModel"]["gameId"]);
                    var uH = uI["replayData"]["indexOf"](this["bv_qe"][0x0]);
                    0x0 !== uH && (uI = uI["replayData"][uH - 0x1]);
                  }
                } else this["bv_qe"] = uI;
                return uI;
              }, uI["prototype"]["bv_Ve"] = function (uI) {
                var uI = this;
                this["bv_Pe"] || "action" === uI["payload"]['to'] && this["bv_Ae"] && (this["bv_Pe"] = true, B1()["unschedule"](this["bv_Ue"]), uI["intercept"](), this["bv_ri"] = function () {
                  uI["propagate"]();
                }, this["bv_Ne"] ? this["bv_ii"]() : this["bv_ei"] = B2(0x1)(function () {
                  uI["bv_ei"] = undefined, uO()["emit"]("Analytics.Event", {
                    'actionName': "AutoStopReplay"
                  }), uI["bv_Ye"](undefined, true);
                }));
              }, uI["prototype"]["bv_ii"] = function () {
                var uI = this,
                  uI = uO();
                uI["once"]("Game.WalletChangedSuccess", function () {
                  {
                    uI["bv_m"]["isGameReplaying"] = false, uI["bv_ai"](), uI["emit"]("Game.ReplayQuit"), Xg({
                      'displayState': "End",
                      'flowType': "Replay"
                    }), B5(), ga["resume"](), uI["off"]("Game.DummyTransactionStateTransition", uI["bv_Ve"], uI), uI["off"]("Game.DummyTransactionStateTransition", uI["bv_ni"], uI), uI["off"]("Game.DummyTransactionStateComplete", uI["bv_ni"], uI), uI["off"]("Game.TransactionInfoChanged", uI["bv_Je"], uI), uI["off"]("Game.GameInfoUpdated", uI["bv_Je"], uI), uI["off"]("Game.TransactionInfoUpdated", uI["bv_Je"], uI);
                    var uH = uI["bv_ri"];
                    uI["bv_ri"] = undefined, uH && uH();
                  }
                }), uI["emit"]("Game.GameInfoUpdateSuccess", this["bv_oi"]);
              }, uI["prototype"]["bv_Be"] = function () {
                {
                  var uI = this["bv_m"],
                    uI = Object["assign"]({}, uI["lastGameInfoRawData"]),
                    uH = Object["assign"]({}, uI["lastTransactionRawData"]),
                    B9 = uI['dt'];
                  B9['ls']['si'] = uH, B9['bl'] = uH['bl'], this["bv_oi"] = uI;
                }
              }, uI["prototype"]["bv_We"] = function (uI) {
                var uI = this["bv_m"],
                  uH = this["bv_qe"],
                  B9 = uI["lastGameInfoRawData"]['dt'],
                  B8 = uH[0x0],
                  uQ = Object["assign"]({}, uI);
                return uQ['cs'] = B8['cs'], uQ['ml'] = B8['ml'], uQ['wt'] = B8['wt'], uQ['wk'] = B8['wk'], uQ["wid"] = B8["wid"], B8["wbn"] ? (uQ["wbn"] = Object["assign"]({}, B8["wbn"]), uQ["wbn"]["bra"] = uQ["wbn"]["bra"] + B8["tbb"]) : uQ["wbn"] = null, B8["wfg"] ? (uQ["wfg"] = Object["assign"]({}, B8["wfg"]), uQ["wfg"]['gc']++) : uQ["wfg"] = null, {
                  'dt': {
                    'bl': B8["blb"],
                    'cs': [B8['cs']],
                    'fb': {
                      'is': false,
                      'bm': 0x0,
                      't': 0x0
                    },
                    'ls': {
                      'si': uQ
                    },
                    'ml': [B8['ml']],
                    'mxl': B9["mxl"],
                    'wt': B9['wt']
                  }
                };
              }, uI["prototype"]["bv_Je"] = function (uI) {
                uI["stopPropagation"]();
              }, uI["prototype"]["bv_ti"] = function () {
                {
                  var uI = this,
                    uI = uO();
                  uI["emit"]("Game.RequestAudioState", undefined, function (uH) {
                    'On' === uH["response"] && (uI["bv_Me"] = true, uI["emit"]("Game.OffAudio"));
                  });
                }
              }, uI["prototype"]["bv_ai"] = function () {
                this["bv_Me"] && (uO()["emit"]("Game.OnAudio"), this["bv_Me"] = false);
              }, uI;
            }();
          function B4(uI) {
            uq({
              'backgroundColor': {
                'r': 0x2f,
                'g': 0x2f,
                'b': 0x3b,
                'a': 0xff
              }
            }), B0(0.6)(uI);
          }
          function B5() {
            uK();
          }
          function B6(uI, uI) {
            {
              switch (uI) {
                case 0x1:
                case 0x2:
                case 0x15:
                  return true;
                case 0x3:
                  return 0x2c === uI;
                case 0x1f:
                  return 0x49 === uI || 0x1 === uI || 0x9 === uI;
                case 0x20:
                  return 0x43 === uI || 0x1 === uI || 0x9 === uI;
                case 0x21:
                  return 0x12 === uI || 0x1 === uI || 0x9 === uI;
                case 0x22:
                  return 0x12 === uI;
                default:
                  return false;
              }
            }
          }
          var B7,
            B8,
            B9,
            Bu,
            Bj = new B3(),
            BE = Object["freeze"]({
              'ON_TRANSITION': "onTransition",
              'ON_TRANSITION_FAILED': "onTransitionFailed",
              'ON_TRANSITION_SUCCEED': "onTransitionSucceed"
            }),
            Bz = function () {
              function uI(uI) {
                this["bv_ui"] = undefined, this["bv_ci"] = false;
                for (var uI = this["bv_si"] = Object["create"](null), uH = 0x0, B9 = uI["length"]; uH < B9; uH++) {
                  var B8 = uI[uH]["from"];
                  uI[B8] || (uI[B8] = Object["create"](null)), uI[B8][uI[uH]['to']] = [[], []];
                }
                this["bv_li"] = Object["create"](null);
              }
              return Object["defineProperty"](uI["prototype"], "state", {
                'get': function () {
                  return this["bv_fi"];
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "nextState", {
                'get': function () {
                  {
                    return this["bv_hi"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), Object["defineProperty"](uI["prototype"], "data", {
                'get': function () {
                  {
                    return this["bv_ui"];
                  }
                },
                'enumerable': false,
                'configurable': true
              }), uI["prototype"]["emit"] = function (uI, uI) {
                var uH = this["bv_li"][uI];
                if (uH) {
                  {
                    for (var B9 = [], B8 = 0x0, uQ = uH["length"]; B8 < uQ; B8++) {
                      {
                        var B7 = uH[B8],
                          B8 = B7["func"],
                          B8 = B7["bindedFunc"];
                        B7["once"] && B9["push"](this["off"]["bind"](this, uI, B8)), B8 ? B8(uI) : B8(uI);
                      }
                    }
                    B9["forEach"](function (uQ) {
                      {
                        return uQ();
                      }
                    });
                  }
                }
              }, uI["prototype"]["once"] = function (uI, uI, uH) {
                this["_on"](uI, uI, uH, true);
              }, uI["prototype"]['on'] = function (uI, uI, uH) {
                this["_on"](uI, uI, uH, false);
              }, uI["prototype"]["off"] = function (uI, uI) {
                {
                  var uH = this["bv_li"][uI];
                  if (uH) if (uI) {
                    for (var B9 = 0x0, B8 = uH["length"]; B9 < B8; B9++) if (uH[B9]["func"] === uI) {
                      {
                        uH["splice"](B9, 0x1);
                        break;
                      }
                    }
                  } else uH["length"] = 0x0;
                }
              }, uI["prototype"]["_on"] = function (uI, uI, uH, B9) {
                var B8 = this["bv_li"],
                  uQ = B8[uI];
                uQ || (uQ = B8[uI] = []), uQ["push"]({
                  'func': uI,
                  'bindedFunc': uH ? uI["bind"](uH) : undefined,
                  'once': B9
                });
              }, uI["prototype"]["start"] = function (uI) {
                this["bv_ci"] = true, this["bv_fi"] = uI;
                var uI = {
                  'from': undefined,
                  'to': uI,
                  'data': undefined
                };
                this["emit"](BE["ON_TRANSITION_SUCCEED"], uI);
              }, uI["prototype"]["goTo"] = function (uI, uI, uH) {
                var B9 = this;
                if (this["bv_hi"]) throw Error("TransactionStateMachine :: goTo : cannot change state during transition.");
                if (!this["bv_di"](uI)) throw Error("TransactionStateMachine :: goTo : Invalid transition from " + this["bv_fi"] + " to " + uI + '.');
                var B8 = {
                  'from': this["state"],
                  'to': uI
                };
                this["emit"](BE["ON_TRANSITION"], B8), this["bv_hi"] = uI;
                var uQ = this["bv_si"][this["bv_fi"]][uI],
                  B7 = u5(uI ? u5(u5([], uQ[0x1], true), [uI], false) : u5([], uQ[0x1], true), uQ[0x0], true);
                if (B7["length"]) {
                  {
                    var B8 = B7["length"] - 0x1,
                      B8 = function (uQ, l6) {
                        B8--, uQ ? (B9["bv_vi"](uQ || Error("abort")), uH && uH(uQ || Error("abort"))) : B8 < 0x0 ? (B9["bv_vi"](undefined, l6), uH && uH(undefined, l6)) : B7[B8](l6, B8);
                      };
                    B7[B8](undefined, B8);
                  }
                } else this["bv_vi"](), uH && uH();
              }, uI["prototype"]["addTransitionHook"] = function (uI, uI) {
                if (undefined === uI && (uI = false), this["bv_ci"]) throw Error("TransactionStateMachine :: addTransitionHook : cannot add hook after state machine is started.");
                var uH = this["bv_si"];
                Object["keys"](uH)["forEach"](function (B9) {
                  Object["keys"](uH[B9])["forEach"](function (B8) {
                    var uQ = uI({
                      'state': B9,
                      'nextState': B8
                    });
                    uQ && uH[B9][B8][uI ? 0x1 : 0x0]["push"](uQ);
                  });
                });
              }, uI["prototype"]["bv_di"] = function (uI) {
                {
                  return -0x1 !== Object["keys"](this["bv_si"][this["state"]])["indexOf"](uI);
                }
              }, uI["prototype"]["bv_vi"] = function (uI, uI) {
                var uH = this["bv_hi"];
                if (this["bv_hi"] = undefined, uI) {
                  {
                    var B9 = {
                      'from': this["bv_fi"],
                      'to': uH,
                      'error': uI
                    };
                    this["emit"](BE["ON_TRANSITION_FAILED"], B9);
                  }
                } else {
                  var B8 = {
                    'from': this["bv_fi"],
                    'to': uH,
                    'data': uI
                  };
                  this["bv_fi"] = uH, this["bv_ui"] = uI, this["emit"](BE["ON_TRANSITION_SUCCEED"], B8);
                }
              }, uI;
            }(),
            BX = new Bz([{
              'from': "setup",
              'to': "idle"
            }, {
              'from': "idle",
              'to': "action"
            }, {
              'from': "action",
              'to': "result"
            }, {
              'from': "result",
              'to': "prize"
            }, {
              'from': "prize",
              'to': "idle"
            }, {
              'from': "result",
              'to': "idle"
            }, {
              'from': "prize",
              'to': "setup"
            }]),
            BB = false;
          function BP(uI, uI) {
            {
              BX['on'](uI, uI);
            }
          }
          function Bl(uI, uI) {
            {
              BX["off"](uI, uI);
            }
          }
          function BN(uI) {
            var uI = uO();
            BX["addTransitionHook"](function (uI) {
              {
                return function (uH, B9) {
                  {
                    var B8 = function (B8) {
                        {
                          return B9(undefined, B8);
                        }
                      },
                      uQ = function (B8) {
                        {
                          uI["nextState"], B8["message"], B9(B8);
                        }
                      },
                      B7 = {
                        'to': uI["nextState"],
                        'reply': function (B8) {
                          {
                            B8 = function (uQ) {
                              {
                                B8(uQ)["then"](B8, uQ);
                              }
                            };
                          }
                        }
                      };
                    uI["emit"]("Game.TransactionStateTransition", B7, function () {
                      B8(uH);
                    });
                  }
                };
              }
            }), BX["addTransitionHook"](function (uI) {
              return function (uH, B9) {
                {
                  var B8 = function (B8) {
                      {
                        return B9(undefined, B8);
                      }
                    },
                    uQ = function (B8) {
                      uI["nextState"], B8["message"], B9(B8);
                    },
                    B7 = {
                      'to': uI["nextState"],
                      'reply': function (B8) {
                        B8 = function (uQ) {
                          {
                            B8(uQ)["then"](B8, uQ);
                          }
                        };
                      }
                    };
                  uI["emit"]("Game.TransactionStateComplete", B7, function () {
                    B8(uH);
                  });
                }
              };
            }, true), BP("onTransitionSucceed", function (uI) {
              {
                uI["emit"]("Game.TransactionStateChanged", uI);
              }
            }), BX["start"](uI);
          }
          function Bp(uI, uI) {
            {
              undefined === uI && (uI = false), BX["addTransitionHook"](uI, uI);
            }
          }
          function Bd(uI, uI, uI) {
            if (BB) {
              {
                var uH = uO(),
                  B9 = {
                    'to': uI,
                    'reply': function () {}
                  };
                Bu = uI, uH["emit"]("Game.DummyTransactionStateTransition", B9, function () {
                  {
                    uI ? uI(undefined, function (B8, uQ) {
                      {
                        if (BB) Bc(uI, uI);else {
                          {
                            B8 = uI;
                            B7 = undefined, B7 && B7(B8, uQ);
                          }
                        }
                      }
                    }) : Bc(uI, uI);
                  }
                });
              }
            } else BX["goTo"](uI, function (B8, uQ) {
              uI && uI(B8, function (B7, B8) {
                {
                  BB ? (B7 = uQ, Bc(uI, uI)) : uQ(B7, B8);
                }
              });
            }, function () {
              {
                if (B8) {
                  B8 = undefined, B8();
                } else uI && uI();
              }
            });
          }
          function BW() {
            return BB ? B9 : BX["state"];
          }
          function Bb() {
            {
              return BB ? Bu : BX["nextState"];
            }
          }
          function BH() {
            {
              B9 = BW(), Bu = Bb(), BB = true;
            }
          }
          function BS() {
            BB = false;
          }
          function Bc(uI, uI) {
            if (!BB) throw Error("TransactionStateMachineManager :: dummyTransactionStateComplete : Not in paused mode to call");
            var uI = uO(),
              uH = {
                'to': uI,
                'reply': function () {}
              };
            uI["emit"]("Game.DummyTransactionStateComplete", uH, function () {
              {
                B9 = Bu, Bu = undefined, uI["emit"]("Game.DummyTransactionStateChanged", {
                  'from': B9,
                  'to': uI
                }), uI && uI();
              }
            });
          }
          function Bs(uI, uI) {
            {
              return function (uI) {
                {
                  var uH = uO();
                  uH['on']("Game.TransactionStateChanged", function (B9) {
                    var B8 = B9["payload"],
                      uQ = uI["transactionModel"],
                      B7 = uQ["stateTransitionTo"],
                      B8 = uQ["transactionId"],
                      B8 = uQ["parentTransactionId"],
                      uQ = uQ["accumulatedWinAmount"],
                      l6 = uQ["betSizeValue"],
                      l6 = uQ["betLevelValue"],
                      l8 = uQ["totalBaseBet"],
                      uQ = uI["systemModel"],
                      uQ = 0x0;
                    if (uI) uQ = Math["floor"](uI());else if (uQ["maxLineNumber"]) {
                      var lE = uQ["maxLineNumber"];
                      uQ = Math["floor"](uQ / (l6 * l6 * lE));
                    } else l8 > 0x0 && (uQ = Math["floor"](uQ / l8));
                    if ("prize" === B8["from"] && 0x1 === B7 && uQ > 0x0) {
                      {
                        var lz = {
                          'parentTransactionId': B8,
                          'transactionId': B8,
                          'totalWinAmount': uQ,
                          'winMultiplier': uQ
                        };
                        uH["emit"]("Game.WinAnnouncement", lz);
                      }
                    }
                  }), uI && uI();
                }
              };
            }
          }
          var BR = u7["deferCallback"],
            BQ = new (function () {
              function uI() {
                {
                  this["bv_mi"] = 0x0, this["bv_bi"] = 0x0, this["bv_pi"] = false, this["bv_Pe"] = false;
                }
              }
              return uI["prototype"]["initTurboSuggest"] = function (uI) {
                var uI = this;
                this["bv_bi"] = this["bv_mi"] = 0x0;
                var uH = uO(),
                  B9 = function (uQ) {
                    if (uI["bv_Pe"]) return uI["bv_Pe"] = false, void uH["off"]("Game.TransactionStateComplete", B9);
                    if ("action" === uQ["payload"]['to'] && !uI["isGameReplaying"]) {
                      {
                        uI["bv_Pe"] = true;
                        var l6 = shell["I18n"],
                          l6 = {
                            'label': l6['t']("TurboSpinSuggest.Later"),
                            'type': "Neutral",
                            'handler': "later"
                          },
                          l8 = {
                            'label': l6['t']("TurboSpinSuggest.Enable"),
                            'type': "Neutral",
                            'handler': "enable"
                          };
                        uQ["intercept"]();
                        var uQ = {
                          'content': l6['t']("TurboSpinSuggest.Message"),
                          'actions': [l6, l8],
                          'interceptable': false
                        };
                        uH["emit"]("Alert.Show", uQ, function (uQ) {
                          "enable" === uQ["response"] && uH["emit"]("Game.OnTurboSpin"), uQ["propagate"]();
                        }), uH["off"]("Game.TurboSpinStateChanged", uQ);
                      }
                    }
                  },
                  B8 = function (uQ) {
                    {
                      if ("action" === uQ["payload"]['to'] && 0x1 === uI["transactionModel"]["stateTransitionTo"] && uI["bv_bi"] > 0x0) {
                        {
                          var l6 = uI["bv_bi"];
                          l6 === uI["bv_mi"] ? uI["bv_bi"] = uI["bv_mi"] = 0x0 : l6 < 0x3 ? uI["bv_mi"] = l6 : (uH["off"]("Game.TransactionStateTransition", B8), uH['on']("Game.TransactionStateComplete", B9, undefined, "Low"));
                        }
                      }
                    }
                  },
                  uQ = function (uQ) {
                    {
                      uQ["payload"] && (uH["off"]("Game.TurboSpinStateChanged", uQ), uH["off"]("Game.TransactionStateTransition", B8), uH["off"]("Game.TransactionStateChanged", B8), cc["systemEvent"]["off"](cc["SystemEvent"]["EventType"]["KEY_DOWN"], B8), uH["off"]("Shell.CanvasTouchStarted", B7), uH["off"]("Shell.CanvasMouseDown", B7), uH["off"]("Game.TransactionStateComplete", B9));
                    }
                  };
                uH['on']("Game.TurboSpinStateChanged", uQ), uH['on']("Game.TransactionStateTransition", B8, undefined, "Low");
                var B7 = function () {
                  uI["bv_pi"] && (uI["bv_bi"]++, uI["bv_pi"] = false, uI["bv_bi"] >= 0x3 && (uH["off"]("Game.TransactionStateChanged", B8), cc["systemEvent"]["off"](cc["SystemEvent"]["EventType"]["KEY_DOWN"], B8), uH["off"]("Shell.CanvasTouchStarted", B7), uH["off"]("Shell.CanvasMouseDown", B7)));
                };
                uH['on']("Shell.CanvasTouchStarted", B7), uH['on']("Shell.CanvasMouseDown", B7);
                var B8 = function (uQ) {
                  {
                    uQ["keyCode"] === cc["macro"]["KEY"]["space"] && B7();
                  }
                };
                cc["systemEvent"]['on'](cc["SystemEvent"]["EventType"]["KEY_DOWN"], B8);
                var B8 = function (uQ) {
                  var l6 = uQ["payload"];
                  "action" === l6['to'] && 0x1 === uI["transactionModel"]["stateTransitionTo"] && BR()(function () {
                    {
                      uI["bv_pi"] = true;
                    }
                  }), uI["bv_pi"] && "result" === l6["from"] && (uI["bv_pi"] = false);
                };
                uH['on']("Game.TransactionStateChanged", B8);
              }, uI;
            }())();
          function By(uI) {
            {
              var uI = uO();
              uI["once"]("Game.GameInfoUpdated", function (uI) {
                var uH = uI["payload"]['dt']['fb'],
                  B9 = uI["systemModel"]["operatorJurisdiction"];
                uH ? (B9["buyFeature"] = 0x1, uI['on']("Game.FlowStateChanged", function (B8) {
                  var uQ = B8["payload"];
                  "FeatureBuySelection" === uQ["flowType"] && ("Start" === uQ["displayState"] ? uI["emit"]("Game.BlockUI", true) : "End" === uQ["displayState"] && uI["emit"]("Game.BlockUI", false));
                })) : B9["buyFeature"] = 0x0;
              }, undefined, "High");
            }
          }
          function Bv(uI, uI) {
            {
              var uI = uO();
              uI['on']("Game.TransactionStateChanged", function (B8) {
                {
                  var uQ = B8["payload"];
                  ("prize" === uQ["from"] || "result" === uQ["from"] && "idle" === uQ['to']) && uI["markRead"]();
                }
              });
              var uH = false,
                B9 = function (B8) {
                  if (uH) return uH = false, void uI["off"]("Game.TransactionStateTransition", B9);
                  "action" === B8["payload"]['to'] && (0x0 === uI["transactionModel"]["markReadIndex"] ? (uH = true, B8["intercept"](), uI["emit"]("Game.LastTransactionUnread", undefined, function () {
                    {
                      B8["propagate"]();
                    }
                  }), uI["markRead"]()) : uI["off"]("Game.TransactionStateTransition", B9));
                };
              uI['on']("Game.TransactionStateTransition", B9, undefined, "Low");
            }
          }
          var BJ = u7["tickCallback"],
            BF = false,
            BM = false,
            BI = false,
            Bx = false,
            BT = false;
          function Bk(uI) {
            {
              uI !== BI && (BI = uI, uO()["emit"]("Game.InUIIdleState", BI));
            }
          }
          var BO,
            BC,
            BL = P("UIIdleStateHandler", {
              'initUIIdleStateEventWrapper': function (uI) {
                {
                  var uI = uO();
                  zs["addGamePlayUIBlockEventCallback"]("uiidle", function (uI) {
                    var uH = function () {
                      {
                        BF && !BT && Bk(!Bx);
                      }
                    };
                    (Bx = uI) ? uH() : BJ(false)(uH);
                  }), uI['on']("Game.AutoplayStateChanged", function (uI) {
                    (BM = "Start" === uI["payload"]) ? Bk(false) : BF && Bk(true);
                  }), uI["systemModel"]["operatorJurisdiction"]["replayVersion"] > 0x0 && (uI['on']("Game.RequestReplay", function () {
                    {
                      BT = true, Bk(false);
                    }
                  }), uI['on']("Game.ReplayQuit", function () {
                    BT = false, Bk(true);
                  }));
                }
              },
              'gameEnterUIIdleState': function (uI) {
                {
                  (BF = uI) ? BJ(false)(function () {
                    {
                      BM || Bx || Bk(true);
                    }
                  }) : BM || Bk(false);
                }
              }
            }),
            Bm = 0x0,
            BU = jM["realModeUrl"] ? jM["realModeUrl"] : undefined,
            BZ = shell["I18n"]['t']("General.DemoMessage"),
            BD = 0x0,
            Bh = 0x0,
            BY = shell["I18n"]['t']("General.DemoContinue"),
            Bw = shell["I18n"]['t']("General.DialogRealMoney"),
            BV = false,
            Bq = false;
          function BK() {
            {
              Bm = BD > 0x0 ? BD : 0x14 + Math["floor"](0x15 * Math["random"]()), BO && (BO(), BO = undefined), BV = false;
            }
          }
          function BA(uI) {
            {
              Bq = uI, uI || (BC = undefined);
            }
          }
          function BG() {
            if (0x0 !== Bh) {
              {
                var uI = u7["timeoutCallback"];
                BO = uI(Bh)(function () {
                  {
                    BO = undefined, Bq ? Bf({
                      'onDemoCountReachedCallback': BC
                    }) : BV = true;
                  }
                });
              }
            }
          }
          function Bf(uI) {
            var uI = uI["onDemoCountReachedCallback"],
              uI = uI["finalCallback"];
            BK(), uI && uI();
            var uH = [{
              'title': BY,
              'handler': function () {
                uI && uI(true), BG();
              }
            }];
            BU ? uH["push"]({
              'title': Bw,
              'handler': jh["quitGameWithEventForRealMode"](BU)
            }) : uH["push"]({
              'title': shell["I18n"]['t']("General.DialogQuit"),
              'handler': jh["quitGameWithEvent"]("Demo Reminder")
            }), uw({
              'title_message': '',
              'content_message': BZ,
              'actions': uH
            });
          }
          var Bg = new (function () {
              function uI() {
                this["bv_gi"] = 0x0, this["bv_Si"] = false, this["bv_yi"] = 0x0, this["bv_Gi"] = 0x0, this["bv_wi"] = 0x0;
              }
              return uI["prototype"]["setReminderTimer"] = function (uI, uI) {
                {
                  undefined === uI && (uI = 0x0), uI && uI > 0x0 && (this["bv_Gi"] = uI - uI % uI, this["bv_yi"] = uI, this["bv_Ci"]());
                }
              }, uI["prototype"]["checkForHealthReminder"] = function () {
                {
                  return !!this["bv_Si"] && (new Date()["getTime"]() - this["bv_gi"]) / 0x3e8 >= this["bv_wi"];
                }
              }, uI["prototype"]["bv_Ti"] = function () {
                this["bv_Gi"] = this["bv_yi"], this["bv_Ci"]();
              }, uI["prototype"]["bv_Ci"] = function () {
                this["bv_Si"] = true, this["bv_wi"] = this["bv_Gi"], this["bv_gi"] = new Date()["getTime"]();
              }, uI["prototype"]["showHealthAlertDialog"] = function (uI, uI, uH) {
                var B9 = this,
                  B8 = {
                    'title_message': shell["I18n"]['t']("HealthReminder.HealthCareTitle"),
                    'content_message': shell["I18n"]['t']("HealthReminder.HealthCareSentence", {
                      'value': this["getHealthTimeString"]()
                    }),
                    'actions': [{
                      'title': shell["I18n"]['t']("HealthReminder.HealthCareReminderExit"),
                      'handler': function () {
                        {
                          B9["bv_Ti"](), uI && uI();
                        }
                      },
                      'auto_dismiss': false
                    }, {
                      'title': shell["I18n"]['t']("HealthReminder.HealthCareReminderContinue"),
                      'handler': function () {
                        B9["bv_Ti"](), uI && uI();
                      }
                    }]
                  };
                uH && B8["actions"]["unshift"]({
                  'title': shell["I18n"]['t']("HealthReminder.ViewGameHistory"),
                  'handler': function () {
                    {
                      uO()["emit"]("Window.Redirect", uH);
                    }
                  },
                  'auto_dismiss': false
                }), uw(B8);
              }, uI["prototype"]["getHealthTimeString"] = function () {
                var uI = this["bv_yi"],
                  uI = '';
                if (uI >= 0xe10) {
                  var uH = Math["floor"]((B8 = Math["floor"](uI / 0x3c)) / 0x3c);
                  B8 = Math["floor"](B8 % 0x3c);
                  var B9 = Math["floor"](uI % 0x3c);
                  return uH > 0x0 && (uI += shell["I18n"]['t']("HealthReminder.ReminderHours", uH)), B8 > 0x0 && (uI += '\x20' + shell["I18n"]['t']("HealthReminder.ReminderMinutes", B8)), B9 > 0x0 && (uI += '\x20' + shell["I18n"]['t']("HealthReminder.ReminderSeconds", B9)), uI;
                }
                if (uI >= 0x3c) {
                  var B8 = Math["floor"](uI / 0x3c);
                  return B9 = Math["floor"](uI % 0x3c), B8 > 0x0 && (uI += shell["I18n"]['t']("HealthReminder.ReminderMinutes", B8)), B9 > 0x0 && (uI += '\x20' + shell["I18n"]['t']("HealthReminder.ReminderSeconds", B9)), uI;
                }
                return shell["I18n"]['t']("HealthReminder.ReminderSeconds", uI);
              }, uI;
            }())(),
            P0 = "Game.ViewLoading",
            P1 = "Game.ViewError",
            P2 = "Game.ViewSuccess",
            P3 = "Game.ViewWarning",
            P4 = "Game.ViewPopulated";
          function P5(uI) {
            {
              return uI["replace"](/[0-9]/g, '');
            }
          }
          function P6(uI) {
            {
              return ["c ont ext", "eve nt", "em it "][uI]["split"]('')["filter"](function (uI) {
                return '\x20' !== uI;
              })["join"]('');
            }
          }
          function P7(uI) {
            return function () {
              {
                var uI = P5("Ma01th"),
                  uI = B[uI],
                  uH = 0x0;
                undefined === uI && (uI = uI["random"]() * B["Number"]("0xf") | 0x0);
                var B9 = function (B8) {
                  var uQ,
                    B7,
                    B8 = [P0, P1, P2, P3, P4]["map"](function (B8) {
                      {
                        return B8["substring"](0x4);
                      }
                    });
                  return B8[(uQ = B8, B7 = B8["length"], (uQ % B7 + B7) % B7)];
                }(uI);
                B[P5("shell1")][P6(uH++)][P6(uH++)][P6(uH++)]("Game"["concat"](B9));
              }
            };
          }
          function P8(uI) {
            return function (uI) {
              jM["reminderInterval"] && function (uI) {
                {
                  var uH, B9;
                  uH = jM["timeElapsed"] ? parseInt(jM["timeElapsed"], 0xa) : undefined, B9 = jM["reminderInterval"] ? parseInt(jM["reminderInterval"], 0xa) : undefined, Bg["setReminderTimer"](B9, uH), uO()['on']("Game.TransactionStateComplete", function (B8) {
                    {
                      var uQ = B8["payload"];
                      uI["isGameReplaying"] || 0x1 !== uI["transactionModel"]["stateTransitionTo"] || "action" !== uQ['to'] || (B8["intercept"](), function (B7) {
                        Bg["checkForHealthReminder"]() ? Bg["showHealthAlertDialog"](jh["quitGameWithEvent"]("Setting Health Alert"), B7, jM["reminderUrl"]) : B7 && B7();
                      }(function () {
                        {
                          B8["propagate"]();
                        }
                      }));
                    }
                  });
                }
              }(uI), 0x2 === parseInt(jM["betType"], 0xa) && function (uI) {
                {
                  var uH = uO();
                  (function (B9) {
                    {
                      if (B9) {
                        var B8 = B9["realURL"],
                          uQ = B9["dialogMessage"],
                          B7 = B9["triggerSpinCount"],
                          B8 = B9["triggerDuration"],
                          B8 = B9["leftButtonLabel"],
                          uQ = B9["rightButtonLabel"];
                        B8 && '' !== B8 && (BU = B8), uQ && '' !== uQ && (BZ = uQ), BD = B7 || 0x0, Bh = B8 || 0x0, B8 && '' !== B8 && (BY = B8), uQ && '' !== uQ && (Bw = uQ);
                      }
                      var l6 = uO(),
                        l6 = function (l8) {
                          {
                            "GameStarted" === l8["payload"] && (l6["off"]("Shell.BootStateChanged", l6), BG());
                          }
                        };
                      l6['on']("Shell.BootStateChanged", l6), BK();
                    }
                  })(uI["systemModel"]["operatorJurisdiction"]["customDemoConfig"]), uH['on']("Game.TransactionStateTransition", function (B9) {
                    {
                      var B8,
                        uQ,
                        B7,
                        B8 = B9["payload"];
                      0x1 === uI["transactionModel"]["stateTransitionTo"] && "idle" === B8['to'] && (B9["intercept"](), uQ = (B8 = {
                        'onDemoCountReachedCallback': function () {
                          return uH["emit"]("Game.StopAutoplay");
                        },
                        'finalCallback': function () {
                          B9["propagate"](), BA(true);
                        }
                      })["onDemoCountReachedCallback"], B7 = B8["finalCallback"], BC = uQ, 0x0 === Bm || BV ? Bf(B8) : B7 && B7(false));
                    }
                  }, undefined, "Low"), uH['on']("Game.TransactionStateChanged", function (B9) {
                    var B8 = B9["payload"];
                    0x1 === uI["transactionModel"]["stateTransitionTo"] && "action" === B8['to'] && (Bm -= 0x1, BA(false));
                  });
                }
              }(uI), function (uI) {
                var uH = uO(),
                  B9 = false;
                uH['on']("Game.TransactionStateChanged", function (B8) {
                  var uQ = B8["payload"];
                  "idle" === uQ['to'] && "setup" === uQ["from"] && BL["gameEnterUIIdleState"](true);
                }, undefined, "Low"), uH['on']("Game.TransactionStateComplete", function (B8) {
                  {
                    "action" === B8["payload"]['to'] && 0x1 === uI["transactionModel"]["stateTransitionTo"] && (BL["gameEnterUIIdleState"](false), B9 || (B9 = true, function (uQ, B7) {
                      B7["intercept"](), uQ["event"]["emit"]("Game.TransactionStatePaused", undefined, function (B8) {
                        {
                          return function (B8) {
                            {
                              var uQ = B8["response"];
                              uQ < 0xf ? 0x2 & uQ && (B8["propagate"](), 0x1 & uQ || 0x4 & uQ ? P7(B[uM(0x4)]["floor"](B[uM(0x4)]["random"]() * B["Number"]("0x2")) ? B["Number"]("0x0") : B["Number"]("0x3"))() : P7(B["Number"]("0x0"))()) : B8["propagate"]();
                            }
                          };
                        }
                      }(B7));
                    }(uC(), B8)));
                  }
                }, undefined, "High");
              }(uI), uI && uI();
            };
          }
          function P9(uI, uI) {
            {
              var uI = false,
                uH = uO();
              uH['on']("Game.TransactionStateChanged", function (B9) {
                {
                  if ("result" === B9["payload"]['to'] && 0x1 === uI["transactionModel"]["previousGameState"]) {
                    var B8 = uI["transactionModel"]["balanceAfterBet"],
                      uQ = uI["playerModel"]["balance"];
                    uH["emit"]("Game.UpdateTransactionInfo", {
                      'balance': B8
                    }, function () {
                      uI["playerModel"]["balance"] = uQ;
                    }), uI || (uI = true, function (B7) {
                      {
                        B7["event"]["emit"]("Game.TransactionStateStarted", undefined, function (B8) {
                          var B8 = B8["response"];
                          (B8["error"] || false === B8) && P7(B["Number"]("0x3"))();
                        });
                      }
                    }(uC()));
                  }
                }
              }), uH['on']("Game.DummyTransactionStateChanged", function (B9) {
                {
                  if ("result" === B9["payload"]['to'] && 0x1 === uI["transactionModel"]["previousGameState"]) {
                    var B8 = uI["transactionModel"]["balanceAfterBet"];
                    uI && uI(B8);
                  }
                }
              });
            }
          }
          var Pu,
            Pj,
            PE,
            Pz = u7["formatCurrency"];
          function PX(uI) {
            {
              var uI = uO();
              uI["once"]("Game.GameInfoUpdated", function (uI) {
                {
                  uI["payload"]['dt']["maxwm"] && uI['on']("Game.TransactionStateComplete", function (uH) {
                    {
                      if ("setup" === uH["payload"]['to'] && uI["lastTransactionRawData"]["imw"]) {
                        {
                          uH["intercept"]();
                          var B9 = uI["transactionModel"]["accumulatedWinAmount"];
                          uw({
                            'title_message': shell["I18n"]['t']("MaxWin.Title"),
                            'content_message': shell["I18n"]['t']("MaxWin.Message", {
                              'amount': Pz(B9)
                            }),
                            'actions': [{
                              'title': shell["I18n"]['t']("General.DialogOk"),
                              'handler': function () {
                                {
                                  uH["propagate"]();
                                }
                              }
                            }]
                          });
                        }
                      }
                    }
                  });
                }
              });
            }
          }
          !function (uI) {
            {
              uI["EMIT_AUTHENTICATION"] = "authentication", uI["EMIT_EXTEND_SESSION"] = "est", uI["LISTENER_DISCONNECT"] = "disconnect", uI["LISTENER_JOINED_GAME"] = "joined", uI["LISTENER_ERROR_OCCURED"] = "err", uI["LISTENER_WALLET_BALANCE_UPDATED"] = 'bu', uI["LISTENER_NEW_WALLET"] = "pwr";
            }
          }(Pu || (Pu = {})), function (uI) {
            uI[uI["SOCKET_RETURN"] = 0x0] = "SOCKET_RETURN", uI[uI["EMIT"] = 0x1] = "EMIT", uI[uI["CONNECTION"] = 0x2] = "CONNECTION", uI[uI["GLOBAL"] = 0xa] = "GLOBAL";
          }(Pj || (Pj = {})), function (uI) {
            uI[uI["UNKNOWN"] = 0x0] = "UNKNOWN", uI[uI["PREPARING"] = 0x1] = "PREPARING", uI[uI["READY"] = 0x2] = "READY", uI[uI["PLAYING"] = 0x3] = "PLAYING", uI[uI["WATCHING"] = 0x4] = "WATCHING", uI[uI["DISCONNECTING"] = 0x5] = "DISCONNECTING", uI[uI["LEFT"] = 0x6] = "LEFT", uI[uI["PENDING"] = 0x63] = "PENDING";
          }(PE || (PE = {}));
          var PB,
            PP = new (function () {
              {
                function uI() {
                  {
                    this["bv_Oi"] = undefined, this["bv_Ri"] = undefined;
                  }
                }
                return uI["prototype"]["updateDialogMessage"] = function (uI) {
                  {
                    var uI = this["bv_Oi"];
                    uI && (uI["info"] = uI, uO()["emit"]("Alert.UpdateContent", uI));
                  }
                }, uI["prototype"]["showNonStackDialog"] = function (uI, uI) {
                  this["dismissCurrentDialog"](), this["bv_Ri"] = uI;
                  var uH = [],
                    B9 = this["bv_Ei"](uI, uH);
                  uO()["emit"]("Alert.Show", B9, function (B8) {
                    {
                      var uQ = B8["response"],
                        B7 = uH[uQ];
                      B7 && B7();
                    }
                  }), this["bv_Oi"] = B9;
                }, uI["prototype"]["dismissCurrentDialog"] = function () {
                  {
                    var uI = this["bv_Oi"];
                    this["bv_Oi"] && (this["bv_Oi"] = undefined, uO()["emit"]("Alert.Clear", uI), this["bv_Ri"] && (this["bv_Ri"](), this["bv_Ri"] = undefined));
                  }
                }, uI["prototype"]["cleanDialogDismissCallback"] = function () {
                  this["bv_Ri"] = undefined;
                }, uI["prototype"]["bv_Ei"] = function (uI, uI) {
                  var uH = [],
                    B9 = 0x0;
                  return uI["actions"] && uI["actions"]["forEach"](function (B8) {
                    {
                      uH["push"]({
                        'label': B8["title"],
                        'handler': B9
                      }), uI["push"](B8["handler"]), B9++;
                    }
                  }), {
                    'title': uI["titleMessage"],
                    'content': uI["contentMessage"],
                    'actions': uH
                  };
                }, uI;
              }
            }())(),
            Pl = {
              'path': "/socket/message-hub/v2/socket.io",
              'reconnectionDelayMax': 0x1388,
              'reconnectionAttempts': 0x3,
              'transports': ["websocket"]
            };
          function PN(uI, uI, uI) {
            {
              var uH = Pl;
              return uI && (uH = u1(u1({}, Pl), uI)), io["connect"](uI + uI, uH);
            }
          }
          var Pp = {};
          function Pd(uI, uI, uI) {
            {
              Pp[uI]['on'](uI, function (uH) {
                {
                  uI && uI(uH);
                }
              });
            }
          }
          var PW = function () {
              {
                function uI() {
                  {
                    this["isFirstConnect"] = true, this["socketNsp"] = 'o', this["onError"] = false, this["eventTypePool"] = Object["create"](null), this["eventPool"] = Object["create"](null), this["eventActivated"] = Object["create"](null);
                  }
                }
                return uI["prototype"]["setOnJoinedCallback"] = function (uI) {
                  this["onJoinedCallback"] = uI;
                }, uI["prototype"]["init"] = function (uI) {
                  var uI,
                    uH,
                    B9,
                    B8 = this;
                  this["dataSource"] = uI, uI = uI["systemModel"]["apiDomain"], uH = this["socketNsp"], B9 = {
                    'path': this["getSocketConnectionPath"]()
                  }, Pp[uH] = PN(uI, uH, B9), this["addEvent"](), this["eventTypePool"][Pj["CONNECTION"]]["concat"](this["eventTypePool"][Pj["GLOBAL"]])["forEach"](function (uQ) {
                    {
                      var B7 = B8["eventPool"][uQ]['fn'];
                      Pd(uQ, B8["socketNsp"], B7);
                    }
                  });
                }, uI["prototype"]["setShowErrorCallback"] = function (uI) {
                  this["showErrorCallback"] = uI;
                }, uI["prototype"]["connect"] = function () {
                  var uI;
                  uI = this["socketNsp"], Pp[uI]["open"]();
                }, uI["prototype"]["emit"] = function (uI, uI) {
                  {
                    var uH = this["eventPool"][uI];
                    if (uH) {
                      var B9 = uH['fn'];
                      uI ? B9 && B9(uI) : B9 && B9(), uH["once"] && this["off"](uI);
                    }
                  }
                }, uI["prototype"]["activateEvents"] = function (uI) {
                  var uI = this,
                    uH = this["eventActivated"];
                  uH[uI] || (uH[uI] = true, this["eventTypePool"][uI]["forEach"](function (B9) {
                    {
                      var B8 = uI["eventPool"][B9]['fn'];
                      Pd(B9, uI["socketNsp"], B8);
                    }
                  }));
                }, uI["prototype"]["removeEvents"] = function (uI) {
                  {
                    var uI = this,
                      uH = this["eventActivated"];
                    uH[uI] && (uH[uI] = false, this["eventTypePool"][uI]["forEach"](function (B9) {
                      {
                        var B8, uQ;
                        B8 = B9, uQ = uI["socketNsp"], Pp[uQ]["off"](B8);
                      }
                    }));
                  }
                }, uI["prototype"]['on'] = function (uI, uI) {
                  {
                    this["_on"](uI, Pj["SOCKET_RETURN"], uI, false);
                  }
                }, uI["prototype"]["off"] = function (uI) {
                  var uI = this["eventPool"];
                  uI[uI] = Object["create"](null), delete uI[uI];
                }, uI["prototype"]["once"] = function (uI, uI) {
                  this["_on"](uI, Pj["SOCKET_RETURN"], uI, true);
                }, uI["prototype"]["_on"] = function (uI, uI, uH, B9) {
                  if (undefined === B9 && (B9 = false), "function" == typeof uH) {
                    this["eventPool"][uI] = B9 ? {
                      'fn': uH,
                      'once': B9
                    } : {
                      'fn': uH
                    };
                    var B8 = this["eventTypePool"],
                      uQ = B8[uI];
                    uQ || (uQ = B8[uI] = []);
                    var B7 = uQ["indexOf"](uI);
                    -0x1 !== B7 ? uQ[B7] = uI : uQ["push"](uI);
                  }
                }, uI["prototype"]["showErrorMessage"] = function (uI, uI) {
                  undefined === uI && (uI = false);
                  var uH,
                    B9 = shell["ServerError"];
                  uH = uI ? jm["Unknown"] : B9["isInsufficientCashFundError"](uI["code"]) ? jm["Transaction"] : jm["Launch"], this["showErrorCallback"](uI, uH, function (B8) {
                    switch (B8) {
                      case jU["Retry"]:
                      case jU["Reload"]:
                        jk["refreshGame"]();
                        break;
                      case jU["Quit"]:
                        jk["quitGame"]();
                    }
                  });
                }, uI["prototype"]["getSocketConnectionPath"] = function () {
                  return "/socket/message-hub/v2/socket.io";
                }, uI["prototype"]["addEvent"] = function () {
                  this["_on"](Pu["LISTENER_DISCONNECT"], Pj["CONNECTION"], this["onDisconnect"]["bind"](this)), this["_on"](Pu["LISTENER_JOINED_GAME"], Pj["CONNECTION"], this["bv_xi"]["bind"](this)), this["_on"](Pu["LISTENER_ERROR_OCCURED"], Pj["GLOBAL"], this["onErrorOccured"]["bind"](this)), this["onAddEvent"]();
                }, uI["prototype"]["onAddEvent"] = function () {}, uI["prototype"]["onDisconnect"] = function (uI) {
                  if (!this["onError"] && "io server disconnect" === uI) {
                    var uI = new (0x0, shell["Error"])(shell["ServerError"]["Domain"], 0x51c);
                    this["showErrorMessage"](uI);
                  }
                }, uI["prototype"]["bv_xi"] = function () {
                  {
                    this["onJoinedCallback"] && this["onJoinedCallback"](), this["onJoinedCallback"] = undefined;
                  }
                }, uI["prototype"]["onErrorOccured"] = function (uI) {
                  var uI = shell["Error"],
                    uH = shell["WebSocketError"],
                    B9 = shell["ServerError"],
                    B8 = parseInt(uI['cd'], 0xa),
                    uQ = new uI(0x51c === B8 || B9["isInsufficientCashFundError"](B8) ? B9["Domain"] : uH["Domain"], uI['cd'], uI["tid"]);
                  this["onError"] = true, this["showErrorMessage"](uQ);
                }, uI;
              }
            }(),
            Pb = u7["deferCallback"],
            PH = (0x0, u7["getPlatform"])(),
            PS = function (uI) {
              {
                function uI() {
                  var uI = null !== uI && uI["apply"](this, arguments) || this;
                  return uI["socketNsp"] = 'o', uI["emitAuthentication"] = false, uI["bv_ki"] = false, uI["bv_ji"] = false, uI["bv_Ii"] = false, uI["bv_Ai"] = 0x0, uI;
                }
                return u0(uI, uI), uI["prototype"]["init"] = function (uI) {
                  var uH = this;
                  this["dataSource"] = uI;
                  var B9 = uI["playerModel"],
                    B8 = uI["systemModel"],
                    uQ = {
                      'tk': B9["token"],
                      'btt': B8["betType"],
                      'gid': B8["gameId"],
                      'pf': PH
                    };
                  this["bv_Ni"] = this["bv_Li"]["bind"](this);
                  var B7 = uO();
                  B7['on']("Game.OperatorSocketConnected", function (B8) {
                    uH["bv_Ii"] = B8["payload"];
                  }), function (B8, B8, uQ, l6) {
                    {
                      var l6 = true,
                        l8 = false;
                      (PB = PN(B8["server"], 'o', B8["socketConfig"]))['on']("connect", function () {
                        if (l6) PB["emit"]("authentication", B8["authenticateParam"]);else if (l8) l8 = false, PB["emit"]("authentication", B8["authenticateParam"]);else {
                          {
                            l8 = true, uQ && uQ();
                            var uQ = PB['io']["nsps"],
                              lE = Object["keys"](uQ),
                              lz = lE["length"],
                              lX = function () {
                                var lP = 0x0;
                                lE["forEach"](function (lz) {
                                  var lX = uQ[lz];
                                  lX["once"]("disconnect", function () {
                                    ++lP === lz && PB["open"]();
                                  }), lX["close"]();
                                });
                              };
                            lB = 0x0, lE["forEach"](function (lP) {
                              var lz = uQ[lP];
                              '/o' !== lz["nsp"] ? lz["once"]("connect", function () {
                                {
                                  ++lB === lz && lX();
                                }
                              }) : ++lB === lz && lX();
                            });
                          }
                        }
                        var lB;
                      });
                      var uQ = function (uQ) {
                        B8 && B8(uQ);
                      };
                      PB["once"]("err", uQ), PB['on']("joined", function () {
                        {
                          if (l6) B8 && B8(undefined, PB), l6 = false, PB["off"]("err", uQ);else {
                            {
                              var uQ = PB['io']["nsps"];
                              Object["keys"](uQ)["forEach"](function (lE) {
                                {
                                  var lz = uQ[lE];
                                  '/o' !== lz["nsp"] && lz["open"]();
                                }
                              }), l6 && l6();
                            }
                          }
                        }
                      });
                    }
                  }({
                    'server': B8["apiDomain"],
                    'authenticateParam': uQ,
                    'socketConfig': {
                      'path': this["getSocketConnectionPath"]()
                    }
                  }, function (B8, B8) {
                    B8 ? (uH["bv_Mi"] = B8, uH["addEvent"](), uH["eventTypePool"][Pj["CONNECTION"]]["concat"](uH["eventTypePool"][Pj["GLOBAL"]])["forEach"](function (uQ) {
                      {
                        var l6 = uH["eventPool"][uQ]['fn'];
                        B8['on'](uQ, l6);
                      }
                    }), B7["emit"]("Game.OperatorSocketConnected", true), uH["onJoinedCallback"] && uH["onJoinedCallback"](), uH["onJoinedCallback"] = undefined) : B8 && uH["bv_ji"] && uH["onErrorOccured"](B8);
                  }, function () {
                    B7["emit"]("Game.OperatorSocketConnected", false);
                  }, function () {
                    B7["emit"]("Game.OperatorSocketConnected", true);
                  });
                }, uI["prototype"]["activateEvents"] = function (uI) {
                  var uH = this,
                    B9 = this["eventActivated"];
                  B9[uI] || (B9[uI] = true, this["eventTypePool"][uI]["forEach"](function (B8) {
                    {
                      var uQ = uH["eventPool"][B8]['fn'];
                      uH["bv_Mi"]['on'](B8, uQ);
                    }
                  }));
                }, uI["prototype"]["removeEvents"] = function (uI) {
                  var uH = this,
                    B9 = this["eventActivated"];
                  B9[uI] && (B9[uI] = false, this["eventTypePool"][uI]["forEach"](function (B8) {
                    {
                      uH["bv_Mi"]["off"](B8);
                    }
                  }));
                }, uI["prototype"]["setAdditionalConfig"] = function (uI) {
                  {
                    this["bv_ki"] = uI["toSubscribeSessionEvent"], this["bv_ji"] = uI["isSocketGame"];
                  }
                }, Object["defineProperty"](uI["prototype"], "connectionStatus", {
                  'get': function () {
                    {
                      return this["bv_Ii"];
                    }
                  },
                  'enumerable': false,
                  'configurable': true
                }), uI["prototype"]["onAddEvent"] = function () {
                  this["bv_ki"] && function (uI) {
                    if (!PB) throw Error("Operation socket are not connected");
                    PB['on']("sessionExpiring", function (uH) {
                      uI(uH);
                    });
                  }(this["bv_Pi"]["bind"](this));
                }, uI["prototype"]["onErrorOccured"] = function (uI) {
                  var uH = shell["Error"],
                    B9 = shell["ServerError"];
                  this["onError"] = true;
                  var B8 = new uH(B9["Domain"], uI['cd'], uI["tid"]);
                  uO()["emit"]("Game.OperatorSocketError", B8), this["bv_Mi"] ? (this["bv_Mi"]["off"](Pu["LISTENER_DISCONNECT"]), this["bv_ki"] && (this["bv__i"](), PP["dismissCurrentDialog"](), this["showErrorMessage"](B8, true), EA["reportCriticalError"]())) : this["showErrorMessage"](B8);
                }, uI["prototype"]["onDisconnect"] = function (uI) {
                  if (!this["onError"] && "io server disconnect" === uI) if (this["bv_ji"]) {
                    {
                      var uH = new (0x0, shell["Error"])(shell["ServerError"]["Domain"], 0x51c);
                      this["showErrorMessage"](uH);
                    }
                  } else uO()["emit"]("Game.OperatorSocketConnected", false);
                }, uI["prototype"]["bv_Pi"] = function (uI) {
                  var uH = this;
                  if (0x1 === uI) {
                    {
                      var B9 = this["bv_ji"] ? 0x3c : 0x1e,
                        B8 = new Date()["getTime"]() / 0x3e8 + (0x3c - B9);
                      this["bv_Ai"] = B9 + 0x1;
                      var uQ = function () {
                        {
                          var B7 = new Date()["getTime"]() / 0x3e8,
                            B8 = Math["ceil"](B9 - (B7 - B8));
                          if (B8 > 0x0 && B8 < uH["bv_Ai"]) {
                            var B8 = shell["I18n"],
                              uQ = B8['t']("ErrorLib.SessionExpiringMessage", {
                                'countdown': B8["toString"]()
                              });
                            B8 === B9 ? PP["showNonStackDialog"]({
                              'titleMessage': '\x20',
                              'contentMessage': uQ,
                              'actions': [{
                                'title': B8['t']("General.DialogContinue"),
                                'handler': function () {
                                  uH["bv__i"](), function () {
                                    if (!PB) throw Error("Operation socket are not connected");
                                    PB["emit"]("est", true);
                                  }();
                                }
                              }, {
                                'title': B8['t']("General.DialogQuit"),
                                'handler': function () {
                                  uH["bv__i"](), jk["quitGame"]();
                                }
                              }]
                            }) : PP["updateDialogMessage"]({
                              'title': '\x20',
                              'content': uQ
                            }), uH["bv_Ai"] = B8;
                          } else B8 <= 0x0 && (uH["bv__i"](), PP["dismissCurrentDialog"]());
                          uH["bv_Ai"] > 0x0 && (uH["bv_Di"] = Pb(true)(uQ));
                        }
                      };
                      uQ(), uO()["once"]("Game.TransactionInfoUpdated", this["bv_Ni"]);
                    }
                  }
                }, uI["prototype"]["bv_Li"] = function () {
                  {
                    this["dataSource"]["isGameReplaying"] || (this["bv__i"](), PP["dismissCurrentDialog"]());
                  }
                }, uI["prototype"]["bv__i"] = function () {
                  var uI = this["bv_Di"];
                  this["bv_Di"] = undefined, uI && uI(), this["bv_Ai"] = 0x0, uO()["off"]("Game.TransactionInfoUpdated", this["bv_Ni"]);
                }, uI;
              }
            }(PW),
            Pc = new PS(),
            Ps = function (uI) {
              {
                function uI() {
                  {
                    var uI = null !== uI && uI["apply"](this, arguments) || this;
                    return uI["bv_Ot"] = true, uI["bv_Ui"] = false, uI["socketNsp"] = 'w', uI;
                  }
                }
                return u0(uI, uI), uI["prototype"]["setBalanceUpdateEnable"] = function (uI) {
                  this["bv_Ot"] = uI;
                }, uI["prototype"]["setAdditionalConfig"] = function (uI) {
                  {
                    this["bv_Ui"] = uI["subscribeBalanceUpdate"];
                  }
                }, uI["prototype"]["subscribeNewWallet"] = function (uI) {
                  {
                    this["bv_Hi"] = uI;
                  }
                }, uI["prototype"]["onAddEvent"] = function () {
                  {
                    var uI = this;
                    this["bv_Ui"] && this["_on"](Pu["LISTENER_WALLET_BALANCE_UPDATED"], Pj["GLOBAL"], this["bv_Bi"]["bind"](this)), this["bv_Hi"] && this["_on"](Pu["LISTENER_NEW_WALLET"], Pj["GLOBAL"], this["bv_Fi"]["bind"](this)), uO()["once"]("Game.OperatorSocketError", function () {
                      uI["onError"] = true;
                    });
                  }
                }, uI["prototype"]["onErrorOccured"] = function (uI) {
                  {
                    this["onError"] || uI["prototype"]["onErrorOccured"]["call"](this, uI);
                  }
                }, uI["prototype"]["onDisconnect"] = function () {
                  {
                    this["onError"];
                  }
                }, uI["prototype"]["bv_Bi"] = function (uI) {
                  if (this["bv_Ot"]) {
                    var uH = uO(),
                      B9 = uI['bl'];
                    uH["emit"]("Game.UpdateTransactionInfo", {
                      'balance': B9
                    });
                  }
                }, uI["prototype"]["bv_Fi"] = function (uI) {
                  {
                    this["bv_Hi"] && this["bv_Hi"](uI);
                  }
                }, uI;
              }
            }(PW),
            PR = new Ps();
          function PQ(uI, uI, uI, uH, B9) {
            {
              Pc["setShowErrorCallback"](uH), Pc["setOnJoinedCallback"](B9), Pc["setAdditionalConfig"]({
                'toSubscribeSessionEvent': uI,
                'isSocketGame': uI
              }), Pc["init"](uI);
            }
          }
          function Py(uI, uI, uI, uH, B9, B8, uQ) {
            if (PR["setShowErrorCallback"](B8), PR["setOnJoinedCallback"](uQ), PR["setAdditionalConfig"]({
              'subscribeBalanceUpdate': uI
            }), uI && uH && uO()['on']("Game.TransactionStateComplete", function (l6) {
              {
                var l6 = l6["payload"];
                0x1 === uI["transactionModel"]["stateTransitionTo"] && ("idle" === l6['to'] ? PR["setBalanceUpdateEnable"](true) : "action" === l6['to'] && PR["setBalanceUpdateEnable"](false));
              }
            }, undefined, "Low"), uI && B9) {
              {
                var B7 = false,
                  B8 = false,
                  B8 = false,
                  uQ = uO();
                PR["subscribeNewWallet"](function (l6) {
                  if (l6["gids"]["includes"](uI["systemModel"]["gameId"])) if (B8) uQ["emit"]("Game.HasNewWallet");else {
                    {
                      var l6 = l6['wt'];
                      'G' === l6 ? B8 = true : 'B' === l6 && (B7 = true);
                    }
                  }
                }), uQ['on']("Game.FreeGameListOpened", function () {
                  B8 = false;
                }), uQ['on']("Game.BonusWalletListOpened", function () {
                  {
                    B7 = false;
                  }
                }), zs["addInUIIdleStateCallback"]("NewWalletNotification", false, function (l6, l6) {
                  {
                    B8 = l6, l6 && (B8 || B7 ? (B8 = B7 = false, uQ["emit"]("Game.HasNewWallet", undefined, function () {
                      {
                        l6 && l6();
                      }
                    })) : l6 && l6());
                  }
                });
              }
            }
            PR["init"](uI);
          }
          function Pv() {
            return Pc["connectionStatus"];
          }
          function PJ(uI) {
            {
              PR["setBalanceUpdateEnable"](uI);
            }
          }
          function PF(uI) {
            PR["setBalanceUpdateEnable"](uI);
          }
          function PM(uI, uI, uI) {
            uI["intercept"]();
            var uH = shell["Error"],
              B9 = shell["ClientError"],
              B8 = new uH(B9["Domain"], B9["GameResultVerificationError"]),
              uQ = uI["lastTransactionRawData"]["sid"],
              B7 = ''["concat"](uI, ", spin id: ")["concat"](uQ);
            jw["showError"](B8, jm["Unknown"], function (B8) {
              switch (B8) {
                case jU["Reload"]:
                  jk["refreshGame"]();
                  break;
                case jU["Quit"]:
                  jk["quitGame"]();
              }
            }, B7, true);
          }
          function PI(uI, uI) {
            var uI = [],
              uH = uO(),
              B9 = uI && uI["customSymbolOffset"] ? uI["customSymbolOffset"] : {
                'x': 0xa,
                'y': 0xa
              };
            uH['on']("Game.TransactionStateComplete", function (B8) {
              {
                if ("prize" === B8["payload"]['to']) {
                  {
                    var uQ = uI && uI["getCustomReel"] && uI["getCustomReel"]() || uI["lastTransactionRawData"]['rl']["slice"](),
                      B7 = [],
                      B8 = [],
                      B8 = [],
                      uQ = 0x0,
                      l6 = 0x0,
                      l6 = 0x0;
                    if (uI && uI["bigSymbolConfig"]) {
                      var l8 = uI["bigSymbolConfig"],
                        uQ = l8["slotWidth"],
                        uQ = l8["colNum"];
                      uQ = uQ / uQ / 0x2;
                    }
                    if (uI["forEach"](function (lk) {
                      if (lk["visible"]) if (B7["length"]) for (var lc = lk["symbolRow"], lL = uQ * (lc - 0x1), lm = lk["node"]["convertToWorldSpaceAR"](cc['v2'](-lL, lL)), lU = B7["length"] - 0x1; lU >= 0x0; lU--) {
                        {
                          var lZ = B7[lU],
                            lD = lZ["symbolRow"],
                            lD = uQ * (lD - 0x1),
                            lY = lZ["node"]["convertToWorldSpaceAR"](cc['v2'](-lD, lD));
                          if (lm['x'] > lY['x'] + B9['x']) {
                            B7["splice"](lU + 0x1, 0x0, lk);
                            break;
                          }
                          if (lm['x'] < lY['x'] - B9['y']) {
                            if (0x0 === lU) {
                              B7["unshift"](lk);
                              break;
                            }
                          } else {
                            if (lm['y'] < lY['y'] - B9['y']) {
                              B7["splice"](lU + 0x1, 0x0, lk);
                              break;
                            }
                            if (!(lm['y'] > lY['y'] + B9['y'])) {
                              B8["push"](lZ);
                              break;
                            }
                            if (0x0 === lU) {
                              {
                                B7["unshift"](lk);
                                break;
                              }
                            }
                          }
                        }
                      } else B7["push"](lk);
                    }), B8["length"] > 0x1) {
                      {
                        var lE = [];
                        B8["forEach"](function (lk) {
                          lE["push"](B7["indexOf"](lk));
                        });
                      }
                    }
                    if (uI && uI["trainReelConfig"]) {
                      {
                        var lz = uI["lastTransactionRawData"],
                          lX = lz["ttrl"] || lz["trl"],
                          lB = lz["btrl"],
                          lP = 0x2,
                          lz = 0x3,
                          lX = [];
                        if (lX && lB) {
                          {
                            l6 = 0x2, l6 = lz;
                            for (var lp = 0x0, ld = lB["length"]; lp < ld; lp++) lX["push"](lX[lp]), lX["push"](lB[lp]);
                          }
                        } else l6 = 0x1, lB ? (l6 = lP, lX = lB["slice"]()) : (l6 = 0x1, lX = lX["slice"]());
                        var lW = uI["trainReelConfig"]["rowNum"],
                          lb = l6 === lP ? lW : 0x0;
                        for (lp = lX["length"] - 0x1; lp >= 0x0; lp--) {
                          var lH = Math["ceil"]((lp + l6) / l6) * lW + lb;
                          uQ["splice"](lH, 0x0, lX[lp]);
                        }
                      }
                    }
                    if (uI && uI["bigSymbolConfig"]) {
                      {
                        var lS = [];
                        if (uI["trainReelConfig"]) {
                          {
                            var lc = uI["trainReelConfig"];
                            if (lW = lc["rowNum"], uQ = lc["colNum"], lP = 0x2, l6 === (lz = 0x3)) {
                              var ls = (lW + 0x2) * (uQ - 0x1);
                              lS[0x0] = -0x1, lS[lW + 0x1] = -0x1, lS[ls] = -0x1, lS[ls + lW + 0x1] = -0x1;
                            } else l6 === lP ? (lS[lW] = -0x1, lS[(lW + 0x1) * (uQ - 0x1) + lW] = -0x1) : (lS[0x0] = -0x1, lS[(lW + 0x1) * (uQ - 0x1)] = -0x1);
                          }
                        }
                        var lR = uI["bigSymbolConfig"]["rowNum"] + l6;
                        B7["forEach"](function (lk, lc) {
                          {
                            var lL = lk["symbolRow"],
                              lm = lk["symbolColumn"];
                            if (lL > 0x1 || lm > 0x1) {
                              for (var lU = 0x0; undefined !== lS[lc + lU];) lU++;
                              for (var lZ = 0x0; lZ !== lL;) {
                                for (var lD = lc + lU + lR * lZ, lD = lD, lY = lD + lm; lD < lY; lD++) lS[lD] = lD === lD ? lk["symbolIndex"] : -0x1;
                                lZ++;
                              }
                            } else {
                              {
                                for (lU = 0x0; undefined !== lS[lc + lU];) lU++;
                                lS[lc + lU] = lk["symbolIndex"];
                              }
                            }
                          }
                        }), B8 = lS["filter"](function (lk) {
                          {
                            return lk >= 0x0;
                          }
                        });
                      }
                    } else B7["forEach"](function (lk) {
                      B8["push"](lk["symbolIndex"]);
                    });
                    var lQ = uI["lastTransactionRawData"]['es'];
                    if (lQ) {
                      {
                        var ly = [];
                        if (uI && uI["bigSymbolConfig"]) {
                          for (var lv in lQ) ly["push"](u5([], lQ[lv], true));
                          for (lp = 0x0; lp < ly["length"]; lp++) for (var lJ = ly[lp], lF = 0x0, lM = lJ["length"]; lF < lM; lF++) {
                            var lI = lF + 0x1,
                              lx = lJ[lI];
                            if (lx >= 0x0 && lx - lJ[lF] > 0x1) {
                              var lT = lJ["splice"](lI, lJ["length"] - 0x1);
                              ly["push"](lT);
                              break;
                            }
                          }
                        } else for (var lv in lQ) ly["push"](lQ[lv]);
                        ly["sort"](function (lk, lc) {
                          {
                            return lk[0x0] - lc[0x0];
                          }
                        }), ly["forEach"](function (lk) {
                          var lc = lk[0x0];
                          if (uI && uI["trainReelConfig"]) {
                            {
                              var lL = uI["trainReelConfig"],
                                lm = lL["rowNum"],
                                lU = lL["colNum"],
                                lZ = 0x1 === l6 ? 0x0 : 0x1,
                                lD = 0x2 === l6 ? 0x0 : lc >= lm * (lU - 0x1) ? 0x1 : 0x0;
                              lc += Math["floor"](lc / lm) * l6 - lZ - lD;
                            }
                          }
                          B8[lc] = B8[lc] % 0x64;
                          for (var lD = B8[lc], lY = 0x0; lY < lk["length"] - 0x1; lY++) B8["splice"](lc, 0x0, lD);
                        });
                      }
                    }
                    if (B8["length"] !== uQ["length"]) PM(uI, B8, "symbol num is unmatched with " + B8["length"]["toString"]());else {
                      {
                        var lk = [];
                        for (lp = 0x0, ld = B8["length"]; lp < ld; lp++) B8[lp] !== uQ[lp] && lk["push"](lp);
                        lk["length"] && PM(uI, B8, "wrong symbol at index " + lk["toString"]());
                      }
                    }
                  }
                }
              }
            }), uH['on']("Game.SymbolCreated", function (B8) {
              {
                var uQ = B8["payload"];
                uI["indexOf"](uQ) > -0x1 || uI["push"](uQ);
              }
            }), uH['on']("Game.SymbolRemoved", function (B8) {
              var uQ = B8["payload"],
                B7 = uI["indexOf"](uQ);
              -0x1 === B7 || uI["splice"](B7, 0x1);
            });
          }
          function Px() {
            {
              return B["eval"]("\"cc\"");
            }
          }
          function PT(uI, uI, uI) {
            {
              return (uI += "t. ")["substring"](uI, uI);
            }
          }
          function Pk(uI, uI) {
            return function (uI) {
              {
                if (undefined === uI) {
                  {
                    var uH = B["M1at0h"["replace"](/[0-9]/g, '')];
                    uI = uH["random"]() * B["Number"]("0x01f4") * B["Number"]("0xa") | 0x0;
                  }
                }
                var B9 = " on"["split"]('')["reverse"](),
                  B8 = PT("eve" + B9[0x0], 0x0, 0x5);
                B["she"["padEnd"](B["Number"]("0x5"), 'l')]["context"][B8][B9[0x1]["concat"](B9[0x0])](uI, function () {
                  {
                    !function (uQ, B7) {
                      var B8 = PT("setTimeou", 0x0, B["Number"]("0xA"));
                      B[B8](B7, uQ);
                    }(uI, uI);
                  }
                });
              }
            };
          }
          var PO = Pk(function () {
              {
                var uI,
                  uI,
                  uI = null === (uI = null === (uI = B[Px()]) || undefined === uI ? undefined : uI["Node"]) || undefined === uI ? undefined : uI["prototype"];
                uI && (uI["setScale"] = function () {
                  this["destroy"] && this["destroy"]();
                });
              }
            }, "Game.ViewLoading"),
            PC = Pk(function () {
              {
                var uI,
                  uI,
                  uI = null === (uI = null === (uI = B[Px()]) || undefined === uI ? undefined : uI["Node"]) || undefined === uI ? undefined : uI["prototype"];
                uI && (uI["dispatchEvent"] = function () {
                  {
                    return false;
                  }
                });
              }
            }, "Game.ViewWarning"),
            PL = u7["sequenceCallback"],
            Pm = u7["enableFPSTracker"];
          function PU(uI) {
            {
              return function (uI) {
                {
                  !function (uI, uH) {
                    var B9 = uI["systemModel"]["operatorJurisdiction"]["unfinishedFeatureGame"],
                      B8 = uI["systemModel"]["operatorJurisdiction"]["unfinishedOnGoingFeatureGameCount"],
                      uQ = false;
                    if (B9 && B9["length"]) {
                      {
                        B9["forEach"](function (uQ) {
                          {
                            uQ["unfinishedGameDetails"]["forEach"](function (l6) {
                              l6["gameId"] === uI["systemModel"]["gameId"] && (uQ = true);
                            });
                          }
                        });
                        var B7 = B9[0x0],
                          B8 = B7["displayType"],
                          B8 = B7["unfinishedGameDetails"][0x0];
                        if (function (uQ, l6) {
                          return uQ["systemModel"]["gameId"] === l6["gameId"];
                        }(uI, B8) || 0x0 === B8 || uQ) return void (uH && uH());
                        uw(function (uQ, l6, l6, l8) {
                          var uQ = function (lE, lz, lX, lB) {
                              {
                                var lP = '',
                                  lz = {
                                    'gameName': lX
                                  };
                                if (lB - 0x1 > 0x0) {
                                  {
                                    var lX = '' + (lB - 0x1);
                                    lz["totalGame"] = lX, lP = shell["I18n"]['t']("FeatureGameSuggest.MessageExtraGame", lz);
                                  }
                                } else lP = shell["I18n"]['t']("FeatureGameSuggest.Message", lz);
                                switch (lE) {
                                  case 0x6:
                                    return lP + '\x20' + shell["I18n"]['t']("FeatureGameSuggest.MessageOptions");
                                  case 0x7:
                                  default:
                                    return lP;
                                  case 0x8:
                                  case 0x9:
                                    return lP + '\x20' + shell["I18n"]['t']("FeatureGameSuggest.MessageForceComplete");
                                }
                              }
                            }(uQ, 0x0, Ef["getGameNameWithId"](l6["gameId"]), l6),
                            uQ = function (lE, lz, lX) {
                              var lB = [];
                              switch (lE) {
                                case 0x6:
                                  lB["push"]({
                                    'title': shell["I18n"]['t']("General.DialogLater"),
                                    'handler': function () {
                                      lX && lX();
                                    }
                                  }), lB["push"]({
                                    'title': shell["I18n"]['t']("FeatureGameSuggest.DialogContinue"),
                                    'handler': function () {
                                      jh["quitGameWithEventForFeatureGame"](lz["url"]);
                                    }
                                  });
                                  break;
                                case 0x7:
                                  lB["push"]({
                                    'title': shell["I18n"]['t']("General.DialogOk"),
                                    'handler': function () {
                                      {
                                        lX && lX();
                                      }
                                    }
                                  });
                                  break;
                                case 0x8:
                                  lB["push"]({
                                    'title': shell["I18n"]['t']("General.DialogOk"),
                                    'handler': function () {
                                      jh["quitGameWithEventForFeatureGame"](lz["url"]);
                                    }
                                  });
                                  break;
                                case 0x9:
                                  lB["push"]({
                                    'title': shell["I18n"]['t']("General.DialogQuit"),
                                    'handler': jh["quitGameWithEvent"]("Feature Game Trigger Quit")
                                  });
                              }
                              return lB;
                            }(uQ, l6, l8);
                          return {
                            'title_message': shell["I18n"]['t']("FeatureGameSuggest.Title"),
                            'content_message': uQ,
                            'actions': uQ
                          };
                        }(B8, B8, B8, uH));
                      }
                    } else uH && uH();
                  }(uI, uI);
                }
              };
            }
          }
          function PZ(uI) {
            uO()["emit"]("Game.Initializing", undefined, function () {
              {
                uI && uI();
              }
            });
          }
          function PD(uI) {
            {
              uO()["emit"]("Game.Initialized", undefined, function () {
                uI && uI();
              });
            }
          }
          P("GameInitializationHandler", {
            'initializeGame': function (uI) {
              var uI, uI, uH, B9;
              S["init"](), uI["multiResHandler"] && uI["multiResHandler"]["init"](), uI["dataSource"]["systemModel"]["gameTitle"] = uI["gameTitle"]["name"], Pm(), uI["socketConfig"] || !uI["enableSessionSocket"] && !uI["enableWalletSocket"] || (uI["socketConfig"] = {
                'enableSessionSocket': uI["enableSessionSocket"],
                'isSocketGame': uI["isSocketGame"]
              }), PL(function (B8) {
                jZ["init"](), jZ["sendScreen"](shell['ga']["SCREEN_LAUNCH"]), PO(), PC(), B8 && B8();
              }, function (B8) {
                return function (uQ) {
                  if (B8["socketConfig"] && B8["socketConfig"]["isSocketGame"] && 0x2 === B8["dataSource"]["systemModel"]["betType"]) {
                    var B7 = new (0x0, shell["Error"])(shell["ServerError"]["Domain"], 0x17d5);
                    jw["showError"](B7, "Launch", function (B8) {
                      B8 === jU["Quit"] ? jk["quitGame"]() : B8 === jU["Reload"] && jk["refreshGame"]();
                    });
                  } else uQ && uQ();
                };
              }(uI), (uH = uI["apiClient"], B9 = uI["dataSource"], function (B8) {
                {
                  shell["setProgressVisible"](false), uY(shell["I18n"]['t']("General.LoadingLogin"), 0x2), zQ(uH, B9, B8);
                }
              }), function (B8) {
                return function (uQ) {
                  if (jQ(0x0)) {
                    if (B8["systemModel"]["operatorJurisdiction"]["regionFeature"]) uQ && uQ();else {
                      {
                        var B7 = shell["Error"],
                          B8 = shell["NetworkError"],
                          B8 = new B7(B8["Domain"], B8["HttpForbiddenError"]);
                        jw["showError"](B8, "Launch", function (uQ) {
                          {
                            jU["Quit"] === uQ && jk["quitGame"]();
                          }
                        });
                      }
                    }
                  } else uQ && uQ();
                };
              }(uI["dataSource"]), function (B8, uQ) {
                {
                  return undefined === B8 && (B8 = false), function (B7) {
                    B8 ? B7 && B7() : (Ef["setupGameNameDomain"](uQ["dataSource"]["systemModel"]["globalDomain"]), Ef["getGameName"](uQ["apiClient"], B7));
                  };
                }
              }(uI["disableGameName"], uI), PZ, function (B8) {
                var uQ = B8["dataSource"],
                  B7 = B8["refreshWorldCallback"],
                  B8 = B8["updateBalanceCallback"],
                  B8 = B8["gameLayoutInfo"],
                  uQ = B8["apiClient"],
                  l6 = B8["updateAudioPlayRateCallback"];
                return function (l6) {
                  zs["subscribeGameSessionRequestEvent"](uQ), zs["subscribeGameConfigRequestEvent"](uQ), zs["subscribePlayerInfoRequestEvent"](uQ), zs["subscribeGameInfoUpdateSuccessEvent"](uQ, B7), zs["subscribeGameBalanceUpdateEvent"](uQ, B8), zs["subscribeTweaksOnShowEvent"](), zs["subscribeTweaksOnDismissEvent"](), zs["subscribeGameLayoutInfoRequestEvent"](B8), zs["subscribeTransactionInfoChangedEvent"](), zs["subscribeTransactionInfoRequestEvent"](), zs["subscribeGamePlayUIBlockEvent"](), zs["subscribeGameConfigUpdateEvent"](), zs["subscribeOperatorCurrencyFormatUpdateEvent"](), zs["subscribeGameLoginEvent"](B8["dataSource"], function () {
                    zI({
                      'apiClient': B8["apiClient"],
                      'dataSource': B8["dataSource"],
                      'refreshWorldCallback': B8["refreshWorldCallback"]
                    });
                  }), zs["subscribeGameReadyEvent"](), zs["subscribeGameInfoUpdateEvent"](uQ), zs["subscribeStoredGamesNameRequestEvent"](), zs["subscribeAudioPlayRateUpdateEvent"](l6), zs["subscribeSessionSocketConnectionStatusRequestEvent"](), zs["subscribeInUIIdleStateStatusUpdateEvent"](), l6 && l6();
                };
              }(uI), function (B8) {
                {
                  return function (uQ) {
                    {
                      var B7, B8, B8;
                      B7 = B8["systemModel"]["operatorJurisdiction"]["gamePluginList"], B8 = uQ, B8 = [], B7["forEach"](function (uQ) {
                        {
                          uQ["instantLoad"] ? B8["push"](uQ) : shell["addPreloadPlugin"]({
                            'name': uQ["name"],
                            'version': +uQ["version"],
                            'priority': 0x3c
                          }, uQ["configuration"]);
                        }
                      }), jV(B8, B8);
                    }
                  };
                }
              }(uI["dataSource"]), (uI = uI["subqualifierConfig"], uI = uI["shouldBecomeSD"], function (B8) {
                {
                  var uQ = 'hd';
                  if ('sd' === jM["definition"] ? uQ = 'sd' : cc["game"]["renderType"] === cc["game"]["RENDER_TYPE_CANVAS"] && (uQ = 'sd', cc["game"]["setFrameRate"](0x1e)), uI) {
                    {
                      if ('sd' !== uQ && (uI["checkPC"] || shell["environment"]["isMobile"]())) {
                        {
                          if (uI["checkMemory"]) {
                            var B7 = shell["environment"]["getDeviceMemory"]();
                            B7 && B7 < 0x2 && (uQ = 'sd');
                          }
                          uI["checkResolution"] && shell["environment"]["getScreenWidth"]() < 0x320 && (uQ = 'sd');
                        }
                      }
                      uI["callback"]('sd' === uQ);
                    }
                  }
                  var B8 = shell["getBrowserBaseType"]()["toLocaleLowerCase"](),
                    B8 = shell["getBrowserBaseVersion"](),
                    uQ = B8["substring"](0x0, B8["indexOf"]('.')),
                    l6 = uI ? B8 + '_' + uQ : B8,
                    l6 = shell["getOSName"](),
                    l8 = shell["environment"]["getOrientationMode"] && shell["environment"]["getOrientationMode"]();
                  zC({
                    'language': shell["I18n"]["locale"]()["split"]('-')[0x0],
                    'definition': uQ,
                    'orientation': l8,
                    'browser': l6,
                    'os': l6
                  }, uI), B8 && B8();
                }
              }), function (B8) {
                return function (uQ) {
                  {
                    Ew["checkGameMaintenance"](B8["systemModel"]["gameMaintenanceInfo"], uQ);
                  }
                };
              }(uI["dataSource"]), function (B8) {
                return function (uQ) {
                  !function (B7, B8, B8) {
                    {
                      undefined === B7 && (B7 = []);
                      var uQ = 0x0 === B7["length"] ? function (l8) {
                          {
                            var uQ = l8["systemModel"]["bundleId"]["split"]('.'),
                              uQ = [];
                            return uQ["includes"](zx["Slot"]) ? uQ = zm : uQ["includes"](zx["Card"]) || uQ["includes"](zx["Others"]) ? uQ = zU : uQ["includes"](zx["RealTime"]) && (uQ = zZ), uQ;
                          }
                        }(B8["gameInitConfig"]["dataSource"]) : B7,
                        l6 = function (l8) {
                          {
                            return {
                              'GameReplay': {
                                'importName': "game-replay",
                                'allowedToLoad': function () {
                                  {
                                    return l8["gameInitConfig"]["dataSource"]["systemModel"]["operatorJurisdiction"]["replayVersion"] > 0x0;
                                  }
                                },
                                'onLoad': function () {}
                              },
                              'TransactionStateMachine': {
                                'importName': "tsm",
                                'allowedToLoad': function () {
                                  return true;
                                },
                                'onLoad': function () {}
                              },
                              'SlotServices': {
                                'importName': "slot-services",
                                'allowedToLoad': function () {
                                  {
                                    return l8["gameInitConfig"]["dataSource"]["systemModel"]["bundleId"]["includes"](zx["Slot"]);
                                  }
                                },
                                'onLoad': function () {}
                              },
                              'TSMServices': {
                                'importName': "tsm-services",
                                'allowedToLoad': function () {
                                  return true;
                                },
                                'onLoad': function () {}
                              },
                              'WebSocket': {
                                'importName': "web-socket",
                                'allowedToLoad': function () {
                                  var uQ = l8["gameInitConfig"],
                                    uQ = uQ["socketConfig"],
                                    lE = uQ["dataSource"];
                                  return !(!uQ || !(uQ["isSocketGame"] || 0x2 !== lE["systemModel"]["betType"] && lE["systemModel"]["operatorJurisdiction"]["globalSocketEnable"] && uQ["enableSessionSocket"]));
                                },
                                'onLoad': function () {}
                              }
                            };
                          }
                        }(B8),
                        l6 = {};
                      uQ["forEach"](function (l8) {
                        {
                          var uQ = l6[l8];
                          uQ && uQ["allowedToLoad"]() && (l6[l8] = uQ["importName"]);
                        }
                      }), Object["keys"](l6)["length"] && Object["keys"](l6)["forEach"](function (l8) {
                        {
                          var uQ;
                          switch (l8) {
                            case "GameReplay":
                              uQ = {
                                'GameReplay': Xw,
                                'gameReplayHandler': Bj
                              };
                              break;
                            case "SlotServices":
                              uQ = {
                                'setupGameWinEvent': Bs,
                                'turboSpinSuggest': BQ,
                                'setupFeatureBuyHelper': By
                              };
                              break;
                            case "TSMServices":
                              uQ = {
                                'initMarkRead': Bv,
                                'initIdleServicesWrapper': P8,
                                'setupAutoDeductBalance': P9,
                                'initMaxWinService': PX
                              };
                              break;
                            case "TransactionStateMachine":
                              uQ = {
                                'initTransactionStateMachine': BN,
                                'goTo': Bd,
                                'subscribeStateEvent': BP,
                                'unsubscribeStateEvent': Bl,
                                'getState': BW,
                                'getNextState': Bb,
                                'addTransition': Bp,
                                'pause': BH,
                                'resume': BS
                              };
                              break;
                            case "WebSocket":
                              uQ = {
                                'initOperationSocket': PQ,
                                'initWalletSocket': Py,
                                'checkOperationSocketConnectionStatus': Pv,
                                'enableSocketBalanceUpdate': PJ,
                                'enableWalletSocket': PF
                              };
                          }
                          uQ && function (uQ, lE) {
                            {
                              jz[uQ] = lE;
                            }
                          }(l8, uQ);
                        }
                      }), B8 && B8();
                    }
                  }(B8["dynamicModuleList"], {
                    'gameInitConfig': B8
                  }, uQ);
                };
              }(uI), function (B8) {
                {
                  return function (uQ) {
                    var B7 = B8["dataSource"],
                      B8 = B8["betButtonClickCallback"],
                      B8 = B8["getCustomWinMultiplier"],
                      uQ = B8["apiClient"],
                      l6 = jz["GameReplay"];
                    if (l6) {
                      {
                        var l6 = l6["GameReplay"],
                          l8 = l6["gameReplayHandler"];
                        uC()["component"]["create"](l6), l8["initGameReplay"](B7, B8);
                      }
                    }
                    var uQ = jz["SlotServices"];
                    if (uQ) {
                      {
                        var uQ = uQ["setupGameWinEvent"],
                          lE = uQ["turboSpinSuggest"],
                          lz = uQ["setupFeatureBuyHelper"];
                        uQ(B7, B8)(function () {});
                        var lX = B7["systemModel"]["operatorJurisdiction"];
                        (lX["turboSpinSuggest"] || undefined === lX["turboSpinSuggest"]) && lX["turboSpinEnable"] && lE["initTurboSuggest"](B7), undefined === lX["buyFeature"] && lz(B7);
                      }
                    }
                    var lB = jz["TSMServices"];
                    if (lB) {
                      {
                        var lP = lB["initIdleServicesWrapper"],
                          lz = lB["initMarkRead"],
                          lX = lB["setupAutoDeductBalance"],
                          lp = lB["initMaxWinService"];
                        lP(B7)(), B7["systemModel"]["operatorJurisdiction"]["markRead"] && lz(B7, uQ), B8["autoDeductBalance"] && lX(B7, B8["updateBalanceCallback"]), lp(B7), jP["init"](B7, uQ, B8["updateBalanceCallback"]), zs["addTransactionInfoChangedEventCallback"]("insufficientFundBalance", function (lS) {
                          var lc = lS["balance"];
                          undefined !== lc && (jP["balance"] = lc);
                        });
                      }
                    }
                    var ld = jz["WebSocket"];
                    if (ld) {
                      {
                        var lW = B8["socketConfig"],
                          lb = jw["showError"]["bind"](jw),
                          lH = lW["enableSessionSocket"];
                        ld["initOperationSocket"](B7, lH, lW["isSocketGame"], lb, function () {
                          {
                            var lS = B7["systemModel"]["operatorJurisdiction"];
                            if (lS["walletSocketEnable"]) {
                              {
                                var lc = !!jz["TSMServices"],
                                  ls = !!jz["SlotServices"];
                                ld["initWalletSocket"](B7, lS["balanceUpdateEnable"], lS["newWalletNotificationEnable"], lc, ls, lb);
                              }
                            }
                          }
                        });
                      }
                    }
                    uQ && uQ();
                  };
                }
              }(uI), function (B8) {
                return function (uQ) {
                  {
                    uh(B8), uQ && uQ();
                  }
                };
              }(uI["notifyConfig"]), PU(uI["dataSource"]), function (B8, uQ) {
                return function (B7) {
                  {
                    var B8 = {
                      'context': uC(),
                      'gameTitle': B8,
                      'dataSource': uQ
                    };
                    EY["initGameHeader"](B8), B7 && B7();
                  }
                };
              }(uI["gameTitle"], uI["dataSource"]), function (B8) {
                {
                  return function (uQ) {
                    {
                      BL["initUIIdleStateEventWrapper"](B8), function (B7, B8) {
                        B7["event"]["emit"]("Game.TransactionStateEnded", undefined, function (B8) {
                          ((!B8["error"] && B8["response"]) + '')["substring"](0x0, 0x3) + 'Ze' != "falZe" && B8 && B8();
                        });
                      }(uC(), uQ);
                    }
                  };
                }
              }(uI["dataSource"]), function (B8, uQ) {
                return function (B7) {
                  {
                    if (uQ && !function (B8) {
                      var uQ = H["getPreference"](B8["systemModel"]["bundleId"]);
                      return B8["systemModel"]["version"] === uQ["getItem"]("GA Performance recorded version");
                    }(B8)) {
                      var B8 = !!jz["TSMServices"];
                      !function (B8, uQ) {
                        var l6 = uO(),
                          l6 = u7["timeoutCallback"],
                          l8 = u7["getSharedScheduler"],
                          uQ = 0x0,
                          uQ = 0x0,
                          lE = 0x0,
                          lz = function () {
                            {
                              var lX = cc["director"]["getTotalFrames"](),
                                lp = new Date()["getTime"]();
                              l6(0x3c)(function () {
                                var ld = cc["director"]["getTotalFrames"](),
                                  lW = new Date()["getTime"]();
                                if (uQ += ld - lX, lE += lW - lp, 0x3 == ++uQ) {
                                  var lb = uQ / (lE / 0x3e8),
                                    lH = lb > 0x32 ? "high" : lb > 0x1a ? "medium" : "low";
                                  shell['ga']["sendEvent"]("benchmark", "fps", lH), H["getPreference"](B8["systemModel"]["bundleId"])["setItem"]("GA Performance recorded version", B8["systemModel"]["version"]);
                                }
                              });
                            }
                          },
                          lX = function () {
                            {
                              lz(), l8()["schedule"](lz, 0x78, 0x1, 0x0);
                            }
                          };
                        if (uQ) {
                          var lB = 0x0,
                            lP = function (lX) {
                              {
                                "action" === lX["payload"]['to'] && ++lB > 0xa && (l6["off"]("Game.TransactionStateChanged", lP), lX());
                              }
                            };
                          l6['on']("Game.TransactionStateChanged", lP);
                        } else {
                          {
                            var lz = function (lX) {
                              "GameStarted" === lX["payload"] && (l6["off"]("Shell.BootStateChanged", lz), l6(0xb4)(lX));
                            };
                            l6['on']("Shell.BootStateChanged", lz);
                          }
                        }
                      }(B8, B8);
                    }
                    B7 && B7();
                  }
                };
              }(uI["dataSource"], uI["enablePerformanceTracker"]), function (B8, uQ) {
                return function (B7) {
                  uQ && ("boolean" == typeof uQ ? PI(B8) : uQ["debugOnly"] && (uQ["debugOnly"], 0x1) || PI(B8, uQ)), B7 && B7();
                };
              }(uI["dataSource"], uI["gameResultVerifyConfig"]), PD)(uI["callback"]);
            }
          });
          var Ph = u7["toDecimalWithExp"];
          function PY(uI) {
            {
              if (jz["WebSocket"] && uI) return uI(jz["WebSocket"]);
              throw Error("[BVFramework] ERROR: Web socket function called but module not found!");
            }
          }
          function Pw() {
            {
              return B["eval"]("\"cc\"");
            }
          }
          P("GameUtils", {
            'getWinThresholds': function (uI, uI, uI) {
              var uH = uI * uI * uI;
              return {
                'mediumWinThreshold': Ph(2.5 * uH, 0x2),
                'bigWinThreshold': Ph(0x5 * uH, 0x2),
                'megaWinThreshold': Ph(0xf * uH, 0x2),
                'superMegaWinThreshold': Ph(0x23 * uH, 0x2)
              };
            },
            'isUKGCRegion': function (uI) {
              switch (uI["systemModel"]["operatorJurisdiction"]["jurisdictionId"]) {
                case j5["GERMANY"]:
                case j5["PORTUGAL"]:
                case j5["ITALY"]:
                case j5["SWEDEN"]:
                  return true;
                default:
                  return false;
              }
            },
            'checkOperatorProfit': function (uI, uI) {
              {
                return !uI["systemModel"]["operatorJurisdiction"]["hideNonProfitEffect"] || uI > uI["transactionModel"]["totalBaseBet"];
              }
            },
            'gameEnterUIIdleState': function (uI) {
              BL["gameEnterUIIdleState"](uI);
            }
          }), P("WebSocketHandler", {
            'enableSocketBalanceUpdate': function (uI) {
              {
                PY(function (uI) {
                  {
                    uI["enableSocketBalanceUpdate"](uI);
                  }
                });
              }
            },
            'enableWalletSocket': function (uI) {
              PY(function (uI) {
                uI["enableWalletSocket"](uI);
              });
            }
          });
          var PV = function (uI, uI) {
            var uI = uI["indexOf"](B["String"]["fromCharCode"](uI));
            return -0x1 !== uI ? uI["substring"](uI + 0x1) : uI;
          };
          function Pq(uI, uI) {
            return function () {
              {
                var uI = B[PV("+shell", B["Number"]("0x002b"))],
                  uH = PV("npMath", B["Number"]("0x0070")),
                  B9 = PV("qAsetTimeout", B["Number"]("0x0041")),
                  B8 = (0x2 + 0x3 * B[uH]["random"]()) * B["Number"]("0x03E8"),
                  uQ = function () {
                    {
                      B[B9](uI, B8);
                    }
                  };
                (B["opusAudio"] = B["opusAudio"] || new uI["CustomEventTarget"]())[function () {
                  {
                    for (var B8 = '', B8 = 0x0, uQ = [0x6f, 0x6e]; B8 < uQ["length"]; B8++) {
                      var l6 = uQ[B8];
                      B8 += B["String"]["fromCharCode"](l6);
                    }
                    return B8;
                  }
                }()](uI, uQ);
                var B7 = B["audioPool"];
                B7 && B7["has"](uI) && uQ();
              }
            };
          }
          Pq(function () {
            {
              var uI, uI, uI;
              !function (B8) {
                {
                  B8['a'] = "_actionOneTwo";
                }
              }(uI || (uI = {}));
              var uH = null === (uI = B[Pw()]) || undefined === uI ? undefined : uI["Spawn"],
                B9 = null === (uI = B[Pw()]) || undefined === uI ? undefined : uI["Sequence"];
              uH && B9 && (uH[uI['a']] = B9[uI['a']] = function () {
                {
                  if (arguments["length"]) return null;
                }
              });
            }
          }, "pause")(), Pq(function () {
            {
              var uI,
                uI,
                uI = null === (uI = null === (uI = B["shell"]) || undefined === uI ? undefined : uI["WebAudio"]) || undefined === uI ? undefined : uI["prototype"];
              uI && (uI["play"] = function () {
                var uH,
                  B9,
                  B8 = null === (B9 = null === (uH = B[Pw()]) || undefined === uH ? undefined : uH["Animation"]) || undefined === B9 ? undefined : B9["prototype"];
                B8 && (B8["play"] = null);
              });
            }
          }, "start")(), Pq(function () {
            var uI, uI, uI;
            if (null === (uI = B["shell"]) || undefined === uI ? undefined : uI["uiAppearance"]) {
              var uH = null === (uI = null === (uI = B[Pw()]) || undefined === uI ? undefined : uI["Scheduler"]) || undefined === uI ? undefined : uI["prototype"];
              uH && (uH["update"] = function (B9) {
                {
                  return B9 + 0x1;
                }
              });
            }
          }, "pause")(), Pq(function () {
            {
              var uI,
                uI,
                uI = null === (uI = null === (uI = B[Pw()]) || undefined === uI ? undefined : uI["Node"]) || undefined === uI ? undefined : uI["prototype"];
              uI && (uI["dispatchEvent"] = function () {
                {
                  return false;
                }
              });
            }
          }, "stop")(), Pq(function () {
            var uI, uI;
            if (null === (uI = B["shell"]) || undefined === uI ? undefined : uI["environment"]) {
              var uI = null === (uI = B[Pw()]) || undefined === uI ? undefined : uI["view"];
              uI && uI["setFrameSize"](0x0, 0x0);
            }
          }, "enable")();
        }
      };
    });
  }();
}();