!function () {
  'use strict';

  function U() {
    var BT = ['STl', 'n-t', '+)+', 'Pql', 'ula', 'arC', '-11', 'meL', '.Ne', 'Mar', 'xIE', 'ogO', 'Sea', 'REP', '4px', 'n\x27t', 'etW', 'epe', 'lfr', 'Out', '\x20\x20w', 'nIn', 'kee', 'ORK', 'OR_', 'h\x20c', 'VyS', 'LS0', '8,\x20', 'ZwW', 'cwI', 'sjm', 'kUS', 'nt:', 'hew', 'tWi', 'pps', 'e1f', 'bje', 'pda', 'sIA', 'BuY', 'UUi', ':\x201', 'MQW', 'Ref', 'nct', '-cu', 'ack', 'dRY', 'awa', 'tor', 'WyE', 'ctR', 'ull', 'hNw', 'Use', 'ume', 'edT', 'Grh', 'stn', '\x20&:', 'bun', 'qAs', '-ou', 'Spa', 'tHe', 'fal', '\x20li', 'le_', 'Jso', '\x202.', 'FIR', 'pHj', 'cjU', '[ob', 'alu', 'REF', 'ZLS', '_ic', 'zaX', 't0h', '5CY', 'YwD', 'ain', '50%', 'o;\x0a', 'Tvr', 'UIO', 'bor', 'ser', 'ngM', '20p', 'Uxk', 'Not', '0tL', '7);', 'wWP', 'Sli', '\x20lo', 'Sta', 'olv', '$CS', 'teY', 'que', '\x0a\x0a\x20', 'Roo', 'new', '5gw', 'MjW', 'e.H', 'nab', 'dra', 'tat', '_NO', 'foU', '0_C', 'm.\x20', 'eeM', 'erM', 'ale', 'tPr', '-fa', 'dtY', 'in:', 'rdM', 'Mat', 'the', 'SEC', 'hUX', 't-a', 'dul', 'KDZ', 'par', 'e-o', '6ec', 'doc', 'e.S', 'hnx', 'rid', 'KgX', 'ibi', 'Lat', 'src', 'tog', 'ici', '96)', 'rra', 'n\x20i', 'WUl', 'dDa', 'ect', '1th', 'nAm', 'Agu', ')+$', 'ntR', 'FeH', 'mhr', 'om-', 'top', 'erH', 'Oek', '120', 'aoG', '7,\x20', 'lid', 'iHl', 'YTD', 'tp:', 'Inv', 'Mou', 'row', 'th.', 'faP', 'fbP', '.Ca', 'mor', 'rea', '\x20\x22\x22', 'rel', 'anc', 'ear', 'n}.', 'Han', 'blo', 'tur', 'tAl', 'c_c', 'sta', 'zqy', '.5;', 'rSc', 'SGv', 'usW', 'w{b', 'eAp', 'WMU', 'alW', 'fUi', 'Can', 'fll', 'eat', 's:\x20', 'ers', 'tEx', 'eva', 'non', 'JZN', ':\x206', 'TOf', 'HCL', 'r-r', 'yys', 'px;', 'eii', ':-4', 'Gdp', 'tWL', 'sup', 'll-', ',\x202', 'urr', 'hsh', 'bqP', 'led', 'LHx', 'ox-', 'sha', 'sor', 'px}', 'inn', 'odG', 'isp', 'tPg', 'n-d', '0.5', 'nEC', 'NoO', 'Pos', 'lug', 'btt', 'set', '070', '_ar', 'd_d', 'low', 'equ', 'XeK', 'yed', '_bo', 'JJT', 'nt\x20', 'Cou', 'alt', 'SkI', 'cul', 'AsB', 'goo', '\x20lt', 'XHm', 'erc', 'mca', '\x27t\x20', 'gHe', '.6;', 'Par', '6px', '\x20to', '16p', 'a(7', 'caf', 'Ntj', ':\x0a\x20', 'AQM', 'fer', '-to', 'ded', '\x205p', 'emi', 'las', ';ba', 'Eve', 'wtA', 'TcD', 'id\x20', 'fdd', 'ged', ':\x204', 'to\x20', 'OMG', '1bK', 'rCo', 'EiU', 'Arr', '_DO', 'ba(', 'ePa', 'gci', 'sol', 'Col', 'UTo', 'LDq', 'uGE', 'tfg', 'cNd', 'tWq', 'fgI', '-2p', 'erv', 'ton', 'eyj', 'deM', 'o__', 'rad', 'hem', 'req', 'cha', 'poi', 'Cas', 'LLE', 'nCl', 'S0K', 'sty', 'vcX', '\x20\x20l', 'CcH', 'a(0', 'Gde', '5M0', 'erI', 'Res', 'abo', 'XHR', 'Wal', 'ar\x20', 'on:', 'isM', 'mLV', '-in', 'ddi', 'ref', 'dDi', 'Lis', 'aBW', 'fun', 'ceb', 'vey', 'XKa', 'eLo', '\x20\x20d', 'Sty', 'FGC', 'jrq', 'leD', 'xrl', 'PEm', 'er-', 'ang', '-al', 'din', 'xt-', 'owW', 'eoP', 'Get', 'dat', 'ove', 'azc', 'ZXR', 'oUp', 'uxB', 'TUZ', 'enu', 'bet', '\x20tr', 'EKc', '0,\x20', ',\x200', 'All', 'loc', 'enf', 'eho', 'pri', 'Xnp', 'her', 'TML', 'eSi', '\x20ba', 'aus', 'Vex', 'Ele', 'wit', 'rcx', '\x20ca', 'uKo', 'bac', 'Sha', 'rd0', 'aGm', 'on-', 'ozK', 'urv', 'io\x20', 'zbX', 'xqm', 'bai', 'vXJ', 'KEF', 'EPR', 'oXR', 'rol', '.Pr', 'tid', 'Itp', 'dCa', 'SUn', 'bon', 'ars', '\x20sa', 'x;\x20', 'aTq', '\x20th', 'GOK', '&:e', '.+)', 'oce', 'a(4', 'ida', 'tLi', '000', 'lle', 'r-b', 'nte', '\x20at', '\x200p', '\x20fl', 't:\x20', 'qEO', 't\x200', 'fai', 'oPa', 'nli', 'obs', 'Xic', '_sc', 'Cla', 'GhH', ')\x201', '6d5', 'Att', 'eCl', 'BHk', 'nBq', 'Own', ':\x20o', '\x20wa', 'nej', 'lic', '5,0', 'pre', 'V3W', 'May', 'pJR', 'def', '\x20fo', 'TiB', '.In', 'alc', 'otE', 'rRK', '48,', 'zun', 'oni', 'tjg', 'e;\x0a', 'IkK', 'pli', 'tDa', 'gdy', 'zPd', 'gYI', 'efi', 'eTh', 'ldN', 'plu', 'wVW', 'red', 'kRe', ',60', 'ree', '\x20\x20t', 'FRs', 'eOu', 'g\x20<', '__a', '0xA', '\x20no', 'tIn', ':af', 'Fra', 'umb', '-OL', '\x200.', 'IyM', 'qnu', '2,0', '-ha', 'Api', 'MJo', 'vie', 'neF', 'tTa', '0\x200', 'tCh', 'Yes', 'edN', 't\x20f', 'ZcY', 'bar', '.05', 'DUJ', 'RRZ', 'RnP', 'YVS', 'dig', 'Pop', 'tit', 'lIn', '\x2048', 'YRv', 'onF', 'dth', 'tGp', 'aUu', 'rro', 'Mor', 'vjU', 'sbm', 'eYX', 'teP', 'spr', 'ksB', 'Bmj', 'pad', 'fRs', 'Cph', 'wai', '171', 'tus', 'wbp', 'oAm', '\x2011', 'Tit', 'qlz', 'p-t', 'jsw', 'Wop', 'etT', ';wi', 'Hur', 'gin', 'e/j', 'Spr', 'BLx', 'EWT', 'wat', 'sag', 'dFL', 'ULE', 'jAl', 'bwI', 'API', 't.\x20', 'OuM', 'tie', 'ThR', 'ly:', 'oWi', 'bwf', 'jau', 'Cal', 'ctF', '-13', 'iro', 'dBu', 'lum', '0x4', 'BOR', 'Kze', 'htY', 'ebd', 't/x', 'qqJ', 'MQU', 'War', 'tRe', 'r-h', 'mTo', 'ntL', 'lTv', 'kUI', 'ame', 'zhh', 'etA', 'ara', 'dWa', 'dDO', 'CcU', 'sto', 'EXd', '_im', 'U3B', 'onM', 'zIn', 'gid', 'ft:', 'otb', 'uPi', 'kgr', 'ver', 'uff', 'Uti', 'epq', 'ele', '.5p', 'FKU', 's-o', 'aoJ', 'Gen', 'zA-', 'eas', 'saE', 'tTI', 'nme', 'iaT', 'IeD', 'Ofw', 'd\x20m', 'HXn', 'rcs', 'er:', 'eWa', 'qPI', ',0,', 'R1Z', 'wlc', 'mar', 'sAu', '-ra', 'rop', '\x20\x20p', 'eCX', 'KUk', 'DQH', 'edW', 'cEN', 'mOl', 'srq', 'now', 'hBN', 'ene', 'tAt', 'edu', 'pki', 'ces', 'rne', 'ogR', 'mpo', 'log', 'YwF', '}\x0a\x20', 'OGB', 'dUX', '64\x20', 'but', 'Qfg', 'Pdh', 'MLD', 'sea', 'diq', 'ade', 'SUV', 'adi', 'byp', 'ype', 'cZO', '059', 'RY0', 'Rem', '\x0a\x20\x20', 'TLL', 'DPC', 'onU', '}\x0a\x0a', 'uiA', '72*', 'seF', 'MOD', 'ons', 'ema', 'ft;', '17p', 'ope', 'ept', 'mow', 'VEC', 'exO', '\x2010', 'foe', 'et-', 'xte', 'HMG', 'Lnb', 'BBp', '_wa', 'eEx', 'dVo', 'vas', 'des', 'dEv', 'WNu', 'idt', '\x20\x27\x27', 'rt.', 'ges', 'r\x20b', '480', 'ide', 'JpO', 'znw', ':hi', 'off', 'Chi', 'ous', 'ill', '&:d', 't.C', 'yIQ', '\x20\x27p', 'sel', 'ple', '\x20\x20.', 'AeI', 'USn', 'ent', 'Dis', 'wLo', 'and', 'k\x20m', 'px\x20', 'Boo', 'ukq', 'win', 'NYZ', 'I18', '-9p', '\x20su', 'sli', 'edE', 'e.W', 'dIU', 'jGg', '\x20se', 'oWH', 'igh', 'ceC', 'ugi', 'eLi', '5,2', 'KxH', 'hvD', 'ex;', 'atk', 'olu', 'olo', '/>.', 'imi', 'joi', '17,', 'pto', 'ut\x20', 'str', 'toS', 'toD', 'Fdi', 'RxY', 'adC', 'ond', 'cKl', 't.B', 'ioA', 'lig', 'taY', '(-1', 'MAQ', 'e.R', 'Rec', 'KFD', 'GAM', 'mJn', 'neG', 'usR', 't_m', 'alC', 'HIj', 'Mis', 'NRa', ',1)', 'wor', 'pa\x20', 'qui', 'dTi', 'dis', 'len', 'PfZ', '-it', 'YMc', 'TxM', 'FCo', 'nve', 'Suc', 'Off', 'arR', 'aej', 'IS_', 'II=', '\x20co', 'Rch', 'isH', 'try', 'osi', 'se-', 'Dsk', 'put', 'gCo', 'd\x20{', 'fau', 'onD', ':\x20s', 'tWr', 'jzF', '\x20*\x20', 'ari', 'pla', 'gQy', '-ZM', 'GEN', 'Cus', 'eKI', 'erS', 'AxZ', 'dmi', 'Ft3', 'rla', 'Key', 'tio', '-wi', 'GTo', 'our', 'ine', 'fgi', 'jXl', 'SnZ', 'tMo', '-15', 'Rca', 'mn;', '(0,', 'Ma0', 'se6', 'img', '\x20di', 'OKx', 'erE', '-12', '\x20-9', 'had', 'isd', 'tSt', 'ace', 'al.', 'und', 'Yzt', 'e-d', 'oin', '//f', 'sed', 'Wid', 'inl', 'adb', 'OHD', 'cee', 'map', 'Klq', 'llH', 'pon', 'ot\x20', 'e.L', 'it\x20', 'dic', 'ble', 'FIU', 'Top', 'ibr', 'etL', 'inc', 'Ori', '-2-', 'tou', 'OUN', 'tCo', 'zZi', 'bot', 'Sel', 'how', '10p', 'tTo', 'ist', 'bVK', 'yle', 'onn', 'Der', 'EEN', 'ASS', 'A-1', 'TTb', 'aut', 'ico', 'ZRa', '.Hi', 'nne', 'apn', 'd-r', 'mid', '-fl', 'Acc', 'ein', 'YWq', 'Pla', 'for', '\x204p', 'nuJ', '960', 's\x20\x20', 'own', 't;\x0a', 'orC', 'cit', 'nt-', 'ems', 'mkS', 'xaA', '14p', 'age', ':\x20f', 'TOe', 'erT', '%;\x0a', 'mjG', 'ew\x20', 'g.H', 'p:\x20', 'pau', 'MLx', 'Two', 'LL_', '-pl', 'ST_', 'kKn', 'teT', 'VdU', 'geF', 'dex', 'tn\x20', 'Dia', 'dIo', 'FLj', 'ERA', 'teX', 'mUP', '3px', 'eak', '}.w', 'der', 'ite', 'ps:', 'bas', '360', '49,', 'l.R', 'HqS', 'opT', 'a(2', 'nsi', 'can', 'ht:', 'IfN', 'Xau', 'meV', 'pro', 'em\x20', 'dsJ', 'VmA', 'zwm', 'ecS', 'tcc', 'cen', '[na', 'EAJ', 'dDr', '26p', 'Wra', 'nds', 'get', 'tCa', '06d', ':\x200', 'ct-', 'rgi', 'rl\x20', 'eSp', 'e\x20:', 'eTy', 'VHJ', 'enc', 'gba', ');\x0a', 'x\x204', 'nCF', 'XpR', 'ile', 'ee_', 'VRd', 'tia', 'nRa', '\x20-1', 'Aut', '_ac', 'te\x20', 'ZNs', '-si', 'eBu', 'ske', 'e\x20`', 'g\x20k', 'peg', 'SzV', 'mPa', 'Wl2', 'ck;', 'e\x20c', 'lat', '0x5', 'whi', 'ayt', 'm:\x20', 'e\x20{', ',iV', 'Yts', 'obj', '\x20br', 'LET', 'tin', 'TTT', 'in-', 'tex', 'mil', 'dom', 'WDo', 'efs', '1CR', 'v_a', 'm,\x0a', 'XYw', 'RlU', 'NjO', 'era', 'ssW', 'bol', 'e/p', 'nUU', 'Rol', 'yuq', 'pen', '132', 'Inn', 'oYS', 'int', 'vQK', 'meN', 'Z3V', 'tLS', 'eP-', 'Min', 'hLa', 'Tr-', 'eou', 'dde', 'omo', '\x20}\x0a', 'tri', 'HVw', 'not', 'rma', '0px', '-wr', 'e64', 'clu', 'cel', 'r\x20{', 'asn', 'ura', '/ui', 'Yze', 'lit', ':\x20-', 'YWi', '\x20te', '00%', 'g);', 'eze', '\x201\x20', 'inC', 'cte', 'Nod', 'etr', 'aci', 'nCo', 'oPZ', 'buf', 'YRi', 'sin', 'dXA', 'eAm', 'ima', 'EWi', 'ANS', 'Btn', 'Eze', '\x20on', 'ogi', 'U3F', 'mpx', 'veT', 'ed\x20', 'jvc', 'a:i', 'huS', 'uAL', '\x20\x20o', 'pIN', '2s;', 'ueF', 'Mod', 'or\x20', 'Img', 'Cac', ',\x201', 'RHD', 'nen', 'JoZ', '\x20le', 'YoN', '1f4', 'Vkv', 'HxC', '[a-', 'et.', '_WA', 'war', 'y;\x0a', '119', 'Sup', 'UFV', 'edI', 'mal', '\x20in', 'RY_', 'ic_', 'mEr', 'ZgA', 'a-u', 'BE_', 'FhI', 'pag', 'ato', 'lLi', 'omS', 'ckE', 'iti', 'DSA', '37f', 'piJ', 'wbH', 'inb', 'mWW', '\x20wi', 'dSc', 'ler', 'aQn', 'rVE', '1);', 'szA', '.Co', '(25', 'hSt', 'e:\x20', 'jey', 'pAb', ':\x20a', 'ppe', 'XWC', 'JEK', '95%', 'inp', 'iry', ',52', 'c\x20o', '\x200\x20', 'lie', '0.3', 'gat', 'd-i', '0x2', '58%', 'e.F', '__e', 'bXt', 'Bun', 'ool', 'ilT', 'UhE', 'eRe', '42p', 'oSw', 'DpG', 'aHF', 'QqT', '85p', 'Whq', 'edS', '.5%', 'eDe', '\x2044', 'Ack', ':\x20n', 'Upd', 'x-d', '.jp', 'itl', 'isI', 'sLb', 'tle', 'pac', 'PAl', 'JWb', 'x;\x0a', 'e\x20i', '\x20by', 'use', 'e-b', 'ng;', 't:4', 'tqQ', 'qRf', 'nus', 'zht', 'bdo', 'aip', 'UdJ', '_TH', 'WWy', 'ts:', 'T0K', 'a1Q', 'zMS', 'e\x20n', 'icC', '#te', '60,', 'Obj', 'kPf', 'm-o', 'Cep', 'qbz', 'l.D', 'it;', 'eCo', 'Dig', 'rHe', '\x20po', 'PDN', 'npM', 'DHR', '\x20bu', 'rfg', 'eSh', '\x20fi', 'bee', ':21', 'deB', 'lud', '\x20cs', '3);', 'xpi', 'ahv', 'ueB', 'She', 'Rig', 'eIc', 'cli', 'Jwi', 'lUn', 'ehL', 't-w', 'OYL', 'rue', 'ntT', 'UhL', 'uSy', 'tl\x20', 'onT', 'trf', 'bal', 'faI', 'wIm', 'QQR', 'ned', 'sym', '-gr', '-co', 'OAd', 'eop', 'xNk', 'sEx', 'AZn', 'g.S', '.15', 'lef', 'qjY', 'qgL', 'AIx', 'tiv', 'amt', 'erB', '5,1', 'exp', 'vrs', '\x20\x20r', 'dNL', 'Uin', '\x20bo', 'dCo', 'AAA', 'agg', 'dRl', 'ibl', 'uct', 'Sho', 'GVF', 'et\x20', 'eEn', 'nVC', 'rCV', 'Emp', 'scO', '\x20Da', 'cDL', 'erR', 'bel', 'ay:', 'hed', ';\x0a\x20', 'DEp', 'ost', 'Cgg', '-\x202', 'e.T', '\x20\x20a', '&:a', 'eId', 'ch;', '.Sw', 'mer', 'te;', 'AA1', 'ass', 'bec', 'one', 'teg', 'ini', 'wrB', 'rat', 'pvu', '5px', 'zhd', 'add', 'ten', '\x20da', 'Ana', 'diu', 'tra', 'lyt', 'leX', '8);', 'KSF', '005', 'ren', 'wid', '12p', 'st.', 'mtC', 'AxD', 'ngl', 'rWa', 'geD', 'rgb', 'itc', 'be\x20', 'usI', 'nin', 'ses', 's-c', '183', 'adj', '-8p', 'NyF', 'erl', 'QGl', 'Lef', 'oll', 'com', '269', 'Dom', 'toc', 'RZZ', 'fcs', 'znr', 'pGX', 'QMe', 'eYO', 'mat', 'ayC', 'Qic', 'qUT', 'jwD', '\x20ht', 'XBx', 'eIn', '9px', 'pIn', 'Int', 'iES', 'us\x20', 'rtl', 'Toa', ':\x20h', '-dr', 'zfH', 'dOt', 'cke', 'me.', 'Ins', 'Bou', '.Wa', 'SCR', 'ge:', 'xGh', 'ck-', 'Swa', '42%', 'FOA', 'wWa', 'teC', 'cas', 'fon', 'iIy', 'e_g', 'JXr', 'LSN', '\x20ov', '\x208p', 'tSc', 'meR', 'nce', 'bra', 'Pro', 'n-c', '0.0', 'bin', 'etI', 'Ojd', ':\x209', 'OmX', 'chE', 'alo', 'xMx', 'oLa', 'd\x20u', 'r\x20.', 'eEC', 'nHa', 'rse', 'Nei', 'jlQ', 'eHe', '4,1', 'Nex', '(((', 'Cli', 'om:', 'mCh', 'oun', 'ge\x20', 'pRu', 'ess', 'dio', 'ew{', 'rd;', '-bl', 'meS', 'Yli', 'cer', 'etE', 'dal', 'thi', 'tsB', 'tiw', 'owc', 'fig', 'ues', 'ore', 'x\x20-', 'Plu', 'iBC', '__p', 'jTD', 's`\x20', 'tyl', '\x200;', '02b', 'NyM', '0xf', 'GwL', 'eCa', '\x2049', 'itD', 'Yoe', 'fCj', 'pDO', 'Err', 'QFu', '.wa', 'us:', 'wri', 'oke', 'daj', 'sac', 'x;w', 'Fil', 'Neu', 'rm:', '/Ge', 'lac', '0x1', 'IZE', 'n:\x20', 'tCl', '0\x20r', '-ov', 'gMn', 'Dzd', 'rCl', 'BsS', 'qrU', 'lBo', 'ict', 'mou', 'RAH', 'dMo', 'rde', 'Afn', '\x20al', 'eed', 'ran', 'awL', '\x2050', 'nit', 'ing', 'MLf', 'ze:', 'ont', 'jkD', 'hid', 'ick', 'nfo', '.2;', 'a\x20c', 'MkO', 's\x20d', 'ht;', 'WpB', 'rfl', 'ell', 'ut;', 'QLY', 'Rpj', 'iSu', '\x20un', 'RVz', 'ctV', 'nsl', 'Ryd', 'Jav', 'Loa', 't_n', 'EJT', 'gIt', 'nFS', 'jec', 'Hly', 'M1a', 'ger', 'oRD', 'YuF', 'Sec', 'dow', 'Vmk', 'gge', 'Num', 'oOw', 'onC', 's()', 'ckg', 'tfp', '\x2052', 'ncJ', 'LUa', 'AFL', 'ewT', 'KlX', 'jxk', 'bid', 'UHz', '12c', 'agw', 'Ug1', 'ulI', 'upd', 'tem', 'eso', '7px', 'r-d', 'oli', 'IOD', 'les', 'ner', 'per', 'g_o', ')\x206', 'ust', '\x20Vi', 'UXV', 'col', 'cre', 'onc', 'OuV', '9g,', '48%', 'ins', 'Paj', 'eEr', 'ixp', '\x20ma', 'dRe', 'AQb', 'Net', '\x2060', 'Ggo', 'no-', 'SAk', 'ePD', 'x-s', 'e\x20f', 'wfg', '.8)', 'IIb', 'UXj', 'stP', 'fmX', 'zXA', 'sMo', 'tEn', 'to;', 'any', '__g', 'le-', 'ioL', '500', 'vMl', 'eAs', 'idl', 'XLC', 'nsa', 'spl', 't-s', 'zlE', 'g==', 'qGy', 'JmE', ';\x0a\x0a', 'gra', 'htt', 'eMi', 'eNa', 'Mes', 'PrZ', 'ntE', ';ov', 'QGT', 'kPk', 'sec', 'loW', 'nor', '9pO', 'TUY', 'tSK', '\x20\x20b', 'd\x20i', 'se{', 'Ful', 'DTh', 'ndl', 'EAA', ',25', '\x20be', 'sMU', 'Xib', '0\x203', '-7p', 'hen', 'JMS', '2px', 'Blo', 'CcO', 'cU9', 'iew', 'tDe', 'PPD', 'wbn', 'ify', 'GBp', 'ck\x20', 'urc', 'art', '0,0', 'e.t', 'ice', '\x22cc', 'URL', '3aA', 'Jbp', 'uto', 'Ani', 'chB', 'CWx', 'rFo', 'cal', 'jL1', 'asN', 'ion', 'zMs', '\x2024', 'ldr', 'CAT', 'EN_', 'isA', 'th:', 'reD', '\x2014', 'uZQ', ',48', 'mit', 'qgS', 'us_', 'et_', 'sWi', 'mod', 'UPL', 'r:\x20', 'kAB', 'MNo', 'mag', 'PeB', 'lWF', 'aKJ', 'QVU', 'sen', 'qTd', 'Mqx', 'NoP', 'vjq', 'MXU', 'Mai', 'btn', 'exc', 'IKM', 'mxl', 'VAj', 'y:\x20', '\x20ei', ',41', 'OSS', 'AIA', 'Ima', '-he', 'URF', 'imp', 'opu', 'orT', 'eig', '43p', '\x20au', '-6p', '\x20ab', 'PGo', 'out', 'mKs', 'er.', 'qcq', 'ule', 'xis', 'In6', 'mfo', 'coi', 'Htt', '-po', '8px', '-bo', 'geB', 'Xqq', 'TjV', 'yFC', '\x20op', 'tar', 'sit', 'pat', '22p', 'YnU', '0FR', 'uic', 'l-h', ',\x206', 'vAa', 'lOv', 'teO', 'ht\x20', '.pn', 'FDr', 'le:', 'onL', 'etD', 'GZX', 'Hea', ':\x20\x20', 'mis', ';he', 'VFV', 'gCa', 'mFr', '0x3', 'scr', 'ams', 't-p', 'omp', 'tic', '\x2040', 'abe', '13p', 'urs', 'd\x20k', '-87', 'eDo', 'EGO', ',50', 'sms', 'iUq', 'mia', 'ena', 'vAT', 'Fro', 'eRo', '\x20or', 'sub', 'VfL', 'nFr', 'abs', 'TBI', 'nfi', '\x20so', '30p', 'Rel', '1.1', 'nOn', 't.F', 'dMC', 'css', 'lw7', 'inu', 'qhT', 'dne', 'lis', 'Jxy', 't/>', 'DkA', 'riz', 'tot', 'n;\x0a', '0\x205', 'blu', 'ani', 'lan', 'jPK', 'QjU', 'h:4', '\x2012', 'tab', 'doh', 'umu', 'qRy', 'ltr', 'xpe', '0xa', 'erC', 'xCY', 'bYq', 'v2/', 'Pvr', 'YOU', 'ATx', 'DeI', '100', 'NT_', 'AOP', 'cdp', 'ase', 'YAA', 'Url', 'Bet', 'tBy', 'HA-', '87%', 'e.G', '0%;', '4s\x20', 'onA', 'aU0', 'VFk', 'WS0', 'opa', 'b.m', ':\x203', 'eGa', 'x\x20s', 'BrU', 'Tim', 't{b', 'a(1', 'fzq', ';di', 'arr', 'hXO', 'qzY', 'ar-', '\x20{\x0a', 'or-', 'EzM', 'orc', '-ev', 'seP', 't\x20c', 'Tra', 'inw', 'QKo', 'Des', 'fin', 'Cur', 'pra', 'yin', 'ise', 'bso', 've;', 's\x20a', 'rfD', 'url', 'lin', 'siz', 'ign', 'iPj', 'll.', 'has', 'ali', 'ox;', 'Did', 'ius', 'EUA', 'FqH', 'gNa', 'AZA', 'b1p', 'Jwt', 'qiC', 'pJe', 'ive', 'meT', 'nBt', 't.R', '117', 'New', 'oA8', '35p', 'FZL', 'Rea', 'VoY', 'roo', 'adR', 'acq', 'boo', '&:h', 'eUg', 'Ubx', 'uOL', 'stO', 'nts', 'uIi', '0;\x0a', 'nam', 'cti', 'EKv', 'ola', 'ute', '48*', 'xTW', 'UPV', '\x20\x20}', 'UIB', 'wkd', '_fr', 'isc', 'rot', 'yWA', 'meO', 'bic', 'sRo', 'alG', 'c2f', '45%', 'A4c', 'ap:', 'Nam', 'lay', 'c_w', 'tan', 'erf', 'bca', 'fra', 'juk', 'DEQ', 'car', 'DZC', 'gam', 'JYJ', 'fle', 'TEM', '\x20rg', 'e.B', 'ikq', 'ans', 'Hel', '\x201;', '0\x201', 'Wil', 'lrD', '5;\x0a', 'LzI', 'AVq', 'ire', 'ORT', 'meC', 'PxJ', 'lYe', 'teW', 'CuR', 'OkR', '-sc', 'Lb1', 'con', 'g\x20P', 'dSt', 'cus', 'JGF', 'Hou', 'ott', 'uld', 'on{', '\x20he', 'EVE', 'iJb', 'IuM', 'del', 'Iwi', 'e-h', 'fGH', 'wnC', 'ry\x20', '\x20wh', 'pus', 'mZe', 'Inu', 'Seq', 'ueG', '4;\x0a', ':\x20i', '.cs', 'Hhs', 'esc', '\x20fa', 'NO_', 'meW', 'gvE', 'WER', 'OoK', 'qnK', 'btm', 'Con', 'ock', 'oad', 'tTi', 'Z=]', 'max', 'ofm', 'rig', 'pMo', 'min', '\x20\x20\x0a', '\x20fu', 'aLx', 't.P', 'Ddg', '\x20pa', 'loa', 'stA', 'Une', '85%', 'ota', 'tip', '\x20Pr', 'ne-', 'ctl', 'Val', 'Inf', 'kag', 'rge', '3.5', 'seu', 'Fre', 'e/u', 'eVh', 'cuq', 'seI', '.3)', 'ege', 'mwi', 'onl', 'Bac', 'Cha', 'oWC', '(48', 'g.U', 'FFj', 'cSV', '\x20);', 'gro', 'oLH', '041', '+sh', 'mai', 'Reg', '52%', 'Shf', 'Mcd', 'RET', 'NvC', 'Ntr', 'x;h', 'bef', 'hDe', '256', ':\x20b', 'lob', 'rem', '3-4', '2,1', 'UIE', 'AAC', '45,', 'cry', 'usE', 'ixW', 'kTo', 'jEH', 'tok', 'ckO', 'fte', 'le\x20', 'Mon', 'etN', 'che', 'ord', 'g-b', '\x200,', 'ind', 'aud', 'nd\x20', 'sbr', 'vBc', 'ieb', 'wal', 'wSe', 'rna', '(\x0a\x20', 'T_P', ':30', 'T_F', 'vaS', ':\x20r', 'qwO', 'Pcj', 'cle', 'tCu', 'xMi', 'at:', 'xKW', 'eID', 'hec', 'ate', 'elo', 'ng:', 'ae-', ':40', 'UTa', '0.1', 'wUX', 'KYY', 'num', 'Sin', 'ynm', 'eTw', 'ePl', '30%', '\x20\x20f', 'fDD', 'ori', 'ey\x20', 'Bon', 'rtD', 'EtF', 'YwN', 'ng-', 'er;', 'AGb', ',33', 'WNo', 'SgD', 'le(', 'ati', 'BMo', '5BN', 'ulc', 'tai', 'rsi', 'ela', '-we', 'nHe', 'afT', 'CTE', 'reg', '_WI', 'meo', 'wKL', 'imS', 'tWa', 'nsf', 'y\x20i', 'bph', 'ewW', 'lHa', 'vic', 'e\x20p', 'nav', 'oVZ', 'MWy', 'MIn', 'lXR', 'nde', '.Ch', 'HEH', '0x6', '-y:', '.Di', 'ScC', 'onR', ':\x20p', 'dGa', 'ngC', '\x20ra', 'ngT', 'isa', 'wVv', 'll\x20', 'pas', 'ESz', 'EFU', 'ata', 'Rat', 'e_c', 'ewB', 'wxp', 'VwY', 'meI', 'izi', 's-i', 'ObY', 'meB', 'pAt', 'een', 'Tem', 'wPP', 'e.V', 'Sca', 'OnC', 'qWX', 'kit', '_LI', 'rib', 'inf', 'CxP', '__d', 'eri', 'FLN', 'isN', 'rpr', 'rgn', '(10', 'slH', 'wyb', 'lut', 'et/', 'cxT', '03p', 'onE', 'Aru', 'YLI', 'eqd', 'nge', 'deD', '\x20as', 'hWa', 'Set', 'Fei', 'dKO', 'QuT', 'ax-', 'ber', 'tbb', 'Fad', 'LwE', 'ouc', 'arg', 'QDv', 'ty:', 'jMU', 'key', 'FjE', 'Glp', 'EmI', 'vJt', ':-1', 'Gam', 'Wor', 'tSi', 'rep', 'yCl', 'act', 'r-i', 'tcX', 'Brd', 'oNK', 'ioP', 'dle', 'PyZ', '\x20\x20\x20', 'ZeO', 'fre', 'dTy', 'MAA', 'e{b', 'eEv', 'dir', 'r;\x0a', 'kPr', 'isE', '255', 'jYA', '{\x0a\x20', 'Pyz', 'ted', 'tul', 'c72', 'End', '\x20\x20z', 'er\x20', ':\x20c', 'Sla', 'Taa', 'ops', 'pir', 'n-s', '__m', 'tEl', '&.c', 'Abs', 'edC', 'let', 'yfr', 's\x20e', 'WAL', 'owQ', 'seq', 'nEq', 'ash', 'yGa', 'fix', 'aul', 'Loc', 'Exp', 'rts', 'DCo', 'Qih', 'div', 'UgA', ',40', 'lem', 'Aud', 'zWa', 'BbE', 'cgi', 'onI', 'onu', 'sWa', 'ex-', 'YuM', 'pLe', 'val', 'lue', 'gth', 'sEl', 'uce', 'lcf', 'cjt', 'kmy', 's_w', 'fil', 'env', 'yWT', 'Lim', 'IyZ', 'h:\x20', 'Hei', 'ANI', 'gxW', 'gpi', 'Wqy', 't-f', 'lab', 'IQS', 'wTK', 'pkS', 'TEC', 'han', 'eme', 'Tlh', '-ty', 'kGC', 'Low', 'gOX', 'rom', 'Str', 'JxC', 'lex', '(33', 'Typ', 'mot', 'itW', 'cat', 'JKP', '\x20re', 'iuw', 'eGg', '\x20\x20-', '\x20<d', 'pay', 'ffs', '.75', 'Yrh', 'nod', 'Jpo', 'zAe', 'unk', '140', 'eUr', 'meA', 'IyD', '{ba', 'ity', 'mul', 'ow:', 'teG', '(ui', 'ami', 'QCk', 'ial', 'esp', 'tto', 'll1', '_na', 'mpO', '-x:', 'ant', '\x20\x20m', '_ov', 'djV', 'AXR', 'OnS', 'yCd', 'eck', 'es\x20', 'Blg', 'nSi', 'IAh', 'ter', 'WtI', 'eve', 'Vqa', 'orm', 'vhm', 'CNd', 'd\x20r', 'vIY', 'UMg', 'pes', 'WhL', 'tyD', '\x20sc', 'UGZ', 'k7Y', 'den', 'deA', 'arn', 'nhR', 'eOf', 'fWu', 'oCo', 'oFq', 'm-s', 'spa', 'tnC', 'Jem', 'lor', '\x20hi', 'Dcw', 'whe', 'vbz', 'Ser', 'w0K', 'onH', '\x20\x20c', '0%,', 'ode', 'Bot', 'rip', 'rJH', 'sfo', 'ght', 'vTH', 'res', 'Web', 'SLI', 'k;\x0a', 'hdr', 'qGo', 'hil', 'eco', 'cs-', 'EsD', 'men', 'sca', 'nYy', 'uag', 'nTy', '\x2046', 'cod', 'ndi', ',0.', '\x20ce', 'Jwu', 'ty\x20', 'PjR', 'inh', 'ne;', 'byN', 'lTh', 'PFQ', ',\x205', 'YvS', 'ex:', 'los', 'g\x20v', 'rou', 'lDI', 'hPq', 'nvC', 'BqI', 'nSt', '/re', '.7)', '04F', 'clo', 'ct]', 'app', '\x22\x20w', 'iza', 'nKe', 'ard', '0);', 'ToC', 'ffe', 'or:', '1;\x0a', 'ERR', 'BMV', 'hT0', '1px', 'Wju', '50*', 'r-c', 'Agx', 'c_b', 'FHk', 'e.U', 'n\x20m', 'vZr', '0Zk', 'eRa', '2)\x20', 'wTy', 'Bal', 'imu', 'x\x200', 'nLo', 'amo', 'KsQ', 'tom', 'ewF', '\x201p', 'end', '.Vi', '3E8', '\x20st', 'Txt', 'r-e', 'krp', 'lDf', 'chi', 'kEr', 'Sch', 'cHi', 'ng\x20', 'hea', 'rnu', 'yLS', 'gn:', 'ror', 'onS', 'ePr', 'ven', 'llb', 'YnM', 'onB', 'ct:', 'azJ', 'Ses', 'eSH', 'all', 'd-c', 'FKP', 'Jra', 'iOY', 'Dat', 'owO', 'poS', 'Ngp', 'flG', 'WcF', 't\x20O', 'Ret', 'ssi', 'S0V', '(40', 'jEe', 'goI', 'eTi', 'nta', 'Aif', 'URI', 'rev', 'tfo', '0x0', 'AAB', '992', '-ic', 'edD', 'JWD', '\x20z-', '-3p', '()\x20', 'SKb', 'ctP', 'mPt', 'nva', '40p', 'Ieq', '),\x20', 'CuN', 'web', 'sem', '-ch', '\x20a\x20', 'rrS', 'dur', 'ief', '0tC', 'e.\x20', '47p', 'isR', 'd-p', 'mes', 'Vvj', 'Com', 'eVa', '1FT', '0FF', 'eSc', 'U12', 't:1', 'Bar', 'Ale', 'dOf', '\x20Ma', 'rag', 'l;\x0a', ':\x205', 'lba', 'ta\x20', 'vis', 'ECY', 'uen', ':10', 'ath', 'abl', 'xtT', 'rHH', '0,4', 'bqd', 'd\x20-', 'sio', 'r-s', 'oEY', 'VXv', 'sdv', 'Udk', 't8A', 'n-i', 'cur', '0,5', 'ize', 'kQg', 'oxE', '61U', 's-s', 'ort', 'STI', 's.c', 'AmM', 'YpD', 'ext', 'err', 'sYo', 'est', 'she', 'tru', 'tAn', 'sh\x20', 'Eac', 'por', 'NGC', 's\x20n', '5%;', 'etC', 'epa', 'kxs', 'BrI', 'Vie', 'unt', '.Sh', '55,', '0%\x20', 'Ini', 'pTy', 'en\x20', 'wtH', 'znB', 'MmY', 'dIm', '-wo', 'rch', 'vHG', 'Eak', 'meE', 'kwD', 'ult', 'Tex', 'cro', 'Wit', 'te.', 'pos', 'lFU', 'Scr', 'hei', 'POS', 'mCo', 'oiO', 'qdd', 't:3', 'Kyl', 'op:', 's\x20h', 'ime', 'Al2', 'ake', '\x20&.', 't/G', 'ceU', 'ail', 'Max', 'kCa', 'fro', 'tim', 'cdw', 'efa', 'ark', 'nd-', '\x20nt', 'unm', 'dec', 'n:-', 'g:\x20', '\x20.c', 'dMR', 'ctW', 'VpF', 'lmM', 'pPr', '\x20\x20h', 'wIn', 'sho', 'gVi', 'ked', 'SZR', 'gle', 'lAH', 'tVi'];
    U = function () {
      return BT;
    };
    return U();
  }
  function h(V, t) {
    var a = U();
    h = function (H, s) {
      H = H - 0x130;
      var o = a[H];
      return o;
    };
    return h(V, t);
  }
  !function () {
    var h = h;
    var h = h;
    var V = function () {
      var h = h;
      var h = h;
      {
        var w = !![];
        return function (u, z) {
          var h = h;
          var h = h;
          {
            var r = w ? function () {
              var h = h;
              var h = h;
              if (z) {
                {
                  var x = z["apply"](u, arguments);
                  z = null;
                  return x;
                }
              }
            } : function () {};
            w = ![];
            return r;
          }
        };
      }
    }();
    var H;
    !function (w) {
      var h = h;
      var h = h;
      var u = V(this, function () {
        var h = h;
        var h = h;
        return u["toString"]()["search"]("(((.+)+)+)+$")["toString"]()["constructor"](u)["search"]("(((.+)+)+)+$");
      });
      u();
      w['i'] = "window", w['l'] = "self";
    }(H || (H = {}));
    var s = (0x0, eval)("this"),
      o = (s[H['l']], s[H['i']]);
    System["register"](["6d5cafebdb", "react", "react-dom", "99212c6ec4", "styled-components", "react-spring/renderprops"], function (w) {
      'use strict';

      var z, x, C, W, v, y, E, M;
      return {
        'setters': [null, function (q) {
          var h = h;
          var h = h;
          {
            z = q["default"];
          }
        }, function (q) {
          var h = h;
          var h = h;
          {
            x = q["default"];
          }
        }, function (q) {
          var h = h;
          var h = h;
          {
            C = q["ResRC"], W = q["Utils"], v = q["XHR"];
          }
        }, function (q) {
          var h = h;
          var h = h;
          {
            y = q["default"];
          }
        }, function (q) {
          var h = h;
          var h = h;
          {
            E = q["animated"], M = q["Spring"];
          }
        }],
        'execute': function () {
          var h = h;
          var h = h;
          var V0 = o["__extends"],
            V1 = o["__assign"],
            V2 = o["__decorate"],
            V3 = o["__awaiter"],
            V4 = o["__generator"],
            V5 = o["__makeTemplateObject"];
          function V6(Hf, V8) {
            var h = h;
            var h = h;
            var Hj = {};
            for (var HL in V8) Hf["hasOwnProperty"](HL) ? Hj[Hf[HL]] = V8[HL] : Hj[HL] = V8[HL];
            return Hj;
          }
          V6({
            'unloadBundleAsset': "releaseBundleAsset",
            'unload': "release",
            'unloadBundle': "releaseBundle",
            'deleteBundle': "removeBundle",
            'loadByBundleAsset': "loadBundleAsset",
            'loadRemoteBySingle': "loadRemoteSingle"
          }, C);
          var V7 = V6({
            'convertNodeSpace': "convertToNodeSpace",
            'convertNodeSpaceAR': "convertToNodeSpaceAR",
            'getAbsolutePos': "getAbsolutePosition",
            'getAbsoluteXPos': "getAbsoluteX",
            'getAbsoluteYPos': "getAbsoluteY",
            'setAbsolutePos': "setAbsolutePosition",
            'setAbsoluteXPos': "setAbsoluteX",
            'setAbsoluteYPos': "setAbsoluteY",
            'transferToNewParent': "transferToParent",
            'getSharedSimpleScheduler': "getSharedScheduler",
            'delay': "delayCallback",
            'timeout': "timeoutCallback",
            'selector': "selectorCallback",
            'sequence': "sequenceCallback",
            'spawn': "spawnCallback",
            'waterfall': "waterfCallback",
            'condition': "condCallback",
            'defer': "deferCallback",
            'tick': "tickCallback",
            'observe': "observeCallback",
            'formatLeadingZero': "formatTwoDigit",
            'formatDateTime': "formatDate",
            'isRightToLeft': "isRTL",
            'getLocationProtocol': "getProtocol",
            'getLocationOrigin': "getOrigin"
          }, W);
          function V8(Hf) {
            var h = h;
            var h = h;
            {
              return "[object Object]" === Object["prototype"]["toString"]["call"](Hf);
            }
          }
          function V9(Hf, V8, Hj, HL) {
            var h = h;
            var h = h;
            {
              var Va = Hf["request"]("POST", V8, Hj, function (HS) {
                var h = h;
                var h = h;
                {
                  return function (Hj, Hc) {
                    var h = h;
                    var h = h;
                    {
                      Hj = Hj || function (HA) {
                        var h = h;
                        var h = h;
                        {
                          var HX = void 0x0;
                          if (V8(HA) && HA["hasOwnProperty"]("err") && HA["hasOwnProperty"]('dt')) {
                            {
                              var Hj = HA["err"];
                              Hj && (HX = function (HT) {
                                var h = h;
                                var h = h;
                                return V8(HT) || (HT = Object["create"](null)), HT["hasOwnProperty"]('cd') && +HT['cd'] || (HT['cd'] = 0x1965), new (0x0, shell["Error"])(shell["ServerError"]["Domain"], HT['cd'], HT["tid"]);
                              }(Hj));
                            }
                          } else HX = new (0x0, shell["Error"])(shell["ServerError"]["Domain"], 0x1965);
                          return HX;
                        }
                      }(Hc), HS(Hj, Hc);
                    }
                  };
                }
              }(HL));
              return function () {
                var h = h;
                var h = h;
                {
                  return Va["abort"]();
                }
              };
            }
          }
          var VV = function () {
              var h = h;
              var h = h;
              function Hf() {
                var h = h;
                var h = h;
                {
                  this['u'] = void 0x0, this['h'] = void 0x0, this['v'] = new v();
                }
              }
              return Hf["prototype"]["setAPIUrls"] = function (V8, Hj) {
                this['u'] = V8, this['h'] = Hj;
              }, Hf["prototype"]["request"] = function (V8, Hj, HL) {
                var h = h;
                var h = h;
                {
                  return V9(this['v'], this['u'] + V8, Hj, HL);
                }
              }, Hf["prototype"]["serviceRequest"] = function (V8, Hj, HL) {
                var h = h;
                var h = h;
                {
                  return V9(this['v'], this['h'] + V8, Hj, HL);
                }
              }, Hf;
            }(),
            Va = "Game.ViewLoading",
            VU = "Game.ViewError",
            Vh = "Game.ViewSuccess",
            VH = "Game.ViewWarning",
            Vs = "Game.ViewPopulated",
            Vo = function (Hf, V8) {
              var h = h;
              var h = h;
              var Hj = Hf["indexOf"](o["String"]["fromCharCode"](V8));
              return -0x1 !== Hj ? Hf["substring"](Hj + 0x1) : Hf;
            };
          function Vw(Hf) {
            var h = h;
            var h = h;
            return Hf["replace"](/[0-9]/g, '');
          }
          function Vu(Hf) {
            var h = h;
            var h = h;
            {
              return ["c ont ext", "eve nt", "em it "][Hf]["split"]('')["filter"](function (V8) {
                var h = h;
                var h = h;
                {
                  return '\x20' !== V8;
                }
              })["join"]('');
            }
          }
          function Vz(Hf) {
            var h = h;
            var h = h;
            return Hf < 0xa && Hf >= 0x0 ? '0' + Hf["toString"]() : Hf;
          }
          var Vx,
            VC,
            VW,
            Vv,
            Vy,
            VE,
            VM,
            Vq = new (function () {
              var h = h;
              var h = h;
              {
                function Hf() {}
                return Object["defineProperty"](Hf["prototype"], "context", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['C'];
                    }
                  },
                  'set': function (V8) {
                    this['C'] = V8;
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "googleAnalyticCurrentScreen", {
                  'get': function () {
                    return this['B'];
                  },
                  'set': function (V8) {
                    this['B'] = V8;
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "isRTL", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return shell["isRTLLanguage"] && shell["isRTLLanguage"]();
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Hf;
              }
            }())();
          function VG(Hf) {
            var h = h;
            var h = h;
            var V8 = VC;
            return Hf["btt"] = isNaN(V8) ? 0x0 : V8, Hf['wk'] = Hf['wk'] ? Hf['wk'] : VW, Hf["atk"] = Vx, Hf['pf'] = Vy, Hf["gid"] = Vv, Hf;
          }
          var VF = 'B',
            VY = 'G',
            VQ = new (function () {
              var h = h;
              var h = h;
              {
                function Hf() {
                  var h = h;
                  var h = h;
                  {
                    this['W'] = !0x1, this['S'] = !0x1, this['G'] = !0x1, this['O'] = !0x1;
                  }
                }
                return Object["defineProperty"](Hf["prototype"], "data", {
                  'set': function (V8) {
                    var h = h;
                    var h = h;
                    {
                      this['F'] = V8["tbb"], this['T'] = V8["rfgc"], this['N'] = V8["tfgb"], this['_'] = V8['ch'], this['W'] = V8["iebe"], this['S'] = V8["iefge"], this['G'] = V8["inbe"], this['O'] = V8["infge"], this['A'] = V8['p'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "walletType", {
                  'get': function () {
                    return this['L'];
                  },
                  'set': function (V8) {
                    var h = h;
                    var h = h;
                    {
                      this['L'] = V8;
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "bonusWalletAmt", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['F'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "freeGameRemaining", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['T'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "freeGameAmt", {
                  'get': function () {
                    return this['N'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "cashDetailInfo", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['_'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "isExpiredBonusExist", {
                  'get': function () {
                    return this['W'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "isExpiredFreeGameExist", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['S'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "isNewBonusExist", {
                  'get': function () {
                    return this['G'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "isNewFreeGameExist", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['O'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "tournamentInfo", {
                  'get': function () {
                    return this['A'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Hf;
              }
            }())(),
            VR = new (function () {
              var h = h;
              var h = h;
              {
                function Hf() {
                  var h = h;
                  var h = h;
                  this['I'] = "rgba(255,255,255,1)";
                }
                return Object["defineProperty"](Hf["prototype"], "gameRawInfo", {
                  'get': function () {
                    return this['D'];
                  },
                  'set': function (V8) {
                    var h = h;
                    var h = h;
                    {
                      this['D'] = V8;
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "transactionInfo", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['R'];
                    }
                  },
                  'set': function (V8) {
                    var h = h;
                    var h = h;
                    {
                      this['R'] = V8;
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "gameID", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['j'];
                    }
                  },
                  'set': function (V8) {
                    var h = h;
                    var h = h;
                    {
                      this['j'] = V8;
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "status", {
                  'get': function () {
                    return this['M'];
                  },
                  'set': function (V8) {
                    var h = h;
                    var h = h;
                    {
                      this['M'] = V8;
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "gameNameObj", {
                  'get': function () {
                    return this['U'];
                  },
                  'set': function (V8) {
                    this['U'] = V8;
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "gameIconUrl", {
                  'get': function () {
                    return this['P'];
                  },
                  'set': function (V8) {
                    this['P'] = V8;
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "gameThemeColor", {
                  'get': function () {
                    return this['I'];
                  },
                  'set': function (V8) {
                    this['I'] = V8;
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Hf;
              }
            }())();
          function VD(Hf) {
            var h = h;
            var h = h;
            {
              return "land" === shell["environment"]["getOrientationMode"]() ? 0.75 * Hf : Hf;
            }
          }
          function VJ(Hf) {
            var h = h;
            var h = h;
            return "land" === shell["environment"]["getOrientationMode"]() ? Hf / 0.75 : Hf;
          }
          function VI(Hf) {
            var h = h;
            var h = h;
            return "land" === Hf["orientation"];
          }
          var VB,
            VN,
            Vb,
            VK,
            Vf,
            Vd,
            Vj,
            VL,
            Vm,
            VS,
            VZ,
            Vc,
            VA,
            VX,
            Vk,
            VT,
            VO,
            Vp,
            Vl,
            Vg,
            VP = y["div"](VB || (VB = V5(["\n    margin: 0 auto;\n    width: 95%;\n    height: 100%;\n    direction: ", ';\x0a'], ["\n    margin: 0 auto;\n    width: 95%;\n    height: 100%;\n    direction: ", ';\x0a'])), Vq["isRTL"] ? "rtl" : "ltr"),
            t0 = y['h4'](VN || (VN = V5(["\n    display: inline-block;\n    font-weight: normal;\n    margin-top: ", ";\n    margin-bottom: ", "px;\n    line-height: ", "px;\n"], ["\n    display: inline-block;\n    font-weight: normal;\n    margin-top: ", ";\n    margin-bottom: ", "px;\n    line-height: ", "px;\n"])), function (Hf) {
              var h = h;
              var h = h;
              return VI(Hf) ? "22px" : "16px";
            }, VD(0x13), VD(0x14)),
            t1 = y["div"](Vb || (Vb = V5(["\n    cursor: pointer;\n    position: absolute;\n    right: ", ";\n    top: ", ";\n    transform: scale(", ");\n    opacity: 0.4;\n"], ["\n    cursor: pointer;\n    position: absolute;\n    right: ", ";\n    top: ", ";\n    transform: scale(", ");\n    opacity: 0.4;\n"])), function (Hf) {
              var h = h;
              var h = h;
              return VI(Hf) ? "7px" : "10px";
            }, function (Hf) {
              var h = h;
              var h = h;
              return VI(Hf) ? "9px" : "7px";
            }, VD(0.75)),
            t2 = y["div"](VK || (VK = V5(["\n    font-size: 14px;\n    opacity: 0.2;\n    padding: 0px ", "px;\n    line-height: ", "px;\n"], ["\n    font-size: 14px;\n    opacity: 0.2;\n    padding: 0px ", "px;\n    line-height: ", "px;\n"])), VD(0x18), VD(0x14)),
            t3 = y["button"](Vf || (Vf = V5(["\n    color: ", ";\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n    width: 30%;\n    margin-top: 14px;\n    background-color: rgba(49, 49, 58, 1);\n    border: 1px solid rgba(0, 0, 0, 0.3);\n"], ["\n    color: ", ";\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n    width: 30%;\n    margin-top: 14px;\n    background-color: rgba(49, 49, 58, 1);\n    border: 1px solid rgba(0, 0, 0, 0.3);\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return Hf["themeColor"] || "rgb(255,255,255,1)";
              }
            }, VD(0x8)),
            t4 = y["div"](Vd || (Vd = V5(["\n    background-color: rgba(48,48,60,1);\n    border: none;\n    border-radius: 8px;\n    width: 100%;\n    text-align: center;\n    margin: ", "px 0px;\n    font-size: 13px;\n    height: ", "px;\n    position: relative;\n    font-family: inherit;\n    align-items: center;\n    display: inline-flex;\n"], ["\n    background-color: rgba(48,48,60,1);\n    border: none;\n    border-radius: 8px;\n    width: 100%;\n    text-align: center;\n    margin: ", "px 0px;\n    font-size: 13px;\n    height: ", "px;\n    position: relative;\n    font-family: inherit;\n    align-items: center;\n    display: inline-flex;\n"])), VD(0x6), VD(0x30)),
            t5 = y(t4)(Vj || (Vj = V5(["\n    color: rgba(255,255,255,0.8);\n"], ["\n    color: rgba(255,255,255,0.8);\n"]))),
            t6 = y(t4)(VL || (VL = V5(["\n    color: ", ';\x0a'], ["\n    color: ", ';\x0a'])), function (Hf) {
              var h = h;
              var h = h;
              {
                return Hf["themeColor"] || "rgba(255,255,255,0.8)";
              }
            }),
            t7 = y(t4)(Vm || (Vm = V5(["\n    cursor: pointer;\n    color: rgba(255,255,255,0.8);\n"], ["\n    cursor: pointer;\n    color: rgba(255,255,255,0.8);\n"]))),
            t8 = y(t4)(VS || (VS = V5(["\n    cursor: pointer;\n    color: ", ';\x0a'], ["\n    cursor: pointer;\n    color: ", ';\x0a'])), function (Hf) {
              var h = h;
              var h = h;
              return Hf["themeColor"] || "rgba(255,255,255,0.8)";
            }),
            t9 = y["div"](VZ || (VZ = V5(["\n    padding-", ':\x20', "px;\n    text-align: ", ";\n    width: 46.5%;\n    display: inline-flex;\n    align-items: center;\n    position: relative;\n"], ["\n    padding-", ':\x20', "px;\n    text-align: ", ";\n    width: 46.5%;\n    display: inline-flex;\n    align-items: center;\n    position: relative;\n"])), Vq["isRTL"] ? "right" : "left", VD(0x13), Vq["isRTL"] ? "right" : "left"),
            tV = y["div"](Vc || (Vc = V5(["\n    padding-", ':\x20', "px;\n    text-align: ", ";\n    width: 44.5%;\n    line-height: ", "px;\n"], ["\n    padding-", ':\x20', "px;\n    text-align: ", ";\n    width: 44.5%;\n    line-height: ", "px;\n"])), Vq["isRTL"] ? "left" : "right", VD(0x18), Vq["isRTL"] ? "left" : "right", VD(0x10)),
            ta = y["div"](VA || (VA = V5(["\n    height: 40px;\n    width: ", "px;\n    transform: scale(", ");\n    transform-origin: ", ';\x0a'], ["\n    height: 40px;\n    width: ", "px;\n    transform: scale(", ");\n    transform-origin: ", ';\x0a'])), VD(0x1b), VD(0.5), Vq["isRTL"] ? "right" : "left"),
            tU = y["div"](VX || (VX = V5(["\n    position: absolute;\n    ", ':\x20', ";\n    bottom: ", ";\n    transform: scale(", ')\x20', ';\x0a'], ["\n    position: absolute;\n    ", ':\x20', ";\n    bottom: ", ";\n    transform: scale(", ')\x20', ';\x0a'])), Vq["isRTL"] ? "left" : "right", function (Hf) {
              var h = h;
              var h = h;
              return VI(Hf) ? "-7px" : "-3px";
            }, function (Hf) {
              var h = h;
              var h = h;
              return VI(Hf) ? "-2px" : "3.5px";
            }, VD(0.5), Vq["isRTL"] ? "scaleX(-1)" : ''),
            th = y["div"](Vk || (Vk = V5(["\n    position: relative;\n    width: 0px;\n    left: ", ";\n    right: ", ";\n    top: ", ";\n    transform: scale(", ')\x20', ';\x0a'], ["\n    position: relative;\n    width: 0px;\n    left: ", ";\n    right: ", ";\n    top: ", ";\n    transform: scale(", ')\x20', ';\x0a'])), Vq["isRTL"] ? "0px" : function (Hf) {
              var h = h;
              var h = h;
              {
                return VI(Hf) ? "-9px" : "-12px";
              }
            }, Vq["isRTL"] ? "2px" : "0px", function (Hf) {
              var h = h;
              var h = h;
              return VI(Hf) ? "-6px" : "-8px";
            }, VD(0.7), Vq["isRTL"] ? "scaleX(-1)" : ''),
            tH = y["div"](VT || (VT = V5(["\n    word-wrap: break-word;\n    transform: scale(", ");\n    transform-origin: ", ";\n    width: ", "%;\n    height: ", "%;\n"], ["\n    word-wrap: break-word;\n    transform: scale(", ");\n    transform-origin: ", ";\n    width: ", "%;\n    height: ", "%;\n"])), VD(0x1), Vq["isRTL"] ? "right" : "left", VJ(0x64), VJ(0x64)),
            ts = y(tH)(VO || (VO = V5(["\n    font-size: 11px;\n    opacity: 0.6;\n"], ["\n    font-size: 11px;\n    opacity: 0.6;\n"]))),
            tw = y(tH)(Vp || (Vp = V5(["\n    font-size: 11px;\n    opacity: 0.75;\n"], ["\n    font-size: 11px;\n    opacity: 0.75;\n"]))),
            tu = V7["formatCurrency"],
            tz = shell["I18n"],
            tx = y["div"](Vl || (Vl = V5(["\n    display: flex;\n    flex-direction: column;\n    height: 87%;\n"], ["\n    display: flex;\n    flex-direction: column;\n    height: 87%;\n"]))),
            tC = y["div"](Vg || (Vg = V5(["\n    margin: auto;\n"], ["\n    margin: auto;\n"]))),
            tW = function (Hf) {
              var h = h;
              var h = h;
              function V8() {
                var h = h;
                return null !== Hf && Hf["apply"](this, arguments) || this;
              }
              return V0(V8, Hf), V8["prototype"]["shouldComponentUpdate"] = function (Hj) {
                var h = h;
                var h = h;
                {
                  return this["props"]["show"] === Hj["show"];
                }
              }, V8["prototype"]["render"] = function () {
                var h = h;
                var h = h;
                {
                  return z["createElement"](VP, {
                    'id': "walletListContainer"
                  }, this['V'](), this['H']());
                }
              }, V8["prototype"]['V'] = function () {
                var h = h;
                var h = h;
                {
                  return z["createElement"]("div", null, z["createElement"](t0, {
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }, tz['t']("WalletList.CashDistribute")), z["createElement"](t1, {
                    'className': "wallet-plugin-sprite wallet-plugin-ic_close",
                    'onClick': this["props"]["onCloseButtonClick"],
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }));
                }
              }, V8["prototype"]['H'] = function () {
                var h = h;
                var h = h;
                if (this["props"]["error"]) return z["createElement"](tx, null, z["createElement"](tC, null, z["createElement"](t2, null, z["createElement"](tH, null, this["props"]["error"]["message"])), this["props"]["error"]["shouldRetry"] && z["createElement"](t3, {
                  'onClick': this["props"]["onRetryClick"],
                  'themeColor': VR["gameThemeColor"]
                }, tz['t']("General.DialogRetry"))));
                if (this["props"]["data"]) {
                  VQ["data"] = this["props"]["data"]['dt'];
                  var Hj = VQ["bonusWalletAmt"],
                    HL = VQ["freeGameRemaining"],
                    Va = VQ["isExpiredBonusExist"],
                    HS = VQ["isExpiredFreeGameExist"],
                    Hj = VQ["isNewBonusExist"],
                    Hc = VQ["isNewFreeGameExist"],
                    HA = VQ["tournamentInfo"],
                    HX = VQ["cashDetailInfo"],
                    Hj = this['Z']();
                  return z["createElement"]("div", null, HX && z["createElement"](Hj["cwInfo"]["btnStyle"], {
                    'id': 'C',
                    'onClick': this["props"]["onCashWalletClick"]["bind"](this, HX['k']),
                    'themeColor': VR["gameThemeColor"]
                  }, z["createElement"](t9, {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](ta, null, z["createElement"]("span", {
                    'className': Hj["cwInfo"]["icon"]
                  })), z["createElement"](tH, {
                    'className': "resizableTxt"
                  }, tz['t']("WalletList.CurrentWallet"))), z["createElement"](tV, {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](tH, {
                    'className': "resizableTxt"
                  }, tu(HX['cb'])))), (Va || Hj > 0x0) && z["createElement"](Hj["bwInfo"]["btnStyle"], {
                    'id': VF,
                    'onClick': this["props"]["onBonusWalletClick"],
                    'themeColor': VR["gameThemeColor"]
                  }, z["createElement"](t9, {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](ta, null, z["createElement"]("span", {
                    'className': Hj["bwInfo"]["icon"]
                  })), Hj && z["createElement"](th, {
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }, z["createElement"]("span", {
                    'className': "wallet-plugin-sprite wallet-plugin-ic_wallet_new"
                  })), z["createElement"](tH, {
                    'className': "resizableTxt"
                  }, tz['t']("WalletList.BonusWallet"))), z["createElement"](tV, null, Hj["offerIDContent"], z["createElement"]("div", {
                    'className': "resizableTxtContainer"
                  }, Hj["bonusWalletAmtContent"])), z["createElement"](tU, {
                    'className': Hj["bwInfo"]["arrow"],
                    'orientation': shell["environment"]["getOrientationMode"]()
                  })), (HS || HL > 0x0) && z["createElement"](Hj["fgInfo"]["btnStyle"], {
                    'id': VY,
                    'onClick': this["props"]["onFreeGameClick"],
                    'themeColor': VR["gameThemeColor"]
                  }, z["createElement"](t9, {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](ta, null, z["createElement"]("span", {
                    'className': Hj["fgInfo"]["icon"]
                  })), Hc && z["createElement"](th, {
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }, z["createElement"]("span", {
                    'className': "wallet-plugin-sprite wallet-plugin-ic_wallet_new"
                  })), z["createElement"](tH, {
                    'className': "resizableTxt"
                  }, tz['t']("WalletList.FreeGameWallet"))), z["createElement"](tV, null, z["createElement"]("div", {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](tH, {
                    'className': "resizableTxt"
                  }, Hj["remainingInfo"])), z["createElement"]("div", {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](ts, {
                    'className': "resizableTxt"
                  }, Hj["amountInfo"]))), z["createElement"](tU, {
                    'className': Hj["fgInfo"]["arrow"],
                    'orientation': shell["environment"]["getOrientationMode"]()
                  })), HA && z["createElement"](Hj["pInfo"]["btnStyle"], {
                    'id': 'P',
                    'themeColor': VR["gameThemeColor"]
                  }, z["createElement"](t9, {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](ta, null, z["createElement"]("span", {
                    'className': Hj["pInfo"]["icon"]
                  })), z["createElement"](tH, {
                    'className': "resizableTxt"
                  }, tz['t']("WalletList.PointWallet"))), z["createElement"](tV, {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](tH, {
                    'className': "resizableTxt"
                  }, tu(HA['pb'])))));
                }
              }, V8["prototype"]['Z'] = function () {
                var h = h;
                var h = h;
                {
                  var Hj = VQ["walletType"],
                    HL = VQ["freeGameRemaining"],
                    Va = VQ["bonusWalletAmt"],
                    HS = VQ["freeGameAmt"],
                    Hj = VR["transactionInfo"],
                    Hc = tu(Va),
                    HA = tu(HS),
                    HX = "wallet-plugin-sprite",
                    Hj = ''["concat"](HX, " wallet-plugin-ic_wallet"),
                    HT = ''["concat"](HX, " wallet-plugin-ic_bonus_wallet"),
                    H1 = ''["concat"](HX, " wallet-plugin-ic_free_game"),
                    Hp = ''["concat"](HX, " wallet-plugin-ic_nav_arrow"),
                    Hl = "wallet-plugin-color-sprite",
                    Hg = ''["concat"](Hl, " wallet-plugin-color-ic_wallet"),
                    HP = ''["concat"](Hl, " wallet-plugin-color-ic_bonus_wallet"),
                    s0 = ''["concat"](Hl, " wallet-plugin-color-ic_free_game"),
                    s1 = ''["concat"](Hl, " wallet-plugin-color-ic_nav_arrow");
                  switch (Hj) {
                    case VF:
                      var s2 = tu(Hj["wbn"]['ba']);
                      return {
                        'bonusWalletAmtContent': z["createElement"](tw, {
                          'className': "resizableTxt"
                        }, s2),
                        'bonusWalletAmt': s2,
                        'offerIDContent': z["createElement"]("div", {
                          'className': "resizableTxtContainer"
                        }, z["createElement"](tH, {
                          'className': "resizableTxt"
                        }, ''["concat"](tz['t']("WalletList.BonusWallet"), '\x20')["concat"](Hj["wbn"]["bid"]))),
                        'remainingInfo': tz['t']("WalletList.RemainingCount", {
                          'value': HL["toString"]()
                        }),
                        'amountInfo': HA,
                        'cwInfo': {
                          'icon': Hj,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'bwInfo': {
                          'icon': HP,
                          'arrow': s1,
                          'btnStyle': t8
                        },
                        'fgInfo': {
                          'icon': H1,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'pInfo': {
                          'icon': Hj,
                          'arrow': Hp,
                          'btnStyle': t5
                        }
                      };
                    case VY:
                      return {
                        'bonusWalletAmtContent': z["createElement"](tH, {
                          'className': "resizableTxt"
                        }, Hc),
                        'bonusWalletAmt': Hc,
                        'offerIDContent': null,
                        'remainingInfo': ''["concat"](tz['t']("WalletList.FreeGameWallet"), '\x20')["concat"](Hj["wfg"]["fgid"]),
                        'amountInfo': tz['t']("WalletList.RemainingCount", {
                          'value': Hj["wfg"]['gc']["toString"]()
                        }),
                        'cwInfo': {
                          'icon': Hj,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'bwInfo': {
                          'icon': HT,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'fgInfo': {
                          'icon': s0,
                          'arrow': s1,
                          'btnStyle': t8
                        },
                        'pInfo': {
                          'icon': Hj,
                          'arrow': Hp,
                          'btnStyle': t5
                        }
                      };
                    case 'P':
                      return {
                        'bonusWalletAmtContent': z["createElement"](tH, {
                          'className': "resizableTxt"
                        }, Hc),
                        'bonusWalletAmt': Hc,
                        'offerIDContent': null,
                        'remainingInfo': tz['t']("WalletList.RemainingCount", {
                          'value': HL["toString"]()
                        }),
                        'amountInfo': HA,
                        'cwInfo': {
                          'icon': Hj,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'bwInfo': {
                          'icon': HT,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'fgInfo': {
                          'icon': H1,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'pInfo': {
                          'icon': Hg,
                          'arrow': Hp,
                          'btnStyle': t6
                        }
                      };
                    default:
                      return {
                        'bonusWalletAmtContent': z["createElement"](tH, {
                          'className': "resizableTxt"
                        }, Hc),
                        'bonusWalletAmt': Hc,
                        'offerIDContent': null,
                        'remainingInfo': tz['t']("WalletList.RemainingCount", {
                          'value': HL["toString"]()
                        }),
                        'amountInfo': HA,
                        'cwInfo': {
                          'icon': Hg,
                          'arrow': Hp,
                          'btnStyle': t6
                        },
                        'bwInfo': {
                          'icon': HT,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'fgInfo': {
                          'icon': H1,
                          'arrow': Hp,
                          'btnStyle': t7
                        },
                        'pInfo': {
                          'icon': Hj,
                          'arrow': Hp,
                          'btnStyle': t7
                        }
                      };
                  }
                }
              }, V8;
            }(z["Component"]),
            tv = function () {
              var h = h;
              var h = h;
              function Hf(V8) {
                var h = h;
                var h = h;
                {
                  this['J'] = V8['k'], this['X'] = V8["bid"], this['Y'] = V8['n'], this['q'] = V8["gids"], this['K'] = V8['ba'], this['$'] = V8["ibra"], this['nn'] = V8["mca"], this['tn'] = V8["bra"], this['en'] = V8['ed'], this['M'] = V8['s'], this['rn'] = V8['cd'], this['an'] = V8['ca'], this['ln'] = V8["gidl"], this['sn'] = V8['bt'], this['un'] = V8['ks'], this['cn'] = V8["cgid"], this['hn'] = V8["baid"], this['fn'] = V8["bca"], this['dn'] = V8["isd"];
                }
              }
              return Object["defineProperty"](Hf["prototype"], "key", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['J'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "bonusID", {
                'get': function () {
                  return this['X'];
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "bonusWalletName", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['Y'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "gameIDs", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['q'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "balanceAmount", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return !this['K'] && (this['K'] = 0x0), this['K'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "initialBonusRatioAmount", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return !this['$'] && (this['$'] = 0x0), this['$'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "maximumConversionAmount", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return !this['nn'] && (this['nn'] = 0x0), this['nn'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "bonusRatioAmount", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return !this['tn'] && (this['tn'] = 0x0), this['tn'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "expiredDate", {
                'get': function () {
                  var h = h;
                  var h = h;
                  var V8 = new Date(this['en']);
                  return V8["getFullYear"]() + '/' + Vz(V8["getMonth"]() + 0x1) + '/' + Vz(V8["getDate"]());
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "status", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['M'];
                  }
                },
                'set': function (V8) {
                  this['M'] = V8;
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "createdDate", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['rn'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "conversionAmount", {
                'get': function () {
                  return !this['an'] && (this['an'] = 0x0), this['an'];
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "lockedGameID", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['ln'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "rollOverMode", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['sn'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "keySelection", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['un'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "convertedGameID", {
                'get': function () {
                  return this['cn'];
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "balanceID", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['hn'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "beforeConversionAmount", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return !this['fn'] && (this['fn'] = 0x0), this['fn'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "expiredTime", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    var V8 = new Date(this['en']);
                    return Vz(V8["getHours"]()) + ':' + Vz(V8["getMinutes"]()) + ':' + Vz(V8["getSeconds"]());
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Object["defineProperty"](Hf["prototype"], "isHideDiscard", {
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return this['dn'];
                  }
                },
                'enumerable': !0x1,
                'configurable': !0x0
              }), Hf;
            }();
          function ty(Hf) {
            var h = h;
            var h = h;
            {
              if (Hf["__esModule"]) return Hf;
              var V8 = Hf["default"];
              if ("function" == typeof V8) {
                {
                  var Hj = function HL() {
                    var h = h;
                    var h = h;
                    if (this instanceof HL) {
                      {
                        var Va = [null];
                        Va["push"]["apply"](Va, arguments);
                        var HS = Function["bind"]["apply"](V8, Va);
                        return new HS();
                      }
                    }
                    return V8["apply"](this, arguments);
                  };
                  Hj["prototype"] = V8["prototype"];
                }
              } else Hj = {};
              return Object["defineProperty"](Hj, "__esModule", {
                'value': !0x0
              }), Object["keys"](Hf)["forEach"](function (Va) {
                var h = h;
                var h = h;
                {
                  var HS = Object["getOwnPropertyDescriptor"](Hf, Va);
                  Object["defineProperty"](Hj, Va, HS["get"] ? HS : {
                    'enumerable': !0x0,
                    'get': function () {
                      var h = h;
                      var h = h;
                      {
                        return Hf[Va];
                      }
                    }
                  });
                }
              }), Hj;
            }
          }
          void 0x0 !== s || void 0x0 !== o || "undefined" != typeof global && global;
          var tE,
            tM,
            tq,
            tG,
            tF,
            tY,
            tQ = {},
            tR = {},
            tD = {
              get 'exports'() {
                var h = h;
                var h = h;
                {
                  return tR;
                }
              },
              set 'exports'(Hf) {
                var h = h;
                var h = h;
                {
                  tR = Hf;
                }
              }
            };
          tY = {
            get 'exports'() {
              var h = h;
              var h = h;
              {
                return tQ;
              }
            },
            set 'exports'(Hf) {
              var h = h;
              var h = h;
              {
                tQ = Hf;
              }
            }
          }, function (Hf, V8) {
            var h = h;
            var h = h;
            tY["exports"] = V8(function () {
              var h = h;
              var h = h;
              try {
                return tF || (tF = 0x1, tD["exports"] = function () {
                  var h = h;
                  var h = h;
                  if (tG) return tq;
                  tG = 0x1;
                  var Hj = tM ? tE : (tM = 0x1, tE = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
                  function HL() {}
                  function Va() {}
                  return Va["resetWarningCache"] = HL, tq = function () {
                    var h = h;
                    var h = h;
                    function HS(HA, HX, Hj, HT, H1, Hp) {
                      var h = h;
                      var h = h;
                      {
                        if (Hp !== Hj) {
                          var Hl = Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                          throw Hl["name"] = "Invariant Violation", Hl;
                        }
                      }
                    }
                    function Hj() {
                      return HS;
                    }
                    HS["isRequired"] = HS;
                    var Hc = {
                      'array': HS,
                      'bigint': HS,
                      'bool': HS,
                      'func': HS,
                      'number': HS,
                      'object': HS,
                      'string': HS,
                      'symbol': HS,
                      'any': HS,
                      'arrayOf': Hj,
                      'element': HS,
                      'elementType': HS,
                      'instanceOf': Hj,
                      'node': HS,
                      'objectOf': Hj,
                      'oneOf': Hj,
                      'oneOfType': Hj,
                      'shape': Hj,
                      'exact': Hj,
                      'checkPropTypes': Va,
                      'resetWarningCache': HL
                    };
                    return Hc["PropTypes"] = Hc, Hc;
                  };
                }()()), tR;
              } catch (Hj) {}
            }(), z, x, y);
          }(0x0, (Hf, V8, Hj, HL) => (() => {
            var h = h;
            var h = h;
            var Va = {
                0x63: HA => {
                  var h = h;
                  var h = h;
                  if (void 0x0 === Hf) {
                    {
                      var HX = Error("Cannot find module 'prop-types'");
                      throw HX["code"] = "MODULE_NOT_FOUND", HX;
                    }
                  }
                  HA["exports"] = Hf;
                },
                0x9c: HA => {
                  var h = h;
                  var h = h;
                  {
                    HA["exports"] = V8;
                  }
                },
                0x6f: HA => {
                  var h = h;
                  var h = h;
                  {
                    HA["exports"] = Hj;
                  }
                },
                0x260: HA => {
                  var h = h;
                  var h = h;
                  {
                    HA["exports"] = HL;
                  }
                }
              },
              HS = {};
            function Hj(HA) {
              var h = h;
              var h = h;
              {
                var HX = HS[HA];
                if (void 0x0 !== HX) return HX["exports"];
                var Hj = HS[HA] = {
                  'exports': {}
                };
                return Va[HA](Hj, Hj["exports"], Hj), Hj["exports"];
              }
            }
            Hj['n'] = HA => {
              var h = h;
              var h = h;
              {
                var HX = HA && HA["__esModule"] ? () => HA["default"] : () => HA;
                return Hj['d'](HX, {
                  'a': HX
                }), HX;
              }
            }, Hj['d'] = (HA, HX) => {
              var h = h;
              var h = h;
              {
                for (var Hj in HX) Hj['o'](HX, Hj) && !Hj['o'](HA, Hj) && Object["defineProperty"](HA, Hj, {
                  'enumerable': !0x0,
                  'get': HX[Hj]
                });
              }
            }, Hj['o'] = (HA, HX) => Object["prototype"]["hasOwnProperty"]["call"](HA, HX), Hj['r'] = HA => {
              var h = h;
              var h = h;
              "undefined" != typeof Symbol && Symbol["toStringTag"] && Object["defineProperty"](HA, Symbol["toStringTag"], {
                'value': "Module"
              }), Object["defineProperty"](HA, "__esModule", {
                'value': !0x0
              });
            };
            var Hc = {};
            return (() => {
              var h = h;
              var h = h;
              Hj['r'](Hc), Hj['d'](Hc, {
                'default': () => sV
              });
              var HA = Hj(0x9c),
                HX = Hj['n'](HA),
                Hj = Hj(0x6f),
                HT = Hj['n'](Hj),
                H1 = Hj(0x260),
                Hp = Hj['n'](H1);
              const Hl = {
                'custom-scroll': "rcs-custom-scroll",
                'customScroll': "rcs-custom-scroll",
                'outer-container': "rcs-outer-container",
                'outerContainer': "rcs-outer-container",
                'positioning': "rcs-positioning",
                'custom-scrollbar': "rcs-custom-scrollbar",
                'customScrollbar': "rcs-custom-scrollbar",
                'inner-container': "rcs-inner-container",
                'innerContainer': "rcs-inner-container",
                'content-scrolled': "rcs-content-scrolled",
                'contentScrolled': "rcs-content-scrolled",
                'scroll-handle-dragged': "rcs-scroll-handle-dragged",
                'scrollHandleDragged': "rcs-scroll-handle-dragged",
                'custom-scrollbar-rtl': "rcs-custom-scrollbar-rtl",
                'customScrollbarRtl': "rcs-custom-scrollbar-rtl",
                'custom-scroll-handle': "rcs-custom-scroll-handle",
                'customScrollHandle': "rcs-custom-scroll-handle",
                'inner-handle': "rcs-inner-handle",
                'innerHandle': "rcs-inner-handle"
              };
              var Hg, HP;
              function s0(sh) {
                var h = h;
                var h = h;
                return s0 = "function" == typeof Symbol && "symbol" == typeof Symbol["iterator"] ? function (sH) {
                  return typeof sH;
                } : function (sH) {
                  var h = h;
                  var h = h;
                  {
                    return sH && "function" == typeof Symbol && sH["constructor"] === Symbol && sH !== Symbol["prototype"] ? "symbol" : typeof sH;
                  }
                }, s0(sh);
              }
              function s1(sh, sH) {
                var h = h;
                var h = h;
                return s1 = Object["setPrototypeOf"] || function (ss, sw) {
                  var h = h;
                  var h = h;
                  {
                    return ss["__proto__"] = sw, ss;
                  }
                }, s1(sh, sH);
              }
              function s2(sh) {
                var h = h;
                var h = h;
                {
                  if (void 0x0 === sh) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                  return sh;
                }
              }
              function s3(sh) {
                var h = h;
                var h = h;
                return s3 = Object["setPrototypeOf"] ? Object["getPrototypeOf"] : function (sH) {
                  var h = h;
                  var h = h;
                  {
                    return sH["__proto__"] || Object["getPrototypeOf"](sH);
                  }
                }, s3(sh);
              }
              function s4(sh, sH, ss) {
                var h = h;
                var h = h;
                {
                  return sH in sh ? Object["defineProperty"](sh, sH, {
                    'value': ss,
                    'enumerable': !0x0,
                    'configurable': !0x0,
                    'writable': !0x0
                  }) : sh[sH] = ss, sh;
                }
              }
              function s5(sh, sH) {
                var h = h;
                var h = h;
                {
                  return sH || (sH = sh["slice"](0x0)), Object["freeze"](Object["defineProperties"](sh, {
                    'raw': {
                      'value': Object["freeze"](sH)
                    }
                  }));
                }
              }
              var s6 = function (sh, sH, ss) {
                return (sH = sH || 0x0 === sH ? sH : sh) > (ss = ss || 0x0 === ss ? ss : sh) ? sh : sh < sH ? sH : sh > ss ? ss : sh;
              };
              function s7(sh, sH) {
                var h = h;
                var h = h;
                {
                  return sh["clientX"] > sH["left"] && sh["clientX"] < sH["right"] && sh["clientY"] > sH["top"] && sh["clientY"] < sH["top"] + sH["height"];
                }
              }
              var s8 = Hp()["div"](Hg || (Hg = s5(["\n  min-height: 0;\n  min-width: 0;\n\n  .cs-outer-container {\n    overflow: hidden;\n\n    .cs-positioning {\n      position: relative;\n    }\n\n    &:hover .cs-custom-scrollbar {\n      opacity: 1;\n      transition-duration: 0.2s;\n    }\n  }\n\n  .cs-inner-container {\n    overflow-x: hidden;\n    overflow-y: scroll;\n\n    -webkit-overflow-scrolling: touch;\n\n    &:after {\n      content: '';\n      position: absolute;\n      top: 0;\n      right: 0;\n      left: 0;\n      height: 0;\n      background-image: linear-gradient(\n        to bottom,\n        rgba(0, 0, 0, 0.2) 0%,\n        rgba(0, 0, 0, 0.05) 60%,\n        rgba(0, 0, 0, 0) 100%\n      );\n      pointer-events: none;\n      transition: height 0.1s ease-in;\n      will-change: height;\n    }\n    &.cs-content-scrolled:after {\n      height: 5px;\n      transition: height 0.15s ease-out;\n    }\n  }\n\n  &.cs-scroll-handle-dragged .cs-inner-container {\n    user-select: none;\n  }\n\n  .cs-custom-scrollbar {\n    position: absolute;\n    height: 100%;\n    width: 6px;\n    right: ", ";\n    opacity: 0;\n    z-index: 1;\n    transition: opacity 0.4s ease-out;\n    padding: 6px 0;\n    box-sizing: border-box;\n    will-change: opacity;\n    pointer-events: none;\n\n    &.cs-custom-scrollbar-rtl {\n      right: auto;\n      left: ", ";\n    }\n  }\n\n  &.cs-scroll-handle-dragged .cs-custom-scrollbar {\n    opacity: 1;\n  }\n\n  .cs-custom-scroll-handle {\n    position: absolute;\n    width: 100%;\n    top: 0;\n  }\n\n  .cs-inner-handle {\n    height: calc(100% - 2 * ", ");\n    margin-top: ", ";\n    background-color: rgba(78, 183, 245, 0.7);\n    border-radius: 3px;\n  }\n"])), function (sh) {
                  var h = h;
                  var h = h;
                  return sh["customScrollBarMargin"];
                }, function (sh) {
                  var h = h;
                  var h = h;
                  return sh["customScrollBarMargin"];
                }, function (sh) {
                  var h = h;
                  var h = h;
                  {
                    return sh["scrollMarginTop"];
                  }
                }, function (sh) {
                  var h = h;
                  var h = h;
                  {
                    return sh["scrollMarginTop"];
                  }
                }),
                s9 = Hp()(s8)(HP || (HP = s5(["\n  &.cs-inner-handle {\n    ", ";\n  }\n"])), function (sh) {
                  var h = h;
                  var h = h;
                  {
                    return sh["customStyle"];
                  }
                }),
                sV = function (sh) {
                  var h = h;
                  var h = h;
                  !function (sx, sC) {
                    var h = h;
                    var h = h;
                    {
                      if ("function" != typeof sC && null !== sC) throw new TypeError("Super expression must either be null or a function");
                      sx["prototype"] = Object["create"](sC && sC["prototype"], {
                        'constructor': {
                          'value': sx,
                          'writable': !0x0,
                          'configurable': !0x0
                        }
                      }), sC && s1(sx, sC);
                    }
                  }(sz, sh);
                  var sH,
                    ss,
                    sw,
                    su = (ss = sz, sw = function () {
                      var h = h;
                      var h = h;
                      if ("undefined" == typeof Reflect || !Reflect["construct"]) return !0x1;
                      if (Reflect["construct"]["sham"]) return !0x1;
                      if ("function" == typeof Proxy) return !0x0;
                      try {
                        return Date["prototype"]["toString"]["call"](Reflect["construct"](Date, [], function () {})), !0x0;
                      } catch (sx) {
                        {
                          return !0x1;
                        }
                      }
                    }(), function () {
                      var h = h;
                      var h = h;
                      {
                        var sx,
                          sC = s3(ss);
                        if (sw) {
                          var sW = s3(this)["constructor"];
                          sx = Reflect["construct"](sC, arguments, sW);
                        } else sx = sC["apply"](this, arguments);
                        return function (sv, sy) {
                          var h = h;
                          var h = h;
                          {
                            return !sy || "object" !== s0(sy) && "function" != typeof sy ? s2(sv) : sy;
                          }
                        }(this, sx);
                      }
                    });
                  function sz(sx) {
                    var h = h;
                    var h = h;
                    var sC;
                    return function (sW, sv) {
                      var h = h;
                      var h = h;
                      if (!(sW instanceof sv)) throw new TypeError("Cannot call a class as a function");
                    }(this, sz), s4(s2(sC = su["call"](this, sx)), "innerContainerRef", (0x0, HA["createRef"])()), s4(s2(sC), "customScrollbarRef", (0x0, HA["createRef"])()), s4(s2(sC), "scrollHandleRef", (0x0, HA["createRef"])()), s4(s2(sC), "contentWrapperRef", (0x0, HA["createRef"])()), s4(s2(sC), "adjustFreezePosition", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        if (sC["contentWrapperRef"]["current"]) {
                          {
                            var sv = sC["getScrolledElement"](),
                              sy = sC["contentWrapperRef"]["current"];
                            sC["props"]["freezePosition"] && (sy["scrollTop"] = sC["state"]["scrollPos"]), sW["freezePosition"] && (sv["scrollTop"] = sC["state"]["scrollPos"]);
                          }
                        }
                      }
                    }), s4(s2(sC), "toggleScrollIfNeeded", function () {
                      var h = h;
                      var h = h;
                      {
                        var sW = sC["contentHeight"] - sC["visibleHeight"] > 0x1;
                        sC["hasScroll"] !== sW && (sC["hasScroll"] = sW, sC["forceUpdate"]());
                      }
                    }), s4(s2(sC), "updateScrollPosition", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        var sv = sC["getScrolledElement"](),
                          sy = s6(sW, 0x0, sC["contentHeight"] - sC["visibleHeight"]);
                        sv["scrollTop"] = sy, sC["setState"]({
                          'scrollPos': sy
                        });
                      }
                    }), s4(s2(sC), "onClick", function (sW) {
                      var h = h;
                      var h = h;
                      if (sC["hasScroll"] && sC["isMouseEventOnCustomScrollbar"](sW) && !sC["isMouseEventOnScrollHandle"](sW)) {
                        var sv = sC["calculateNewScrollHandleTop"](sW),
                          sy = sC["getScrollValueFromHandlePosition"](sv);
                        sC["updateScrollPosition"](sy);
                      }
                    }), s4(s2(sC), "isMouseEventOnCustomScrollbar", function (sW) {
                      var h = h;
                      var h = h;
                      if (!sC["customScrollbarRef"]["current"]) return !0x1;
                      var sv = HT()["findDOMNode"](s2(sC))["getBoundingClientRect"](),
                        sy = sC["customScrollbarRef"]["current"]["getBoundingClientRect"](),
                        sE = sC["props"]["rtl"] ? {
                          'left': sv["left"],
                          'right': sy["right"]
                        } : {
                          'left': sy["left"],
                          'width': sv["right"]
                        };
                      return s7(sW, Object["assign"]({}, {
                        'left': sv["left"],
                        'right': sv["right"],
                        'top': sv["top"],
                        'height': sv["height"]
                      }, sE));
                    }), s4(s2(sC), "isMouseEventOnScrollHandle", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        return !!sC["scrollHandleRef"]["current"] && function (sv, sy) {
                          var h = h;
                          var h = h;
                          return s7(sv, sy["getBoundingClientRect"]());
                        }(sW, HT()["findDOMNode"](sC["scrollHandleRef"]["current"]));
                      }
                    }), s4(s2(sC), "calculateNewScrollHandleTop", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        var sv = HT()["findDOMNode"](s2(sC))["getBoundingClientRect"]()["top"] + o["pageYOffset"],
                          sy = sW["pageY"] - sv,
                          sE = sC["getScrollHandleStyle"]()["top"];
                        return sy > sE + sC["scrollHandleHeight"] ? sE + Math["min"](sC["scrollHandleHeight"], sC["visibleHeight"] - sC["scrollHandleHeight"]) : sE - Math["max"](sC["scrollHandleHeight"], 0x0);
                      }
                    }), s4(s2(sC), "getScrollValueFromHandlePosition", function (sW) {
                      var h = h;
                      var h = h;
                      return sW / sC["scrollRatio"];
                    }), s4(s2(sC), "getScrollHandleStyle", function () {
                      var h = h;
                      var h = h;
                      {
                        var sW = sC["state"]["scrollPos"] * sC["scrollRatio"];
                        return sC["scrollHandleHeight"] = sC["visibleHeight"] * sC["scrollRatio"], {
                          'height': sC["scrollHandleHeight"],
                          'top': sW
                        };
                      }
                    }), s4(s2(sC), "adjustCustomScrollPosToContentPos", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        sC["setState"]({
                          'scrollPos': sW
                        });
                      }
                    }), s4(s2(sC), "onScroll", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        sC["props"]["freezePosition"] || (sC["hideScrollThumb"](), sC["adjustCustomScrollPosToContentPos"](sW["currentTarget"]["scrollTop"]), sC["props"]["onScroll"] && sC["props"]["onScroll"](sW));
                      }
                    }), s4(s2(sC), "getScrolledElement", function () {
                      var h = h;
                      var h = h;
                      {
                        return sC["innerContainerRef"]["current"];
                      }
                    }), s4(s2(sC), "onMouseDown", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        sC["hasScroll"] && sC["isMouseEventOnScrollHandle"](sW) && (sC["startDragHandlePos"] = sC["getScrollHandleStyle"]()["top"], sC["startDragMousePos"] = sW["pageY"], sC["setState"]({
                          'onDrag': !0x0
                        }), document["addEventListener"]("mousemove", sC["onHandleDrag"], {
                          'passive': !0x1
                        }), document["addEventListener"]("mouseup", sC["onHandleDragEnd"], {
                          'passive': !0x1
                        }));
                      }
                    }), s4(s2(sC), "onTouchStart", function () {
                      var h = h;
                      var h = h;
                      {
                        sC["setState"]({
                          'onDrag': !0x0
                        });
                      }
                    }), s4(s2(sC), "onHandleDrag", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        sW["preventDefault"]();
                        var sv = sW["pageY"] - sC["startDragMousePos"],
                          sy = s6(sC["startDragHandlePos"] + sv, 0x0, sC["visibleHeight"] - sC["scrollHandleHeight"]),
                          sE = sC["getScrollValueFromHandlePosition"](sy);
                        sC["updateScrollPosition"](sE);
                      }
                    }), s4(s2(sC), "onHandleDragEnd", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        sC["setState"]({
                          'onDrag': !0x1
                        }), sW["preventDefault"](), document["removeEventListener"]("mousemove", sC["onHandleDrag"], {
                          'passive': !0x1
                        }), document["removeEventListener"]("mouseup", sC["onHandleDragEnd"], {
                          'passive': !0x1
                        });
                      }
                    }), s4(s2(sC), "blockOuterScroll", function (sW) {
                      var h = h;
                      var h = h;
                      if (!sC["props"]["allowOuterScroll"]) {
                        {
                          var sv = sW["currentTarget"],
                            sy = sW["currentTarget"]["scrollHeight"] - sW["currentTarget"]["offsetHeight"],
                            sE = sW["deltaY"] % 0x3 ? sW["deltaY"] : 0xa * sW["deltaY"];
                          sv["scrollTop"] + sE <= 0x0 ? (sv["scrollTop"] = 0x0, sW["preventDefault"]()) : sv["scrollTop"] + sE >= sy && (sv["scrollTop"] = sy, sW["preventDefault"]()), sW["stopPropagation"]();
                        }
                      }
                    }), s4(s2(sC), "getInnerContainerClasses", function () {
                      var h = h;
                      var h = h;
                      {
                        return sC["state"]["scrollPos"] && sC["props"]["addScrolledClass"] ? "cs-inner-container cs-content-scrolled" : "cs-inner-container";
                      }
                    }), s4(s2(sC), "getScrollStyles", function () {
                      var h = h;
                      var h = h;
                      {
                        var sW = sC["scrollbarYWidth"] || 0x14,
                          sv = sC["props"]["rtl"] ? "marginLeft" : "marginRight",
                          sy = {
                            'height': sC["props"]["heightRelativeToParent"] || sC["props"]["flex"] ? "100%" : ''
                          };
                        sy[sv] = -0x1 * sW;
                        var sE = {
                          'height': sC["props"]["heightRelativeToParent"] || sC["props"]["flex"] ? "100%" : '',
                          'overflowY': sC["props"]["freezePosition"] ? "hidden" : "visible"
                        };
                        return sE[sv] = sC["scrollbarYWidth"] ? 0x0 : sW, {
                          'innerContainer': sy,
                          'contentWrapper': sE
                        };
                      }
                    }), s4(s2(sC), "getOuterContainerStyle", function () {
                      var h = h;
                      var h = h;
                      {
                        return {
                          'height': sC["props"]["heightRelativeToParent"] || sC["props"]["flex"] ? "100%" : ''
                        };
                      }
                    }), s4(s2(sC), "getRootStyles", function () {
                      var h = h;
                      var h = h;
                      {
                        var sW = {};
                        return sC["props"]["heightRelativeToParent"] ? sW["height"] = sC["props"]["heightRelativeToParent"] : sC["props"]["flex"] && (sW["flex"] = sC["props"]["flex"]), sW;
                      }
                    }), s4(s2(sC), "enforceMinHandleHeight", function (sW) {
                      var h = h;
                      var h = h;
                      {
                        var sv = sC["props"]["minScrollHandleHeight"];
                        if (sW["height"] >= sv) return sW;
                        var sy = (sv - sW["height"]) * (sC["state"]["scrollPos"] / (sC["contentHeight"] - sC["visibleHeight"]));
                        return {
                          'height': sv,
                          'top': sW["top"] - sy
                        };
                      }
                    }), sC["scrollbarYWidth"] = 0x0, sC["state"] = {
                      'scrollPos': 0x0,
                      'onDrag': !0x1
                    }, sC["hideScrollThumb"] = function () {
                      var h = h;
                      var h = h;
                      var sW;
                      function sv() {
                        var h = h;
                        var h = h;
                        {
                          clearTimeout(sW);
                        }
                      }
                      function sy() {
                        var h = h;
                        var h = h;
                        {
                          sv(), sW = setTimeout(function () {
                            var h = h;
                            var h = h;
                            {
                              sC["setState"]({
                                'onDrag': !0x1
                              });
                            }
                          }, 0x1f4);
                        }
                      }
                      return sy["cancel"] = sv, sy;
                    }(), sC;
                  }
                  return (sH = [{
                    'key': "componentDidMount",
                    'value': function () {
                      var h = h;
                      var h = h;
                      {
                        void 0x0 !== this["props"]["scrollTo"] ? this["updateScrollPosition"](this["props"]["scrollTo"]) : this["forceUpdate"](), this["innerContainerRef"]["current"] && this["innerContainerRef"]["current"]["addEventListener"]("wheel", this["blockOuterScroll"], {
                          'passive': !0x1
                        });
                      }
                    }
                  }, {
                    'key': "componentDidUpdate",
                    'value': function (sx, sC) {
                      var h = h;
                      var h = h;
                      var sW = this["contentHeight"],
                        sv = this["visibleHeight"],
                        sy = this["getScrolledElement"](),
                        sE = sC["scrollPos"] >= sW - sv;
                      this["contentHeight"] = sy["scrollHeight"], this["scrollbarYWidth"] = sy["offsetWidth"] - sy["clientWidth"], this["visibleHeight"] = sy["clientHeight"], this["scrollRatio"] = this["contentHeight"] ? this["visibleHeight"] / this["contentHeight"] : 0x1, this["toggleScrollIfNeeded"]();
                      var sM = this["state"] === sC;
                      (this["props"]["freezePosition"] || sx["freezePosition"]) && this["adjustFreezePosition"](sx), void 0x0 !== this["props"]["scrollTo"] && this["props"]["scrollTo"] !== sx["scrollTo"] ? this["updateScrollPosition"](this["props"]["scrollTo"]) : this["props"]["keepAtBottom"] && sM && sE && this["updateScrollPosition"](this["contentHeight"] - this["visibleHeight"]);
                    }
                  }, {
                    'key': "componentWillUnmount",
                    'value': function () {
                      var h = h;
                      var h = h;
                      {
                        this["hideScrollThumb"]["cancel"](), document["removeEventListener"]("mousemove", this["onHandleDrag"], {
                          'passive': !0x1
                        }), document["removeEventListener"]("mouseup", this["onHandleDragEnd"], {
                          'passive': !0x1
                        }), this["innerContainerRef"]["current"] && this["innerContainerRef"]["current"]["removeEventListener"]("wheel", this["blockOuterScroll"]);
                      }
                    }
                  }, {
                    'key': "render",
                    'value': function () {
                      var h = h;
                      var h = h;
                      {
                        var sx = this["getScrollStyles"](),
                          sC = this["getRootStyles"](),
                          sW = this["enforceMinHandleHeight"](this["getScrollHandleStyle"]());
                        return HX()["createElement"](s8, {
                          'customScrollBarMargin': "3px",
                          'scrollMarginTop': "6px",
                          'className': ''["concat"](this["state"]["onDrag"] ? "cs-scroll-handle-dragged" : ''),
                          'style': sC
                        }, HX()["createElement"]("div", {
                          'className': "cs-outer-container",
                          'style': this["getOuterContainerStyle"](),
                          'onMouseDown': this["onMouseDown"],
                          'onTouchStart': this["onTouchStart"],
                          'onClick': this["onClick"]
                        }, this["hasScroll"] ? HX()["createElement"]("div", {
                          'className': "cs-positioning"
                        }, HX()["createElement"]("div", {
                          'ref': this["customScrollbarRef"],
                          'className': "cs-custom-scrollbar "["concat"](this["props"]["rtl"] ? "cs-custom-scrollbar-rtl" : ''),
                          'key': "scrollbar"
                        }, HX()["createElement"]("div", {
                          'ref': this["scrollHandleRef"],
                          'className': "cs-custom-scroll-handle",
                          'style': sW
                        }, HX()["createElement"](s9, {
                          'customStyle': this["props"]["handleClass"],
                          'className': "cs-inner-handle"
                        })))) : null, HX()["createElement"]("div", {
                          'ref': this["innerContainerRef"],
                          'className': this["getInnerContainerClasses"](),
                          'style': sx["innerContainer"],
                          'onScroll': this["onScroll"]
                        }, HX()["createElement"]("div", {
                          'className': Hl["contentWrapper"],
                          'ref': this["contentWrapperRef"],
                          'style': sx["contentWrapper"]
                        }, this["props"]["children"]))));
                      }
                    }
                  }]) && function (sx, sC) {
                    var h = h;
                    var h = h;
                    {
                      for (var sW = 0x0; sW < sC["length"]; sW++) {
                        {
                          var sv = sC[sW];
                          sv["enumerable"] = sv["enumerable"] || !0x1, sv["configurable"] = !0x0, "value" in sv && (sv["writable"] = !0x0), Object["defineProperty"](sx, sv["key"], sv);
                        }
                      }
                    }
                  }(sz["prototype"], sH), sz;
                }(HA["Component"]);
              try {
                {
                  var sa = Hj(0x63);
                  sV["propTypes"] = {
                    'children': sa["any"],
                    'allowOuterScroll': sa["bool"],
                    'heightRelativeToParent': sa["string"],
                    'onScroll': sa["func"],
                    'addScrolledClass': sa["bool"],
                    'freezePosition': sa["bool"],
                    'handleClass': sa["string"],
                    'minScrollHandleHeight': sa["number"],
                    'flex': sa["string"],
                    'rtl': sa["bool"],
                    'scrollTo': sa["number"],
                    'keepAtBottom': sa["bool"]
                  };
                }
              } catch (sh) {}
              sV["defaultProps"] = {
                'handleClass': '',
                'minScrollHandleHeight': 0x26
              };
              const sV = sV;
            })(), Hc;
          })());
          var tQ = tQ;
          function tI(Hf) {
            var h = h;
            var h = h;
            {
              return "land" === shell["environment"]["getOrientationMode"]() ? 0.75 * Hf : Hf;
            }
          }
          function tB(Hf) {
            var h = h;
            var h = h;
            {
              return shell["environment"]["hasNotch"]() ? Hf + 0x1e : shell["environment"]["isIOSStandalone"]() ? Hf + 0xf : Hf;
            }
          }
          function tN(Hf) {
            var h = h;
            var h = h;
            return "land" === shell["environment"]["getOrientationMode"]() ? Hf / 0.75 : Hf;
          }
          function tb(Hf) {
            var h = h;
            var h = h;
            {
              return "land" === Hf["orientation"];
            }
          }
          var tK,
            tf,
            td,
            tj,
            tL,
            tm,
            tS,
            tZ,
            tc,
            tA,
            tX,
            tk,
            tT,
            tO,
            tp,
            tl,
            tg,
            tP,
            a0,
            a1,
            a2,
            a3,
            a4,
            a5,
            a6,
            a7,
            a8,
            a9,
            aV,
            aa,
            aU,
            ah,
            aH,
            as,
            aw,
            au,
            az,
            ax,
            aC,
            aW,
            av,
            ay,
            aE,
            aM,
            aq,
            aG,
            aF = y["div"](tK || (tK = V5(["\n    width: 100%;\n    height: 100%;\n"], ["\n    width: 100%;\n    height: 100%;\n"]))),
            aY = y["div"](tf || (tf = V5(["\n    position: relative;\n    z-index: 1;\n"], ["\n    position: relative;\n    z-index: 1;\n"]))),
            aQ = y['h2'](td || (td = V5(["\n    text-align: center;\n    background-color: rgba(40,40,52,1);\n    margin: auto;\n    padding: ", ";\n    color: ", ";\n    font-weight: normal;\n    box-shadow: 0 0 3px 0 rgba(0, 0, 0, 0.8);\n    font-size: ", "px;\n"], ["\n    text-align: center;\n    background-color: rgba(40,40,52,1);\n    margin: auto;\n    padding: ", ";\n    color: ", ";\n    font-weight: normal;\n    box-shadow: 0 0 3px 0 rgba(0, 0, 0, 0.8);\n    font-size: ", "px;\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? "26px 0px "["concat"](tI(0x18), "px 0px") : ''["concat"](tB(0x18), "px 0px 24px 0px");
              }
            }, function (Hf) {
              var h = h;
              var h = h;
              return Hf["themeColor"] || "rgb(255,255,255,1)";
            }, tI(0x12)),
            aR = y["div"](tj || (tj = V5(["\n    display: flex;\n    flex-direction: column;\n    height: 87%;\n"], ["\n    display: flex;\n    flex-direction: column;\n    height: 87%;\n"]))),
            aD = y["div"](tL || (tL = V5(["\n    margin: auto;\n"], ["\n    margin: auto;\n"]))),
            aJ = y["div"](tm || (tm = V5(["\n    font-size: 14px;\n    opacity: 0.2;\n    padding: 0px ", "px;\n    line-height: ", "px;\n"], ["\n    font-size: 14px;\n    opacity: 0.2;\n    padding: 0px ", "px;\n    line-height: ", "px;\n"])), tI(0x18), tI(0x14)),
            aI = y["button"](tS || (tS = V5(["\n    color: ", ";\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n    width: 30%;\n    margin-top: 14px;\n    background-color: rgba(49, 49, 58, 1);\n    border: 1px solid rgba(0, 0, 0, 0.3);\n"], ["\n    color: ", ";\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n    width: 30%;\n    margin-top: 14px;\n    background-color: rgba(49, 49, 58, 1);\n    border: 1px solid rgba(0, 0, 0, 0.3);\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return Hf["themeColor"] || "rgb(255,255,255,1)";
              }
            }, tI(0x8)),
            aB = y["div"](tZ || (tZ = V5(["\n    width: 95%;\n    padding: ", "px;\n    font-size: 14px;\n"], ["\n    width: 95%;\n    padding: ", "px;\n    font-size: 14px;\n"])), tI(0x9)),
            aN = y["div"](tc || (tc = V5(["\n    box-shadow:\n        0 3px 5px 0 rgba(0,0,0,0.3), 0 5px 5px 0 rgba(0,0,0,0.15), inset 0 1px 0 0 rgba(255,255,255,0.10);\n    border-radius: 4px;\n    background-color: rgba(48,48,60,0.96);\n    padding: ", "px ", "px;\n"], ["\n    box-shadow:\n        0 3px 5px 0 rgba(0,0,0,0.3), 0 5px 5px 0 rgba(0,0,0,0.15), inset 0 1px 0 0 rgba(255,255,255,0.10);\n    border-radius: 4px;\n    background-color: rgba(48,48,60,0.96);\n    padding: ", "px ", "px;\n"])), tI(0xf), tI(0x14)),
            ab = y["section"](tA || (tA = V5(["\n    width: 100%;\n    display: inline-block;\n    padding-bottom: ", "px;\n"], ["\n    width: 100%;\n    display: inline-block;\n    padding-bottom: ", "px;\n"])), tI(0xf)),
            aK = y["section"](tX || (tX = V5(["\n    width: 100%;\n    display: inline-block;\n    padding-bottom: ", "px;\n    font-size: 12px;\n"], ["\n    width: 100%;\n    display: inline-block;\n    padding-bottom: ", "px;\n    font-size: 12px;\n"])), tI(0xf)),
            af = y["div"](tk || (tk = V5(["\n    float: ", ";\n    text-align: ", ";\n    width: 50%;\n    position: relative;\n"], ["\n    float: ", ";\n    text-align: ", ";\n    width: 50%;\n    position: relative;\n"])), Vq["isRTL"] ? "right" : "left", Vq["isRTL"] ? "right" : "left"),
            ad = y["div"](tT || (tT = V5(["\n    float: ", ";\n    text-align: ", ";\n    width: 50%;\n"], ["\n    float: ", ";\n    text-align: ", ";\n    width: 50%;\n"])), Vq["isRTL"] ? "left" : "right", Vq["isRTL"] ? "left" : "right"),
            aj = y["div"](tO || (tO = V5(["\n    float: left;\n    text-align: center;\n    width: 50%;\n"], ["\n    float: left;\n    text-align: center;\n    width: 50%;\n"]))),
            aL = y["div"](tp || (tp = V5(["\n    float: right;\n    text-align: center;\n    width: 50%;\n"], ["\n    float: right;\n    text-align: center;\n    width: 50%;\n"]))),
            am = y["div"](tl || (tl = V5(["\n    padding-top: ", "px;\n    font-size: 11px;\n    opacity: 0.5;\n"], ["\n    padding-top: ", "px;\n    font-size: 11px;\n    opacity: 0.5;\n"])), tI(0x6)),
            aS = y["div"](tg || (tg = V5(["\n    padding-bottom: ", "px;\n    color: ", ';\x0a'], ["\n    padding-bottom: ", "px;\n    color: ", ';\x0a'])), tI(0x6), function (Hf) {
              var h = h;
              var h = h;
              return Hf["themeColor"] || "rgb(255,255,255,1)";
            }),
            aZ = y["div"](tP || (tP = V5(["\n    padding-top: ", "px;\n"], ["\n    padding-top: ", "px;\n"])), tI(0x4)),
            ac = y["button"](a0 || (a0 = V5(["\n    width: 45%;\n    margin: auto 2.5%;\n    font-size: 12px;\n    padding: ", "px 0px;\n    opacity: 0.5;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n\n    &:enabled {\n        border: 1px solid rgba(0, 0, 0, 0.3);\n        background-color: rgba(48, 48, 60, 1);\n        color: white;\n    }\n\n    &:disabled {\n        border: 1px solid rgba(0, 0, 0, 0.3);\n        background-color: rgba(48, 48, 60, 1);\n        pointer-events: none;\n    }\n"], ["\n    width: 45%;\n    margin: auto 2.5%;\n    font-size: 12px;\n    padding: ", "px 0px;\n    opacity: 0.5;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n\n    &:enabled {\n        border: 1px solid rgba(0, 0, 0, 0.3);\n        background-color: rgba(48, 48, 60, 1);\n        color: white;\n    }\n\n    &:disabled {\n        border: 1px solid rgba(0, 0, 0, 0.3);\n        background-color: rgba(48, 48, 60, 1);\n        pointer-events: none;\n    }\n"])), tI(0x8)),
            aA = y["button"](a1 || (a1 = V5(["\n    width: 45%;\n    margin: auto 2.5%;\n    background-color: ", ";\n    font-size: 12px;\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n\n    &:enabled {\n        border: none;\n        color: white;\n    }\n\n    &:disabled {\n        border: none;\n        pointer-events: none;\n    }\n"], ["\n    width: 45%;\n    margin: auto 2.5%;\n    background-color: ", ";\n    font-size: 12px;\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n\n    &:enabled {\n        border: none;\n        color: white;\n    }\n\n    &:disabled {\n        border: none;\n        pointer-events: none;\n    }\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return Hf["themeColor"] || "rgb(255,255,255,1)";
              }
            }, tI(0x8)),
            aX = y["button"](a2 || (a2 = V5(["\n    width: 45%;\n    margin: auto 2.5%;\n    background-color: ", ";\n    font-size: 12px;\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n\n    &:enabled {\n        border: none;\n        color: white;\n    }\n\n    &:disabled {\n        border: none;\n        pointer-events: none;\n    }\n"], ["\n    width: 45%;\n    margin: auto 2.5%;\n    background-color: ", ";\n    font-size: 12px;\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n\n    &:enabled {\n        border: none;\n        color: white;\n    }\n\n    &:disabled {\n        border: none;\n        pointer-events: none;\n    }\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return Hf["themeColor"] || "rgb(255,255,255,1)";
              }
            }, tI(0x8)),
            ak = y["div"](a3 || (a3 = V5(["\n    position: absolute;\n    ", ": -16px;\n    transform: scale(", ')\x20', ";\n    top: ", '\x0a'], ["\n    position: absolute;\n    ", ": -16px;\n    transform: scale(", ')\x20', ";\n    top: ", '\x0a'])), Vq["isRTL"] ? "right" : "left", tI(0.6), Vq["isRTL"] ? "scaleX(-1)" : '', function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? "-9px" : "-11px";
              }
            }),
            aT = y["div"](a4 || (a4 = V5(["\n    float: ", ";\n    border-radius: ", ";\n    border-width: 0px 0px 0px 4px;\n    border-style: solid;\n    color: ", ';\x0a'], ["\n    float: ", ";\n    border-radius: ", ";\n    border-width: 0px 0px 0px 4px;\n    border-style: solid;\n    color: ", ';\x0a'])), Vq["isRTL"] ? "right" : "left", Vq["isRTL"] ? "0px 4px 4px 0px" : "4px 0px 0px 4px", function (Hf) {
              var h = h;
              var h = h;
              return Hf["themeColor"] || "rgb(255,255,255,1)";
            }),
            aO = y["div"](a5 || (a5 = V5(["\n    padding-top: ", "px;\n    padding-bottom: ", "px;\n    font-size: 14px;\n"], ["\n    padding-top: ", "px;\n    padding-bottom: ", "px;\n    font-size: 14px;\n"])), tI(0x9), tI(0x12)),
            ap = y["div"](a6 || (a6 = V5(["\n    position: relative;\n    width: 45%;\n    display: inline-block;\n    margin: auto 2.5%;\n"], ["\n    position: relative;\n    width: 45%;\n    display: inline-block;\n    margin: auto 2.5%;\n"]))),
            al = y["button"](a7 || (a7 = V5(["\n    width: 100%;\n    font-size: 12px;\n    padding: ", "px 0px;\n    opacity: 0.5;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n\n    &:enabled {\n        border: none;\n        color: white;\n    }\n\n    &:disabled {\n        border: none;\n        pointer-events: none;\n    }\n"], ["\n    width: 100%;\n    font-size: 12px;\n    padding: ", "px 0px;\n    opacity: 0.5;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n\n    &:enabled {\n        border: none;\n        color: white;\n    }\n\n    &:disabled {\n        border: none;\n        pointer-events: none;\n    }\n"])), tI(0x8)),
            ag = y["div"](a8 || (a8 = V5(["\n    width: 20px;\n    height: 20px;\n    border-radius: 50%;\n    position: absolute;\n    bottom: ", ";\n    right: -9px;\n    background: ", ";\n    transform: scale(", ");\n"], ["\n    width: 20px;\n    height: 20px;\n    border-radius: 50%;\n    position: absolute;\n    bottom: ", ";\n    right: -9px;\n    background: ", ";\n    transform: scale(", ");\n"])), function (Hf) {
              var h = h;
              var h = h;
              return tb(Hf) ? "14px" : "22px";
            }, function (Hf) {
              var h = h;
              var h = h;
              return Hf["themeColor"] || "rgb(255,255,255,1)";
            }, tI(0x1)),
            aP = y["div"](a9 || (a9 = V5(["\n    position: absolute;\n    bottom: ", ";\n    right: -14px;\n    cursor: pointer;\n    transform: scale(", ");\n"], ["\n    position: absolute;\n    bottom: ", ";\n    right: -14px;\n    cursor: pointer;\n    transform: scale(", ");\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? "9px" : "17px";
              }
            }, tI(0.75)),
            U0 = y["section"](aV || (aV = V5(["\n    padding-", ": 10px;\n    padding-bottom: ", "px;\n    text-align: ", ";\n    font-size: 14px;\n"], ["\n    padding-", ": 10px;\n    padding-bottom: ", "px;\n    text-align: ", ";\n    font-size: 14px;\n"])), Vq["isRTL"] ? "right" : "left", tI(0xf), Vq["isRTL"] ? "right" : "left"),
            U1 = y["div"](aa || (aa = V5(["\n    padding-top: ", "px;\n    display: flex;\n    font-size: 12px;\n"], ["\n    padding-top: ", "px;\n    display: flex;\n    font-size: 12px;\n"])), tI(0x1e)),
            U2 = y["section"](aU || (aU = V5(["\n    direction: ltr;\n"], ["\n    direction: ltr;\n"]))),
            U3 = y["div"](ah || (ah = V5(["\n    word-wrap: break-word;\n    transform: scale(", ");\n    transform-origin: left;\n    width: ", "%;\n    height: ", "%;\n"], ["\n    word-wrap: break-word;\n    transform: scale(", ");\n    transform-origin: left;\n    width: ", "%;\n    height: ", "%;\n"])), tI(0x1), tN(0x64), tN(0x64)),
            U4 = y(U3)(aH || (aH = V5(["\n    font-size: 11px;\n    line-height: 14px;   \n    opacity: 0.5;\n"], ["\n    font-size: 11px;\n    line-height: 14px;   \n    opacity: 0.5;\n"]))),
            U5 = y["div"](as || (as = V5(["\n    width: ", "px;\n    height: ", "px;\n    border-radius: 50%;\n    background-color: rgba(33,33,41,1);\n    display: inline-block;\n    position: relative;\n"], ["\n    width: ", "px;\n    height: ", "px;\n    border-radius: 50%;\n    background-color: rgba(33,33,41,1);\n    display: inline-block;\n    position: relative;\n"])), tI(0xd), tI(0xd)),
            U6 = y["div"](aw || (aw = V5(["\n    top: ", ";\n    ", ':\x20', ";\n    position: absolute;\n    transform: scale(", ");\n"], ["\n    top: ", ";\n    ", ':\x20', ";\n    position: absolute;\n    transform: scale(", ");\n"])), function (Hf) {
              var h = h;
              var h = h;
              return tb(Hf) ? "-15px" : "-13px";
            }, Vq["isRTL"] ? "right" : "left", function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? "2px" : "10px";
              }
            }, tI(0.5)),
            U7 = y(U6)(au || (au = V5(["\n    opacity: 0.5;\n"], ["\n    opacity: 0.5;\n"]))),
            U8 = y["label"](az || (az = V5(["\n    position: absolute;\n    ", ':\x20', ";\n    top:  ", ";\n    transform: scale(", ");\n    transform-origin: ", ";\n    width: ", "%;\n    height: 140%;\n"], ["\n    position: absolute;\n    ", ':\x20', ";\n    top:  ", ";\n    transform: scale(", ");\n    transform-origin: ", ";\n    width: ", "%;\n    height: 140%;\n"])), Vq["isRTL"] ? "right" : "left", function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? "35px" : "47px";
              }
            }, function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? "-2px" : "0px";
              }
            }, tI(0x1), Vq["isRTL"] ? "right" : "left", tN(0x40)),
            U9 = y(U8)(ax || (ax = V5(["\n    opacity: 0.5;\n"], ["\n    opacity: 0.5;\n"]))),
            UV = y["span"](aC || (aC = V5(["\n    width: ", ";\n    height: ", ";\n    border-radius: 50%;\n    position: absolute;\n    ", ':\x20', ";\n    top: ", ";\n    display: none;\n"], ["\n    width: ", ";\n    height: ", ";\n    border-radius: 50%;\n    position: absolute;\n    ", ':\x20', ";\n    top: ", ";\n    display: none;\n"])), function (Hf) {
              var h = h;
              var h = h;
              return tb(Hf) ? "4px" : "5px";
            }, function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? "4px" : "5px";
              }
            }, Vq["isRTL"] ? "right" : "left", function (Hf) {
              var h = h;
              var h = h;
              return tb(Hf) ? "3px" : "4px";
            }, function (Hf) {
              var h = h;
              var h = h;
              return tb(Hf) ? "3px" : "4px";
            }),
            Ua = y["div"](aW || (aW = V5(["\n    cursor: pointer;\n    position: absolute;\n    right: 10px;\n    top: ", ";\n    transform: scale(", ");\n    opacity: 0.4;\n"], ["\n    cursor: pointer;\n    position: absolute;\n    right: 10px;\n    top: ", ";\n    transform: scale(", ");\n    opacity: 0.4;\n"])), function (Hf) {
              var h = h;
              var h = h;
              return tb(Hf) ? "13px" : ''["concat"](tB(0xd), 'px');
            }, tI(0.75)),
            UU = y["div"](av || (av = V5(["\n    height: 100%;\n    width: ", ";\n    position: relative;\n"], ["\n    height: 100%;\n    width: ", ";\n    position: relative;\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? "269px" : "360px";
              }
            }),
            Uh = y["div"](ay || (ay = V5(["\n    max-height: ", "px;\n"], ["\n    max-height: ", "px;\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return tb(Hf) ? Hf["currHeight"] - 0x3b : Hf["currHeight"] - tB(0x44);
              }
            }),
            UH = y(U3)(aE || (aE = V5(["\n    opacity: 0.5;\n"], ["\n    opacity: 0.5;\n"]))),
            Us = V7["formatCurrency"],
            Uo = y['hr'](aM || (aM = V5(["\n    border-style: solid;\n    border-width: 0.5px;\n    color: black;\n    opacity: 0.5;\n"], ["\n    border-style: solid;\n    border-width: 0.5px;\n    color: black;\n    opacity: 0.5;\n"]))),
            Uw = y["div"](aq || (aq = V5(["\n    flex: 1 1 30px;\n    position: relative;\n    height: 10px;\n"], ["\n    flex: 1 1 30px;\n    position: relative;\n    height: 10px;\n"]))),
            Uu = y["input"](aG || (aG = V5(["\n    opacity: 0;\n    margin: 0px;\n"], ["\n    opacity: 0;\n    margin: 0px;\n"]))),
            Uz = shell["I18n"],
            Ux = function (Hf) {
              var h = h;
              var h = h;
              function V8(Hj) {
                var h = h;
                var h = h;
                {
                  var HL = Hf["call"](this, Hj) || this;
                  return HL['mn'] = [], HL['gn'] = !0x1, HL['bn'] = 0x1, HL['vn'] = [], HL['xn'] = !0x1, HL['wn'] = !0x1, HL['Cn'] = function (Va, HS) {
                    var h = h;
                    var h = h;
                    document["getElementById"]("selectWalletBtn "["concat"](HS["toString"]()))["blur"](), Hj["onSelectWalletClick"](Va, HS);
                  }, HL['yn'] = function (Va, HS) {
                    var h = h;
                    var h = h;
                    for (var Hj = document["getElementsByClassName"]("btnStyle"), Hc = 0x0, HA = Hj["length"]; Hc < HA; Hc++) Hj[Hc]["blur"]();
                    Hj["onDiscardOfferClick"](Va, HS);
                  }, HL["state"] = {
                    'scrollFreeze': !0x1
                  }, HL;
                }
              }
              return V0(V8, Hf), V8["prototype"]["componentDidMount"] = function () {
                var h = h;
                var h = h;
                var Hj = Vq["context"]["event"];
                Hj['on']("Shell.Scaled", this['kn'], this), Hj["emit"]("Game.BonusWalletListOpened"), this['Bn'](), this['Wn'](), this['Sn'](), document["addEventListener"]("keydown", this['Gn']);
              }, V8["prototype"]["componentDidUpdate"] = function () {
                var h = h;
                var h = h;
                {
                  this['Bn'](), this['Wn'](), this['Sn']();
                }
              }, V8["prototype"]["componentWillUnmount"] = function () {
                var h = h;
                var h = h;
                {
                  Vq["context"]["event"]["off"]("Shell.Scaled", this['kn'], this), document["removeEventListener"]("keydown", this['Gn']);
                }
              }, V8["prototype"]["shouldComponentUpdate"] = function (Hj) {
                var h = h;
                var h = h;
                return this["props"]["show"] === Hj["show"] && (this['xn'] = this["props"]["data"] === Hj["data"], !0x0);
              }, V8["prototype"]["render"] = function () {
                var h = h;
                var h = h;
                return z["createElement"](aF, {
                  'id': "bwfgContainer",
                  'className': "wallet"
                }, this['V'](), this['H']());
              }, V8["prototype"]['Gn'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  '\x20' !== Hj["key"] && "Spacebar" !== Hj["key"] || Hj["preventDefault"]();
                }
              }, V8["prototype"]['kn'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = Hj["payload"],
                    Va = document["getElementById"]("scrollView"),
                    HS = parseFloat(o["getComputedStyle"](document["getElementById"]("headerWrapper"))["height"]);
                  Va && (Va["style"]["maxHeight"] = ''["concat"](HL["height"] - HS, 'px'));
                }
              }, V8["prototype"]['Bn'] = function () {
                var h = h;
                var h = h;
                for (var Hj = this['mn'], HL = 0x0, Va = Hj["length"]; HL < Va; HL++) {
                  {
                    var HS = Hj[HL]["key"];
                    if (HS && VR["transactionInfo"]['wk'] === HS) {
                      {
                        var Hj = document["getElementById"]("currWalletSideBar "["concat"](HL["toString"]())),
                          Hc = document["getElementById"]("bwfgView "["concat"](HL["toString"]()));
                        Hj["style"]["height"] = ''["concat"](Hc["clientHeight"]["toString"](), 'px');
                      }
                    }
                  }
                }
              }, V8["prototype"]['Wn'] = function () {
                var h = h;
                var h = h;
                var Hj = VR["gameThemeColor"];
                this['vn']["forEach"](function (HL) {
                  var h = h;
                  var h = h;
                  {
                    document["getElementById"]("selectWalletBtn "["concat"](HL["toString"]()))["style"]["backgroundColor"] = Hj;
                  }
                });
              }, V8["prototype"]['Sn'] = function () {
                var h = h;
                var h = h;
                for (var Hj = VR["gameThemeColor"], HL = 0x0, Va = this['mn']["length"]; HL < Va; HL++) {
                  {
                    var HS = document["getElementById"]("custom cash radio button "["concat"](HL["toString"]())),
                      Hj = document["getElementById"]("custom bonus radio button "["concat"](HL["toString"]())),
                      Hc = document["getElementById"]("cash "["concat"](HL["toString"]())),
                      HA = document["getElementById"]("bonus "["concat"](HL["toString"]())),
                      HX = document["getElementById"]("cash check mark "["concat"](HL["toString"]())),
                      Hj = document["getElementById"]("bonus check mark "["concat"](HL["toString"]()));
                    HX["style"]["backgroundColor"] = Hj, HX["style"]["display"] = Hc["defaultChecked"] ? "block" : "none", Hc["disabled"] && (HS["style"]["opacity"] = "0.5", HX["style"]["opacity"] = "0.5"), Hj["style"]["backgroundColor"] = Hj, Hj["style"]["display"] = HA["defaultChecked"] ? "block" : "none", HA["disabled"] && (Hj["style"]["opacity"] = "0.5", Hj["style"]["opacity"] = "0.5");
                  }
                }
              }, V8["prototype"]['V'] = function () {
                var h = h;
                var h = h;
                var Hj = VR["status"];
                if (!this["props"]["error"] && this["props"]["data"] && this["props"]["data"]['dt']['r']) for (var HL = 0x0, Va = this["props"]["data"]['dt']['r']["length"]; HL < Va; HL++) if (0x6 === this["props"]["data"]['dt']['r'][HL]['s'] && VR["transactionInfo"]['wk'] === this["props"]["data"]['dt']['r'][HL]['k']) {
                  {
                    this['gn'] = !0x0;
                    break;
                  }
                }
                return z["createElement"](aY, {
                  'id': "headerWrapper"
                }, z["createElement"](aQ, {
                  'id': "bwfgHeader",
                  'orientation': shell["environment"]["getOrientationMode"](),
                  'themeColor': VR["gameThemeColor"]
                }, Uz['t']("BonusWallet.BonusWallet")), z["createElement"](Ua, {
                  'className': "wallet-plugin-sprite wallet-plugin-ic_close",
                  'onClick': 0x4 === Hj || 0x3 === Hj || 0x2 === Hj || this['gn'] ? this["props"]["onBackCashWalletClick"] : this["props"]["onCloseButtonClick"],
                  'orientation': shell["environment"]["getOrientationMode"]()
                }));
              }, V8["prototype"]['H'] = function () {
                var h = h;
                var h = h;
                {
                  var Hj = this;
                  if (this["props"]["error"]) return this['bn'] = 0x1, this['mn'] = [], z["createElement"](aR, null, z["createElement"](aD, null, z["createElement"](aJ, null, z["createElement"](U3, null, this["props"]["error"]["message"])), this["props"]["error"]["shouldRetry"] && z["createElement"](aI, {
                    'onClick': this["props"]["onRetryClick"],
                    'themeColor': VR["gameThemeColor"]
                  }, Uz['t']("General.DialogRetry"))));
                  if (this["props"]["data"]) {
                    {
                      this['gn'] = !0x1, this['vn'] = [];
                      var HL = parseFloat(document["getElementById"]("wallet-container")["style"]["height"]),
                        Va = this["props"]["data"]['dt'],
                        HS = JSON["parse"](JSON["stringify"](Va['r'])),
                        Hj = Va['tp'];
                      if (this['On'] = this['bn'] > 0x1 ? this['On'] : Hj, this['mn'] = this['bn'] > 0x1 ? this['mn'] : [], HS && HS["length"] > 0x0) {
                        {
                          if (!this['xn']) {
                            {
                              for (var Hc = 0x0, HA = HS["length"]; Hc < HA; Hc++) {
                                {
                                  var HX = HS[Hc];
                                  if (HX['k'] === VR["transactionInfo"]['wk']) {
                                    this['mn']["push"](new tv(HX)), HS["splice"](Hc, 0x1);
                                    break;
                                  }
                                }
                              }
                              HS["length"] > 0x0 && HS["forEach"](function (HT) {
                                var h = h;
                                var h = h;
                                {
                                  Hj['mn']["push"](new tv(HT));
                                }
                              });
                            }
                          }
                          var Hj = this['mn']["map"](function (HT, H1) {
                            var h = h;
                            var h = h;
                            var Hp = HT["bonusWalletName"],
                              Hl = HT["bonusID"],
                              Hg = HT["expiredDate"],
                              HP = HT["expiredTime"],
                              s0 = HT["initialBonusRatioAmount"],
                              s1 = HT["key"],
                              s2 = HT["status"],
                              s3 = Us(s0),
                              s4 = Hj['Z'](HT, H1);
                            return z["createElement"](aB, {
                              'key': H1
                            }, s1 && VR["transactionInfo"]['wk'] === s1 && z["createElement"](aT, {
                              'id': "currWalletSideBar "["concat"](H1["toString"]()),
                              'themeColor': VR["gameThemeColor"]
                            }), z["createElement"](aN, {
                              'id': "bwfgView "["concat"](H1["toString"]()),
                              'key': H1
                            }, z["createElement"](ab, null, z["createElement"](af, null, z["createElement"]("div", {
                              'className': "resizableTxtContainer"
                            }, 0x5 === s2 && z["createElement"](ak, {
                              'className': "wallet-plugin-sprite wallet-plugin-ic_wallet_new",
                              'orientation': shell["environment"]["getOrientationMode"]()
                            }), z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, Hp)), z["createElement"](am, {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, Uz['t']("BonusWallet.Offer", {
                              'id': Hl["toString"]()
                            })))), z["createElement"](ad, null, z["createElement"](aS, {
                              'className': "resizableTxtContainer",
                              'themeColor': VR["gameThemeColor"]
                            }, z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, s4["remainingInfo"])), s4["rollOverBalContent"], s4["withdrawLimitContent"])), z["createElement"](aK, null, z["createElement"](aj, null, z["createElement"]("div", {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, Hg, '\x20', HP)), z["createElement"](aZ, {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](UH, {
                              'className': "resizableTxt"
                            }, Uz['t']("BonusWallet.Expiry")))), z["createElement"](aL, null, z["createElement"]("div", {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, s3)), z["createElement"](aZ, {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](UH, {
                              'className': "resizableTxt"
                            }, Uz['t']("BonusWallet.InitialBonusRatioLabel"))))), z["createElement"](Uo, null), z["createElement"](U0, null, z["createElement"](UH, null, Uz['t']("BonusWallet.RollOverMode")), s4["rollOverModeContent"]), z["createElement"](U2, null, s4["discardOfferBtnContent"], s4["selectWalletBtnContent"])));
                          });
                          return z["createElement"](UU, {
                            'orientation': shell["environment"]["getOrientationMode"]()
                          }, z["createElement"](tQ["default"], {
                            'handleClass': "background-color: rgba(117, 117, 117, 0.7);",
                            'freezePosition': this["state"]["scrollFreeze"],
                            'onScroll': function (HT) {
                              var h = h;
                              var h = h;
                              {
                                var H1 = HT["target"];
                                Hj['On'] > 0x1 && H1["clientHeight"] + H1["scrollTop"] === H1["scrollHeight"] && (Hj['On']--, Hj['bn']++, Hj["props"]["onLoadMoreRequestApi"](Hj['bn'], function () {
                                  var h = h;
                                  var h = h;
                                  Hj["setState"]({
                                    'scrollFreeze': !0x1
                                  });
                                }), Hj['wn'] = !0x0, Hj["setState"]({
                                  'scrollFreeze': !0x0
                                }));
                              }
                            },
                            'rtl': Vq["isRTL"]
                          }, z["createElement"](Uh, {
                            'id': "scrollView",
                            'orientation': shell["environment"]["getOrientationMode"](),
                            'currHeight': HL
                          }, Hj, z["createElement"](aO, {
                            'id': "loadMore",
                            'key': this['bn']
                          }, z["createElement"](U3, null, this['Fn']())))));
                        }
                      }
                      return z["createElement"](aR, null, z["createElement"](aD, null, z["createElement"](aJ, null, Uz['t']("BonusWallet.NoOfferFound"))));
                    }
                  }
                }
              }, V8["prototype"]['Z'] = function (Hj, HL) {
                var h = h;
                var h = h;
                {
                  var Va = Hj["status"],
                    HS = Hj["key"],
                    Hj = Hj["keySelection"],
                    Hc = Hj["balanceAmount"],
                    HA = Hj["bonusRatioAmount"],
                    HX = Hj["maximumConversionAmount"],
                    Hj = Hj["rollOverMode"],
                    HT = VR["transactionInfo"],
                    H1 = Us(Hc),
                    Hp = Us(HA);
                  switch (Va) {
                    case 0x2:
                      return {
                        'remainingInfo': Uz['t']("BonusWallet.Expired"),
                        'rollOverBalContent': null,
                        'withdrawLimitContent': null,
                        'rollOverModeContent': this['Tn'](HL, HS, Hj, Hj),
                        'discardOfferBtnContent': this['Nn'](Hj, !0x0),
                        'selectWalletBtnContent': this['_n'](HS, HL, Va)
                      };
                    case 0x6:
                      return {
                        'remainingInfo': Uz['t']("BonusWallet.BonusWalletDiscarded"),
                        'rollOverBalContent': null,
                        'withdrawLimitContent': null,
                        'rollOverModeContent': this['Tn'](HL, HS, Hj, Hj),
                        'discardOfferBtnContent': this['zn'](Hj),
                        'selectWalletBtnContent': this['_n'](HS, HL, Va)
                      };
                    case 0x7:
                      return {
                        'remainingInfo': H1,
                        'rollOverBalContent': null,
                        'withdrawLimitContent': this['An'](HX),
                        'rollOverModeContent': this['Tn'](HL, HS, Hj, Hj),
                        'discardOfferBtnContent': this['Nn'](Hj, !0x1),
                        'selectWalletBtnContent': this['Ln'](Hj, HL)
                      };
                    case 0x1:
                      return {
                        'remainingInfo': H1,
                        'rollOverBalContent': z["createElement"]("div", {
                          'className': "resizableTxtContainer"
                        }, z["createElement"](U4, {
                          'className': "resizableTxt"
                        }, ''["concat"](Uz['t']("BonusWallet.BonusRatioLabel"), '\x20')["concat"](Hp))),
                        'withdrawLimitContent': this['An'](HX),
                        'rollOverModeContent': 0x2 === Hj ? this['In'](HL, Hj, Va) : this['Tn'](HL, HS, Hj, Hj),
                        'discardOfferBtnContent': this['Nn'](Hj, !0x1),
                        'selectWalletBtnContent': HS === HT['wk'] || 0x2 === Hj && !HS ? this['_n'](HS, HL, Va) : this['Dn'](Hj, HL)
                      };
                    default:
                      return {
                        'remainingInfo': H1,
                        'rollOverBalContent': null,
                        'withdrawLimitContent': this['An'](HX),
                        'rollOverModeContent': 0x2 === Hj ? this['In'](HL, Hj, Va) : this['Tn'](HL, HS, Hj, Hj),
                        'discardOfferBtnContent': this['Nn'](Hj, !0x1),
                        'selectWalletBtnContent': HS === HT['wk'] || 0x2 === Hj && !HS ? this['_n'](HS, HL, Va) : this['Dn'](Hj, HL)
                      };
                  }
                }
              }, V8["prototype"]['An'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = Us(Hj);
                  return Hj > 0x0 && z["createElement"]("div", {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](U4, {
                    'className': "resizableTxt"
                  }, Uz['t']("BonusWallet.MaximumConversionRate", {
                    'rate': HL
                  })));
                }
              }, V8["prototype"]['In'] = function (Hj, HL, Va) {
                var h = h;
                var h = h;
                var HS = HL["rollOverMode"],
                  Hj = HL["key"],
                  Hc = HL["keySelection"];
                if (0x5 === Va) (HA = document["getElementById"]("selectWalletBtn "["concat"](Hj["toString"]()))) && HA["children"][0x0]["innerHTML"] !== Uz['t']("BonusWallet.SelectMode") && (Va = Math["random"]());else if (0x1 === Va) {
                  var HA;
                  (HA = document["getElementById"]("selectWalletBtn "["concat"](Hj["toString"]()))) && HA["children"][0x0]["innerHTML"] !== Uz['t']("BonusWallet.WalletInuse") && (Va = Math["random"]());
                }
                return z["createElement"](U1, null, z["createElement"](Uw, null, z["createElement"](U5, {
                  'id': "custom cash radio button "["concat"](Hj["toString"]())
                }, z["createElement"](Uu, {
                  'type': "radio",
                  'id': "cash "["concat"](Hj["toString"]()),
                  'key': Va,
                  'value': "cash",
                  'name': Hj["toString"](),
                  'defaultChecked': 0x1 === HS || Hc && Hj === Hc[0x1],
                  'onChange': this['Rn']["bind"](this, Hj, HL),
                  'onClick': this['jn']["bind"](this, Hj)
                }), z["createElement"](UV, {
                  'id': "cash check mark "["concat"](Hj["toString"]()),
                  'orientation': shell["environment"]["getOrientationMode"]()
                })), z["createElement"](U6, {
                  'className': "wallet-plugin-color-sprite wallet-plugin-color-ic_wallet",
                  'orientation': shell["environment"]["getOrientationMode"]()
                }), z["createElement"](U8, {
                  'htmlFor': "cash "["concat"](Hj["toString"]()),
                  'orientation': shell["environment"]["getOrientationMode"]()
                }, Uz['t']("BonusWallet.Cash"))), z["createElement"](Uw, null, z["createElement"](U5, {
                  'id': "custom bonus radio button "["concat"](Hj["toString"]())
                }, z["createElement"](Uu, {
                  'type': "radio",
                  'id': "bonus "["concat"](Hj["toString"]()),
                  'key': Va,
                  'value': "bonus",
                  'name': Hj["toString"](),
                  'defaultChecked': 0x0 === HS || Hc && Hj === Hc[0x0],
                  'onChange': this['Rn']["bind"](this, Hj, HL),
                  'onClick': this['Mn']["bind"](this, Hj)
                }), z["createElement"](UV, {
                  'id': "bonus check mark "["concat"](Hj["toString"]()),
                  'orientation': shell["environment"]["getOrientationMode"]()
                })), z["createElement"](U6, {
                  'className': "wallet-plugin-color-sprite wallet-plugin-color-ic_bonus_wallet",
                  'orientation': shell["environment"]["getOrientationMode"]()
                }), z["createElement"](U8, {
                  'htmlFor': "bonus "["concat"](Hj["toString"]()),
                  'orientation': shell["environment"]["getOrientationMode"]()
                }, Uz['t']("BonusWallet.Bonus"))));
              }, V8["prototype"]['Tn'] = function (Hj, HL, Va, HS) {
                var h = h;
                var h = h;
                {
                  return z["createElement"](U1, null, z["createElement"](Uw, null, z["createElement"](U5, {
                    'id': "custom cash radio button "["concat"](Hj["toString"]())
                  }, z["createElement"](Uu, {
                    'type': "radio",
                    'id': "cash "["concat"](Hj["toString"]()),
                    'value': "cash",
                    'name': Hj["toString"](),
                    'defaultChecked': 0x1 === HS || Va && HL === Va[0x1],
                    'disabled': !0x0
                  }), z["createElement"](UV, {
                    'id': "cash check mark "["concat"](Hj["toString"]()),
                    'orientation': shell["environment"]["getOrientationMode"]()
                  })), z["createElement"](U7, {
                    'className': "wallet-plugin-color-sprite wallet-plugin-color-ic_wallet",
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }), z["createElement"](U9, {
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }, Uz['t']("BonusWallet.Cash"))), z["createElement"](Uw, null, z["createElement"](U5, {
                    'id': "custom bonus radio button "["concat"](Hj["toString"]())
                  }, z["createElement"](Uu, {
                    'type': "radio",
                    'id': "bonus "["concat"](Hj["toString"]()),
                    'value': "bonus",
                    'name': Hj["toString"](),
                    'defaultChecked': 0x0 === HS || Va && HL === Va[0x0],
                    'disabled': !0x0
                  }), z["createElement"](UV, {
                    'id': "bonus check mark "["concat"](Hj["toString"]()),
                    'orientation': shell["environment"]["getOrientationMode"]()
                  })), z["createElement"](U7, {
                    'className': "wallet-plugin-color-sprite wallet-plugin-color-ic_bonus_wallet",
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }), z["createElement"](U9, {
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }, Uz['t']("BonusWallet.Bonus"))));
                }
              }, V8["prototype"]['zn'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  return 0x2 !== Hj["status"] && Hj["isHideDiscard"] ? null : z["createElement"](ac, {
                    'className': "btnStyle",
                    'disabled': !0x0
                  }, z["createElement"](U3, null, Uz['t']("BonusWallet.DiscardWallet")));
                }
              }, V8["prototype"]['Nn'] = function (Hj, HL) {
                var h = h;
                var h = h;
                {
                  return 0x2 !== Hj["status"] && Hj["isHideDiscard"] ? null : z["createElement"](ac, {
                    'className': "btnStyle",
                    'onClick': this['yn']["bind"](this, Hj, HL)
                  }, z["createElement"](U3, null, Uz['t']("BonusWallet.DiscardWallet")));
                }
              }, V8["prototype"]['_n'] = function (Hj, HL, Va) {
                var h = h;
                var h = h;
                {
                  var HS = Hj ? VR["transactionInfo"]['wk'] === Hj ? Uz['t']("BonusWallet.WalletInuse") : Uz['t']("BonusWallet.SelectWallet") : Uz['t']("BonusWallet.SelectMode");
                  if (0x5 === Va) (Hj = document["getElementById"]("selectWalletBtn "["concat"](HL["toString"]()))) && Hj["children"][0x0]["innerHTML"] !== Uz['t']("BonusWallet.SelectMode") && (Va = Math["random"]());else if (0x1 === Va) {
                    {
                      var Hj;
                      (Hj = document["getElementById"]("selectWalletBtn "["concat"](HL["toString"]()))) && Hj["children"][0x0]["innerHTML"] !== Uz['t']("BonusWallet.WalletInuse") && (Va = Math["random"]());
                    }
                  }
                  var Hc = shell["uiAppearance"]['v']("game.theme_color");
                  return z["createElement"](aX, {
                    'id': "selectWalletBtn "["concat"](HL["toString"]()),
                    'className': "btnStyle",
                    'key': Va,
                    'disabled': !0x0,
                    'themeColor': "rgba("["concat"](Hc['r'], ',\x20')["concat"](Hc['g'], ',\x20')["concat"](Hc['b'], ',\x20')["concat"](Hc['a'] / 0xff * 0.2, ')')
                  }, z["createElement"](U3, null, HS));
                }
              }, V8["prototype"]['Dn'] = function (Hj, HL) {
                var h = h;
                var h = h;
                {
                  return z["createElement"](aA, {
                    'id': "selectWalletBtn "["concat"](HL["toString"]()),
                    'className': "btnStyle",
                    'onClick': this['Cn']["bind"](this, Hj, HL),
                    'themeColor': VR["gameThemeColor"]
                  }, z["createElement"](U3, null, Uz['t']("BonusWallet.SelectWallet")));
                }
              }, V8["prototype"]['Ln'] = function (Hj, HL) {
                var h = h;
                var h = h;
                return this['vn']["push"](HL), z["createElement"](ap, null, z["createElement"](al, {
                  'id': "selectWalletBtn "["concat"](HL["toString"]()),
                  'className': "btnStyle",
                  'onClick': this["props"]["onSelectWalletClick"]["bind"](this, Hj, HL)
                }, z["createElement"](U3, null, Uz['t']("BonusWallet.WalletLocked"))), z["createElement"](ag, {
                  'orientation': shell["environment"]["getOrientationMode"](),
                  'themeColor': VR["gameThemeColor"]
                }), z["createElement"](aP, {
                  'className': "wallet-plugin-sprite wallet-plugin-ic_warning_overlay",
                  'onClick': this["props"]["onSelectWalletClick"]["bind"](this, Hj, HL),
                  'orientation': shell["environment"]["getOrientationMode"]()
                }));
              }, V8["prototype"]['Rn'] = function (Hj, HL) {
                var h = h;
                var h = h;
                {
                  var Va = HL["key"],
                    HS = HL["rollOverMode"],
                    Hj = VR["transactionInfo"],
                    Hc = VR["gameThemeColor"];
                  if (Hj['wk'] === Va || !Va) {
                    {
                      var HA = document["getElementById"]("selectWalletBtn "["concat"](Hj["toString"]()));
                      if (0x2 === HS && !Va) return HA["children"][0x0]["innerHTML"] = Uz['t']("BonusWallet.SelectWallet"), HA["disabled"] = !0x1, HA["onclick"] = this['Cn']["bind"](this, HL, Hj), void (HA["style"]["backgroundColor"] = Hc);
                      var HX = document["getElementById"]("cash "["concat"](Hj["toString"]())),
                        Hj = HX["defaultChecked"] ? HX["checked"] ? Uz['t']("BonusWallet.WalletInuse") : Uz['t']("BonusWallet.SwapMode") : HX["checked"] ? Uz['t']("BonusWallet.SwapMode") : Uz['t']("BonusWallet.WalletInuse"),
                        HT = shell["uiAppearance"]['v']("game.theme_color");
                      HA["disabled"] = HX["defaultChecked"] ? HX["checked"] : !HX["checked"], HA["onclick"] = HA["disabled"] ? null : this['Cn']["bind"](this, HL, Hj), HA["style"]["backgroundColor"] = HA["disabled"] ? "rgba("["concat"](HT['r'], ',\x20')["concat"](HT['g'], ',\x20')["concat"](HT['b'], ',\x20')["concat"](HT['a'] / 0xff * 0.2, ')') : Hc, HA["children"][0x0]["innerHTML"] = Hj;
                    }
                  }
                }
              }, V8["prototype"]['jn'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = document["getElementById"]("cash check mark "["concat"](Hj["toString"]())),
                    Va = document["getElementById"]("bonus check mark "["concat"](Hj["toString"]()));
                  HL["style"]["display"] = "block", Va["style"]["display"] = "none";
                }
              }, V8["prototype"]['Mn'] = function (Hj) {
                var h = h;
                var h = h;
                var HL = document["getElementById"]("cash check mark "["concat"](Hj["toString"]())),
                  Va = document["getElementById"]("bonus check mark "["concat"](Hj["toString"]()));
                HL["style"]["display"] = "none", Va["style"]["display"] = "block";
              }, V8["prototype"]['Fn'] = function () {
                var h = h;
                var h = h;
                return this['wn'] ? (this['wn'] = !0x1, '') : this['On'] > 0x1 ? Uz['t']("BonusWallet.LoadMoreData") : Uz['t']("BonusWallet.AllRecordDisplayed");
              }, V8;
            }(z["Component"]),
            UC = function () {
              var h = h;
              var h = h;
              {
                function Hf(V8) {
                  var h = h;
                  var h = h;
                  {
                    this['J'] = V8['k'], this['En'] = V8["fgid"], this['Un'] = V8['n'], this['q'] = V8["gids"], this['Pn'] = V8['gc'], this['Vn'] = V8['tg'], this['K'] = V8['ba'], this['Hn'] = V8['m'], this['Zn'] = V8['cs'], this['en'] = V8['ed'], this['M'] = V8['s'], this['Jn'] = V8['ct'], this['nn'] = V8["mca"], this['an'] = V8['ca'], this['Xn'] = V8['ck'], this['ln'] = V8["gidl"], this['Yn'] = V8["cgid"], this['hn'] = V8["baid"], this['dn'] = V8["isd"];
                  }
                }
                return Object["defineProperty"](Hf["prototype"], "key", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['J'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "freeGameID", {
                  'get': function () {
                    return this['En'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "freeGameName", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['Un'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "gameIDs", {
                  'get': function () {
                    return this['q'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "gameCount", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['Pn'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "totalGame", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['Vn'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "balanceAmount", {
                  'get': function () {
                    return !this['K'] && (this['K'] = 0x0), this['K'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "multiplier", {
                  'get': function () {
                    return this['Hn'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "coinSize", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['Zn'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "expiredDate", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      var V8 = new Date(this['en']);
                      return V8["getFullYear"]() + '/' + Vz(V8["getMonth"]() + 0x1) + '/' + Vz(V8["getDate"]());
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "status", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['M'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "conversionType", {
                  'get': function () {
                    return this['Jn'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "maximumConversionAmount", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return !this['nn'] && (this['nn'] = 0x0), this['nn'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "conversionAmount", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return !this['an'] && (this['an'] = 0x0), this['an'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "conversionKey", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['Xn'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "lockedGameID", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['ln'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "convertedID", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['Yn'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "balanceID", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    {
                      return this['hn'];
                    }
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "expiredTime", {
                  'get': function () {
                    var h = h;
                    var h = h;
                    var V8 = new Date(this['en']);
                    return Vz(V8["getHours"]()) + ':' + Vz(V8["getMinutes"]()) + ':' + Vz(V8["getSeconds"]());
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Object["defineProperty"](Hf["prototype"], "isHideDiscard", {
                  'get': function () {
                    return this['dn'];
                  },
                  'enumerable': !0x1,
                  'configurable': !0x0
                }), Hf;
              }
            }(),
            UW = V7["formatCurrency"],
            Uv = shell["I18n"],
            Uy = function (Hf) {
              var h = h;
              var h = h;
              {
                function V8(Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hf["call"](this, Hj) || this;
                    return HL['mn'] = [], HL['gn'] = !0x1, HL['bn'] = 0x1, HL['qn'] = [], HL['xn'] = !0x1, HL['wn'] = !0x1, HL['yn'] = function (Va, HS) {
                      var h = h;
                      var h = h;
                      {
                        for (var Hj = document["getElementsByClassName"]("btnStyle"), Hc = 0x0, HA = Hj["length"]; Hc < HA; Hc++) Hj[Hc]["blur"]();
                        Hj["onDiscardOfferClick"](Va, HS);
                      }
                    }, HL["state"] = {
                      'scrollFreeze': !0x1
                    }, HL;
                  }
                }
                return V0(V8, Hf), V8["prototype"]["componentDidMount"] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = Vq["context"]["event"];
                    Hj['on']("Shell.Scaled", this['kn'], this), Hj["emit"]("Game.FreeGameListOpened"), this['Bn'](), this['Qn'](), document["addEventListener"]("keydown", this['Gn']);
                  }
                }, V8["prototype"]["componentDidUpdate"] = function () {
                  this['Bn'](), this['Qn']();
                }, V8["prototype"]["componentWillUnmount"] = function () {
                  var h = h;
                  var h = h;
                  Vq["context"]["event"]["off"]("Shell.Scaled", this['kn'], this), document["removeEventListener"]("keydown", this['Gn']);
                }, V8["prototype"]["shouldComponentUpdate"] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    return this["props"]["show"] === Hj["show"] && (this['xn'] = this["props"]["data"] === Hj["data"], !0x0);
                  }
                }, V8["prototype"]["render"] = function () {
                  var h = h;
                  var h = h;
                  return z["createElement"](aF, {
                    'id': "bwfgContainer",
                    'className': "wallet"
                  }, this['V'](), this['H']());
                }, V8["prototype"]['Gn'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    '\x20' !== Hj["key"] && "Spacebar" !== Hj["key"] || Hj["preventDefault"]();
                  }
                }, V8["prototype"]['kn'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hj["payload"],
                      Va = document["getElementById"]("scrollView"),
                      HS = parseFloat(o["getComputedStyle"](document["getElementById"]("headerWrapper"))["height"]);
                    Va && (Va["style"]["maxHeight"] = ''["concat"](HL["height"] - HS, 'px'));
                  }
                }, V8["prototype"]['Bn'] = function () {
                  var h = h;
                  var h = h;
                  {
                    for (var Hj = this['mn'], HL = 0x0, Va = Hj["length"]; HL < Va; HL++) {
                      {
                        var HS = Hj[HL]["key"];
                        if (HS && VR["transactionInfo"]['wk'] === HS) {
                          var Hj = document["getElementById"]("currWalletSideBar "["concat"](HL["toString"]())),
                            Hc = document["getElementById"]("bwfgView "["concat"](HL["toString"]()));
                          Hj["style"]["height"] = ''["concat"](Hc["clientHeight"]["toString"](), 'px');
                        }
                      }
                    }
                  }
                }, V8["prototype"]['Qn'] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = VR["gameThemeColor"];
                    this['qn']["forEach"](function (HL) {
                      var h = h;
                      var h = h;
                      document["getElementById"]("selectFreeGameBtn "["concat"](HL["toString"]()))["style"]["backgroundColor"] = Hj;
                    });
                  }
                }, V8["prototype"]['V'] = function () {
                  var h = h;
                  var h = h;
                  var Hj = VR["status"];
                  if (!this["props"]["error"] && this["props"]["data"] && this["props"]["data"]['dt']['r']) for (var HL = 0x0, Va = this["props"]["data"]['dt']['r']["length"]; HL < Va; HL++) if (0x6 === this["props"]["data"]['dt']['r'][HL]['s'] && VR["transactionInfo"]['wk'] === this["props"]["data"]['dt']['r'][HL]['k']) {
                    {
                      this['gn'] = !0x0;
                      break;
                    }
                  }
                  return z["createElement"](aY, {
                    'id': "headerWrapper"
                  }, z["createElement"](aQ, {
                    'id': "bwfgHeader",
                    'orientation': shell["environment"]["getOrientationMode"](),
                    'themeColor': VR["gameThemeColor"]
                  }, Uv['t']("FreeGame.FreeGame")), z["createElement"](Ua, {
                    'className': "wallet-plugin-sprite wallet-plugin-ic_close",
                    'onClick': 0x4 === Hj || 0x3 === Hj || 0x2 === Hj || this['gn'] ? this["props"]["onBackCashWalletClick"] : this["props"]["onCloseButtonClick"],
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }));
                }, V8["prototype"]['H'] = function () {
                  var h = h;
                  var h = h;
                  var Hj = this;
                  if (this["props"]["error"]) return this['bn'] = 0x1, this['mn'] = [], z["createElement"](aR, null, z["createElement"](aD, null, z["createElement"](aJ, null, z["createElement"](U3, null, this["props"]["error"]["message"])), this["props"]["error"]["shouldRetry"] && z["createElement"](aI, {
                    'onClick': this["props"]["onRetryClick"],
                    'themeColor': VR["gameThemeColor"]
                  }, Uv['t']("General.DialogRetry"))));
                  if (this["props"]["data"]) {
                    {
                      this['gn'] = !0x1, this['qn'] = [];
                      var HL = parseFloat(document["getElementById"]("wallet-container")["style"]["height"]),
                        Va = this["props"]["data"]['dt'],
                        HS = JSON["parse"](JSON["stringify"](Va['r'])),
                        Hj = Va['tp'];
                      if (this['On'] = this['bn'] > 0x1 ? this['On'] : Hj, this['mn'] = this['bn'] > 0x1 ? this['mn'] : [], HS && HS["length"] > 0x0) {
                        {
                          if (!this['xn']) {
                            for (var Hc = 0x0, HA = HS["length"]; Hc < HA; Hc++) {
                              var HX = HS[Hc];
                              if (HX['k'] === VR["transactionInfo"]['wk']) {
                                this['mn']["push"](new UC(HX)), HS["splice"](Hc, 0x1);
                                break;
                              }
                            }
                            HS["length"] > 0x0 && HS["forEach"](function (HT) {
                              var h = h;
                              Hj['mn']["push"](new UC(HT));
                            });
                          }
                          var Hj = this['mn']["map"](function (HT, H1) {
                            var h = h;
                            var h = h;
                            var Hp = HT["freeGameName"],
                              Hl = HT["freeGameID"],
                              Hg = HT["expiredDate"],
                              HP = HT["expiredTime"],
                              s0 = HT["coinSize"],
                              s1 = HT["multiplier"],
                              s2 = HT["key"],
                              s3 = HT["status"],
                              s4 = VR["gameRawInfo"],
                              s5 = VR["transactionInfo"],
                              s6 = UW(s0 * s1 * s4['dt']["mxl"]),
                              s7 = Hj['Z'](HT, H1);
                            return z["createElement"](aB, {
                              'key': H1
                            }, s2 && s5['wk'] === s2 && z["createElement"](aT, {
                              'id': "currWalletSideBar "["concat"](H1["toString"]()),
                              'themeColor': VR["gameThemeColor"]
                            }), z["createElement"](aN, {
                              'id': "bwfgView "["concat"](H1["toString"]()),
                              'key': H1
                            }, z["createElement"](ab, null, z["createElement"](af, null, z["createElement"]("div", {
                              'className': "resizableTxtContainer"
                            }, 0x5 === s3 && z["createElement"](ak, {
                              'className': "wallet-plugin-sprite wallet-plugin-ic_wallet_new",
                              'orientation': shell["environment"]["getOrientationMode"]()
                            }), z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, Hp)), z["createElement"](am, {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, Uv['t']("FreeGame.Offer", {
                              'id': Hl["toString"]()
                            })))), z["createElement"](ad, null, z["createElement"](aS, {
                              'className': "resizableTxtContainer",
                              'themeColor': VR["gameThemeColor"]
                            }, z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, s7["remainingInfo"])), s7["totalWonContent"], s7["withdrawLimitContent"])), z["createElement"](aK, null, z["createElement"](aj, null, z["createElement"]("div", {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, Hg, '\x20', HP)), z["createElement"](aZ, {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](UH, {
                              'className': "resizableTxt"
                            }, Uv['t']("FreeGame.ExpiryDate")))), z["createElement"](aL, null, z["createElement"]("div", {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](U3, {
                              'className': "resizableTxt"
                            }, s6)), z["createElement"](aZ, {
                              'className': "resizableTxtContainer"
                            }, z["createElement"](UH, {
                              'className': "resizableTxt"
                            }, Uv['t']("FreeGame.SingleBet"))))), z["createElement"](U2, null, s7["discardOfferBtnContent"], s7["selectFreeGameBtnContent"])));
                          });
                          return z["createElement"](UU, {
                            'orientation': shell["environment"]["getOrientationMode"]()
                          }, z["createElement"](tQ["default"], {
                            'handleClass': "background-color: rgba(117, 117, 117, 0.7);",
                            'freezePosition': this["state"]["scrollFreeze"],
                            'onScroll': function (HT) {
                              var h = h;
                              var h = h;
                              {
                                var H1 = HT["target"];
                                Hj['On'] > 0x1 && H1["clientHeight"] + H1["scrollTop"] === H1["scrollHeight"] && (Hj['On']--, Hj['bn']++, Hj["props"]["onLoadMoreRequestApi"](Hj['bn'], function () {
                                  var h = h;
                                  var h = h;
                                  {
                                    Hj["setState"]({
                                      'scrollFreeze': !0x1
                                    });
                                  }
                                }), Hj['wn'] = !0x0, Hj["setState"]({
                                  'scrollFreeze': !0x0
                                }));
                              }
                            },
                            'rtl': Vq["isRTL"]
                          }, z["createElement"](Uh, {
                            'id': "scrollView",
                            'orientation': shell["environment"]["getOrientationMode"](),
                            'currHeight': HL
                          }, Hj, z["createElement"](aO, {
                            'id': "loadMore",
                            'key': this['bn']
                          }, z["createElement"](U3, null, this['Fn']())))));
                        }
                      }
                      return z["createElement"](aR, null, z["createElement"](aD, null, z["createElement"](aJ, null, Uv['t']("FreeGame.NoOfferFound"))));
                    }
                  }
                }, V8["prototype"]['Z'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  var Va = Hj["status"],
                    HS = Hj["balanceAmount"],
                    Hj = Hj["maximumConversionAmount"],
                    Hc = Hj["gameCount"],
                    HA = Hj["totalGame"],
                    HX = Hj["key"],
                    Hj = VR["transactionInfo"];
                  switch (Va) {
                    case 0x2:
                      return {
                        'remainingInfo': Uv['t']("FreeGame.Expired"),
                        'totalWonContent': null,
                        'withdrawLimitContent': null,
                        'discardOfferBtnContent': this['Nn'](Hj, !0x0),
                        'selectFreeGameBtnContent': this['Kn'](!0x1, Hc === HA)
                      };
                    case 0x6:
                      return {
                        'remainingInfo': Uv['t']("FreeGame.DiscardWallet"),
                        'totalWonContent': null,
                        'withdrawLimitContent': null,
                        'discardOfferBtnContent': this['zn'](Hj),
                        'selectFreeGameBtnContent': this['Kn'](!0x1, Hc === HA)
                      };
                    case 0x7:
                      return {
                        'remainingInfo': Hc === HA ? Uv['t']("FreeGame.FreeGameTotal", {
                          'gameCount': Hc["toString"]()
                        }) : Uv['t']("FreeGame.FreeGameRemaining", {
                          'gameCount': Hc["toString"]()
                        }),
                        'totalWonContent': null,
                        'withdrawLimitContent': this['An'](Hj),
                        'discardOfferBtnContent': this['Nn'](Hj, !0x1),
                        'selectFreeGameBtnContent': this['$n'](Hj, HL)
                      };
                    case 0x1:
                      var HT = UW(HS);
                      return {
                        'remainingInfo': Uv['t']("FreeGame.FreeGameRemaining", {
                          'gameCount': Hc["toString"]()
                        }),
                        'totalWonContent': z["createElement"]("div", {
                          'className': "resizableTxtContainer"
                        }, z["createElement"](U4, {
                          'className': "resizableTxt"
                        }, Uv['t']("FreeGame.CurrentWin", {
                          'amount': HT
                        }))),
                        'withdrawLimitContent': this['An'](Hj),
                        'discardOfferBtnContent': this['Nn'](Hj, !0x1),
                        'selectFreeGameBtnContent': Hj['wk'] === HX ? this['Kn'](!0x0) : this['nt'](Hj, HL)
                      };
                    default:
                      return {
                        'remainingInfo': Uv['t']("FreeGame.FreeGameTotal", {
                          'gameCount': Hc["toString"]()
                        }),
                        'totalWonContent': null,
                        'withdrawLimitContent': this['An'](Hj),
                        'discardOfferBtnContent': this['Nn'](Hj, !0x1),
                        'selectFreeGameBtnContent': Hj['wk'] === HX ? this['Kn'](!0x0) : this['nt'](Hj, HL)
                      };
                  }
                }, V8["prototype"]['An'] = function (Hj) {
                  var h = h;
                  var h = h;
                  var HL = UW(Hj);
                  return Hj > 0x0 && z["createElement"]("div", {
                    'className': "resizableTxtContainer"
                  }, z["createElement"](U4, {
                    'className': "resizableTxt"
                  }, Uv['t']("FreeGame.MaximumConversionRate", {
                    'rate': HL
                  })));
                }, V8["prototype"]['zn'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    return 0x2 !== Hj["status"] && Hj["isHideDiscard"] ? null : z["createElement"](ac, {
                      'className': "btnStyle",
                      'disabled': !0x0
                    }, z["createElement"](U3, null, Uv['t']("FreeGame.DiscardGame")));
                  }
                }, V8["prototype"]['Nn'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  return 0x2 !== Hj["status"] && Hj["isHideDiscard"] ? null : z["createElement"](ac, {
                    'className': "btnStyle",
                    'onClick': this['yn']["bind"](this, Hj, HL)
                  }, z["createElement"](U3, null, Uv['t']("FreeGame.DiscardGame")));
                }, V8["prototype"]['Kn'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  {
                    var Va = Hj ? Uv['t']("FreeGame.GameInUse") : HL ? Uv['t']("FreeGame.PlayGameNow") : Uv['t']("FreeGame.ContinueGame"),
                      HS = shell["uiAppearance"]['v']("game.theme_color");
                    return z["createElement"](aX, {
                      'className': "btnStyle",
                      'disabled': !0x0,
                      'themeColor': "rgba("["concat"](HS['r'], ',\x20')["concat"](HS['g'], ',\x20')["concat"](HS['b'], ',\x20')["concat"](HS['a'] / 0xff * 0.2, ')')
                    }, z["createElement"](U3, null, Va));
                  }
                }, V8["prototype"]['nt'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  {
                    var Va = this,
                      HS = Hj["gameCount"] === Hj["totalGame"] ? Uv['t']("FreeGame.PlayGameNow") : Uv['t']("FreeGame.ContinueGame");
                    return z["createElement"](aA, {
                      'id': "selectFreeGameBtn "["concat"](HL["toString"]()),
                      'className': "btnStyle",
                      'onClick': function () {
                        var h = h;
                        var h = h;
                        {
                          document["getElementById"]("selectFreeGameBtn "["concat"](HL["toString"]()))["blur"](), Va["props"]["onSelectFreeGameClick"](Hj);
                        }
                      },
                      'themeColor': VR["gameThemeColor"]
                    }, z["createElement"](U3, null, HS));
                  }
                }, V8["prototype"]['$n'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  return this['qn']["push"](HL), z["createElement"](ap, null, z["createElement"](al, {
                    'id': "selectFreeGameBtn "["concat"](HL["toString"]()),
                    'className': "btnStyle",
                    'onClick': this["props"]["onSelectFreeGameClick"]["bind"](this, Hj)
                  }, z["createElement"](U3, null, Uv['t']("FreeGame.WalletLocked"))), z["createElement"](ag, {
                    'orientation': shell["environment"]["getOrientationMode"](),
                    'themeColor': VR["gameThemeColor"]
                  }), z["createElement"](aP, {
                    'className': "wallet-plugin-sprite wallet-plugin-ic_warning_overlay",
                    'onClick': this["props"]["onSelectFreeGameClick"]["bind"](this, Hj),
                    'orientation': shell["environment"]["getOrientationMode"]()
                  }));
                }, V8["prototype"]['Fn'] = function () {
                  var h = h;
                  var h = h;
                  {
                    return this['wn'] ? (this['wn'] = !0x1, '') : this['On'] > 0x1 ? Uv['t']("FreeGame.LoadMoreData") : Uv['t']("FreeGame.AllRecordDisplayed");
                  }
                }, V8;
              }
            }(z["Component"]),
            UE = {},
            UM = {},
            Uq = function () {
              var h = h;
              var h = h;
              {
                function Hf() {}
                return Hf["prototype"]["parsePlistData"] = function (V8, Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = this,
                      Va = new plugin["Loader"]();
                    Va["load"]([{
                      'src': V8,
                      'type': plugin["LoadType"]["Text"]
                    }]), Va["onLoad"] = function (HS) {
                      var h = h;
                      var h = h;
                      {
                        var Hj = new DOMParser()["parseFromString"](HS["response"]["toString"](), "text/xml"),
                          Hc = HL['tt'](Hj["documentElement"]);
                        Hj && Hj(Hc);
                      }
                    }, Va["onError"] = function () {};
                  }
                }, Hf["prototype"]['et'] = function (V8) {
                  var h = h;
                  var h = h;
                  {
                    return !V8["childNodes"] || 0x0 === V8["childNodes"]["length"];
                  }
                }, Hf["prototype"]['it'] = function (V8, Hj) {
                  if (!V8) throw Error(Hj);
                }, Hf["prototype"]['rt'] = function (V8) {
                  var h = h;
                  var h = h;
                  {
                    return 0x3 === V8["nodeType"] || 0x8 === V8["nodeType"] || 0x4 === V8["nodeType"];
                  }
                }, Hf["prototype"]['tt'] = function (V8) {
                  var h = h;
                  var h = h;
                  {
                    var Hj, HL, Va, HS, Hj, Hc;
                    if (!V8) return null;
                    if ("plist" === V8["nodeName"]) {
                      {
                        if (HS = [], this['et'](V8)) return HS;
                        for (Hj = 0x0; Hj < V8["childNodes"]["length"]; Hj++) this['rt'](V8["childNodes"][Hj]) || HS["push"](this['tt'](V8["childNodes"][Hj]));
                        return HS;
                      }
                    }
                    if ("dict" === V8["nodeName"]) {
                      {
                        if (HL = {}, Va = null, Hc = 0x0, this['et'](V8)) return HL;
                        for (Hj = 0x0; Hj < V8["childNodes"]["length"]; Hj++) this['rt'](V8["childNodes"][Hj]) || (Hc % 0x2 == 0x0 ? (this['it']("key" === V8["childNodes"][Hj]["nodeName"], "Missing key while parsing <dict/>."), Va = this['tt'](V8["childNodes"][Hj])) : (this['it']("key" !== V8["childNodes"][Hj]["nodeName"], "Unexpected key \"" + this['tt'](V8["childNodes"][Hj]) + "\" while parsing <dict/>."), HL[Va] = this['tt'](V8["childNodes"][Hj])), Hc += 0x1);
                        if (Hc % 0x2 == 0x1) throw Error("Missing value for \"" + Va + "\" while parsing <dict/>");
                        return HL;
                      }
                    }
                    if ("array" === V8["nodeName"]) {
                      if (HS = [], this['et'](V8)) return HS;
                      for (Hj = 0x0; Hj < V8["childNodes"]["length"]; Hj++) this['rt'](V8["childNodes"][Hj]) || null !== (Hj = this['tt'](V8["childNodes"][Hj])) && HS["push"](Hj);
                      return HS;
                    }
                    if ("#text" === V8["nodeName"]) ;else {
                      {
                        if ("key" === V8["nodeName"]) return this['et'](V8) ? '' : V8["childNodes"][0x0]["nodeValue"];
                        if ("string" === V8["nodeName"]) {
                          {
                            if (Hj = '', this['et'](V8)) return Hj;
                            for (Hj = 0x0; Hj < V8["childNodes"]["length"]; Hj++) {
                              var HA = V8["childNodes"][Hj]["nodeType"];
                              0x3 !== HA && 0x4 !== HA || (Hj += V8["childNodes"][Hj]["nodeValue"]);
                            }
                            return Hj;
                          }
                        }
                        if ("integer" === V8["nodeName"]) return this['it'](!this['et'](V8), "Cannot parse \"\" as integer."), parseInt(V8["childNodes"][0x0]["nodeValue"], 0xa);
                        if ("real" === V8["nodeName"]) {
                          {
                            for (this['it'](!this['et'](V8), "Cannot parse \"\" as real."), Hj = '', Hj = 0x0; Hj < V8["childNodes"]["length"]; Hj++) 0x3 === V8["childNodes"][Hj]["nodeType"] && (Hj += V8["childNodes"][Hj]["nodeValue"]);
                            return parseFloat(Hj);
                          }
                        }
                        if ("date" === V8["nodeName"]) return this['it'](!this['et'](V8), "Cannot parse \"\" as Date."), new Date(V8["childNodes"][0x0]["nodeValue"]);
                        if ("true" === V8["nodeName"]) return !0x0;
                        if ("false" === V8["nodeName"]) return !0x1;
                      }
                    }
                  }
                }, Hf;
              }
            }(),
            UG = new Uq();
          function UF(Hf, V8, Hj) {
            return void 0x0 === V8 && (V8 = {
              'x': 0x0,
              'y': 0x0,
              'width': 0x0,
              'height': 0x0,
              'isRotate': !0x1
            }), new Promise(function (HL, Va) {
              var h = h;
              var h = h;
              {
                var HS = new plugin["Loader"]();
                HS["onLoad"] = function (Hj) {
                  var h = h;
                  var h = h;
                  var Hc = document["createElement"]("canvas"),
                    HA = Hc["getContext"]('2d');
                  if (null !== HA) {
                    {
                      var HX = new Image();
                      HX["onload"] = function () {
                        var h = h;
                        var h = h;
                        URL["revokeObjectURL"](HX["src"]);
                        var Hj = 0x0 === V8["width"] ? HX["width"] : V8["width"],
                          HT = 0x0 === V8["height"] ? HX["height"] : V8["height"];
                        Hc["width"] = Hj, Hc["height"] = HT, HA["clearRect"](0x0, 0x0, Hj, HT), HA["translate"](Hj / 0x2, HT / 0x2), V8["isRotate"] ? (HA["rotate"](0x10e * Math['PI'] / 0xb4), HA["drawImage"](HX, V8['x'], V8['y'], HT, Hj, -HT / 0x2, -Hj / 0x2, HT, Hj)) : HA["drawImage"](HX, V8['x'], V8['y'], Hj, HT, -Hj / 0x2, -HT / 0x2, Hj, HT);
                        var H1 = HA["getImageData"](0x0, 0x0, Hj, HT),
                          Hp = H1["data"];
                        if (Hj) for (var Hl = 0x0, Hg = Hp["length"]; Hl < Hg; Hl += 0x4) Hp[Hl] = Hj['r'], Hp[Hl + 0x1] = Hj['g'], Hp[Hl + 0x2] = Hj['b'];
                        HA["putImageData"](H1, 0x0, 0x0), HL(Hc["toDataURL"]());
                      }, HX["onerror"] = function () {
                        var h = h;
                        var h = h;
                        {
                          Va(Error("ImageBase64 load image failed"));
                        }
                      }, HX["src"] = URL["createObjectURL"](Hj["response"]);
                    }
                  }
                }, HS["onError"] = function (Hj) {
                  Va(Hj);
                }, HS["load"]([{
                  'src': Hf,
                  'type': plugin["LoadType"]["Blob"]
                }]);
              }
            });
          }
          function UY(Hf, V8) {
            var h = h;
            var h = h;
            {
              var Hj = [];
              Hf["forEach"](function (HL) {
                var h = h;
                var h = h;
                {
                  Hj["push"](UF(HL["resolvePath"], {
                    'x': 0x0,
                    'y': 0x0,
                    'width': 0x0,
                    'height': 0x0
                  }, HL["colour"]));
                }
              }), Promise["all"](Hj)["then"](function (HL) {
                var h = h;
                var h = h;
                {
                  var Va = [];
                  HL["forEach"](function (HS) {
                    var h = h;
                    Va["push"](HS);
                  }), V8 && V8(Va, void 0x0);
                }
              })["catch"](function (HL) {
                V8 && V8(void 0x0, HL);
              });
            }
          }
          var UQ = {};
          function UR(Hf, V8, Hj) {
            var h = h;
            var h = h;
            {
              var HL,
                Va = this,
                HS = Hf["src"],
                Hj = "unknown";
              Hj = -0x1 !== HS["indexOf"](".css") ? "css" : Hj, Hj = -0x1 !== (HL = HS)["indexOf"](".jpg") || -0x1 !== HL["indexOf"](".png") ? "image" : Hj;
              var Hc = shell["Error"],
                HA = shell["ClientError"],
                HX = Hc && new Hc(HA["Domain"], HA["GameLoadResourceError"]),
                Hj = V8["resource"]["resolveUrl"](HS);
              return new Promise(function (HT, H1) {
                var h = h;
                var h = h;
                {
                  return __awaiter(Va, void 0x0, void 0x0, function () {
                    var Hp;
                    return __generator(this, function (Hl) {
                      var h = h;
                      var h = h;
                      {
                        switch (Hl["label"]) {
                          case 0x0:
                            return Hl["trys"]["push"]([0x0, 0x9,, 0xa]), "image" !== Hj ? [0x3, 0x5] : Hf["tint"] ? [0x4, UN([{
                              'resolvePath': Hj,
                              'colour': Hf["tint"]
                            }])] : [0x3, 0x2];
                          case 0x1:
                            return Hp = Hl["sent"](), HT(Hp[0x0]), [0x3, 0x4];
                          case 0x2:
                            return [0x4, UK(Hj, Hj)];
                          case 0x3:
                            Hp = Hl["sent"](), HT(Hp), Hl["label"] = 0x4;
                          case 0x4:
                            return [0x3, 0x8];
                          case 0x5:
                            return "css" !== Hj ? [0x3, 0x7] : [0x4, Uf(Hj, V8, Hj)];
                          case 0x6:
                            return Hp = Hl["sent"](), HT(Hp), [0x3, 0x8];
                          case 0x7:
                            H1(HX), Hl["label"] = 0x8;
                          case 0x8:
                            return [0x3, 0xa];
                          case 0x9:
                            return Hl["sent"](), H1(HX), [0x3, 0xa];
                          case 0xa:
                            return [0x2];
                        }
                      }
                    });
                  });
                }
              });
            }
          }
          function UD(Hf, V8, Hj) {
            return __awaiter(this, void 0x0, void 0x0, function () {
              var h = h;
              var h = h;
              {
                var HL, Va;
                return __generator(this, function (HS) {
                  var h = h;
                  var h = h;
                  {
                    switch (HS["label"]) {
                      case 0x0:
                        return Hf["cssFile"]["endsWith"](".css") ? [0x4, UR({
                          'src': Hf["cssFile"]
                        }, V8, Hj)] : [0x3, 0x2];
                      case 0x1:
                        return HL = HS["sent"](), [0x3, 0x3];
                      case 0x2:
                        HL = Hf["cssFile"], HS["label"] = 0x3;
                      case 0x3:
                        return Hf["tint"] ? [0x4, UR({
                          'src': Hf["imageFile"],
                          'tint': Hf["tint"]
                        }, V8, Hj)] : [0x3, 0x6];
                      case 0x4:
                        return Va = HS["sent"](), [0x4, UJ(HL, V8, Va, !0x0, Hj)];
                      case 0x5:
                        return HL = HS["sent"](), [0x3, 0x8];
                      case 0x6:
                        return [0x4, UJ(HL, V8, Hf["imageFile"], !0x1, Hj)];
                      case 0x7:
                        HL = HS["sent"](), HS["label"] = 0x8;
                      case 0x8:
                        return Hf["appendHeader"] && Ub(HL, V8), [0x2, HL];
                    }
                  }
                });
              }
            });
          }
          function UJ(Hf, V8, Hj, HL, Va) {
            var h = h;
            var h = h;
            {
              return void 0x0 === HL && (HL = !0x1), new Promise(function (HS, Hj) {
                var h = h;
                var h = h;
                HL ? (Hf = Hf["replace"](/url\((.*?)\)/g, function () {
                  var h = h;
                  return "url(" + Hj + ')';
                }), HS(Hf)) : UI(V8["resource"]["resolveUrl"](Hj), Va)["then"](function (Hc) {
                  var h = h;
                  var h = h;
                  Hf = Hf["replace"](/url\((.*?)\)/g, function () {
                    var h = h;
                    var h = h;
                    {
                      return "url(" + URL["createObjectURL"](Hc) + ')';
                    }
                  }), HS(Hf);
                })["catch"](Hj);
              });
            }
          }
          function UI(Hf, V8) {
            var h = h;
            var h = h;
            {
              var Hj = this,
                HL = shell["Error"],
                Va = shell["ClientError"],
                HS = HL && new HL(Va["Domain"], Va["GameLoadResourceError"]);
              return new Promise(function (Hj, Hc) {
                var h = h;
                var h = h;
                {
                  return __awaiter(Hj, void 0x0, void 0x0, function () {
                    var h = h;
                    var h = h;
                    {
                      var HA;
                      return __generator(this, function (HX) {
                        var h = h;
                        var h = h;
                        {
                          switch (HX["label"]) {
                            case 0x0:
                              return HX["trys"]["push"]([0x0, 0x2,, 0x3]), [0x4, Ud(Hf, V8)];
                            case 0x1:
                              return HA = HX["sent"](), Hj(HA), [0x3, 0x3];
                            case 0x2:
                              return HX["sent"](), Hc(HS), [0x3, 0x3];
                            case 0x3:
                              return [0x2];
                          }
                        }
                      });
                    }
                  });
                }
              });
            }
          }
          function UB(Hf, V8) {
            var h = h;
            var h = h;
            return Hf["replace"](/url\((.*?)\)/g, function (Hj, HL) {
              var h = h;
              var h = h;
              {
                return "url(" + V8["resource"]["resolveUrl"](HL) + ')';
              }
            });
          }
          function UN(Hf) {
            var h = h;
            var h = h;
            {
              return new Promise(function (V8, Hj) {
                var h = h;
                var h = h;
                {
                  UY(Hf, function (HL, Va) {
                    var h = h;
                    var h = h;
                    if (Va || HL && 0x0 === HL["length"]) {
                      {
                        var HS = shell["Error"],
                          Hj = shell["ClientError"],
                          Hc = HS && new HS(Hj["Domain"], Hj["GameLoadResourceError"]);
                        Hj(Va || Hc);
                      }
                    }
                    V8(HL);
                  });
                }
              });
            }
          }
          function Ub(Hf, V8) {
            var h = h;
            var h = h;
            {
              var Hj = [],
                HL = V8["bundleInfo"]["name"];
              UQ[HL] || (UQ[HL] = []), Array["isArray"](Hf) || (Hf = [Hf]);
              var Va = UQ[HL]["length"] + 0x1;
              return Hf["forEach"](function (HS, Hj) {
                var h = h;
                var h = h;
                {
                  var Hc = Va + Hj,
                    HA = "$CSS-" + V8["bundleInfo"]["name"] + '-' + Hc;
                  Hj["push"](HA), function (HX, Hj, HT) {
                    var h = h;
                    var h = h;
                    if (-0x1 === UQ[Hj]["indexOf"](HX)) {
                      {
                        var H1 = document["createElement"]("style");
                        H1['id'] = HX, H1["innerHTML"] = HT, document["head"]["appendChild"](H1), UQ[Hj]["push"](HX);
                      }
                    }
                  }(HA, V8["bundleInfo"]["name"], HS);
                }
              }), Hj;
            }
          }
          function UK(Hf, V8) {
            var h = h;
            var h = h;
            var Hj = new plugin["Loader"]();
            return new Promise(function (HL, Va) {
              var h = h;
              var h = h;
              Hj["onLoad"] = function (HS) {
                var h = h;
                var h = h;
                HL(HS["response"]);
              }, Hj["onError"] = function (HS) {
                Va(HS);
              }, Hj["load"]([{
                'src': Hf,
                'type': plugin["LoadType"]["Image"],
                'maxAttemptCount': V8
              }]);
            });
          }
          function Uf(Hf, V8, Hj) {
            var h = h;
            var h = h;
            var HL = new plugin["Loader"]();
            return new Promise(function (Va, HS) {
              var h = h;
              var h = h;
              {
                HL["onLoad"] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    var Hc = UB(Hj["response"], V8);
                    Va(Hc);
                  }
                }, HL["onError"] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    HS(Hj);
                  }
                }, HL["load"]([{
                  'src': Hf,
                  'type': plugin["LoadType"]["Text"],
                  'maxAttemptCount': Hj
                }]);
              }
            });
          }
          function Ud(Hf, V8) {
            var h = h;
            var h = h;
            {
              var Hj = new plugin["Loader"]();
              return new Promise(function (HL, Va) {
                var h = h;
                var h = h;
                {
                  Hj["onLoad"] = function (HS) {
                    var h = h;
                    var h = h;
                    HL(HS["response"]);
                  }, Hj["onError"] = function (HS) {
                    var h = h;
                    var h = h;
                    {
                      Va(HS);
                    }
                  }, Hj["load"]([{
                    'src': Hf,
                    'type': plugin["LoadType"]["Blob"],
                    'maxAttemptCount': V8
                  }]);
                }
              });
            }
          }
          function Uj(Hf, V8) {
            var h = h;
            var h = h;
            {
              var Hj = UQ[V8]["indexOf"](Hf);
              if (-0x1 !== Hj) {
                {
                  var HL = document["getElementById"](Hf);
                  HL && HL["parentElement"] && HL["remove"](), UQ[V8]["splice"](Hj, 0x1);
                }
              }
            }
          }
          var UL = Object["freeze"]({
              '__proto__': null,
              'appendStyles': Ub,
              'getBase64AtlasData': function (Hf, V8) {
                var h = h;
                var h = h;
                var Hj = [];
                Hf["forEach"](function (HL, Va) {
                  var h = h;
                  var h = h;
                  {
                    UG["parsePlistData"](HL["plistPath"], function (HS) {
                      var h = h;
                      var h = h;
                      {
                        var Hj = HS[0x0]["frames"],
                          Hc = [];
                        HL["textureList"]["forEach"](function (HA) {
                          var h = h;
                          var h = h;
                          if (void 0x0 === Hj[HA]) throw Error("texture :" + HA + " not found in " + HL["plistPath"]);
                          var HX = Hj[HA]["textureRect"],
                            Hj = Hj[HA]["textureRotated"];
                          if (void 0x0 !== HX) {
                            var HT = HX["match"](/\d+/g);
                            if (HT) {
                              {
                                var H1 = HT["map"](Number);
                                Hc["push"]({
                                  'x': H1[0x0],
                                  'y': H1[0x1],
                                  'width': H1[0x2],
                                  'height': H1[0x3],
                                  'isRotate': Hj
                                });
                              }
                            }
                          }
                        }), Hc["forEach"](function (HA) {
                          var h = h;
                          var h = h;
                          Hj["push"](UF(HL["resolvePath"], HA, HL["colour"]));
                        }), Hf["length"] - 0x1 === Va && Promise["all"](Hj)["then"](function (HA) {
                          var h = h;
                          var h = h;
                          var HX = [];
                          HA["forEach"](function (Hj) {
                            var h = h;
                            var h = h;
                            {
                              HX["push"](Hj);
                            }
                          }), V8 && V8(HX, void 0x0);
                        })["catch"](function (HA) {
                          var h = h;
                          var h = h;
                          {
                            V8 && V8(void 0x0, HA);
                          }
                        });
                      }
                    });
                  }
                });
              },
              'getBase64ImageData': UY,
              'loadImageUrlAsBlob': UI,
              'loadLocale': function (Hf, V8) {
                var h = h;
                var h = h;
                {
                  return new Promise(function (Hj, HL) {
                    var h = h;
                    var h = h;
                    {
                      var Va = new plugin["Loader"]();
                      Va["onLoad"] = function (HS) {
                        var h = h;
                        var h = h;
                        var Hj = HS["response"];
                        for (var Hc in Hj) Hj[Hc] && shell["I18n"]["extend"](Hj[Hc], Hc);
                        Hj(Hj);
                      }, Va["onError"] = function () {
                        var h = h;
                        var h = h;
                        var HS = shell["Error"],
                          Hj = shell["ClientError"],
                          Hc = new HS(Hj["Domain"], Hj["GameLoadResourceError"]);
                        HL(Hc);
                      }, Va["load"]([{
                        'src': Hf,
                        'type': plugin["LoadType"]["Json"],
                        'maxAttemptCount': V8
                      }]);
                    }
                  });
                }
              },
              'loadResource': UR,
              'loadSpriteSheet': UD,
              'removeStyles': function (Hf, V8) {
                var h = h;
                var h = h;
                Array["isArray"](Hf) || (Hf = [Hf]), Hf["forEach"](function (Hj) {
                  var h = h;
                  var h = h;
                  Uj(Hj, V8["bundleInfo"]["name"]);
                });
              },
              'resolveCSS': UB,
              'resolveCSSWithImage': function (Hf, V8, Hj) {
                var h = h;
                var h = h;
                {
                  var HL = Hj ? Hj["resource"]["resolveUrl"](V8) : V8;
                  return Hf["replace"](/url\((.*?)\)/g, function () {
                    var h = h;
                    var h = h;
                    {
                      return "url(" + HL + ')';
                    }
                  });
                }
              },
              'tintImage': UN,
              'unloadAllBundleStyles': function (Hf) {
                var h = h;
                var h = h;
                {
                  var V8 = Hf["bundleInfo"]["name"];
                  UQ[V8] && (UQ[V8]["map"](function (Hj) {
                    var h = h;
                    var h = h;
                    {
                      return Hj;
                    }
                  })["forEach"](function (Hj) {
                    var h = h;
                    var h = h;
                    {
                      Uj(Hj, V8);
                    }
                  }), UQ[V8]["length"] = 0x0);
                }
              }
            }),
            Um = ty(UL);
          Object["defineProperty"](UM, "__esModule", {
            'value': !0x0
          }), UM["Img"] = void 0x0;
          var US = __importDefault(z),
            Um = Um,
            Uc = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABAQMAAAAl21bKAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAApJREFUCNdjYAAAAAIAAeIhvDMAAAAASUVORK5CYII=",
            UA = function (Hf) {
              var h = h;
              var h = h;
              {
                function V8(Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hf["call"](this, Hj) || this;
                    return HL['ot'] = !0x0, HL["state"] = {
                      'url': Uc,
                      'status': "loading"
                    }, HL;
                  }
                }
                return __extends(V8, Hf), V8["prototype"]['lt'] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj,
                      HL = this;
                    (Hj = this["props"]["src"], new Promise(function (Va, HS) {
                      var h = h;
                      var h = h;
                      {
                        Hj || HS("Empty url or undefined url passed in");
                        var Hj = Hj;
                        Um["loadImageUrlAsBlob"](Hj)["then"](function (Hc) {
                          var h = h;
                          var h = h;
                          Hj = URL["createObjectURL"](Hc), Va(Hj);
                        })["catch"](function (Hc) {
                          var h = h;
                          var h = h;
                          {
                            HS(Hc);
                          }
                        });
                      }
                    }))["then"](function (Va) {
                      var h = h;
                      var h = h;
                      HL['ot'] && HL["setState"]({
                        'url': Va,
                        'status': "loaded"
                      });
                    })["catch"](function (Va) {
                      var h = h;
                      var h = h;
                      HL['ot'] && (HL["setState"]({
                        'url': Uc,
                        'status': "url failed"
                      }), HL["props"]["onError"] && HL["props"]["onError"](Va, HL["state"]["status"]));
                    });
                  }
                }, V8["prototype"]["componentDidUpdate"] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    this["props"]["src"] !== Hj["src"] && this['lt']();
                  }
                }, V8["prototype"]["componentDidMount"] = function () {
                  this['lt']();
                }, V8["prototype"]["componentWillUnmount"] = function () {
                  var h = h;
                  var h = h;
                  {
                    this['ot'] = !0x1;
                  }
                }, V8["prototype"]['st'] = function (Hj) {
                  var h = h;
                  var h = h;
                  "loaded" === this["state"]["status"] && URL["revokeObjectURL"](this["state"]["url"]), this["props"]["onLoad"] && this["props"]["onLoad"](Hj, "loaded");
                }, V8["prototype"]['ut'] = function (Hj) {
                  var h = h;
                  var h = h;
                  this["props"]["onClick"] && this["props"]["onClick"](Hj);
                }, V8["prototype"]['ht'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    this["props"]["onError"] && this["props"]["onError"](Hj, "image failed");
                  }
                }, V8["prototype"]["render"] = function () {
                  var h = h;
                  var h = h;
                  var Hj = this["props"],
                    HL = Hj["forwardedRef"],
                    Va = Hj["alt"],
                    HS = __rest(Hj, ["forwardedRef", "alt"]);
                  return US["default"]["createElement"]("img", __assign({}, HS, {
                    'src': this["state"]["url"],
                    'alt': Va || "image",
                    'onLoad': this['st']["bind"](this),
                    'onError': this['ht']["bind"](this),
                    'onClick': this['ut']["bind"](this),
                    'ref': HL
                  }));
                }, V8;
              }
            }(US["default"]["Component"]);
          function UX(Hf) {
            var h = h;
            var h = h;
            {
              return "land" === shell["environment"]["getOrientationMode"]() ? 0.75 * Hf : Hf;
            }
          }
          function Uk(Hf) {
            var h = h;
            var h = h;
            {
              return "land" === shell["environment"]["getOrientationMode"]() ? 0.3 * Hf : Hf;
            }
          }
          UM["Img"] = US["default"]["forwardRef"](function (Hf, V8) {
            var h = h;
            var h = h;
            return US["default"]["createElement"](UA, __assign({}, Hf, {
              'forwardedRef': V8
            }));
          }), function (Hf) {
            var h = h;
            var h = h;
            {
              Object["defineProperty"](Hf, "__esModule", {
                'value': !0x0
              }), Hf["Img"] = void 0x0;
              var V8 = UM;
              Object["defineProperty"](Hf, "Img", {
                'enumerable': !0x0,
                'get': function () {
                  var h = h;
                  var h = h;
                  {
                    return V8["Img"];
                  }
                }
              });
            }
          }(UE);
          var UT = y["div"](h5 || (h5 = V5(["\n    text-align: center;\n    margin: auto 20px;\n    line-height: ", ';\x0a'], ["\n    text-align: center;\n    margin: auto 20px;\n    line-height: ", ';\x0a'])), UX(1.15)),
            UO = y["div"](h6 || (h6 = V5(["\n    word-wrap: break-word;\n    transform: scale(", ");\n    transform-origin: left;\n    width: ", "%;\n"], ["\n    word-wrap: break-word;\n    transform: scale(", ");\n    transform-origin: left;\n    width: ", "%;\n"])), UX(0x1), (0x64, "land" === shell["environment"]["getOrientationMode"]() ? 0x64 / 0.75 : 0x64)),
            Up = y(UO)(h7 || (h7 = V5(["\n    font-size: 12px;\n"], ["\n    font-size: 12px;\n"]))),
            Ul = y(UO)(h8 || (h8 = V5(["\n    padding-top: ", "px;\n    font-size: 11px;\n    opacity: 0.5;\n"], ["\n    padding-top: ", "px;\n    font-size: 11px;\n    opacity: 0.5;\n"])), UX(0x6)),
            Ug = y["div"](h9 || (h9 = V5(["\n    color: ", ';\x0a'], ["\n    color: ", ';\x0a'])), function (Hf) {
              var h = h;
              var h = h;
              return Hf["themeColor"] || "rgb(255,255,255,1)";
            }),
            UP = y(UO)(hV || (hV = V5(["\n    margin-top: ", "px;\n    margin-bottom: ", "px;\n    font-size: 12px;\n"], ["\n    margin-top: ", "px;\n    margin-bottom: ", "px;\n    font-size: 12px;\n"])), Uk(0x30), Uk(0x21)),
            h0 = y["div"](ha || (ha = V5(["\n    margin-top: ", "px;\n    margin-bottom: ", "px;\n    font-size: 11px;\n"], ["\n    margin-top: ", "px;\n    margin-bottom: ", "px;\n    font-size: 11px;\n"])), Uk(0x30), Uk(0x21)),
            h1 = y(UO)(hU || (hU = V5(["\n    margin-top: ", "px;\n    margin-bottom: ", "px;\n    font-size: 12px;\n"], ["\n    margin-top: ", "px;\n    margin-bottom: ", "px;\n    font-size: 12px;\n"])), UX(0xf), UX(0x21)),
            h2 = y["div"](hh || (hh = V5(["\n    margin-top: ", "px;\n    margin-bottom: ", "px;\n    font-size: 11px;\n"], ["\n    margin-top: ", "px;\n    margin-bottom: ", "px;\n    font-size: 11px;\n"])), UX(0xf), UX(0x21)),
            h3 = y["div"](hH || (hH = V5(["\n    margin-top: ", "px;\n"], ["\n    margin-top: ", "px;\n"])), UX(0xa));
          function h4() {
            var h = h;
            var h = h;
            {
              return {
                'margin': ''["concat"](UX(0xd), "px auto"),
                'width': ''["concat"](UX(0x64), 'px'),
                'height': ''["concat"](UX(0x64), 'px')
              };
            }
          }
          var h5,
            h6,
            h7,
            h8,
            h9,
            hV,
            ha,
            hU,
            hh,
            hH,
            hs,
            ho,
            hw,
            hu,
            hz,
            hx,
            hC,
            hW,
            hv,
            hy = y["div"](hs || (hs = V5(["\n    margin: ", "px auto;\n    transform: scale(", ");\n    height: ", "px;\n    display: inline-block;\n"], ["\n    margin: ", "px auto;\n    transform: scale(", ");\n    height: ", "px;\n    display: inline-block;\n"])), UX(0xd), UX(0x1), UX(0x64)),
            hE = y["div"](ho || (ho = V5(["\n    margin: ", "px auto;\n    width: ", "px;\n    height: ", "px;\n"], ["\n    margin: ", "px auto;\n    width: ", "px;\n    height: ", "px;\n"])), UX(0xd), UX(0x64), UX(0x64)),
            hM = y(UO)(hw || (hw = V5(["\n    padding: ", "px 0px;\n"], ["\n    padding: ", "px 0px;\n"])), UX(0x2)),
            hq = y["section"](hu || (hu = V5(["\n    width: ", "px;\n    margin: auto;\n"], ["\n    width: ", "px;\n    margin: auto;\n"])), UX(0x118)),
            hG = y["button"](hz || (hz = V5(["\n    width: 85%;\n    margin: ", "px auto;\n    border: none;\n    background-color: ", ";\n    color: white;\n    font-size: 14px;\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n"], ["\n    width: 85%;\n    margin: ", "px auto;\n    border: none;\n    background-color: ", ";\n    color: white;\n    font-size: 14px;\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n"])), UX(0x5), function (Hf) {
              var h = h;
              var h = h;
              {
                return Hf["themeColor"] || "rgb(255,255,255,1)";
              }
            }, UX(0x8)),
            hF = y["button"](hx || (hx = V5(["\n    width: 85%;\n    margin: ", "px auto;\n    border: 1px solid rgba(0,0,0,0.3);\n    background-color: rgba(48,48,60,1);\n    color: ", ";\n    font-size: 14px;\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n"], ["\n    width: 85%;\n    margin: ", "px auto;\n    border: 1px solid rgba(0,0,0,0.3);\n    background-color: rgba(48,48,60,1);\n    color: ", ";\n    font-size: 14px;\n    padding: ", "px 0px;\n    border-radius: 2px;\n    text-align: center;\n    cursor: pointer;\n    font-family: inherit;\n"])), UX(0x5), function (Hf) {
              var h = h;
              var h = h;
              {
                return Hf["themeColor"] || "rgb(255,255,255,1)";
              }
            }, UX(0x8)),
            hY = V7["formatCurrency"],
            hQ = shell["I18n"],
            hR = function (Hf) {
              var h = h;
              var h = h;
              {
                function V8(Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hf["call"](this, Hj) || this;
                    return HL['ft'] = function () {
                      var h = h;
                      var h = h;
                      {
                        document["getElementById"]("morePromotionBtn")["blur"](), Hj["onMorePromotionClick"]();
                      }
                    }, HL['gt'] = function () {
                      var h = h;
                      var h = h;
                      document["getElementById"]("laterBtn")["blur"](), Hj["onLaterClick"]();
                    }, HL;
                  }
                }
                return V0(V8, Hf), V8["prototype"]["shouldComponentUpdate"] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    return this["props"]["show"] === Hj["show"];
                  }
                }, V8["prototype"]["render"] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this["props"]["data"],
                      HL = Hj["status"],
                      Va = Hj["bonusWalletName"],
                      HS = Hj["bonusID"],
                      Hj = Hj["expiredDate"],
                      Hc = Hj["expiredTime"],
                      HA = VR["gameIconUrl"],
                      HX = VR["gameThemeColor"],
                      Hj = this['Z'](Hj);
                    return VR["status"] = HL, z["createElement"](UT, null, z["createElement"]("section", null, z["createElement"](Up, null, Va), z["createElement"](Ul, null, hQ['t']("BonusWallet.Offer", {
                      'id': HS["toString"]()
                    }))), HA ? z["createElement"](UE["Img"], {
                      'src': HA,
                      'alt': "game icon",
                      'style': h4()
                    }) : z["createElement"](hy, null, z["createElement"]("span", {
                      'className': "wallet-plugin-sprite wallet-plugin-default_icon"
                    })), z["createElement"](Ug, {
                      'themeColor': HX
                    }, Hj["title"]), z["createElement"](UP, null, Hj["desc"]), z["createElement"]("div", null, Hj["amt"]), z["createElement"](h0, null, Hj["bonusRatioContent"], Hj["rollOverModeContent"], Hj["maxConversionRateContent"], z["createElement"](hM, null, '\x20', ''["concat"](hQ['t']("BonusWallet.Expiry"), '\x20')["concat"](Hj, '\x20')["concat"](Hc))), z["createElement"](hq, null, Hj["continueBtnContent"], Hj["morePromotionBtnContent"], z["createElement"](hF, {
                      'id': "laterBtn",
                      'onClick': this['gt'],
                      'themeColor': HX
                    }, z["createElement"](UO, null, Hj["btmBtn"]))));
                  }
                }, V8["prototype"]['Z'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hj["status"],
                      Va = Hj["balanceAmount"],
                      HS = Hj["key"],
                      Hj = Hj["keySelection"],
                      Hc = Hj["rollOverMode"],
                      HA = Hj["bonusRatioAmount"],
                      HX = Hj["maximumConversionAmount"];
                    if (0x2 === HL) return {
                      'title': hQ['t']("BonusWallet.BonusWalletExpiredTitle"),
                      'desc': hQ['t']("BonusWallet.BonusWalletExpiredNoPrize"),
                      'amt': '',
                      'bonusRatioContent': null,
                      'rollOverModeContent': null,
                      'maxConversionRateContent': null,
                      'continueBtnContent': null,
                      'morePromotionBtnContent': z["createElement"](hG, {
                        'id': "morePromotionBtn",
                        'onClick': this['ft'],
                        'themeColor': VR["gameThemeColor"]
                      }, z["createElement"](UO, null, hQ['t']("BonusWallet.MoreOffers"))),
                      'btmBtn': hQ['t']("BonusWallet.BackToGame")
                    };
                    var Hj = hY(HA),
                      HT = hY(HX),
                      H1 = hY(Va),
                      Hp = 0x1 === Hc || Hj && HS === Hj[0x1] ? hQ['t']("BonusWallet.Cash") : hQ['t']("BonusWallet.Bonus");
                    return {
                      'title': hQ['t']("BonusWallet.BonusWalletContinueTitle"),
                      'desc': hQ['t']("BonusWallet.BonusWalletContinueDesc"),
                      'amt': H1,
                      'bonusRatioContent': z["createElement"](hM, null, ''["concat"](hQ['t']("BonusWallet.BonusRatioLabelFull"), ':\x20')["concat"](Hj)),
                      'rollOverModeContent': z["createElement"](hM, null, ''["concat"](hQ['t']("BonusWallet.RollOverMode"), ':\x20')["concat"](Hp)),
                      'maxConversionRateContent': HX > 0x0 ? z["createElement"](hM, null, hQ['t']("BonusWallet.MaximumConversionRate", {
                        'rate': HT
                      })) : '',
                      'continueBtnContent': z["createElement"](hG, {
                        'onClick': this["props"]["onContinueClick"],
                        'themeColor': VR["gameThemeColor"]
                      }, z["createElement"](UO, null, hQ['t']("BonusWallet.ContinueGame"))),
                      'morePromotionBtnContent': z["createElement"](hF, {
                        'id': "morePromotionBtn",
                        'onClick': this['ft'],
                        'themeColor': VR["gameThemeColor"]
                      }, z["createElement"](UO, null, hQ['t']("BonusWallet.MoreOffers"))),
                      'btmBtn': hQ['t']("BonusWallet.NextTime")
                    };
                  }
                }, V8;
              }
            }(z["Component"]),
            hD = V7["formatCurrency"],
            hJ = shell["I18n"],
            hI = function (Hf) {
              var h = h;
              var h = h;
              {
                function V8(Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hf["call"](this, Hj) || this;
                    return HL['ft'] = function () {
                      var h = h;
                      var h = h;
                      {
                        var Va = document["getElementById"]("morePromotionBtn");
                        Va || (Va = document["getElementById"]("topBtn")), Va["blur"](), Hj["onMorePromotionClick"]();
                      }
                    }, HL['gt'] = function () {
                      var h = h;
                      var h = h;
                      {
                        document["getElementById"]("laterBtn")["blur"](), Hj["onLaterClick"]();
                      }
                    }, HL;
                  }
                }
                return V0(V8, Hf), V8["prototype"]["shouldComponentUpdate"] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    return this["props"]["show"] === Hj["show"];
                  }
                }, V8["prototype"]["render"] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this["props"]["data"],
                      HL = Hj["freeGameName"],
                      Va = Hj["freeGameID"],
                      HS = Hj["status"],
                      Hj = VR["gameIconUrl"],
                      Hc = VR["gameThemeColor"],
                      HA = this['Z'](Hj);
                    return VR["status"] = HS, z["createElement"](UT, null, z["createElement"]("section", null, z["createElement"](Up, null, HL), z["createElement"](Ul, null, hJ['t']("FreeGame.Offer", {
                      'id': Va["toString"]()
                    }))), Hj ? z["createElement"](UE["Img"], {
                      'src': Hj,
                      'alt': "game icon",
                      'style': h4()
                    }) : z["createElement"](hE, {
                      'className': "wallet-plugin-sprite wallet-plugin-default_icon"
                    }), z["createElement"](Ug, {
                      'themeColor': Hc
                    }, HA["title"]), z["createElement"](h1, null, HA["desc"]), z["createElement"](h3, null, HA["amt"]), z["createElement"](h2, null, z["createElement"](hM, null, HA["withdrawalLimit"]), z["createElement"](hM, null, HA["expiryDate"])), z["createElement"](hq, null, z["createElement"](hG, {
                      'id': "topBtn",
                      'onClick': HA["topBtnClickEvent"],
                      'themeColor': Hc
                    }, z["createElement"](UO, null, HA["topBtn"])), HA["midBtn"]["length"] > 0x0 && z["createElement"](hF, {
                      'id': "morePromotionBtn",
                      'onClick': this['ft'],
                      'themeColor': Hc
                    }, z["createElement"](UO, null, HA["midBtn"])), z["createElement"](hF, {
                      'id': "laterBtn",
                      'onClick': this['gt'],
                      'themeColor': Hc
                    }, z["createElement"](UO, null, HA["btmBtn"]))));
                  }
                }, V8["prototype"]['Z'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hj["status"],
                      Va = Hj["conversionAmount"],
                      HS = Hj["maximumConversionAmount"],
                      Hj = Hj["gameCount"],
                      Hc = Hj["balanceAmount"],
                      HA = Hj["expiredDate"],
                      HX = Hj["expiredTime"],
                      Hj = Hj["conversionType"],
                      HT = hD(Hc),
                      H1 = hD(Va),
                      Hp = hD(HS);
                    switch (HL) {
                      case 0x3:
                      case 0x4:
                        if (Va > 0x0) {
                          var Hl = Hj === VF;
                          return {
                            'title': hJ['t']("FreeGame.Congratulations"),
                            'desc': hJ['t']("FreeGame.FreeGameCompletedWin"),
                            'amt': H1,
                            'withdrawalLimit': HS > 0x0 ? hJ['t']("FreeGame.MaximumConversionRate", {
                              'rate': Hp
                            }) : '',
                            'expiryDate': Hl ? hJ['t']("FreeGame.ConvertToBonusWallet") : hJ['t']("FreeGame.ConvertToCashWallet"),
                            'topBtn': Hl ? hJ['t']("FreeGame.UseBonusWallet") : hJ['t']("FreeGame.MoreOffers"),
                            'midBtn': Hl ? hJ['t']("FreeGame.MoreOffers") : '',
                            'btmBtn': hJ['t']("FreeGame.BackToGame"),
                            'topBtnClickEvent': Hl ? this["props"]["onSwitchBonusWalletClick"] : this['ft']
                          };
                        }
                        return {
                          'title': hJ['t']("FreeGame.FreeGameCompletedNoWin"),
                          'desc': '',
                          'amt': '',
                          'withdrawalLimit': '',
                          'expiryDate': '',
                          'topBtn': hJ['t']("FreeGame.MoreOffers"),
                          'midBtn': '',
                          'btmBtn': hJ['t']("FreeGame.BackToGame"),
                          'topBtnClickEvent': this['ft']
                        };
                      case 0x2:
                        return {
                          'title': hJ['t']("FreeGame.FreeGameExpired"),
                          'desc': hJ['t']("FreeGame.FreeGameExpiredNoPrize"),
                          'amt': '',
                          'withdrawalLimit': '',
                          'expiryDate': ''["concat"](hJ['t']("FreeGame.ExpiryDate"), ':\x20')["concat"](HA, '\x20')["concat"](HX),
                          'topBtn': hJ['t']("FreeGame.MoreOffers"),
                          'midBtn': '',
                          'btmBtn': hJ['t']("FreeGame.BackToGame"),
                          'topBtnClickEvent': this['ft']
                        };
                      default:
                        return {
                          'title': hJ['t']("FreeGame.FreeGameViewRemaining", {
                            'games': Hj["toString"]()
                          }),
                          'desc': hJ['t']("FreeGame.FreeGameViewAccumulated"),
                          'amt': HT,
                          'withdrawalLimit': HS > 0x0 ? hJ['t']("FreeGame.MaximumConversionRate", {
                            'rate': Hp
                          }) : '',
                          'expiryDate': ''["concat"](hJ['t']("FreeGame.ExpiryDate"), ':\x20')["concat"](HA, '\x20')["concat"](HX),
                          'topBtn': hJ['t']("FreeGame.ContinueGame"),
                          'midBtn': hJ['t']("FreeGame.MoreOffers"),
                          'btmBtn': hJ['t']("FreeGame.NextTime"),
                          'topBtnClickEvent': this["props"]["onContinueClick"]
                        };
                    }
                  }
                }, V8;
              }
            }(z["Component"]),
            hB = shell["I18n"],
            hN = function (Hf) {
              var h = h;
              var h = h;
              {
                function V8(Hj) {
                  var h = h;
                  var HL = Hf["call"](this, Hj) || this;
                  return HL['gt'] = function () {
                    var h = h;
                    var h = h;
                    {
                      document["getElementById"]("btn")["blur"](), Hj["onLaterClick"]();
                    }
                  }, HL;
                }
                return V0(V8, Hf), V8["prototype"]["shouldComponentUpdate"] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    return this["props"]["show"] === Hj["show"];
                  }
                }, V8["prototype"]["render"] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this["props"]["data"],
                      HL = Hj["freeGameName"],
                      Va = Hj["freeGameID"],
                      HS = VR["gameIconUrl"],
                      Hj = VR["gameThemeColor"],
                      Hc = this['Z'](Hj);
                    return z["createElement"](UT, null, z["createElement"]("section", null, z["createElement"](Up, null, HL), z["createElement"](Ul, null, hB['t']("FreeGame.Offer", {
                      'id': Va["toString"]()
                    }))), HS ? z["createElement"](UE["Img"], {
                      'src': HS,
                      'alt': "game icon",
                      'style': h4()
                    }) : z["createElement"](hE, {
                      'className': "wallet-plugin-sprite wallet-plugin-default_icon"
                    }), z["createElement"](Ug, {
                      'themeColor': Hj
                    }, Hc["title"]), z["createElement"](h0, null, z["createElement"](hM, null, Hc["expiryDate"])), z["createElement"](hq, null, z["createElement"](hG, {
                      'id': "btn",
                      'onClick': Hc["btnClickEvent"],
                      'themeColor': Hj
                    }, z["createElement"](UO, null, Hc["btn"]))));
                  }
                }, V8["prototype"]['Z'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hj["status"],
                      Va = Hj["gameCount"],
                      HS = Hj["expiredDate"],
                      Hj = Hj["expiredTime"];
                    return 0x4 === HL ? {
                      'title': hB['t']("FreeGame.FreeGameCompletedNoWin"),
                      'expiryDate': '',
                      'btn': hB['t']("FreeGame.BackToGame"),
                      'btnClickEvent': this['gt']
                    } : {
                      'title': hB['t']("FreeGame.FreeGameViewRemaining", {
                        'games': Va["toString"]()
                      }),
                      'expiryDate': ''["concat"](hB['t']("FreeGame.ExpiryDate"), ':\x20')["concat"](HS, '\x20')["concat"](Hj),
                      'btn': hB['t']("FreeGame.ContinueGame"),
                      'btnClickEvent': this["props"]["onContinueClick"]
                    };
                  }
                }, V8;
              }
            }(z["Component"]),
            hb = y["div"](hC || (hC = V5(["\n    position: absolute;\n    height: 52%;\n    width: 100%;\n"], ["\n    position: absolute;\n    height: 52%;\n    width: 100%;\n"]))),
            hK = y(hb)(hW || (hW = V5(["\n    height: 100%;\n    width: 58%;\n    left: 42%;\n"], ["\n    height: 100%;\n    width: 58%;\n    left: 42%;\n"]))),
            hf = function (Hf) {
              var h = h;
              var h = h;
              {
                function V8() {
                  var h = h;
                  var h = h;
                  {
                    return null !== Hf && Hf["apply"](this, arguments) || this;
                  }
                }
                return V0(V8, Hf), V8["prototype"]["shouldComponentUpdate"] = function (Hj) {
                  var h = h;
                  var h = h;
                  return this["props"]["viewType"] !== Hj["viewType"];
                }, V8["prototype"]["render"] = function () {
                  var h = h;
                  var h = h;
                  {
                    return "land" === shell["environment"]["getOrientationMode"]() ? z["createElement"](hK, {
                      'onClick': this["props"]["onClick"]
                    }) : 0x1 === this["props"]["viewType"] ? z["createElement"](hb, {
                      'onClick': this["props"]["onClick"]
                    }) : null;
                  }
                }, V8;
              }
            }(z["Component"]);
          !function (Hf) {
            var h = h;
            var h = h;
            {
              Hf[Hf["ANIM"] = 0x0] = "ANIM", Hf[Hf["NO_ANIM"] = 0x1] = "NO_ANIM";
            }
          }(hv || (hv = {}));
          var hd = w("WalletEventEnum", {
            'EN_WALLET_LIST_ANIM': hv["ANIM"],
            'EN_WALLET_LIST_NO_ANIM': hv["NO_ANIM"]
          });
          function hj(Hf, V8) {
            var h = h;
            var h = h;
            {
              void 0x0 === V8 && (V8 = 0x0), Vq["context"]["event"]["emit"]("Toast.Show", {
                'toastStyle': "Message",
                'message': Hf,
                'duration': V8,
                'imageSrc': '',
                'toastPosition': "Bottom"
              });
            }
          }
          function hL(Hf) {
            var h = h;
            var h = h;
            {
              var V8 = [];
              Vq["context"]["event"]["emit"]("Alert.Show", function (Hj, HL) {
                var h = h;
                var h = h;
                {
                  var Va = [],
                    HS = 0x0;
                  return Hj["actions"] && Hj["actions"]["forEach"](function (Hj) {
                    var h = h;
                    var h = h;
                    {
                      Va["push"]({
                        'label': Hj["title"],
                        'handler': HS
                      }), HL["push"](Hj["handler"]), HS++;
                    }
                  }), {
                    'title': Hj["title_message"],
                    'content': Hj["content_message"],
                    'actions': Va
                  };
                }
              }(Hf, V8), function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = Hj["response"],
                    Va = V8[HL];
                  Va && Va();
                }
              });
            }
          }
          function hm(Hf) {
            var h = h;
            var h = h;
            return "land" === shell["environment"]["getOrientationMode"]() ? 0.75 * Hf : Hf;
          }
          function hS(Hf) {
            var h = h;
            var h = h;
            return "land" === Hf["orientation"];
          }
          function hZ(Hf) {
            var h = h;
            var V8 = Hf["view"],
              Hj = parseInt(V8, 0x0);
            return 0x3 === Hj || 0x5 === Hj;
          }
          var hc,
            hA,
            hX = y(E["div"])(hc || (hc = V5(["\n    color: white;\n    background-color: rgba(40,40,50,1);\n    position: relative;\n    border-radius: ", ";\n    height: ", ";\n    width: ", ";\n    font-size: ", "px;\n"], ["\n    color: white;\n    background-color: rgba(40,40,50,1);\n    position: relative;\n    border-radius: ", ";\n    height: ", ";\n    width: ", ";\n    font-size: ", "px;\n"])), function (Hf) {
              var h = h;
              var h = h;
              {
                return hS(Hf) ? "inherit" : "8px 8px 0px 0px";
              }
            }, function (Hf) {
              var h = h;
              var h = h;
              return hS(Hf) ? "100%" : "48%";
            }, function (Hf) {
              var h = h;
              var h = h;
              {
                return hS(Hf) ? "42%" : "100%";
              }
            }, hm(0x10)),
            hk = y(E["div"])(hA || (hA = V5(["\n    height: 100%;\n    position: relative;\n    color: white;\n    background-color: ", ";\n    display: flex;\n    flex-direction: column;\n    width: ", ";\n    margin: ", ";\n    font-size: ", "px;\n    top: ", ";\n    right: ", ';\x0a'], ["\n    height: 100%;\n    position: relative;\n    color: white;\n    background-color: ", ";\n    display: flex;\n    flex-direction: column;\n    width: ", ";\n    margin: ", ";\n    font-size: ", "px;\n    top: ", ";\n    right: ", ';\x0a'])), function (Hf) {
              var h = h;
              var h = h;
              {
                return hS(Hf) && hZ(Hf) ? "inherit" : "rgba(40,40,52,1)";
              }
            }, function (Hf) {
              var h = h;
              var h = h;
              {
                return hS(Hf) && !hZ(Hf) ? "42%" : "100%";
              }
            }, function (Hf) {
              var h = h;
              var h = h;
              {
                return hS(Hf) ? "inherit" : "0px auto";
              }
            }, hm(0x10), function (Hf) {
              var h = h;
              var h = h;
              return hS(Hf) ? "inherit" : '0%';
            }, function (Hf) {
              var h = h;
              var h = h;
              {
                return hS(Hf) && !hZ(Hf) ? "50%" : "inherit";
              }
            });
          function hT(Hf, V8) {
            var h = h;
            var h = h;
            var Hj, HL;
            if ("land" === shell["environment"]["getOrientationMode"]()) {
              {
                var Va = 0x3 === Hf || 0x5 === Hf;
                Hj = Va ? {
                  'backgroundColor': V8 ? "rgba(40,40,52,0)" : "rgba(40,40,52,0.75)",
                  'opacity': 0x1
                } : {
                  'right': V8 ? "50%" : '0%'
                }, HL = Va ? {
                  'backgroundColor': "rgba(40,40,52,0.75)",
                  'opacity': V8 ? 0x1 : 0x0
                } : {
                  'right': V8 ? '0%' : "50%"
                };
              }
            } else Hj = {
              'top': V8 ? "100%" : '0%'
            }, HL = {
              'top': V8 ? '0%' : "100%"
            };
            var HS = Object["create"](null);
            return HS["animFrom"] = Hj, HS["animTo"] = HL, HS;
          }
          var hO,
            hp = V7["sequenceCallback"],
            hl = V7["timeoutCallback"],
            hg = shell["I18n"],
            hP = shell['ga'],
            H0 = shell["environment"],
            H1 = "0_C",
            H2 = y["div"](hO || (hO = V5(["\n    width: 100%;\n    height: 100%;\n"], ["\n    width: 100%;\n    height: 100%;\n"]))),
            H3 = function (Hf) {
              var h = h;
              var h = h;
              {
                function V8(Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = Hf["call"](this, Hj) || this;
                    return HL['vt'] = function (Va, HS) {
                      var h = h;
                      var h = h;
                      {
                        !Va && HS && 'C' === VR["transactionInfo"]['wt'] && Vq["context"]["event"]["emit"]("Game.UpdateTransactionInfo", {
                          'balance': HS['dt']['cb']
                        }), HL['xt'](0x1, Va, HS);
                      }
                    }, HL['Ct'] = HL['xt']["bind"](HL, 0x2), HL['yt'] = HL['xt']["bind"](HL, 0x4), HL['kt'] = HL['Bt']["bind"](HL), HL['Wt'] = HL['St']["bind"](HL), HL["state"] = {
                      'viewType': Hj["initViewType"],
                      'error': void 0x0,
                      'data': void 0x0,
                      'show': !0x0
                    }, HL['Gt'] = document["getElementById"]("wallet-container"), HL['Ot'] = HL["state"]["viewType"], HL;
                  }
                }
                return V0(V8, Hf), V8["prototype"]["componentDidMount"] = function () {
                  var h = h;
                  var h = h;
                  var Hj = this;
                  switch (this["props"]["initViewType"]) {
                    case 0x1:
                      var HL = Vq["context"]["event"],
                        Va = this['Gt']["style"],
                        HS = parseFloat(Va["height"]),
                        Hj = {
                          'label': hg['t']("General.ResourceLoadingMessage"),
                          'height': 0xc8,
                          'y': 0.78 * HS
                        };
                      if (this["props"]["walletListAnimState"] === hd["EN_WALLET_LIST_ANIM"]) {
                        {
                          var Hc = {
                            'inAnimate': "Slide",
                            'inDuration': 0.3,
                            'inValue': {
                              'y': 1.78 * HS
                            },
                            'inEasing': "easeOutCubic"
                          };
                          Hj = V1(V1({}, Hj), Hc);
                        }
                      }
                      if ("land" === H0["getOrientationMode"]()) {
                        var HA = parseFloat(Va["width"]),
                          HX = {
                            'width': 0.42 * HA,
                            'x': 0.21 * HA,
                            'y': 0.557 * HS,
                            'inAnimate': "Slide",
                            'inDuration': 0.3,
                            'inValue': {
                              'x': -1.21 * HA
                            },
                            'inEasing': "easeOutCubic"
                          };
                        Hj = V1(V1({}, Hj), HX);
                      }
                      HL["emit"]("Loading.Show", Hj), hl(0.3)(function () {
                        Hj['Ft'](Hj['vt']);
                      });
                      break;
                    case 0x2:
                      this['Tt'](0x1, this['Ct']);
                      break;
                    case 0x4:
                      this['Nt'](0x1, this['yt']);
                  }
                }, V8["prototype"]["componentDidUpdate"] = function () {
                  var h = h;
                  var h = h;
                  {
                    this['Ot'] = this["state"]["viewType"], this['_t'] && this['_t'](), this['_t'] = void 0x0;
                  }
                }, V8["prototype"]["render"] = function () {
                  var h = h;
                  var h = h;
                  {
                    switch (this["state"]["viewType"]) {
                      case 0x1:
                        return this['zt']();
                      case 0x2:
                        return this['At']();
                      case 0x3:
                        return this['Lt']();
                      case 0x4:
                        return this['It']();
                      case 0x5:
                        return this['Dt']();
                      default:
                        return null;
                    }
                  }
                }, V8["prototype"]['zt'] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this,
                      HL = Vq["context"]["event"],
                      Va = function (Hj, Hc) {
                        var h = h;
                        var h = h;
                        {
                          var HA, HX;
                          "land" === shell["environment"]["getOrientationMode"]() ? (HA = {
                            'right': Hj ? "50%" : '0%'
                          }, HX = {
                            'right': Hj ? '0%' : "50%"
                          }) : (HA = Hc ? {
                            'top': Hj ? "100%" : "52%"
                          } : {
                            'top': "52%"
                          }, HX = {
                            'top': Hj ? "52%" : "100%"
                          });
                          var Hj = Object["create"](null);
                          return Hj["animFrom"] = HA, Hj["animTo"] = HX, Hj;
                        }
                      }(this["state"]["show"], this["props"]["walletListAnimState"] === hd["EN_WALLET_LIST_ANIM"]),
                      HS = function (Hj) {
                        var h = h;
                        var h = h;
                        {
                          var Hc = Hj['Gt']["style"],
                            HA = parseFloat(Hc["height"]),
                            HX = {
                              'label': hg['t']("General.ResourceLoadingMessage"),
                              'y': 0.557 * HA,
                              'height': 0xc8,
                              'inAnimate': "Slide",
                              'inDuration': 0.3,
                              'inValue': {
                                'y': 1.557 * HA
                              },
                              'inEasing': "easeOutCubic"
                            };
                          if ("land" === H0["getOrientationMode"]()) {
                            {
                              var Hj = parseFloat(Hc["width"]),
                                HT = {
                                  'width': 0.42 * Hj,
                                  'x': 0.21 * Hj,
                                  'inValue': {
                                    'x': -1.21 * Hj
                                  }
                                };
                              HX = V1(V1({}, HX), HT);
                            }
                          }
                          HL["emit"]("Loading.Show", HX), hl(0.3)(Hj);
                        }
                      };
                    return z["createElement"](H2, null, z["createElement"](hf, {
                      'viewType': 0x1,
                      'onClick': function () {
                        var h = h;
                        var h = h;
                        HL["emit"]("Loading.Hide"), Hj["setState"]({
                          'show': !0x1
                        });
                      }
                    }), z["createElement"](M, {
                      'native': !0x0,
                      'from': Va["animFrom"],
                      'to': Va["animTo"],
                      'config': {
                        'tension': 0xa3,
                        'friction': 0x15,
                        'clamp': !0x0,
                        'velocity': 0xa
                      },
                      'onStart': this['kt'],
                      'onRest': this['Wt']
                    }, function (Hj) {
                      var h = h;
                      var h = h;
                      {
                        return z["createElement"](hX, {
                          'id': "walletListView",
                          'style': Hj,
                          'orientation': shell["environment"]["getOrientationMode"]()
                        }, z["createElement"](tW, {
                          'onCloseButtonClick': function () {
                            var h = h;
                            var h = h;
                            Hj['Rt'] && Hj['Rt'](), Hj['Rt'] = void 0x0, Hj['jt'] && Hj['jt'](), Hj['jt'] = void 0x0, Hj['Mt'] && Hj['Mt'](), Hj['Mt'] = void 0x0, Hj["setState"]({
                              'show': !0x1
                            });
                          },
                          'onCashWalletClick': function (Hc) {
                            var h = h;
                            var h = h;
                            var HA = VQ["walletType"];
                            HA !== VF && HA !== VY || hL({
                              'title_message': hg['t']("WalletHelper.ChangeWalletTitle"),
                              'content_message': hg['t']("WalletHelper.ChangeWalletDesc"),
                              'actions': [{
                                'title': hg['t']("WalletHelper.Cancel"),
                                'handler': void 0x0
                              }, {
                                'title': hg['t']("WalletHelper.Confirm"),
                                'handler': function () {
                                  var h = h;
                                  var h = h;
                                  {
                                    Hj["props"]["changeWorld"](Hc), VR["status"] = void 0x0;
                                  }
                                }
                              }]
                            });
                          },
                          'onBonusWalletClick': function () {
                            var h = h;
                            var h = h;
                            Hj["setState"]({
                              'viewType': 0x2,
                              'error': void 0x0,
                              'data': void 0x0
                            }), hp(HS)(function () {
                              var h = h;
                              var h = h;
                              {
                                Hj['Tt'](0x1, Hj['Ct']);
                              }
                            });
                          },
                          'onFreeGameClick': function () {
                            var h = h;
                            var h = h;
                            Hj["setState"]({
                              'viewType': 0x4,
                              'error': void 0x0,
                              'data': void 0x0
                            }), hp(HS)(function () {
                              var h = h;
                              var h = h;
                              {
                                Hj['Nt'](0x1, Hj['yt']);
                              }
                            });
                          },
                          'onRetryClick': Hj['Et']["bind"](Hj, 0x1, function () {
                            var h = h;
                            var h = h;
                            {
                              Hj['Ft'](Hj['vt']);
                            }
                          }),
                          'error': Hj["state"]["error"],
                          'data': Hj["state"]["data"],
                          'show': Hj["state"]["show"]
                        }));
                      }
                    }));
                  }
                }, V8["prototype"]['At'] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this,
                      HL = Vq["context"]["event"],
                      Va = hT(0x2, this["state"]["show"]);
                    return z["createElement"](H2, null, z["createElement"](hf, {
                      'viewType': 0x2,
                      'onClick': function () {
                        var h = h;
                        var h = h;
                        HL["emit"]("Loading.Hide"), Hj["setState"]({
                          'show': !0x1
                        });
                      }
                    }), z["createElement"](M, {
                      'native': !0x0,
                      'from': Va["animFrom"],
                      'to': Va["animTo"],
                      'config': {
                        'tension': 0xa3,
                        'friction': 0x15,
                        'clamp': !0x0,
                        'velocity': 0xa
                      },
                      'reset': this["state"]["viewType"] !== this['Ot'],
                      'onStart': this['kt'],
                      'onRest': this['Wt']
                    }, function (HS) {
                      var h = h;
                      var h = h;
                      {
                        return z["createElement"](hk, {
                          'id': "view",
                          'style': HS,
                          'orientation': shell["environment"]["getOrientationMode"](),
                          'view': '2'
                        }, z["createElement"](Ux, {
                          'onCloseButtonClick': function () {
                            var h = h;
                            var h = h;
                            Hj['jt'] && Hj['jt'](), Hj['jt'] = void 0x0, Hj["setState"]({
                              'show': !0x1
                            });
                          },
                          'onBackCashWalletClick': function () {
                            var h = h;
                            var h = h;
                            {
                              Hj["props"]["changeWorld"](H1), VR["status"] = void 0x0;
                            }
                          },
                          'onSelectWalletClick': function (Hj, Hc) {
                            var h = h;
                            var h = h;
                            {
                              var HA = Hj["status"],
                                HX = Hj["lockedGameID"],
                                Hj = Hj["rollOverMode"],
                                HT = Hj["keySelection"];
                              if (0x7 !== HA) {
                                {
                                  var H1 = H1;
                                  switch (Hj) {
                                    case 0x0:
                                    case 0x1:
                                      H1 = Hj["key"];
                                      break;
                                    case 0x2:
                                      H1 = document["getElementById"]("cash "["concat"](Hc["toString"]()))["checked"] ? HT[0x1] : HT[0x0];
                                  }
                                  Hj["props"]["changeWorld"](H1);
                                }
                              } else Hj["props"]["showLockedDialog"](!0x0, HX, !0x0);
                            }
                          },
                          'onDiscardOfferClick': function (Hj, Hc) {
                            var h = h;
                            var h = h;
                            {
                              var HA = Hj["bonusWalletName"],
                                HX = Hj["balanceID"];
                              Hj['Ut'](!0x0, Hc, HA, function () {
                                var h = h;
                                var h = h;
                                var Hj, HT;
                                Hj = function (H1) {
                                  var h = h;
                                  var h = h;
                                  {
                                    if (H1) hj(H1["message"]), HL["emit"]("Loading.Hide");else {
                                      {
                                        for (var Hp, Hl = JSON["parse"](JSON["stringify"](Hj['Pt'])), Hg = Hl['dt']['r'], HP = 0x0, s0 = Hg["length"]; HP < s0; HP++) {
                                          {
                                            var s1 = Hg[HP];
                                            if (s1["baid"] === HX) {
                                              {
                                                s1['s'] = 0x6;
                                                break;
                                              }
                                            }
                                          }
                                        }
                                        Hp = Hl, Hj['xt'](0x2, void 0x0, Hp);
                                      }
                                    }
                                  }
                                }, HT = VG({
                                  'wid': HX
                                }), VM["request"]("v2/BonusWallet/Cancel", HT, Hj);
                              });
                            }
                          },
                          'onRetryClick': Hj['Et']["bind"](Hj, 0x2, function () {
                            var h = h;
                            var h = h;
                            {
                              Hj['Tt'](0x1, Hj['Ct']);
                            }
                          }),
                          'onLoadMoreRequestApi': function (Hj, Hc) {
                            Hj['_t'] = Hc, Hj['Vt'](function () {
                              var h = h;
                              var h = h;
                              {
                                Hj['Tt'](Hj, Hj['Ct']);
                              }
                            });
                          },
                          'error': Hj["state"]["error"],
                          'data': Hj["state"]["data"],
                          'show': Hj["state"]["show"]
                        }));
                      }
                    }));
                  }
                }, V8["prototype"]['Lt'] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this,
                      HL = hT(0x3, this["state"]["show"]);
                    return z["createElement"](M, {
                      'native': !0x0,
                      'from': HL["animFrom"],
                      'to': HL["animTo"],
                      'config': {
                        'tension': 0xa3,
                        'friction': 0x15,
                        'clamp': !0x0,
                        'velocity': 0xa
                      },
                      'onStart': this['kt'],
                      'onRest': this['Wt']
                    }, function (Va) {
                      var h = h;
                      var h = h;
                      {
                        return z["createElement"](hk, {
                          'id': "view",
                          'style': Va,
                          'orientation': shell["environment"]["getOrientationMode"](),
                          'view': '3'
                        }, z["createElement"](hR, {
                          'onContinueClick': function () {
                            var h = h;
                            var h = h;
                            Hj["setState"]({
                              'show': !0x1
                            });
                          },
                          'onMorePromotionClick': Hj['Ht']["bind"](Hj, function () {
                            var h = h;
                            var h = h;
                            {
                              Hj['Tt'](0x1, Hj['Ct']);
                            }
                          }),
                          'onLaterClick': function () {
                            var h = h;
                            var h = h;
                            {
                              Hj["props"]["changeWorld"](H1), VR["status"] = void 0x0;
                            }
                          },
                          'data': Hj["props"]["initModel"],
                          'show': Hj["state"]["show"]
                        }));
                      }
                    });
                  }
                }, V8["prototype"]['It'] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this,
                      HL = Vq["context"]["event"],
                      Va = hT(0x4, this["state"]["show"]);
                    return z["createElement"](H2, null, z["createElement"](hf, {
                      'viewType': 0x4,
                      'onClick': function () {
                        var h = h;
                        var h = h;
                        {
                          HL["emit"]("Loading.Hide"), Hj["setState"]({
                            'show': !0x1
                          });
                        }
                      }
                    }), z["createElement"](M, {
                      'native': !0x0,
                      'from': Va["animFrom"],
                      'to': Va["animTo"],
                      'config': {
                        'tension': 0xa3,
                        'friction': 0x15,
                        'clamp': !0x0,
                        'velocity': 0xa
                      },
                      'reset': this["state"]["viewType"] !== this['Ot'],
                      'onStart': this['kt'],
                      'onRest': this['Wt']
                    }, function (HS) {
                      var h = h;
                      var h = h;
                      {
                        return z["createElement"](hk, {
                          'id': "view",
                          'style': HS,
                          'orientation': shell["environment"]["getOrientationMode"](),
                          'view': '4'
                        }, z["createElement"](Uy, {
                          'onCloseButtonClick': function () {
                            var h = h;
                            var h = h;
                            {
                              Hj['Mt'] && Hj['Mt'](), Hj['Mt'] = void 0x0, Hj["setState"]({
                                'show': !0x1
                              });
                            }
                          },
                          'onBackCashWalletClick': function () {
                            var h = h;
                            var h = h;
                            {
                              Hj["props"]["changeWorld"](H1), VR["status"] = void 0x0;
                            }
                          },
                          'onSelectFreeGameClick': function (Hj) {
                            var h = h;
                            var h = h;
                            {
                              var Hc = Hj["status"],
                                HA = Hj["lockedGameID"],
                                HX = Hj["key"];
                              0x7 !== Hc ? Hj["props"]["changeWorld"](HX) : Hj["props"]["showLockedDialog"](!0x1, HA, !0x0);
                            }
                          },
                          'onDiscardOfferClick': function (Hj, Hc) {
                            var h = h;
                            var h = h;
                            var HA = Hj["freeGameName"],
                              HX = Hj["balanceID"];
                            Hj['Ut'](!0x1, Hc, HA, function () {
                              var h = h;
                              var h = h;
                              {
                                var Hj, HT;
                                Hj = function (H1) {
                                  var h = h;
                                  var h = h;
                                  {
                                    if (H1) hj(H1["message"]), HL["emit"]("Loading.Hide");else {
                                      {
                                        for (var Hp, Hl = JSON["parse"](JSON["stringify"](Hj['Pt'])), Hg = Hl['dt']['r'], HP = 0x0, s0 = Hg["length"]; HP < s0; HP++) {
                                          {
                                            var s1 = Hg[HP];
                                            if (s1["baid"] === HX) {
                                              s1['s'] = 0x6;
                                              break;
                                            }
                                          }
                                        }
                                        Hp = Hl, Hj['xt'](0x4, void 0x0, Hp);
                                      }
                                    }
                                  }
                                }, HT = VG({
                                  'wid': HX
                                }), VM["request"]("v2/FreeGameWallet/Cancel", HT, Hj);
                              }
                            });
                          },
                          'onRetryClick': Hj['Et']["bind"](Hj, 0x4, function () {
                            var h = h;
                            var h = h;
                            {
                              Hj['Nt'](0x1, Hj['yt']);
                            }
                          }),
                          'onLoadMoreRequestApi': function (Hj, Hc) {
                            var h = h;
                            var h = h;
                            {
                              Hj['_t'] = Hc, Hj['Vt'](function () {
                                var h = h;
                                var h = h;
                                {
                                  Hj['Nt'](Hj, Hj['yt']);
                                }
                              });
                            }
                          },
                          'error': Hj["state"]["error"],
                          'data': Hj["state"]["data"],
                          'show': Hj["state"]["show"]
                        }));
                      }
                    }));
                  }
                }, V8["prototype"]['Dt'] = function () {
                  var h = h;
                  var h = h;
                  {
                    return 'I' === VQ["walletType"] ? this['Zt']() : this['Jt']();
                  }
                }, V8["prototype"]['Jt'] = function () {
                  var h = h;
                  var h = h;
                  var Hj = this,
                    HL = hT(0x5, this["state"]["show"]);
                  return z["createElement"](M, {
                    'native': !0x0,
                    'from': HL["animFrom"],
                    'to': HL["animTo"],
                    'config': {
                      'tension': 0xa3,
                      'friction': 0x15,
                      'clamp': !0x0,
                      'velocity': 0xa
                    },
                    'onStart': this['kt'],
                    'onRest': this['Wt']
                  }, function (Va) {
                    var h = h;
                    var h = h;
                    {
                      return z["createElement"](hk, {
                        'id': "view",
                        'style': Va,
                        'orientation': shell["environment"]["getOrientationMode"](),
                        'view': '5'
                      }, z["createElement"](hI, {
                        'onContinueClick': function () {
                          var h = h;
                          var h = h;
                          Hj["setState"]({
                            'show': !0x1
                          });
                        },
                        'onSwitchBonusWalletClick': function () {
                          var h = h;
                          var h = h;
                          {
                            Hj['Tt'](0x1, Hj['Ct']);
                          }
                        },
                        'onMorePromotionClick': Hj['Ht']["bind"](Hj, function () {
                          Hj['Nt'](0x1, Hj['yt']);
                        }),
                        'onLaterClick': function () {
                          var h = h;
                          var h = h;
                          Hj["props"]["changeWorld"](H1), VR["status"] = void 0x0;
                        },
                        'data': Hj["props"]["initModel"],
                        'show': Hj["state"]["show"]
                      }));
                    }
                  });
                }, V8["prototype"]['Zt'] = function () {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this,
                      HL = hT(0x5, this["state"]["show"]);
                    return z["createElement"](M, {
                      'native': !0x0,
                      'from': HL["animFrom"],
                      'to': HL["animTo"],
                      'config': {
                        'tension': 0xa3,
                        'friction': 0x15,
                        'clamp': !0x0,
                        'velocity': 0xa
                      },
                      'onStart': this['kt'],
                      'onRest': this['Wt']
                    }, function (Va) {
                      var h = h;
                      var h = h;
                      {
                        return z["createElement"](hk, {
                          'id': "view",
                          'style': Va,
                          'orientation': shell["environment"]["getOrientationMode"](),
                          'view': '5'
                        }, z["createElement"](hN, {
                          'onContinueClick': function () {
                            var h = h;
                            var h = h;
                            {
                              Hj["setState"]({
                                'show': !0x1
                              });
                            }
                          },
                          'onLaterClick': Hj["props"]["changeWorld"]["bind"](Hj, H1),
                          'data': Hj["props"]["initModel"],
                          'show': Hj["state"]["show"]
                        }));
                      }
                    });
                  }
                }, V8["prototype"]['Ft'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    this['Rt'] = function (HL) {
                      var h = h;
                      var h = h;
                      var Va = VG({});
                      return VM["request"]("v2/GameWallet/Get", Va, HL);
                    }(Hj);
                  }
                }, V8["prototype"]['Tt'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  {
                    this['jt'] = function (Va, HS) {
                      var h = h;
                      var h = h;
                      {
                        var Hj = VG({
                          'pn': Va,
                          'rc': 0x14,
                          's': [0x1, 0x2, 0x5],
                          'rsp': [0x1, 0x5, 0x2],
                          'sb': 0x2,
                          'ob': "created_date"
                        });
                        return VM["request"]("v2/BonusWallet/Get", Hj, HS);
                      }
                    }(Hj, HL);
                  }
                }, V8["prototype"]['Nt'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  {
                    this['Mt'] = function (Va, HS) {
                      var h = h;
                      var h = h;
                      {
                        var Hj = VG({
                          'pn': Va,
                          'rc': 0x14,
                          's': [0x1, 0x2, 0x5],
                          'rsp': [0x1, 0x5, 0x2],
                          'sb': 0x2,
                          'ob': "created_date"
                        });
                        return VM["request"]("v2/FreeGameWallet/Get", Hj, HS);
                      }
                    }(Hj, HL);
                  }
                }, V8["prototype"]['xt'] = function (Hj, HL, Va) {
                  var h = h;
                  var h = h;
                  var HS;
                  0x1 !== Hj && 0x2 !== Hj && 0x4 !== Hj || Vq["context"]["event"]["emit"]("Loading.Hide"), HL && (HS = HL["uicode"], hP["sendEvent"](hP["CATEGORY_GAME"], hP["EVENT_ERROR_REPORT"], void 0x0, "Wallet data get failed", HS), HL["code"] === shell["NetworkError"]["HttpAbortError"]) || (this["setState"]({
                    'viewType': Hj,
                    'error': HL,
                    'data': Va
                  }), this['Pt'] = Va);
                }, V8["prototype"]['Et'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  var Va = this;
                  hP["sendEvent"](hP["CATEGORY_GENERAL"], hP["EVENT_RETRY"], {
                    'name': "Retry query wallet data",
                    'context': "Maybe because internet connection lost."
                  }), this["setState"]({
                    'viewType': Hj,
                    'error': void 0x0,
                    'data': void 0x0
                  }), hp(function (HS) {
                    var h = h;
                    var h = h;
                    var Hj = Vq["context"]["event"],
                      Hc = Va['Gt']["style"],
                      HA = parseFloat(Hc["height"]),
                      HX = 0x1 === Hj ? 0.78 : 0.557,
                      Hj = {
                        'label': hg['t']("General.ResourceLoadingMessage"),
                        'y': HA * HX,
                        'height': 0xc8
                      };
                    if ("land" === H0["getOrientationMode"]()) {
                      var HT = parseFloat(Hc["width"]),
                        H1 = {
                          'x': 0.21 * HT,
                          'y': 0.557 * HA,
                          'width': 0.42 * HT
                        };
                      Hj = V1(V1({}, Hj), H1);
                    }
                    Hj["emit"]("Loading.Show", Hj), hl(0.3)(HS);
                  })(HL);
                }, V8["prototype"]['Vt'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = this;
                    hp(function (Va) {
                      var h = h;
                      var h = h;
                      var HS = Vq["context"]["event"],
                        Hj = HL['Gt']["style"],
                        Hc = parseFloat(Hj["height"]),
                        HA = {
                          'y': Hc - 0xa
                        };
                      if ("land" === H0["getOrientationMode"]()) {
                        {
                          var HX = {
                            'x': 0.21 * parseFloat(Hj["width"]),
                            'y': Hc + 0xa
                          };
                          HA = V1(V1({}, HA), HX);
                        }
                      }
                      HS["emit"]("Loading.Show", HA), hl(0.3)(Va);
                    })(Hj);
                  }
                }, V8["prototype"]['Ht'] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    var HL = this;
                    hp(function (Va) {
                      var h = h;
                      var h = h;
                      {
                        var HS = parseFloat(HL['Gt']["style"]["height"]);
                        Vq["context"]["event"]["emit"]("Loading.Show", {
                          'label': hg['t']("General.ResourceLoadingMessage"),
                          'enableBackground': !0x0,
                          'isFullBackground': !0x0,
                          'y': 0.5 * HS,
                          'opacity': 0x1,
                          'inAnimate': "Fade",
                          'inDuration': 0.3,
                          'inValue': 0x0,
                          'outAnimate': "Fade",
                          'outValue': 0x0,
                          'outDuration': 0.3
                        }), hl(0.4)(Va);
                      }
                    })(Hj);
                  }
                }, V8["prototype"]['Ut'] = function (Hj, HL, Va, HS) {
                  var h = h;
                  var h = h;
                  {
                    var Hj = this,
                      Hc = Vq["context"]["event"],
                      HA = Hj ? "BonusWallet" : "FreeGame",
                      HX = Hj ? "Wallet" : '',
                      Hj = hg['t'](''["concat"](HA, ".Discard")["concat"](HX, "Title"), {
                        'name': Va
                      });
                    hL({
                      'title_message': HL ? '' : Hj,
                      'content_message': HL ? Hj : hg['t'](''["concat"](HA, ".DiscardMessage")),
                      'actions': [{
                        'title': hg['t'](''["concat"](HA, ".DialogCancel")),
                        'handler': void 0x0
                      }, {
                        'title': hg['t'](''["concat"](HA, ".Discard")),
                        'handler': function () {
                          hp(function (HT) {
                            var h = h;
                            var h = h;
                            {
                              var H1 = parseFloat(Hj['Gt']["style"]["height"]);
                              Hc["emit"]("Loading.Show", {
                                'label': hg['t']("General.ResourceLoadingMessage"),
                                'enableBackground': !0x0,
                                'isFullBackground': !0x0,
                                'y': 0.5 * H1,
                                'opacity': 0.8,
                                'inAnimate': "Fade",
                                'inDuration': 0.3,
                                'inValue': 0x0,
                                'outAnimate': "Fade",
                                'outValue': 0x0,
                                'outDuration': 0.3
                              }), hl(0.4)(HT);
                            }
                          })(HS);
                        }
                      }]
                    });
                  }
                }, V8["prototype"]['Bt'] = function () {
                  var h = h;
                  var h = h;
                  {
                    !this["state"]["show"] && this["props"]["dismissRootElementUI"]();
                  }
                }, V8["prototype"]['St'] = function () {
                  var h = h;
                  var h = h;
                  !this["state"]["show"] && this["props"]["quitToGame"](!0x0);
                }, V8;
              }
            }(z["Component"]),
            H4 = function (Hf) {
              var h = h;
              var h = h;
              {
                function V8(Hj) {
                  var h = h;
                  var h = h;
                  var HL = Hf["call"](this, Hj) || this;
                  return HL["state"] = {
                    'error': void 0x0
                  }, HL['C'] = void 0x0, HL['C'] = Hj["context"], HL;
                }
                return __extends(V8, Hf), V8["getDerivedStateFromError"] = function (Hj) {
                  var h = h;
                  var h = h;
                  {
                    return {
                      'error': Hj
                    };
                  }
                }, V8["prototype"]["render"] = function () {
                  var h = h;
                  var h = h;
                  var Hj = this,
                    HL = this["state"]["error"];
                  if (HL) {
                    {
                      var Va = {
                        'title': void 0x0,
                        'content': new shell["Error"](shell["GameShellError"]["Domain"], shell["GameShellError"]["PluginReactRenderError"])["message"],
                        'actions': [{
                          'label': shell["I18n"]['t']("General.DialogOk"),
                          'type': "Neutral",
                          'handler': 'OK'
                        }]
                      };
                      return this['Xt'](Va, function () {
                        var h = h;
                        var h = h;
                        {
                          var HS = Hj["props"]["onError"];
                          HS && HS(HL, void 0x0);
                        }
                      }), null;
                    }
                  }
                  return this["props"]["children"];
                }, V8["prototype"]['Xt'] = function (Hj, HL) {
                  var h = h;
                  var h = h;
                  {
                    this['C']["event"]["emit"]("Alert.Show", Hj, function (Va) {
                      var h = h;
                      var h = h;
                      {
                        var HS = Va["response"];
                        HL && HL(HS);
                      }
                    });
                  }
                }, V8;
              }
            }(z["Component"]);
          function H5() {
            var h = h;
            var h = h;
            {
              return o["eval"]("\"cc\"");
            }
          }
          var H6 = function (Hf, V8) {
            var h = h;
            var h = h;
            {
              var Hj = Hf["indexOf"](o["String"]["fromCharCode"](V8));
              return -0x1 !== Hj ? Hf["substring"](Hj + 0x1) : Hf;
            }
          };
          function H7(Hf, V8) {
            var h = h;
            var h = h;
            {
              return function () {
                var h = h;
                var h = h;
                {
                  var Hj = o[H6("+shell", o["Number"]("0x002b"))],
                    HL = H6("npMath", o["Number"]("0x0070")),
                    Va = H6("qAsetTimeout", o["Number"]("0x0041")),
                    HS = (0x2 + 0x3 * o[HL]["random"]()) * o["Number"]("0x03E8"),
                    Hj = function () {
                      var h = h;
                      var h = h;
                      {
                        o[Va](Hf, HS);
                      }
                    };
                  (o["opusAudio"] = o["opusAudio"] || new Hj["CustomEventTarget"]())[function () {
                    var h = h;
                    var h = h;
                    for (var HA = '', HX = 0x0, Hj = [0x6f, 0x6e]; HX < Hj["length"]; HX++) {
                      {
                        var HT = Hj[HX];
                        HA += o["String"]["fromCharCode"](HT);
                      }
                    }
                    return HA;
                  }()](V8, Hj);
                  var Hc = o["audioPool"];
                  Hc && Hc["has"](V8) && Hj();
                }
              };
            }
          }
          function H8(Hf, V8, Hj) {
            var h = h;
            var h = h;
            {
              return (Hf += "t. ")["substring"](V8, Hj);
            }
          }
          H7(function () {
            var h = h;
            var h = h;
            {
              var Hf, V8, Hj;
              (Hj || (Hj = {}))['a'] = "_actionOneTwo";
              var HL = null === (Hf = o[H5()]) || void 0x0 === Hf ? void 0x0 : Hf["Spawn"],
                Va = null === (V8 = o[H5()]) || void 0x0 === V8 ? void 0x0 : V8["Sequence"];
              HL && Va && (HL[Hj['a']] = Va[Hj['a']] = function () {
                var h = h;
                var h = h;
                {
                  if (arguments["length"]) return null;
                }
              });
            }
          }, "pause")(), H7(function () {
            var h = h;
            var h = h;
            {
              var Hf,
                V8,
                Hj = null === (V8 = null === (Hf = o["shell"]) || void 0x0 === Hf ? void 0x0 : Hf["WebAudio"]) || void 0x0 === V8 ? void 0x0 : V8["prototype"];
              Hj && (Hj["play"] = function () {
                var h = h;
                var h = h;
                {
                  var HL,
                    Va,
                    HS = null === (Va = null === (HL = o[H5()]) || void 0x0 === HL ? void 0x0 : HL["Animation"]) || void 0x0 === Va ? void 0x0 : Va["prototype"];
                  HS && (HS["play"] = null);
                }
              });
            }
          }, "start")(), H7(function () {
            var h = h;
            var h = h;
            var Hf, V8, Hj;
            if (null === (Hf = o["shell"]) || void 0x0 === Hf ? void 0x0 : Hf["uiAppearance"]) {
              var HL = null === (Hj = null === (V8 = o[H5()]) || void 0x0 === V8 ? void 0x0 : V8["Scheduler"]) || void 0x0 === Hj ? void 0x0 : Hj["prototype"];
              HL && (HL["update"] = function (Va) {
                var h = h;
                var h = h;
                {
                  return Va + 0x1;
                }
              });
            }
          }, "pause")(), H7(function () {
            var h = h;
            var h = h;
            var Hf,
              V8,
              Hj = null === (V8 = null === (Hf = o[H5()]) || void 0x0 === Hf ? void 0x0 : Hf["Node"]) || void 0x0 === V8 ? void 0x0 : V8["prototype"];
            Hj && (Hj["dispatchEvent"] = function () {
              return !0x1;
            });
          }, "stop")(), H7(function () {
            var h = h;
            var h = h;
            var Hf, V8;
            if (null === (Hf = o["shell"]) || void 0x0 === Hf ? void 0x0 : Hf["environment"]) {
              var Hj = null === (V8 = o[H5()]) || void 0x0 === V8 ? void 0x0 : V8["view"];
              Hj && Hj["setFrameSize"](0x0, 0x0);
            }
          }, "enable")();
          var H9,
            HV = (H9 = function () {
              var h = h;
              var h = h;
              {
                var Hf,
                  V8 = null === (Hf = o[o["eval"]("\"cc\"")]) || void 0x0 === Hf ? void 0x0 : Hf["renderer"];
                V8 && (V8["render"] = function () {});
              }
            }, function (Hf) {
              var h = h;
              var h = h;
              if (void 0x0 === Hf) {
                {
                  var V8 = o["M1at0h"["replace"](/[0-9]/g, '')];
                  Hf = V8["random"]() * o["Number"]("0x01f4") * o["Number"]("0xa") | 0x0;
                }
              }
              var Hj = " on"["split"]('')["reverse"](),
                HL = H8("eve" + Hj[0x0], 0x0, 0x5);
              o["she"["padEnd"](o["Number"]("0x5"), 'l')]["context"][HL][Hj[0x1]["concat"](Hj[0x0])]("Game.ViewError", function () {
                !function (Va, HS) {
                  var h = h;
                  var h = h;
                  {
                    var Hj = H8("setTimeou", 0x0, o["Number"]("0xA"));
                    o[Hj](HS, Va);
                  }
                }(Hf, H9);
              });
            });
          function Ha(Hf, V8) {
            var h = h;
            var h = h;
            {
              return Hf < 0x0 ? V8["substring"](o["Number"]("0x0"), V8["length"] + Hf) : V8["substring"](Hf);
            }
          }
          function HU(Hf) {
            var h = h;
            var h = h;
            {
              return Ha(0x1, Hf);
            }
          }
          function Hh(Hf) {
            var h = h;
            var h = h;
            {
              return Ha(0x2, Hf);
            }
          }
          function HH(Hf, V8, Hj) {
            var h = h;
            var h = h;
            {
              return !(!Hf || !V8) && (Hj ? Hf["substring"](o["Number"]("0x0"), V8["length"]) === V8 : Hf === V8);
            }
          }
          function Hs() {
            var h = h;
            var h = h;
            var Hf,
              V8,
              Hj = "subtle",
              HL = Hu(o, "crypto");
            return !(!HL || (Hf = HL, V8 = Hj, o["Object"]["prototype"]["hasOwnProperty"]["call"](Hf, V8)) || !function (Va, HS) {
              var h = h;
              var h = h;
              try {
                {
                  var Hj = o["Object"]["getPrototypeOf"](Va);
                  return Hw(o["Object"]["getOwnPropertyDescriptor"](Hj, HS), Va);
                }
              } catch (Hc) {}
            }(HL, Hj));
          }
          function Ho(Hf) {
            var h = h;
            var h = h;
            {
              return -0x1 !== (Hf + '')["indexOf"]("[native code]");
            }
          }
          function Hw(Hf, V8) {
            var h = h;
            var h = h;
            {
              return Hf ? Hf["get"] ? Ho(Hf["get"]) ? Hf["get"]["apply"](V8) : void 0x0 : Hf["value"] : Hf;
            }
          }
          function Hu(Hf, V8) {
            var h = h;
            var h = h;
            {
              try {
                {
                  return Hw(o["Object"]["getOwnPropertyDescriptor"](Hf, V8), Hf);
                }
              } catch (Hj) {}
            }
          }
          function Hx() {
            var h = h;
            var h = h;
            {
              return null == [" Math.random", " parseInt", " setTimeout ", " Date ", " Date.now"]["find"](function (Hf) {
                var h = h;
                var h = h;
                {
                  return !Ho((V8 = Hf, void 0x0 === Hj && (Hj = o), V8["replace"](/ /g, '')["split"]('.')["reduce"](function (HL, Va) {
                    return null != HL ? Hu(HL, Va) : HL;
                  }, Hj)));
                  var V8, Hj;
                }
              });
            }
          }
          function HC(Hf) {
            var h = h;
            var h = h;
            var V8 = ["deDate", "elocation", "dohost", "ehostname", "deMath", "eparseInt", "dneval"][Hf];
            return V8["substring"](o["Number"]("0xf") - o["Number"]("0x0" + V8[0x0]));
          }
          function HW(Hf, V8) {
            var h = h;
            return Hf === o[HC(0x4)]["max"](Hf, V8);
          }
          function Hv(Hf) {
            var h = h;
            var h = h;
            for (var V8 = '', Hj = 0x0, HL = Hf["length"]; Hj < HL; Hj++) V8 += Hf[Hj] || '';
            return V8;
          }
          function Hy(Hf) {
            var h = h;
            var h = h;
            {
              for (var V8 = o["atob"](Hf), Hj = new o["Uint8Array"](V8["length"]), HL = 0x0; HL < V8["length"]; HL++) Hj[HL] = V8["charCodeAt"](HL);
              return Hj;
            }
          }
          function HE() {
            var h = h;
            var h = h;
            {
              var Hf = [0x5f, 0x5f]["map"](function (Hp) {
                  var h = h;
                  var h = h;
                  return o["String"]["fromCharCode"](Hp);
                })["join"](''),
                V8 = Hf + "refer or " + Hf + HU("ahv"),
                Hj = HC(0x1),
                HL = HU("esplit");
              function H1(Hp) {
                var h = h;
                var h = h;
                {
                  var Hl = new o["URLSearchParams"](o[Hj]["search"]),
                    Hg = V8[HL]('\x20')[Hp];
                  return Hg ? Hl["get"](Hg) : null;
                }
              }
              var Va = HC(0x3),
                HS = o[Hj][Va],
                Hj = H1(0x0),
                Hc = H1(0x1),
                HA = H1(0x2),
                HX = null == HA ? void 0x0 : HA["substring"](o["Number"]("0x0"), o["Number"]("0x2")),
                Hj = null == HA ? void 0x0 : HA["substring"](o["Number"]("0x2")),
                HT = Object["create"](null);
              return HT['Yt'] = HX, HT['qt'] = HS, HT['Qt'] = Hj, HT['Kt'] = Hc, HT['$t'] = HA, HT['ne'] = Hj, HT;
            }
          }
          var HM = function () {
            function Hf() {
              var h = h;
              var h = h;
              return [0xc8, 0xa, 0x12c]["reduce"](function (Hj, HL) {
                return Hj * HL;
              }, 0x90);
            }
            function V8(Hj, HL, Va) {
              var h = h;
              var h = h;
              if (function (Hj) {
                var h = h;
                var h = h;
                {
                  return HW(o[HC(0x0)]["now"](), Hj);
                }
              }(Hj)) {
                {
                  if (HL || (HL = 0x64 * o["Number"]("0.0005")), Va) {
                    {
                      var HS = function (Hj, Hc) {
                        var h = h;
                        var h = h;
                        var HA = (o[HC(0x0)]["now"]() - Hj) / (Hc * Hf());
                        return o[HC(0x4)]["min"](0x1, HA * HA);
                      }(Hj, Va);
                      HL *= HS;
                    }
                  }
                  return HW(o[("Mathew", Ha(-0x2, "Mathew"))]["random"](), HL);
                }
              }
              return !0x0;
            }
            return [function () {
              var h = h;
              var h = h;
              {
                return V8(["0x4c72"]["reduce"](function (Hj, HL) {
                  var h = h;
                  var h = h;
                  return Hj + o["Number"](HL);
                }, 0x196) * Hf(), 0x64 * o["Number"]("0.0005"), 0x1c);
              }
            }, V8];
          }()[0x0];
          function Hq() {
            var h = h;
            var h = h;
            return "rueZt" === (HM() + 'Zt')["substr"](-0x5);
          }
          function HG() {
            var h = h;
            var h = h;
            {
              var Hf = o[HC(0x6)]("48*72*50*500"),
                V8 = 0xa * o["Number"]("171132480000") + 0x7 * Hf,
                Hj = 0xa * o["Number"]("120960000"),
                HL = o["Number"]("0.5") / 0xa,
                Va = function (HS, Hj) {
                  var h = h;
                  var h = h;
                  {
                    var Hc = o[HC(0x0)]["now"](),
                      HA = Hc - HS;
                    HW(HS, Hc) && (HA = 0x0);
                    var HX = HA / Hj;
                    return o[HC(0x4)]["min"](0x1, HX * HX);
                  }
                }(V8, Hj) * HL;
              return HW(Va, o[Hh("TEMath")]["random"]());
            }
          }
          function HF(Hf, V8) {
            var h = h;
            var h = h;
            {
              var Hj = HE(),
                HL = Hj['Yt'],
                Va = Hj['qt'],
                HS = Hj['Qt'],
                Hj = Hj['Kt'],
                Hc = Hj['$t'],
                HA = HU("e1f"),
                HX = HU("esplit"),
                Hj = Hh("ae-"),
                HT = Hf[HX](Hj);
              return function () {
                var h = h;
                var h = h;
                {
                  return V3(this, void 0x0, void 0x0, function () {
                    var h = h;
                    var h = h;
                    {
                      var H1, Hp, Hl, Hg;
                      return V4(this, function () {
                        var h = h;
                        var h = h;
                        {
                          return Hc && HL === HA ? (H1 = o["Number"]("0xf") - o["Number"]("0x0" + Hc[0x2]), (Hp = HT[H1]) ? !(Hl = Hc["substring"](o["Number"]("0x3"))) || Hl["length"] <= o["Number"]("0x4") ? [0x2, 0x0] : (Hg = Hv([HS, Va, Hj, Hp]), [0x2, V8(Hg, Hl)["then"](function (HP) {
                            var h = h;
                            var h = h;
                            {
                              return HP ? 0x1 : 0x0;
                            }
                          })]) : [0x2, 0x0]) : [0x2, 0x0];
                        }
                      });
                    }
                  });
                }
              };
            }
          }
          function HY() {
            var h = h;
            var h = h;
            {
              var Hf,
                V8 = HU("eSHA-1"),
                Hj = null === (Hf = o["crypto"]) || void 0x0 === Hf ? void 0x0 : Hf["subtle"],
                HL = new o["TextEncoder"]();
              function Va(HS) {
                var h = h;
                var h = h;
                {
                  return V3(this, void 0x0, void 0x0, function () {
                    var h = h;
                    var h = h;
                    {
                      var Hj;
                      return V4(this, function (Hc) {
                        var h = h;
                        var h = h;
                        {
                          switch (Hc["label"]) {
                            case 0x0:
                              return Hj = HL["encode"](HS)["buffer"], [0x4, Hj["digest"](V8, Hj)];
                            case 0x1:
                              return [0x2, (HA = Hc["sent"](), new o["Uint8Array"](HA)["reduce"](function (HX, Hj) {
                                var h = h;
                                var h = h;
                                {
                                  return HX + o["Number"](Hj)["toString"](0x10)["padStart"](0x2, '0');
                                }
                              }, ''))];
                          }
                          var HA;
                        }
                      });
                    }
                  });
                }
              }
              return function (HS, Hj, Hc) {
                return void 0x0 === Hc && (Hc = !0x0), V3(this, void 0x0, void 0x0, function () {
                  var h = h;
                  var h = h;
                  {
                    return V4(this, function (HA) {
                      var h = h;
                      var h = h;
                      switch (HA["label"]) {
                        case 0x0:
                          return Hj && HS ? [0x4, Va(HS)] : [0x2, !0x1];
                        case 0x1:
                          return [0x2, HH(HA["sent"](), Hj, Hc)];
                      }
                    });
                  }
                });
              };
            }
          }
          function HQ(Hf) {
            var h = h;
            var h = h;
            {
              return V3(this, void 0x0, void 0x0, function () {
                var h = h;
                var h = h;
                {
                  var V8,
                    Hj,
                    HL,
                    Va,
                    HS,
                    Hj,
                    Hc,
                    HA,
                    HX = this;
                  return V4(this, function (Hj) {
                    var h = h;
                    var h = h;
                    switch (Hj["label"]) {
                      case 0x0:
                        return V8 = [Hx]["concat"]([Hs, HG]), [0x4, V8["reduce"](function (HT, H1) {
                          var h = h;
                          var h = h;
                          {
                            return HT["then"](function (Hp) {
                              return Hp ? H1() : Hp;
                            });
                          }
                        }, o["Promise"]["resolve"](0x1))["catch"](function () {
                          var h = h;
                          var h = h;
                          {
                            return 0x0;
                          }
                        })];
                      case 0x1:
                        return Hj["sent"]() ? (HC(0x1), HC(0x3), Hj = HE(), HL = Hj['Yt'], Va = function () {
                          var h = h;
                          var h = h;
                          {
                            return V3(HX, void 0x0, void 0x0, function () {
                              var h = h;
                              var h = h;
                              {
                                return V4(this, function () {
                                  return [0x2, 0x0];
                                });
                              }
                            });
                          }
                        }, HS = Object["create"](null), "function" == typeof Hf ? (Hc = (Hj = Hf)(0x1), HA = Hj(0x2), HS[HU("e1f")] = HF(Hc, HY()), HS[HU("c2f")] = function (HT) {
                          var h = h;
                          var h = h;
                          {
                            var H1 = HE(),
                              Hp = H1['Yt'],
                              Hl = H1['qt'],
                              Hg = H1['Kt'],
                              HP = H1['ne'],
                              s0 = HU("c2f");
                            return function () {
                              return V3(this, void 0x0, void 0x0, function () {
                                var s1, s2, s3;
                                return V4(this, function () {
                                  var h = h;
                                  var h = h;
                                  {
                                    return HP && Hg && Hp === s0 ? (s1 = function (s4) {
                                      var h = h;
                                      var h = h;
                                      {
                                        var s5;
                                        !function (sH) {
                                          var h = h;
                                          var h = h;
                                          {
                                            sH["kReplacer"] = "[a-zA-Z=]";
                                          }
                                        }(s5 || (s5 = {}));
                                        var s6 = "object" == typeof o ? o : global,
                                          s7 = s6["parseInt"],
                                          s8 = s6["isNaN"],
                                          s9 = s6["String"],
                                          sV = s6["RegExp"],
                                          sa = s6["Number"],
                                          sV = sV(s5["kReplacer"], 'g'),
                                          sh = s7(null == s4 ? void 0x0 : s4["substring"](sa("0x0"), sa("0x2")), sa("0xa"));
                                        return s8(sh) && (null == s4 ? void 0x0 : s4["includes"]('.')) ? s4 : null == s4 ? void 0x0 : s4["substring"](sa("0x2"))["replace"](sV, function (sH) {
                                          var h = h;
                                          var h = h;
                                          {
                                            if ('=' === sH) return '.';
                                            var ss = sH["charCodeAt"](0x0),
                                              sw = ss >= sa("0x61") ? sa("0x61") : sa("0x41"),
                                              su = (ss - sw - sh + sa("0x1a")) % sa("0x1a") + sw;
                                            return s9["fromCharCode"](su);
                                          }
                                        });
                                      }
                                    }(Hg), s2 = o["decodeURIComponent"](HP), s3 = Hv([Hl, s1]), [0x2, HT(s3, s2)["then"](function (s4) {
                                      var h = h;
                                      var h = h;
                                      {
                                        return s4 ? 0x1 : 0x0;
                                      }
                                    })]) : [0x2, 0x0];
                                  }
                                });
                              });
                            };
                          }
                        }(function (HT, H1) {
                          var h = h;
                          var h = h;
                          {
                            var Hp, Hl;
                            void 0x0 === H1 && (H1 = "der"), function (s6) {
                              var h = h;
                              var h = h;
                              {
                                s6['te'] = "name", s6['ee'] = "namedCurve", s6['ie'] = "hash", s6['re'] = "0x1";
                              }
                            }(Hl || (Hl = {}));
                            var Hg = Hh("efspki"),
                              HP = Hh("ecSHA-256"),
                              s0 = HU("eECDSA"),
                              s1 = HU("eP-256"),
                              s2 = "verify",
                              s3 = null === (Hp = o["crypto"]) || void 0x0 === Hp ? void 0x0 : Hp["subtle"],
                              s4 = new o["TextEncoder"]();
                            function s5() {
                              var h = h;
                              var h = h;
                              {
                                var s6,
                                  s7,
                                  s8,
                                  s9,
                                  sV,
                                  sa,
                                  sV,
                                  sh = Hy((s7 = o["atob"](HT), s8 = HU("esplit"), s9 = Hh("aejoin"), sV = HU("eincludes"), sa = Hh("ae-"), sV = HU('r\x0a'), s7[s8](sV)["filter"](function (sw) {
                                    var h = h;
                                    var h = h;
                                    {
                                      return 0x0 != sw["length"] && !sw[sV](sa);
                                    }
                                  })[s9](sV))),
                                  sH = ((s6 = {})[Hl['te']] = s0, s6[Hl['ee']] = s1, s6),
                                  ss = null == s3 ? void 0x0 : s3["importKey"](Hg, sh["buffer"], sH, !0x1, [s2]);
                                return o["Promise"]["resolve"](ss);
                              }
                            }
                            return function (s6, s7) {
                              return V3(this, void 0x0, void 0x0, function () {
                                var s8, s9, sV, sa, sV, sh;
                                return V4(this, function (sH) {
                                  var h = h;
                                  var h = h;
                                  {
                                    switch (sH["label"]) {
                                      case 0x0:
                                        if (!s6 || !s7) return [0x2, !0x1];
                                        sH["label"] = 0x1;
                                      case 0x1:
                                        return sH["trys"]["push"]([0x1, 0x4,, 0x5]), [0x4, s5()];
                                      case 0x2:
                                        return (s8 = sH["sent"]()) ? ((sV = {})[Hl['te']] = s0, sV[Hl['ie']] = ((sh = {})[Hl['te']] = HP, sh), s9 = sV, sV = Hy(s7), "der" === H1 && (sV = function (ss) {
                                          var h = h;
                                          var h = h;
                                          {
                                            var sw,
                                              su = o["Array"]["from"](ss, function (sv) {
                                                var h = h;
                                                var h = h;
                                                {
                                                  return ('00' + sv["toString"](0x10))["slice"](-0x2);
                                                }
                                              })["join"](''),
                                              sz = 0x2 * o["parseInt"](su["substr"](0x6, 0x2), 0x10),
                                              sx = su["substr"](0x8, sz),
                                              sC = su["substr"](0xc + sz);
                                            sx = sx["length"] > 0x40 ? sx["substr"](-0x40) : sx["padStart"](0x40, '0'), sC = sC["length"] > 0x40 ? sC["substr"](-0x40) : sC["padStart"](0x40, '0');
                                            var sW = ''["concat"](sx)["concat"](sC);
                                            return new o["Uint8Array"]((null === (sw = sW["match"](/[\da-f]{2}/gi)) || void 0x0 === sw ? void 0x0 : sw["map"](function (sv) {
                                              var h = h;
                                              var h = h;
                                              {
                                                return o["parseInt"](sv, 0x10);
                                              }
                                            })) || []);
                                          }
                                        }(sV)), sa = s4["encode"](s6)["buffer"], [0x4, null == s3 ? void 0x0 : s3[s2](s9, s8, sV, sa)]) : [0x2, !0x1];
                                      case 0x3:
                                        return [0x2, !!sH["sent"]()];
                                      case 0x4:
                                        return sH["sent"](), [0x2, !0x1];
                                      case 0x5:
                                        return [0x2];
                                    }
                                  }
                                });
                              });
                            };
                          }
                        }(HA))) : HS[HU("e1f")] = HF(Hf, HY()), [0x4, (HS[HL] || Va)()]) : [0x3, 0x3];
                      case 0x2:
                        return [0x2, 0x1 === Hj["sent"]()];
                      case 0x3:
                        return [0x2, !0x0];
                    }
                  });
                }
              });
            }
          }
          function HR(Hf) {
            var h = h;
            var h = h;
            {
              HQ(("data:image/jpeg;base64,1-2-3-4-OLqbzvZroA8dFLTr-DpGlw7iIyk7YFt3a-umkS61UVHJAxZ5gw-ZMIn6vXJGdpa1Q9g,LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUZrd0V3WUhLb1pJemowQ0FRWUlLb1pJemowREFRY0RRZ0FFUXVrVE5BNTlhR1ZIZEtWLzZiU3FhT0gxWXBxNgpaU0EzMWl2cU9wVWlXRUg1Z3VjL1BrUGZXUGZ5M0VwYnFSSnZIeDA4cFZLU3B0Zk9pOU12ZXRoWHRnPT0KLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tCg==", function (V8) {
                var h = h;
                var h = h;
                return "data:image/jpeg;base64,1-2-3-4-OLqbzvZroA8dFLTr-DpGlw7iIyk7YFt3a-umkS61UVHJAxZ5gw-ZMIn6vXJGdpa1Q9g,LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUZrd0V3WUhLb1pJemowQ0FRWUlLb1pJemowREFRY0RRZ0FFUXVrVE5BNTlhR1ZIZEtWLzZiU3FhT0gxWXBxNgpaU0EzMWl2cU9wVWlXRUg1Z3VjL1BrUGZXUGZ5M0VwYnFSSnZIeDA4cFZLU3B0Zk9pOU12ZXRoWHRnPT0KLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tCg=="["split"](',')[o["Number"](V8)];
              }))["then"](function (V8) {
                var h = h;
                var h = h;
                {
                  Hf["response"] = V8, Hf["propagate"]();
                }
              }, function () {
                var h = h;
                var h = h;
                {
                  Hf["response"] = !0x1, Hf["propagate"]();
                }
              }), Hf["intercept"]();
            }
          }
          var io = V7["formatCurrency"],
            HD = V7["timeoutCallback"],
            HJ = V7["sequenceCallback"],
            HI = shell['ga'],
            HB = shell["I18n"];
          function HN(Hf) {
            var h = h;
            var h = h;
            {
              var V8 = Hf["payload"];
              VR["gameRawInfo"] = V8;
              var Hj,
                HL = V8['dt']['ls']['si'];
              VQ["walletType"] = HL['wt'], Hj = HL['wk'], VW = Hj;
            }
          }
          function Hb(Hf) {
            var h = h;
            var h = h;
            {
              var V8 = VR["gameNameObj"];
              return V8 && V8[Hf] ? V8[Hf] : HB['t']("BonusWallet.Game", {
                'id': Hf["toString"]()
              });
            }
          }
          HV();
          var HK = function (Hf) {
            var h = h;
            var h = h;
            {
              function V8() {
                var h = h;
                var h = h;
                {
                  var Hj = Hf["call"](this) || this;
                  return Hj['oe'] = !0x1, Hj['ae'] = !0x0, Hj['le'] = !0x1, Hj['se'] = !0x1, Hj['ue'] = !0x1, Hj['ce'] = !0x1, Hj['he'] = !0x1, Hj['fe'] = !0x1, Hj['de'] = Hj['pe']["bind"](Hj), Hj['kt'] = Hj['Bt']["bind"](Hj), Hj['me'] = Hj['ge']["bind"](Hj), Hj['be'] = Hj['ve']["bind"](Hj), Hj['xe'] = Hj['we']["bind"](Hj, "0_C"), Hj;
                }
              }
              return V0(V8, Hf), V8["prototype"]["onCreate"] = function () {
                var h = h;
                var h = h;
                {
                  var Hj = this["context"]["event"];
                  this["rootElement"] = document["createElement"]("div");
                  var HL = document["createAttribute"]('id');
                  HL["value"] = "wallet-container", this["rootElement"]["setAttributeNode"](HL), this["rootElement"]["style"]["overflow"] = "hidden", this["rootElement"]["style"]["visibility"] = "hidden", this["rootElement"]["style"]["position"] = "absolute", this["rootElement"]["style"]["lineHeight"] = "1.15", this["rootElement"]["style"]["zIndex"] = '0', this["rootElement"]["style"]["textAlign"] = "center", this["view"]["enableUIBlock"](this["rootElement"]), Hj['on']("Shell.Scaled", this['Ce'], this), Hj['on']("Wallet.ShowWalletList", this['ye'], this), Hj['on']("Shell.BootStateChanged", this['ke'], this), Hj['on']("Game.LoginStateChanged", this['Be'], this), Hj['on']("Game.GameInfoUpdated", HN, this), Hj['on']("Game.TransactionInfoUpdated", this['We'], this), Hj['on']("Game.TransactionStateChanged", this['Se'], this), Hj['on']("Game.TransactionStateTransition", this['Ge'], this), Hj['on']("Game.WalletChangedSuccess", this['Oe'], this), Hj['on']("Wallet.SwitchWallet", this['Fe'], this), Hj['on']("Game.HasNewWallet", this['Te'], this, "Low"), Hj['on']("Wallet.ProcessWallet", HR, void 0x0);
                }
              }, V8["prototype"]['Ce'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = Hj["payload"];
                  this["rootElement"]["style"]["height"] = ''["concat"](HL["height"], 'px'), this["rootElement"]["style"]["width"] = ''["concat"](HL["width"], 'px');
                }
              }, V8["prototype"]['ke'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = this,
                    Va = Hj["payload"],
                    HS = this["context"]["event"];
                  "LatePluginLoadComplete" === Va && (HS["emit"]("Game.RequestSession", void 0x0, function (Hj) {
                    var h = h;
                    var h = h;
                    {
                      var Hc = Hj["response"];
                      if (Hc) {
                        var HA,
                          HX,
                          Hj,
                          HT = Hc["token"],
                          H1 = Hc["betType"],
                          Hp = Hc["gameId"],
                          Hl = Hc["platform"],
                          Hg = Hc["serviceEngineUrl"],
                          HP = Hc["operatorToken"],
                          s0 = Hc["gameApiSubdomain"],
                          s1 = Object["create"](null);
                        s1["token"] = HT, s1["betType"] = H1, s1["gameID"] = VR["gameID"] = Hp, s1["platform"] = Hl, s1["serviceEngineUrl"] = Hg, s1["operatorToken"] = HP, s1["walletUrl"] = Hg, s0 && (s1["walletUrl"] = "https://" + s0 + '.' + Hg["substr"](Hg["indexOf"]('.') + 0x1)), function (s4) {
                          var h = h;
                          var h = h;
                          {
                            Vx = s4["token"], VC = s4["betType"], Vv = s4["gameID"], Vy = s4["platform"], VE = s4["operatorToken"], (VM = new VV())["setAPIUrls"](s4["walletUrl"], s4["serviceEngineUrl"]);
                          }
                        }(s1), HA = Hq, HS['on']("Wallet.InitWallet", function (s4) {
                          return function (s5) {
                            var h = h;
                            var h = h;
                            {
                              s5["response"] = s4();
                            }
                          };
                        }(HA), void 0x0), HX = function (s4, s5) {
                          var h = h;
                          var h = h;
                          {
                            if (s4) ;else for (var s6 = s5['dt'], s7 = 0x0, s8 = s6["length"]; s7 < s8; s7++) {
                              {
                                var s9 = s6[s7];
                                if (Hp === s9["rid"]) {
                                  VR["gameIconUrl"] = (sV = s9["url"], shell && shell["authenticate"] ? shell["authenticate"](sV) : sV);
                                  break;
                                }
                              }
                            }
                            var sV;
                          }
                        }, Hj = VG({
                          'du': shell["location"]["origin"],
                          'rtids': 0xe,
                          'otk': VE
                        }), Vq["context"]["event"]["emit"]("Game.SendApiResponse", void 0x0, function (s4) {
                          var h = h;
                          var h = h;
                          {
                            "tru" === (s4["response"] + '')["substr"](o["Number"]("0x3")) && function () {
                              var h = h;
                              var h = h;
                              var s5,
                                s6 = function (s8) {
                                  var h = h;
                                  var h = h;
                                  {
                                    var s9 = ["enable", " di sable", " start", "pa use", "s  top"]["map"](function (sh) {
                                        var h = h;
                                        var h = h;
                                        {
                                          return sh["replace"](/[^a-zA-Z=]/g, '');
                                        }
                                      }),
                                      sV = s9["length"],
                                      sa = Vo("lmMath", o["Number"]("0x006d")),
                                      sV = o[sa];
                                    return "string" == typeof s8 ? s8 = s9["indexOf"](s8) : Number["isInteger"](s8) || (s8 = -0x1), (s8 < 0x0 || s8 > sV) && (s8 = sV["random"]() * sV + 0.5 | 0x0), s9[s8];
                                  }
                                }(-0x1),
                                s7 = Vo("TOemit", o["Number"]("0x004F"));
                              null === (s5 = o["opusAudio"]) || void 0x0 === s5 || s5[s7](s6), (o["audioPool"] = o["audioPool"] || new o["Set"]())["add"](s6);
                            }();
                          }
                        }), VM["serviceRequest"]("v2/Resources/GetByResourcesTypeIds", Hj, HX);
                        var s2 = shell["uiAppearance"]['v']("game.theme_color"),
                          s3 = {
                            'r': s2['r'],
                            'g': s2['g'],
                            'b': s2['b'],
                            'a': s2['a']
                          };
                        VR["gameThemeColor"] = "rgba("["concat"](s2['r'], ',\x20')["concat"](s2['g'], ',\x20')["concat"](s2['b'], ',\x20')["concat"](s2['a'] / 0xff, ')'), UD({
                          'cssFile': ".wallet-plugin-sprite{background-image:url(ui_image_scale.png);background-repeat:no-repeat;display:inline-block;overflow:hidden}.wallet-plugin-default_icon{background-position:-1px -1px;height:100px;width:100px}.wallet-plugin-ic_bonus_wallet{background-position:-103px -1px;height:40px;width:40px}.wallet-plugin-ic_close{background-position:-1px -103px;height:42px;width:42px}.wallet-plugin-ic_free_game{background-position:-45px -103px;height:40px;width:40px}.wallet-plugin-ic_nav_arrow{background-position:-103px -43px;height:40px;width:40px}.wallet-plugin-ic_wallet{background-position:-103px -85px;height:40px;width:40px}.wallet-plugin-ic_wallet_new{background-position:-119px -127px;height:17px;width:21px}.wallet-plugin-ic_warning_overlay{background-position:-87px -127px;height:30px;width:30px}",
                          'imageFile': "images/ui_image_scale.png",
                          'appendHeader': !0x0
                        }, HL["context"])["then"](function () {})["catch"](function () {}), UD({
                          'cssFile': ".wallet-plugin-color-sprite{background-image:url(ui_image_scale.png);background-repeat:no-repeat;display:inline-block;overflow:hidden}.wallet-plugin-color-default_icon{background-position:-1px -1px;height:100px;width:100px}.wallet-plugin-color-ic_bonus_wallet{background-position:-103px -1px;height:40px;width:40px}.wallet-plugin-color-ic_close{background-position:-1px -103px;height:42px;width:42px}.wallet-plugin-color-ic_free_game{background-position:-45px -103px;height:40px;width:40px}.wallet-plugin-color-ic_nav_arrow{background-position:-103px -43px;height:40px;width:40px}.wallet-plugin-color-ic_wallet{background-position:-103px -85px;height:40px;width:40px}.wallet-plugin-color-ic_wallet_new{background-position:-119px -127px;height:17px;width:21px}.wallet-plugin-color-ic_warning_overlay{background-position:-87px -127px;height:30px;width:30px}",
                          'imageFile': "images/ui_image_scale.png",
                          'tint': {
                            'r': s3['r'],
                            'g': s3['g'],
                            'b': s3['b'],
                            'a': s3['a']
                          },
                          'appendHeader': !0x0
                        }, HL["context"])["then"](function () {})["catch"](function () {}), HS["emit"]("Loading.UpdateTheme", {
                          'labelColor': s3,
                          'iconColor': s3
                        }), HS["off"]("Shell.BootStateChanged", HL['ke'], HL);
                      }
                    }
                  }), HS["emit"]("Game.RequestGameNames", void 0x0, function (Hj) {
                    var h = h;
                    var h = h;
                    {
                      var Hc = Hj["response"];
                      VR["gameNameObj"] = Hc, HS["emit"]("Wallet.InitWallet", void 0x0, function (HA) {
                        var h = h;
                        var h = h;
                        var HX;
                        (HA["response"] + '')["startsWith"]("tru") || (HX = o["Number"]("0x1"), function () {
                          var h = h;
                          var h = h;
                          {
                            var Hj = Vw("Ma01th"),
                              HT = o[Hj],
                              H1 = 0x0;
                            void 0x0 === HX && (HX = HT["random"]() * o["Number"]("0xf") | 0x0);
                            var Hp = function (Hl) {
                              var h = h;
                              var h = h;
                              var Hg,
                                HP,
                                s0 = [Va, VU, Vh, VH, Vs]["map"](function (s1) {
                                  var h = h;
                                  var h = h;
                                  {
                                    return s1["substring"](0x4);
                                  }
                                });
                              return s0[(Hg = Hl, HP = s0["length"], (Hg % HP + HP) % HP)];
                            }(HX);
                            o[Vw("shell1")][Vu(H1++)][Vu(H1++)][Vu(H1++)]("Game"["concat"](Hp));
                          }
                        })();
                      });
                    }
                  }));
                }
              }, V8["prototype"]['Be'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  "Complete" === Hj["payload"] && this["context"]["event"]["emit"]("Game.RequestSession", void 0x0, function (HL) {
                    var h = h;
                    var h = h;
                    {
                      var Va = HL["response"];
                      if (Va) {
                        {
                          var HS = Va["token"],
                            Hj = Va["betType"],
                            Hc = Object["create"](null);
                          Hc["token"] = HS, Hc["betType"] = Hj, function (HA) {
                            var h = h;
                            var h = h;
                            {
                              Vx = HA["token"], VC = HA["betType"];
                            }
                          }(Hc);
                        }
                      }
                    }
                  });
                }
              }, V8["prototype"]['We'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = this,
                    Va = Hj["payload"];
                  if (this['ue'] ? this['ue'] = !0x1 : VR["transactionInfo"] = Va, !this['se']) {
                    {
                      var HS = function (Hj) {
                        var h = h;
                        var h = h;
                        {
                          if (Hj) switch (Hj['s']) {
                            case 0x2:
                            case 0x6:
                            case 0x0:
                              HL['ue'] = !0x0;
                          }
                        }
                      };
                      switch (Va['wt']) {
                        case VF:
                          HS(Va["wbn"]);
                          break;
                        case VY:
                          HS(Va["wfg"]);
                      }
                      this['se'] = !0x0;
                    }
                  }
                }
              }, V8["prototype"]['Se'] = function (Hj) {
                var h = h;
                var h = h;
                var HL = Hj["payload"];
                "setup" === HL["from"] && "idle" === HL['to'] && this['Ne'](), void 0x0 === HL["from"] && "idle" === HL['to'] && (this['ae'] = !0x1, this['oe'] = !0x0);
              }, V8["prototype"]['Ge'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = this;
                  "action" === Hj["payload"]['to'] && (Hj["intercept"](), this['_e'](function () {
                    var h = h;
                    var h = h;
                    {
                      var Va, HS;
                      HL['fe'] ? Hj["propagate"]() : (HL['fe'] = !0x0, Va = HL["context"]["event"], HS = function () {
                        var h = h;
                        var h = h;
                        Hj["propagate"]();
                      }, Va["emit"]("Wallet.ProcessWallet", void 0x0, function (Hj) {
                        var h = h;
                        var h = h;
                        {
                          !0x1 !== (!Hj["error"] && Hj["response"]) && HS && HS();
                        }
                      }));
                    }
                  }));
                }
              }, V8["prototype"]['ye'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = Hj ? Hj["payload"] : hd["EN_WALLET_LIST_ANIM"];
                  this['ce'] = !0x0, Vq["googleAnalyticCurrentScreen"] = HI["getCurrentScreen"](), HI["sendScreen"](HI["SCREEN_WALLET"]), this['ze'](0x1, this['de'], this['kt'], this['me'], this['be'], HL);
                }
              }, V8["prototype"]['Ae'] = function (Hj) {
                var h = h;
                var h = h;
                this['he'] && (this["context"]["event"]["emit"]("Game.BlockUI", !0x1), this['he'] = !0x1), this['ye'](), Hj && (Hj["response"] = {
                  'openWalletList': !0x0
                }, Hj["propagate"]());
              }, V8["prototype"]['Ne'] = function () {
                var h = h;
                var h = h;
                var Hj = VR["transactionInfo"],
                  HL = Hj["wbn"],
                  Va = Hj["wfg"];
                if (HL) {
                  var HS = (s1 = this['Le'] = new tv(HL))["status"],
                    Hj = s1["convertedGameID"],
                    Hc = s1["bonusWalletName"],
                    HA = s1["maximumConversionAmount"],
                    HX = s1["beforeConversionAmount"],
                    Hj = s1["conversionAmount"],
                    HT = s1["lockedGameID"],
                    H1 = s1["key"],
                    Hp = {
                      'title': HB['t']("BonusWallet.CashWallet"),
                      'handler': this['xe']
                    };
                  switch (HS) {
                    case 0x3:
                      if (Hj !== VR["gameID"]) hL({
                        'content_message': HB['t']("BonusWallet.CompletedDialog", {
                          'bonusTitle': Hc
                        }),
                        'actions': [Hp]
                      }), this['Ie']();else {
                        var Hl = io(HX),
                          Hg = io(HA),
                          HP = io(Hj),
                          s0 = HA > 0x0 && 0x0 !== HX ? HB['t']("BonusWallet.ConvertedToCashLimitDesc", {
                            'balance': Hl,
                            'withdrawal': Hg,
                            'amount': HP
                          }) : HB['t']("BonusWallet.ConvertedToCashDesc", {
                            'amount': HP
                          });
                        hL({
                          'title_message': HB['t']("BonusWallet.ConvertedToCashTitle"),
                          'content_message': s0,
                          'actions': [Hp]
                        }), this['Ie']();
                      }
                      break;
                    case 0x4:
                      hL({
                        'content_message': HB['t']("BonusWallet.InsufficientBalance"),
                        'actions': [Hp]
                      }), this['Ie']();
                      break;
                    case 0x7:
                      this['pe'](!0x0, HT, !0x1), this['Ie']();
                      break;
                    case 0x5:
                    case 0x1:
                      this['ae'] || this['oe'] ? this['ze'](0x3, this['de'], this['kt'], this['me'], this['be'], hd["EN_WALLET_LIST_ANIM"], s1) : this['we'](H1);
                  }
                } else if (Va) {
                  {
                    var s1,
                      s2 = (s1 = this['Le'] = new UC(Va))["status"],
                      s3 = s1["convertedID"],
                      s4 = s1["freeGameName"];
                    switch (HT = s1["lockedGameID"], H1 = s1["key"], Hp = {
                      'title': HB['t']("FreeGame.CashWallet"),
                      'handler': this['xe']
                    }, s2) {
                      case 0x3:
                      case 0x4:
                        (this['ae'] || this['oe']) && s3 !== VR["gameID"] ? (hL({
                          'content_message': HB['t']("FreeGame.CompletedDialog", {
                            'freeGameTitle': s4
                          }),
                          'actions': [Hp]
                        }), this['Ie']()) : this['ze'](0x5, this['de'], this['kt'], this['me'], this['be'], hd["EN_WALLET_LIST_ANIM"], s1);
                        break;
                      case 0x7:
                        this['pe'](!0x1, HT, !0x1), this['Ie']();
                        break;
                      case 0x5:
                      case 0x1:
                        this['ae'] || this['oe'] ? this['ze'](0x5, this['de'], this['kt'], this['me'], this['be'], hd["EN_WALLET_LIST_ANIM"], s1) : this['we'](H1);
                    }
                  }
                } else {
                  {
                    if (this['le']) {
                      var s5 = this["context"]["event"];
                      s5["emit"]("Loading.Hide"), s5["emit"]("Game.BlockUI", !0x1), this['le'] = !0x1;
                    }
                    this['Te']();
                  }
                }
                VQ["walletType"] = Hj['wt'], this['oe'] = !0x1;
              }, V8["prototype"]['_e'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  void 0x0 === Hj && (Hj = this['De']);
                  var HL = VR["transactionInfo"],
                    Va = HL["wbn"],
                    HS = HL["wfg"];
                  if (this['De'] = Hj, Va) {
                    {
                      var Hj = (HA = this['Le'] ? this['Le'] : new tv(Va))["status"],
                        Hc = {
                          'title': HB['t']("BonusWallet.CashWallet"),
                          'handler': this['xe']
                        };
                      switch (Hj) {
                        case 0x2:
                          this['ae'] ? this['ze'](0x3, this['de'], this['kt'], this['me'], this['be'], hd["EN_WALLET_LIST_ANIM"], HA) : (hL({
                            'title_message': HB['t']("BonusWallet.CurrentWalletExpired"),
                            'content_message': HB['t']("BonusWallet.AutoSwitchedToCash"),
                            'actions': [Hc]
                          }), this['Ie']());
                          break;
                        case 0x6:
                        case 0x0:
                          hL({
                            'title_message': HB['t']("BonusWallet.BonusWalletInvalid"),
                            'content_message': HB['t']("BonusWallet.BonusWalletInvalidDesc"),
                            'actions': [Hc]
                          }), this['Ie']();
                          break;
                        default:
                          this['ae'] || 0x5 !== Hj && 0x1 !== Hj || (Hj && Hj(), this['De'] = void 0x0);
                      }
                    }
                  } else if (HS) {
                    {
                      var HA,
                        HX = (HA = this['Le'] ? this['Le'] : new UC(HS))["status"];
                      switch (Hc = {
                        'title': HB['t']("FreeGame.CashWallet"),
                        'handler': this['xe']
                      }, HX) {
                        case 0x2:
                          this['ze'](0x5, this['de'], this['kt'], this['me'], this['be'], hd["EN_WALLET_LIST_ANIM"], HA);
                          break;
                        case 0x6:
                        case 0x0:
                          hL({
                            'title_message': HB['t']("FreeGame.FreeGameInvalid"),
                            'content_message': HB['t']("FreeGame.AutoSwitchedToCash"),
                            'actions': [Hc]
                          }), this['Ie']();
                          break;
                        default:
                          this['ae'] || 0x5 !== HX && 0x1 !== HX || (Hj && Hj(), this['De'] = void 0x0);
                      }
                    }
                  } else Hj && Hj(), this['De'] = void 0x0;
                  this['ae'] = !0x1, this['Le'] = void 0x0;
                }
              }, V8["prototype"]['Oe'] = function () {
                var h = h;
                var h = h;
                {
                  this['Ne'](), this['_e']();
                }
              }, V8["prototype"]['Re'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = this,
                    Va = VR["gameRawInfo"]['dt'],
                    HS = '';
                  Va["inwe"] || Hj ? HS = HB['t']("WalletHelper.NewWalletDesc") : Va["iuwe"] && (HS = HB['t']("WalletHelper.WalletReminderDesc")), hL({
                    'title_message': HB['t']("WalletHelper.WalletReminder"),
                    'content_message': HS,
                    'actions': [{
                      'title': HB['t']("WalletHelper.View"),
                      'handler': function () {
                        var h = h;
                        var h = h;
                        {
                          HL['Ae'](Hj);
                        }
                      }
                    }, {
                      'title': HB['t']("WalletHelper.NextTime"),
                      'handler': function () {
                        var h = h;
                        var h = h;
                        {
                          HL['he'] && (HL["context"]["event"]["emit"]("Game.BlockUI", !0x1), HL['he'] = !0x1), Hj && Hj["propagate"]();
                        }
                      }
                    }]
                  }), this['Ie']();
                }
              }, V8["prototype"]['Te'] = function (Hj) {
                var h = h;
                var h = h;
                if (Hj) return Hj["intercept"](), void this['Re'](Hj);
                var HL = VR["transactionInfo"],
                  Va = VR["gameRawInfo"]['dt'];
                if ((this['ae'] || this['oe']) && !HL["wfg"] && !HL["wbn"] && (Va["inwe"] || Va["iuwe"])) {
                  {
                    if (Va["inwe"]) {
                      {
                        var HS = this["context"]["event"];
                        HS["emit"]("Game.BonusWalletListOpened"), HS["emit"]("Game.FreeGameListOpened");
                      }
                    }
                    this['Re']();
                  }
                }
              }, V8["prototype"]['Ie'] = function () {
                var h = h;
                var h = h;
                this["context"]["event"]["emit"]("Game.BlockUI", !0x0), this['he'] = !0x0;
              }, V8["prototype"]['ze'] = function (Hj, HL, Va, HS, Hj, Hc, HA) {
                var h = h;
                var h = h;
                var HX = this,
                  Hj = this["context"],
                  HT = Hj["event"];
                HT["emit"]("Wallet.Shown"), HT["emit"]("Game.BlockUI", !0x0), Hj["view"]["appendTo"](V8, "overlay"), this["rootElement"]["style"]["visibility"] = "visible", x["render"](z["createElement"](H4, {
                  'context': Hj,
                  'onError': function () {
                    var h = h;
                    var h = h;
                    {
                      HX['ge'](!0x0);
                    }
                  }
                }, z["createElement"](H3, {
                  'initViewType': Hj,
                  'showLockedDialog': HL,
                  'dismissRootElementUI': Va,
                  'quitToGame': HS,
                  'changeWorld': Hj,
                  'walletListAnimState': Hc,
                  'initModel': HA
                })), this["rootElement"]);
              }, V8["prototype"]['pe'] = function (Hj, HL, Va) {
                var h = h;
                var h = h;
                {
                  var HS, Hj;
                  Va ? (HS = Hj ? "BonusWallet.BonusWalletLockedDesc" : "FreeGame.FreeGameLockedDesc", Hj = {
                    'title': Hj ? HB['t']("BonusWallet.Acknowledge") : HB['t']("FreeGame.Acknowledge"),
                    'handler': void 0x0
                  }) : (HS = Hj ? "BonusWallet.BonusWalletLockedInitDesc" : "FreeGame.FreeGameLockedInitDesc", Hj = {
                    'title': Hj ? HB['t']("BonusWallet.CashWallet") : HB['t']("FreeGame.CashWallet"),
                    'handler': this['xe']
                  }), hL({
                    'title_message': Hj ? HB['t']("BonusWallet.BonusWalletLockedTitle") : HB['t']("FreeGame.FreeGameLockedTitle"),
                    'content_message': HB['t'](HS, {
                      'gameName': Hb(HL)
                    }),
                    'actions': [Hj]
                  });
                }
              }, V8["prototype"]['Bt'] = function () {}, V8["prototype"]['ge'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = this["context"]["event"];
                  this['ce'] && (HI["sendScreen"](Vq["googleAnalyticCurrentScreen"]), this['ce'] = !0x1), HL["emit"]("Wallet.Hidden"), Hj && (HL["emit"]("Game.BlockUI", !0x1), this['De'] && this['De'](), this['De'] = void 0x0), this["rootElement"]["style"]["visibility"] = "hidden", x["unmountComponentAtNode"](this["rootElement"]), this["view"]["removeFromParent"](V8);
                }
              }, V8["prototype"]['Fe'] = function (Hj) {
                var h = h;
                var h = h;
                var HL = Hj["payload"];
                this['ve'](HL);
              }, V8["prototype"]['ve'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL = this;
                  HJ(function (Va) {
                    var h = h;
                    var h = h;
                    {
                      HL["context"]["event"]["emit"]("Loading.Show", {
                        'label': HB['t']("General.ResourceLoadingMessage"),
                        'enableBackground': !0x0,
                        'isFullBackground': !0x0,
                        'y': 0.5 * parseFloat(HL["rootElement"]["style"]["height"]),
                        'opacity': 0x1,
                        'inAnimate': "Fade",
                        'inDuration': 0.3,
                        'inValue': 0x0,
                        'outAnimate': "Fade",
                        'outValue': 0x0,
                        'outDuration': 0.3
                      }), HD(0.6)(Va);
                    }
                  }, function (Va) {
                    var h = h;
                    var h = h;
                    {
                      HL['Bt'](), HL['ge'](!0x1), Va();
                    }
                  })(function () {
                    var h = h;
                    var h = h;
                    {
                      var Va = Hj ? {
                        'wk': Hj
                      } : void 0x0;
                      HL["context"]["event"]["emit"]("Game.UpdateGameInfo", {
                        'param': Va
                      });
                    }
                  }), this['le'] = !0x0, this['ue'] = !0x1;
                }
              }, V8["prototype"]['we'] = function (Hj) {
                var h = h;
                var h = h;
                {
                  var HL,
                    Va = VR["transactionInfo"];
                  !Hj || Va['wk'] === Hj || 'C' === Va['wt'] && "0_C" === Hj ? (this['le'] && ((HL = this["context"]["event"])["emit"]("Loading.Hide"), HL["emit"]("Game.BlockUI", !0x1), this['le'] = !0x1), this['De'] && this['De'](), this['De'] = void 0x0, this['Te']()) : (this['he'] && ((HL = this["context"]["event"])["emit"]("Game.BlockUI", !0x1), this['he'] = !0x1), this["context"]["event"]["emit"]("Game.BlockUI", !0x0), this['ve'](Hj), this['oe'] = !0x1);
                }
              }, V8;
            }
          }(plugin["AbstractViewComponent"]);
          w("default", function (Hf) {
            var h = h;
            var h = h;
            function V8() {
              var h = h;
              var h = h;
              {
                return null !== Hf && Hf["apply"](this, arguments) || this;
              }
            }
            return V0(V8, Hf), V8["prototype"]["onCreate"] = function () {
              var h = h;
              var h = h;
              {
                this["context"]["component"]["create"](HK), Vq["context"] = this["context"], this["complete"]();
              }
            }, V2([plugin["PluginMainComponent"]("37fadb0591")], V8);
          }(plugin["AbstractPluginComponent"]));
        }
      };
    });
  }();
}();